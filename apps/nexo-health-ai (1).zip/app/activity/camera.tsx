import React from 'react';
import { CameraCalibrationScreen } from '../../src/screens/BodyAIScreen/CameraCalibrationScreen';
import { ExerciseType } from '../../src/types/bodyAI';
import { UserProfile } from '../../src/types';

export default function CameraRoute({
  exerciseType,
  userProfile,
  onBack,
  onCalibrationComplete,
}: {
  exerciseType: ExerciseType;
  userProfile: UserProfile;
  onBack: () => void;
  onCalibrationComplete: (stream: MediaStream | null) => void;
}) {
  return (
    <CameraCalibrationScreen
      exerciseType={exerciseType}
      userProfile={userProfile}
      onBack={onBack}
      onCalibrationComplete={onCalibrationComplete}
    />
  );
}
