import React from 'react';
import { ExerciseSelectScreen } from '../../src/screens/BodyAIScreen/ExerciseSelectScreen';
import { ExerciseType } from '../../src/types/bodyAI';
import { UserProfile } from '../../src/types';

export default function ExerciseSelectRoute({
  userProfile,
  onSelectExercise,
  onOpenTestSuite,
}: {
  userProfile: UserProfile;
  onSelectExercise: (type: ExerciseType) => void;
  onOpenTestSuite: () => void;
}) {
  return (
    <ExerciseSelectScreen
      userProfile={userProfile}
      onSelectExercise={onSelectExercise}
      onOpenTestSuite={onOpenTestSuite}
    />
  );
}
