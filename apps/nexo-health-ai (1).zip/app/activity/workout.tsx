import React from 'react';
import { LiveWorkoutScreen } from '../../src/screens/BodyAIScreen/LiveWorkoutScreen';
import { ExerciseType, WorkoutSessionSummary } from '../../src/types/bodyAI';
import { UserProfile } from '../../src/types';

export default function WorkoutRoute({
  exerciseType,
  mediaStream,
  userProfile,
  onFinishWorkout,
  onCancelWorkout,
}: {
  exerciseType: ExerciseType;
  mediaStream: MediaStream | null;
  userProfile: UserProfile;
  onFinishWorkout: (summary: WorkoutSessionSummary) => void;
  onCancelWorkout: () => void;
}) {
  return (
    <LiveWorkoutScreen
      exerciseType={exerciseType}
      mediaStream={mediaStream}
      userProfile={userProfile}
      onFinishWorkout={onFinishWorkout}
      onCancelWorkout={onCancelWorkout}
    />
  );
}
