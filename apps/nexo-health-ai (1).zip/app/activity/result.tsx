import React from 'react';
import { WorkoutResultScreen } from '../../src/screens/BodyAIScreen/WorkoutResultScreen';
import { WorkoutSessionSummary } from '../../src/types/bodyAI';
import { UserProfile } from '../../src/types';

export default function ResultRoute({
  summary,
  userProfile,
  onTryAgain,
  onSaveWorkout,
  onReturnToDashboard,
}: {
  summary: WorkoutSessionSummary;
  userProfile: UserProfile;
  onTryAgain: () => void;
  onSaveWorkout: (summary: WorkoutSessionSummary) => void;
  onReturnToDashboard: () => void;
}) {
  return (
    <WorkoutResultScreen
      summary={summary}
      userProfile={userProfile}
      onTryAgain={onTryAgain}
      onSaveWorkout={onSaveWorkout}
      onReturnToDashboard={onReturnToDashboard}
    />
  );
}
