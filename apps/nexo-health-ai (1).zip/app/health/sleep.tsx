import React from 'react';
import { useHealth } from '../../src/context/HealthContext';
import { useProfile } from '../../src/context/ProfileContext';
import { SleepCard } from '../../src/components/health/SleepCard';

export default function SleepRoute() {
  const { todayRecord, logSleep } = useHealth();
  const { userProfile } = useProfile();
  const isIndonesian = userProfile.language !== 'en';

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <SleepCard
        sleep={todayRecord.sleep}
        isIndonesian={isIndonesian}
        onSaveSleep={logSleep}
      />
    </div>
  );
}
