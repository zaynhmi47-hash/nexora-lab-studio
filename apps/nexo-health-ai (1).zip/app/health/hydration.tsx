import React from 'react';
import { useHealth } from '../../src/context/HealthContext';
import { useProfile } from '../../src/context/ProfileContext';
import { HydrationCard } from '../../src/components/health/HydrationCard';

export default function HydrationRoute() {
  const { todayRecord, addWater } = useHealth();
  const { userProfile } = useProfile();
  const isIndonesian = userProfile.language !== 'en';

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <HydrationCard
        hydration={todayRecord.hydration}
        isIndonesian={isIndonesian}
        onAddWater={addWater}
      />
    </div>
  );
}
