import React from 'react';
import { HealthScreen } from '../../src/screens/HealthScreen';

export default function HealthRoute() {
  return <HealthScreen />;
}
