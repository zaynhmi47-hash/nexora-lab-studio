import React from 'react';
import { useHealth } from '../../src/context/HealthContext';
import { useProfile } from '../../src/context/ProfileContext';
import { HealthTimeline } from '../../src/components/health/HealthTimeline';

export default function TimelineRoute() {
  const { events } = useHealth();
  const { userProfile } = useProfile();
  const isIndonesian = userProfile.language !== 'en';

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <HealthTimeline events={events} isIndonesian={isIndonesian} />
    </div>
  );
}
