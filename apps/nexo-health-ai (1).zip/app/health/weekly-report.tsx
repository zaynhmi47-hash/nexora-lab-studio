import React from 'react';
import { useHealth } from '../../src/context/HealthContext';
import { useProfile } from '../../src/context/ProfileContext';
import { WeeklyReport } from '../../src/components/health/WeeklyReport';

export default function WeeklyReportRoute() {
  const { weeklyReport, generateWeeklyAiReport, isGeneratingWeeklyReport } = useHealth();
  const { userProfile } = useProfile();
  const isIndonesian = userProfile.language !== 'en';

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto">
      <WeeklyReport
        report={weeklyReport}
        isIndonesian={isIndonesian}
        onAskAi={generateWeeklyAiReport}
        isGeneratingAi={isGeneratingWeeklyReport}
      />
    </div>
  );
}
