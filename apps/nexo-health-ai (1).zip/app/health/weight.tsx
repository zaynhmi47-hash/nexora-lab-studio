import React from 'react';
import { useHealth } from '../../src/context/HealthContext';
import { useProfile } from '../../src/context/ProfileContext';
import { WeightChart } from '../../src/components/health/WeightChart';

export default function WeightRoute() {
  const { weightHistory, todayRecord, logWeight } = useHealth();
  const { userProfile } = useProfile();
  const isIndonesian = userProfile.language !== 'en';

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      <WeightChart
        weights={weightHistory}
        currentWeight={todayRecord.weight}
        isIndonesian={isIndonesian}
        onLogWeight={logWeight}
      />
    </div>
  );
}
