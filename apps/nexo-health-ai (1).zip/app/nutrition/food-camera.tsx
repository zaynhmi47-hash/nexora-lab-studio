import React from 'react';
import { FoodAnalyzer } from '../../src/components/nutrition/FoodAnalyzer';
import { useNutrition } from '../../src/context/NutritionContext';
import { useProfile } from '../../src/context/ProfileContext';

export default function FoodCameraRoute() {
  const { addFood } = useNutrition();
  const { userProfile } = useProfile();

  return (
    <div className="min-h-screen bg-slate-950 p-4">
      <FoodAnalyzer
        isOpen={true}
        onClose={() => {}}
        onConfirmLog={(entries) => entries.forEach((e) => addFood(e))}
        userProfile={userProfile}
      />
    </div>
  );
}
