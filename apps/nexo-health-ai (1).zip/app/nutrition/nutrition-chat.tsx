import React from 'react';
import { NutritionChatView } from '../../src/screens/NutritionScreen/NutritionChatView';

export default function NutritionChatRoute() {
  return (
    <div className="min-h-screen bg-slate-950 p-4 sm:p-6 text-white max-w-4xl mx-auto">
      <NutritionChatView />
    </div>
  );
}
