import React from 'react';
import { AddFoodModal } from '../../src/screens/NutritionScreen/AddFoodModal';
import { useNutrition } from '../../src/context/NutritionContext';
import { useProfile } from '../../src/context/ProfileContext';

export default function AddFoodRoute() {
  const { addFood } = useNutrition();
  const { userProfile } = useProfile();

  return (
    <div className="min-h-screen bg-slate-950 p-4">
      <AddFoodModal
        isOpen={true}
        onClose={() => {}}
        onAddEntry={addFood}
        userProfile={userProfile}
      />
    </div>
  );
}
