import React from 'react';
import { NutritionScreen } from '../../src/screens/NutritionScreen';

export default function NutritionRoute() {
  return <NutritionScreen />;
}
