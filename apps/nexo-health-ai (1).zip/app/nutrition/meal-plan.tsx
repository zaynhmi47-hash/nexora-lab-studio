import React from 'react';
import { MealPlanView } from '../../src/screens/NutritionScreen/MealPlanView';

export default function MealPlanRoute() {
  return (
    <div className="min-h-screen bg-slate-950 p-4 sm:p-6 text-white max-w-5xl mx-auto">
      <MealPlanView />
    </div>
  );
}
