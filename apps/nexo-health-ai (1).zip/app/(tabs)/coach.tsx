import React from 'react';
import { CoachScreen } from '../../src/screens/CoachScreen';
import { ConversationProvider } from '../../src/context/ConversationContext';
import { ProfileProvider } from '../../src/context/ProfileContext';

/**
 * Expo Router Tab Entry: app/(tabs)/coach.tsx
 * Wraps the CoachScreen with ProfileProvider and ConversationProvider.
 */
export default function CoachTabRoute() {
  return (
    <ProfileProvider>
      <ConversationProvider>
        <CoachScreen />
      </ConversationProvider>
    </ProfileProvider>
  );
}
