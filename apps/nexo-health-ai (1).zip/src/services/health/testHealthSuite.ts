import { DailyHealthRecord, HealthEvent, WeightEntry } from '../../types/health';
import {
  calculateWellnessScore,
  calculateMetricTrend,
  calculateAllTrends,
  buildWeeklyReport,
  generateLocalHealthInsight,
  calculateHabitConsistency,
} from '../analytics';

export interface TestCaseResult {
  id: number;
  name: string;
  nameEn: string;
  description: string;
  passed: boolean;
  outputData: any;
  durationMs: number;
}

export interface TestSuiteSummary {
  total: number;
  passed: number;
  failed: number;
  allPassed: boolean;
  results: TestCaseResult[];
  executedAt: string;
}

export async function runHealthTestSuite(): Promise<TestSuiteSummary> {
  const results: TestCaseResult[] = [];

  // Helper to record result
  const runTest = (
    id: number,
    name: string,
    nameEn: string,
    description: string,
    testFn: () => { passed: boolean; outputData: any }
  ) => {
    const start = performance.now();
    try {
      const res = testFn();
      const end = performance.now();
      results.push({
        id,
        name,
        nameEn,
        description,
        passed: res.passed,
        outputData: res.outputData,
        durationMs: Math.round((end - start) * 100) / 100,
      });
    } catch (err: any) {
      results.push({
        id,
        name,
        nameEn,
        description,
        passed: false,
        outputData: { error: err.message || 'Test exception' },
        durationMs: 0,
      });
    }
  };

  // 1. Empty health data
  runTest(
    1,
    'Data Kesehatan Kosong (Empty Data)',
    'Empty Health Data',
    'Verifikasi perhitungan skor wellness dan tren saat data kosong tanpa melempar error atau NaN.',
    () => {
      const emptyRec: Partial<DailyHealthRecord> = { date: '2026-08-23' };
      const score = calculateWellnessScore(emptyRec);
      const trends = calculateAllTrends([]);
      const passed =
        typeof score.score === 'number' &&
        !isNaN(score.score) &&
        trends.every((t) => t.direction === 'insufficient_data');
      return { passed, outputData: { score: score.score, trendsCount: trends.length } };
    }
  );

  // 2. One day of data
  runTest(
    2,
    'Data Satu Hari (One Day of Data)',
    'One Day of Data',
    'Perhitungan metrik harian tunggal menghasilkan wellness score valid dan tren mendeteksi insufficient data (< 3 hari).',
    () => {
      const oneDay: DailyHealthRecord = {
        date: '2026-08-23',
        activity: { steps: 8500, stepsGoal: 8000, activeMinutes: 45, activeMinutesGoal: 45, distanceKm: 6.2, estimatedCaloriesBurned: 350 },
        sleep: { sleepDurationHours: 7.5, sleepGoalHours: 8, bedtime: '23:00', wakeTime: '06:30', sleepConsistencyScore: 85 },
        hydration: { waterIntakeMl: 2500, waterGoalMl: 2500, hydrationEntries: [] },
        nutrition: { caloriesConsumed: 2100, caloriesGoal: 2100, proteinG: 120, carbsG: 220, fatG: 60, loggedMealsCount: 3 },
        events: [],
      };
      const score = calculateWellnessScore(oneDay);
      const trend = calculateMetricTrend('steps', [oneDay]);
      const passed = score.score >= 80 && trend.direction === 'insufficient_data';
      return { passed, outputData: { score: score.score, trendDirection: trend.direction } };
    }
  );

  // 3. Seven days of data
  runTest(
    3,
    'Data Tujuh Hari Penuh (Seven Days of Data)',
    'Seven Days of Data',
    'Agregasi laporan mingguan 7 hari menghasilkan rata-rata, kepatuhan kebiasaan, dan wellness score delta yang valid.',
    () => {
      const sevenDays: DailyHealthRecord[] = [];
      for (let i = 6; i >= 0; i--) {
        sevenDays.push({
          date: `2026-08-${17 + i}`,
          activity: { steps: 8000 + i * 200, stepsGoal: 8000, activeMinutes: 40, activeMinutesGoal: 45, distanceKm: 6.0, estimatedCaloriesBurned: 320 },
          sleep: { sleepDurationHours: 7.5, sleepGoalHours: 8, bedtime: '23:00', wakeTime: '06:30', sleepConsistencyScore: 80 },
          hydration: { waterIntakeMl: 2400, waterGoalMl: 2500, hydrationEntries: [] },
          nutrition: { caloriesConsumed: 2000, caloriesGoal: 2000, proteinG: 110, carbsG: 200, fatG: 50, loggedMealsCount: 3 },
          events: [],
        });
      }
      const rep = buildWeeklyReport(sevenDays);
      const passed = rep.activity.averageDailySteps >= 8000 && rep.consistency.percentage >= 50;
      return { passed, outputData: { avgSteps: rep.activity.averageDailySteps, consistencyPct: rep.consistency.percentage } };
    }
  );

  // 4. Missing sleep data
  runTest(
    4,
    'Data Tidur Kosong (Missing Sleep Data)',
    'Missing Sleep Data',
    'Sistem tetap menghitung skor wellness dan memberikan fallback pesan tanpa crash saat data tidur 0 jam.',
    () => {
      const rec: DailyHealthRecord = {
        date: '2026-08-23',
        activity: { steps: 8000, stepsGoal: 8000, activeMinutes: 40, activeMinutesGoal: 45, distanceKm: 6.0, estimatedCaloriesBurned: 300 },
        sleep: { sleepDurationHours: 0, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 0 },
        hydration: { waterIntakeMl: 2500, waterGoalMl: 2500, hydrationEntries: [] },
        nutrition: { caloriesConsumed: 2000, caloriesGoal: 2000, proteinG: 100, carbsG: 200, fatG: 50, loggedMealsCount: 3 },
        events: [],
      };
      const score = calculateWellnessScore(rec);
      const passed = score.score > 0 && typeof score.components.sleep === 'number';
      return { passed, outputData: { score: score.score, sleepComponent: score.components.sleep } };
    }
  );

  // 5. Missing hydration data
  runTest(
    5,
    'Data Hidrasi Kosong (Missing Hydration Data)',
    'Missing Hydration Data',
    'Menangani 0 ml asupan air secara anggun dengan saran pemenuhan hidrasi terarah.',
    () => {
      const rec: DailyHealthRecord = {
        date: '2026-08-23',
        activity: { steps: 7000, stepsGoal: 8000, activeMinutes: 30, activeMinutesGoal: 45, distanceKm: 5.0, estimatedCaloriesBurned: 280 },
        sleep: { sleepDurationHours: 7.0, sleepGoalHours: 8, bedtime: '23:00', wakeTime: '06:00', sleepConsistencyScore: 75 },
        hydration: { waterIntakeMl: 0, waterGoalMl: 2500, hydrationEntries: [] },
        nutrition: { caloriesConsumed: 1900, caloriesGoal: 2000, proteinG: 95, carbsG: 210, fatG: 45, loggedMealsCount: 2 },
        events: [],
      };
      const score = calculateWellnessScore(rec);
      const insight = generateLocalHealthInsight(rec);
      const passed = score.components.hydration === 0 && insight.focusArea === 'hydration';
      return { passed, outputData: { hydrationScore: score.components.hydration, focusArea: insight.focusArea } };
    }
  );

  // 6. Missing nutrition data
  runTest(
    6,
    'Data Nutrisi Kosong (Missing Nutrition Data)',
    'Missing Nutrition Data',
    'Menghitung skor proporsional dan tidak menghasilkan NaN ketika 0 makanan dicatat.',
    () => {
      const rec: Partial<DailyHealthRecord> = {
        date: '2026-08-23',
        activity: { steps: 6000, stepsGoal: 8000, activeMinutes: 30, activeMinutesGoal: 45, distanceKm: 4.5, estimatedCaloriesBurned: 240 },
        sleep: { sleepDurationHours: 7.2, sleepGoalHours: 8, bedtime: '23:00', wakeTime: '06:12', sleepConsistencyScore: 80 },
        hydration: { waterIntakeMl: 2000, waterGoalMl: 2500, hydrationEntries: [] },
      };
      const score = calculateWellnessScore(rec);
      const passed = typeof score.components.nutrition === 'number' && !isNaN(score.score);
      return { passed, outputData: { nutritionScore: score.components.nutrition, totalScore: score.score } };
    }
  );

  // 7. Workout data from Body AI
  runTest(
    7,
    'Integrasi Data Latihan Body AI (Body AI Event)',
    'Body AI Workout Event',
    'Event latihan dari Body AI tercatat di timeline dan mengintegrasikan kalori/durasi ke aktivitas harian.',
    () => {
      const event: HealthEvent = {
        id: 'ev_body_ai_test',
        type: 'workout',
        timestamp: '17:00',
        date: '2026-08-23',
        title: 'Body AI Sesi Squats',
        description: '3 set x 12 reps',
        source: 'body_ai',
        metrics: { durationMinutes: 20, calories: 150, reps: 36, exerciseName: 'Squats' },
      };
      const passed = event.source === 'body_ai' && event.metrics?.reps === 36;
      return { passed, outputData: { eventTitle: event.title, reps: event.metrics?.reps } };
    }
  );

  // 8. Nutrition data from Nutrition AI
  runTest(
    8,
    'Integrasi Data Makanan Nutrition AI (Nutrition AI Event)',
    'Nutrition AI Meal Event',
    'Event makanan dari Nutrition AI menyimpan estimasi kalori dan makronutrisi ke histori event harian.',
    () => {
      const event: HealthEvent = {
        id: 'ev_nutrition_test',
        type: 'meal',
        timestamp: '12:30',
        date: '2026-08-23',
        title: 'Makan Siang Salmon Bowl',
        description: '520 kcal | 38g Protein',
        source: 'nutrition_ai',
        metrics: { calories: 520, proteinG: 38, carbsG: 48, fatG: 14 },
      };
      const passed = event.source === 'nutrition_ai' && event.metrics?.calories === 520;
      return { passed, outputData: { eventTitle: event.title, calories: event.metrics?.calories } };
    }
  );

  // 9. Wellness score calculation
  runTest(
    9,
    'Validasi Komputasi Wellness Score (Wellness Formula)',
    'Wellness Score Calculation',
    'Memastikan skor wellness terikat ketat antara 0 dan 100 serta memiliki status dan disclaimer non-medis.',
    () => {
      const optimalRec: DailyHealthRecord = {
        date: '2026-08-23',
        activity: { steps: 10000, stepsGoal: 8000, activeMinutes: 55, activeMinutesGoal: 45, distanceKm: 7.5, estimatedCaloriesBurned: 420 },
        sleep: { sleepDurationHours: 8.0, sleepGoalHours: 8, bedtime: '22:30', wakeTime: '06:30', sleepConsistencyScore: 92 },
        hydration: { waterIntakeMl: 2800, waterGoalMl: 2500, hydrationEntries: [] },
        nutrition: { caloriesConsumed: 2150, caloriesGoal: 2100, proteinG: 135, carbsG: 225, fatG: 62, loggedMealsCount: 3 },
        events: [
          { id: '1', type: 'workout', timestamp: '08:00', date: '2026-08-23', title: 'Latihan', description: '', source: 'body_ai' },
          { id: '2', type: 'meal', timestamp: '12:00', date: '2026-08-23', title: 'Makan', description: '', source: 'nutrition_ai' },
        ],
      };
      const score = calculateWellnessScore(optimalRec);
      const passed = score.score >= 85 && score.status === 'optimal' && !!score.educationalDisclaimer;
      return { passed, outputData: { score: score.score, status: score.status } };
    }
  );

  // 10. Improving trend
  runTest(
    10,
    'Deteksi Tren Meningkat (Improving Trend)',
    'Improving Trend Detection',
    'Mendeteksi kenaikan langkah aktif secara tepat dengan arah "improving" dan persentase positif.',
    () => {
      const records: DailyHealthRecord[] = [
        { date: '2026-08-18', activity: { steps: 4000, stepsGoal: 8000, activeMinutes: 20, activeMinutesGoal: 45, distanceKm: 3, estimatedCaloriesBurned: 150 }, sleep: { sleepDurationHours: 7, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 70 }, hydration: { waterIntakeMl: 1500, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 1800, caloriesGoal: 2000, proteinG: 80, carbsG: 200, fatG: 50, loggedMealsCount: 2 }, events: [] },
        { date: '2026-08-19', activity: { steps: 4200, stepsGoal: 8000, activeMinutes: 20, activeMinutesGoal: 45, distanceKm: 3.1, estimatedCaloriesBurned: 160 }, sleep: { sleepDurationHours: 7, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 70 }, hydration: { waterIntakeMl: 1600, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 1850, caloriesGoal: 2000, proteinG: 85, carbsG: 200, fatG: 50, loggedMealsCount: 2 }, events: [] },
        { date: '2026-08-20', activity: { steps: 8500, stepsGoal: 8000, activeMinutes: 45, activeMinutesGoal: 45, distanceKm: 6.4, estimatedCaloriesBurned: 350 }, sleep: { sleepDurationHours: 8, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 85 }, hydration: { waterIntakeMl: 2500, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 2050, caloriesGoal: 2000, proteinG: 120, carbsG: 200, fatG: 50, loggedMealsCount: 3 }, events: [] },
        { date: '2026-08-21', activity: { steps: 9000, stepsGoal: 8000, activeMinutes: 50, activeMinutesGoal: 45, distanceKm: 6.8, estimatedCaloriesBurned: 380 }, sleep: { sleepDurationHours: 8, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 85 }, hydration: { waterIntakeMl: 2600, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 2100, caloriesGoal: 2000, proteinG: 125, carbsG: 200, fatG: 50, loggedMealsCount: 3 }, events: [] },
      ];
      const trend = calculateMetricTrend('steps', records);
      const passed = trend.direction === 'improving' && (trend.percentageChange || 0) > 0;
      return { passed, outputData: { direction: trend.direction, change: trend.percentageChange } };
    }
  );

  // 11. Stable trend
  runTest(
    11,
    'Deteksi Tren Stabil (Stable Trend)',
    'Stable Trend Detection',
    'Perubahan metrik di bawah ambang batas delta (e.g. < 4%) teridentifikasi sebagai "stable".',
    () => {
      const records: DailyHealthRecord[] = [
        { date: '2026-08-18', activity: { steps: 8000, stepsGoal: 8000, activeMinutes: 40, activeMinutesGoal: 45, distanceKm: 6, estimatedCaloriesBurned: 320 }, sleep: { sleepDurationHours: 7.5, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 80 }, hydration: { waterIntakeMl: 2400, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 2000, caloriesGoal: 2000, proteinG: 110, carbsG: 200, fatG: 50, loggedMealsCount: 3 }, events: [] },
        { date: '2026-08-19', activity: { steps: 8100, stepsGoal: 8000, activeMinutes: 40, activeMinutesGoal: 45, distanceKm: 6.1, estimatedCaloriesBurned: 325 }, sleep: { sleepDurationHours: 7.5, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 80 }, hydration: { waterIntakeMl: 2450, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 2000, caloriesGoal: 2000, proteinG: 110, carbsG: 200, fatG: 50, loggedMealsCount: 3 }, events: [] },
        { date: '2026-08-20', activity: { steps: 8050, stepsGoal: 8000, activeMinutes: 40, activeMinutesGoal: 45, distanceKm: 6.0, estimatedCaloriesBurned: 322 }, sleep: { sleepDurationHours: 7.5, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 80 }, hydration: { waterIntakeMl: 2420, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 2000, caloriesGoal: 2000, proteinG: 110, carbsG: 200, fatG: 50, loggedMealsCount: 3 }, events: [] },
        { date: '2026-08-21', activity: { steps: 8080, stepsGoal: 8000, activeMinutes: 40, activeMinutesGoal: 45, distanceKm: 6.0, estimatedCaloriesBurned: 323 }, sleep: { sleepDurationHours: 7.5, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 80 }, hydration: { waterIntakeMl: 2440, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 2000, caloriesGoal: 2000, proteinG: 110, carbsG: 200, fatG: 50, loggedMealsCount: 3 }, events: [] },
      ];
      const trend = calculateMetricTrend('steps', records);
      const passed = trend.direction === 'stable';
      return { passed, outputData: { direction: trend.direction, change: trend.percentageChange } };
    }
  );

  // 12. Declining trend
  runTest(
    12,
    'Deteksi Tren Menurun (Declining Trend)',
    'Declining Trend Detection',
    'Mendeteksi penurunan rata-rata durasi tidur dengan status "declining" dan pesan konstruktif.',
    () => {
      const records: DailyHealthRecord[] = [
        { date: '2026-08-18', activity: { steps: 8000, stepsGoal: 8000, activeMinutes: 40, activeMinutesGoal: 45, distanceKm: 6, estimatedCaloriesBurned: 320 }, sleep: { sleepDurationHours: 8.5, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 90 }, hydration: { waterIntakeMl: 2500, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 2000, caloriesGoal: 2000, proteinG: 110, carbsG: 200, fatG: 50, loggedMealsCount: 3 }, events: [] },
        { date: '2026-08-19', activity: { steps: 8000, stepsGoal: 8000, activeMinutes: 40, activeMinutesGoal: 45, distanceKm: 6, estimatedCaloriesBurned: 320 }, sleep: { sleepDurationHours: 8.0, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 85 }, hydration: { waterIntakeMl: 2500, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 2000, caloriesGoal: 2000, proteinG: 110, carbsG: 200, fatG: 50, loggedMealsCount: 3 }, events: [] },
        { date: '2026-08-20', activity: { steps: 7000, stepsGoal: 8000, activeMinutes: 30, activeMinutesGoal: 45, distanceKm: 5, estimatedCaloriesBurned: 280 }, sleep: { sleepDurationHours: 5.5, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 65 }, hydration: { waterIntakeMl: 2000, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 1900, caloriesGoal: 2000, proteinG: 90, carbsG: 200, fatG: 50, loggedMealsCount: 2 }, events: [] },
        { date: '2026-08-21', activity: { steps: 6500, stepsGoal: 8000, activeMinutes: 25, activeMinutesGoal: 45, distanceKm: 4.8, estimatedCaloriesBurned: 260 }, sleep: { sleepDurationHours: 5.2, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 60 }, hydration: { waterIntakeMl: 1800, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 1800, caloriesGoal: 2000, proteinG: 85, carbsG: 200, fatG: 50, loggedMealsCount: 2 }, events: [] },
      ];
      const trend = calculateMetricTrend('sleep', records);
      const passed = trend.direction === 'declining';
      return { passed, outputData: { direction: trend.direction, change: trend.percentageChange } };
    }
  );

  // 13. Insufficient data
  runTest(
    13,
    'Penanganan Data Tidak Cukup (Insufficient Data)',
    'Insufficient Data Handling',
    'Menampilkan indikator "Belum cukup data riwayat" saat histori data < 3 hari.',
    () => {
      const records: DailyHealthRecord[] = [
        { date: '2026-08-22', activity: { steps: 8000, stepsGoal: 8000, activeMinutes: 40, activeMinutesGoal: 45, distanceKm: 6, estimatedCaloriesBurned: 320 }, sleep: { sleepDurationHours: 7.5, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 80 }, hydration: { waterIntakeMl: 2400, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 2000, caloriesGoal: 2000, proteinG: 110, carbsG: 200, fatG: 50, loggedMealsCount: 3 }, events: [] },
        { date: '2026-08-23', activity: { steps: 8500, stepsGoal: 8000, activeMinutes: 45, activeMinutesGoal: 45, distanceKm: 6.3, estimatedCaloriesBurned: 340 }, sleep: { sleepDurationHours: 7.8, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 85 }, hydration: { waterIntakeMl: 2500, waterGoalMl: 2500, hydrationEntries: [] }, nutrition: { caloriesConsumed: 2050, caloriesGoal: 2000, proteinG: 115, carbsG: 200, fatG: 50, loggedMealsCount: 3 }, events: [] },
      ];
      const trend = calculateMetricTrend('steps', records);
      const passed = trend.direction === 'insufficient_data' && !trend.hasSufficientData;
      return { passed, outputData: { direction: trend.direction, desc: trend.description } };
    }
  );

  // 14. Weekly AI insight
  runTest(
    14,
    'Penyusunan Insight Mingguan Terstruktur (Structured Weekly Insight)',
    'Structured Weekly Insight',
    'Laporan mingguan menghasilkan struktur insight dengan poin positif, saran konstruktif, dan fokus kebiasaan.',
    () => {
      const records: DailyHealthRecord[] = [];
      for (let i = 6; i >= 0; i--) {
        records.push({
          date: `2026-08-${17 + i}`,
          activity: { steps: 8000, stepsGoal: 8000, activeMinutes: 35, activeMinutesGoal: 45, distanceKm: 6, estimatedCaloriesBurned: 310 },
          sleep: { sleepDurationHours: 7.5, sleepGoalHours: 8, bedtime: '', wakeTime: '', sleepConsistencyScore: 80 },
          hydration: { waterIntakeMl: 2400, waterGoalMl: 2500, hydrationEntries: [] },
          nutrition: { caloriesConsumed: 2000, caloriesGoal: 2000, proteinG: 110, carbsG: 200, fatG: 50, loggedMealsCount: 3 },
          events: [],
        });
      }
      const rep = buildWeeklyReport(records);
      const insight = rep.aiInsight;
      const passed =
        !!insight &&
        insight.positiveAreas.length > 0 &&
        insight.suggestions.length > 0 &&
        !!insight.focusArea;
      return { passed, outputData: { headline: insight?.headline, positiveCount: insight?.positiveAreas.length } };
    }
  );

  // 15. Gemini failure / fallback
  runTest(
    15,
    'Fallback Deterministik Saat AI Offline (Gemini Failure Fallback)',
    'Gemini Offline Deterministic Fallback',
    'Menghasilkan insight kesehatan yang informatif dan aman menggunakan generator lokal saat endpoint Gemini tidak tersedia.',
    () => {
      const rec: DailyHealthRecord = {
        date: '2026-08-23',
        activity: { steps: 8200, stepsGoal: 8000, activeMinutes: 40, activeMinutesGoal: 45, distanceKm: 6.1, estimatedCaloriesBurned: 325 },
        sleep: { sleepDurationHours: 7.5, sleepGoalHours: 8, bedtime: '23:00', wakeTime: '06:30', sleepConsistencyScore: 84 },
        hydration: { waterIntakeMl: 2600, waterGoalMl: 2500, hydrationEntries: [] },
        nutrition: { caloriesConsumed: 2050, caloriesGoal: 2100, proteinG: 120, carbsG: 210, fatG: 55, loggedMealsCount: 3 },
        events: [],
      };
      rec.wellnessScore = calculateWellnessScore(rec);
      const fallbackInsight = generateLocalHealthInsight(rec);
      const passed =
        fallbackInsight.isAiGenerated === false &&
        fallbackInsight.positiveAreas.length > 0 &&
        !!fallbackInsight.headline;
      return { passed, outputData: { headline: fallbackInsight.headline, isAiGenerated: fallbackInsight.isAiGenerated } };
    }
  );

  const passedCount = results.filter((r) => r.passed).length;
  const failedCount = results.length - passedCount;

  return {
    total: results.length,
    passed: passedCount,
    failed: failedCount,
    allPassed: failedCount === 0,
    results,
    executedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
  };
}
