import {
  DailyHealthRecord,
  HealthEvent,
  WeightEntry,
  WellnessScore,
} from '../../types/health';
import { calculateWellnessScore } from '../analytics/wellnessEngine';

export interface IHealthRepository {
  getDailyRecord(date: string): Promise<DailyHealthRecord | null>;
  saveHealthRecord(record: DailyHealthRecord): Promise<void>;
  getRecords(startDate?: string, endDate?: string): Promise<DailyHealthRecord[]>;
  deleteRecord(date: string): Promise<void>;
  addHealthEvent(event: HealthEvent): Promise<void>;
  getEvents(date?: string): Promise<HealthEvent[]>;
  getWeightHistory(): Promise<WeightEntry[]>;
  saveWeightEntry(entry: WeightEntry): Promise<void>;
}

const STORAGE_KEY_RECORDS = 'health_ai_daily_records_v1';
const STORAGE_KEY_WEIGHTS = 'health_ai_weight_history_v1';

/**
 * Generates realistic seed data for the past 14 days.
 */
function generateSeedRecords(): { records: DailyHealthRecord[]; weights: WeightEntry[] } {
  const records: DailyHealthRecord[] = [];
  const weights: WeightEntry[] = [];
  const now = new Date();

  const baseWeight = 72.5;

  for (let i = 13; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    const dateStr = d.toISOString().split('T')[0];

    // Slight realistic variations
    const steps = 7500 + Math.floor(Math.sin(i * 1.5) * 2200);
    const activeMinutes = 35 + Math.floor(Math.cos(i) * 20);
    const sleepDuration = Number((7.2 + Math.sin(i * 0.8) * 0.9).toFixed(1));
    const waterIntake = 2200 + Math.floor(Math.cos(i * 0.9) * 600);
    const calories = 2050 + Math.floor(Math.sin(i * 0.5) * 250);
    const weightVal = Number((baseWeight - (13 - i) * 0.08 + Math.sin(i) * 0.2).toFixed(1));

    const events: HealthEvent[] = [
      {
        id: `ev_${dateStr}_sleep`,
        type: 'sleep',
        timestamp: '07:00',
        date: dateStr,
        title: 'Tidur Malam Terjadwal',
        description: `Waktu istirahat ${sleepDuration} jam (Efisiensi 88%)`,
        source: 'manual',
        metrics: { durationMinutes: Math.round(sleepDuration * 60) },
      },
      {
        id: `ev_${dateStr}_bfast`,
        type: 'meal',
        timestamp: '08:15',
        date: dateStr,
        title: 'Sarapan Sehat: Oatmeal & Buah Segar',
        description: '380 kcal | Protein 18g | Karbo 52g',
        source: 'nutrition_ai',
        metrics: { calories: 380, proteinG: 18, carbsG: 52, fatG: 8 },
      },
      {
        id: `ev_${dateStr}_water1`,
        type: 'water',
        timestamp: '10:30',
        date: dateStr,
        title: 'Hidrasi Pagi',
        description: 'Konsumsi 500 ml air putih',
        source: 'manual',
        metrics: { volumeMl: 500 },
      },
      {
        id: `ev_${dateStr}_lunch`,
        type: 'meal',
        timestamp: '12:45',
        date: dateStr,
        title: 'Makan Siang: Nasi Merah, Ayam Panggang & Sayur',
        description: '620 kcal | Protein 42g | Karbo 65g',
        source: 'nutrition_ai',
        metrics: { calories: 620, proteinG: 42, carbsG: 65, fatG: 16 },
      },
    ];

    if (i % 2 === 0) {
      events.push({
        id: `ev_${dateStr}_workout`,
        type: 'workout',
        timestamp: '17:30',
        date: dateStr,
        title: 'Body AI Sesi Latihan: Squat & Core Stability',
        description: '25 mnt | 3 set x 12 reps | Akurasi Pose 94%',
        source: 'body_ai',
        metrics: { durationMinutes: 25, calories: 195, reps: 36, exerciseName: 'Squats' },
      });
    }

    const dayRecord: DailyHealthRecord = {
      date: dateStr,
      activity: {
        steps,
        stepsGoal: 8000,
        activeMinutes,
        activeMinutesGoal: 45,
        distanceKm: Number(((steps * 0.75) / 1000).toFixed(2)),
        estimatedCaloriesBurned: Math.round(steps * 0.04 + activeMinutes * 5),
      },
      sleep: {
        sleepDurationHours: sleepDuration,
        sleepGoalHours: 8.0,
        bedtime: '23:15',
        wakeTime: '06:45',
        sleepConsistencyScore: 82,
        qualityRating: sleepDuration >= 7 ? 'good' : 'fair',
      },
      hydration: {
        waterIntakeMl: waterIntake,
        waterGoalMl: 2500,
        hydrationEntries: [
          { id: `hyd_${dateStr}_1`, timestamp: '08:00', amountMl: 350 },
          { id: `hyd_${dateStr}_2`, timestamp: '11:00', amountMl: 500 },
          { id: `hyd_${dateStr}_3`, timestamp: '14:30', amountMl: 650 },
          { id: `hyd_${dateStr}_4`, timestamp: '19:00', amountMl: 700 },
        ],
      },
      nutrition: {
        caloriesConsumed: calories,
        caloriesGoal: 2100,
        proteinG: 125,
        carbsG: 220,
        fatG: 58,
        loggedMealsCount: 3,
      },
      weight: weightVal,
      events,
    };

    dayRecord.wellnessScore = calculateWellnessScore(dayRecord);
    records.push(dayRecord);

    if (i % 3 === 0 || i === 0) {
      weights.push({
        id: `w_${dateStr}`,
        date: dateStr,
        timestamp: `${dateStr}T07:15:00`,
        weightKg: weightVal,
        bodyFatPercentage: 18.2,
        trend: 'improving',
      });
    }
  }

  return { records, weights };
}

/**
 * Local-First Mock Health Repository.
 * Abstracted so switching to ApiHealthRepository requires zero UI changes.
 */
export class MockHealthRepository implements IHealthRepository {
  private recordsCache: Map<string, DailyHealthRecord> = new Map();
  private weightHistoryCache: WeightEntry[] = [];
  private isInitialized = false;

  private init() {
    if (this.isInitialized) return;

    try {
      const storedRecords = localStorage.getItem(STORAGE_KEY_RECORDS);
      const storedWeights = localStorage.getItem(STORAGE_KEY_WEIGHTS);

      if (storedRecords && storedWeights) {
        const parsedRecs: DailyHealthRecord[] = JSON.parse(storedRecords);
        parsedRecs.forEach((r) => this.recordsCache.set(r.date, r));
        this.weightHistoryCache = JSON.parse(storedWeights);
      } else {
        const { records, weights } = generateSeedRecords();
        records.forEach((r) => this.recordsCache.set(r.date, r));
        this.weightHistoryCache = weights;
        this.persist();
      }
    } catch (e) {
      const { records, weights } = generateSeedRecords();
      records.forEach((r) => this.recordsCache.set(r.date, r));
      this.weightHistoryCache = weights;
    }

    this.isInitialized = true;
  }

  private persist() {
    try {
      const recs = Array.from(this.recordsCache.values());
      localStorage.setItem(STORAGE_KEY_RECORDS, JSON.stringify(recs));
      localStorage.setItem(STORAGE_KEY_WEIGHTS, JSON.stringify(this.weightHistoryCache));
    } catch (e) {
      console.warn('Local storage persistence error:', e);
    }
  }

  public async getDailyRecord(date: string): Promise<DailyHealthRecord | null> {
    this.init();
    return this.recordsCache.get(date) || null;
  }

  public async saveHealthRecord(record: DailyHealthRecord): Promise<void> {
    this.init();
    // Always recompute wellness score safely before persisting
    record.wellnessScore = calculateWellnessScore(record);
    this.recordsCache.set(record.date, record);
    this.persist();
  }

  public async getRecords(startDate?: string, endDate?: string): Promise<DailyHealthRecord[]> {
    this.init();
    let list = Array.from(this.recordsCache.values());
    list.sort((a, b) => a.date.localeCompare(b.date));

    if (startDate) list = list.filter((r) => r.date >= startDate);
    if (endDate) list = list.filter((r) => r.date <= endDate);

    return list;
  }

  public async deleteRecord(date: string): Promise<void> {
    this.init();
    this.recordsCache.delete(date);
    this.persist();
  }

  public async addHealthEvent(event: HealthEvent): Promise<void> {
    this.init();
    const date = event.date;
    let rec = this.recordsCache.get(date);

    if (!rec) {
      rec = {
        date,
        activity: { steps: 0, stepsGoal: 8000, activeMinutes: 0, activeMinutesGoal: 45, distanceKm: 0, estimatedCaloriesBurned: 0 },
        sleep: { sleepDurationHours: 0, sleepGoalHours: 8, bedtime: '23:00', wakeTime: '07:00', sleepConsistencyScore: 75 },
        hydration: { waterIntakeMl: 0, waterGoalMl: 2500, hydrationEntries: [] },
        nutrition: { caloriesConsumed: 0, caloriesGoal: 2000, proteinG: 0, carbsG: 0, fatG: 0, loggedMealsCount: 0 },
        events: [],
      };
    }

    rec.events = [event, ...rec.events.filter((e) => e.id !== event.id)];

    // If event has metric impact, integrate with daily summary
    if (event.type === 'water' && event.metrics?.volumeMl) {
      rec.hydration.waterIntakeMl += event.metrics.volumeMl;
      rec.hydration.hydrationEntries.push({
        id: event.id,
        timestamp: event.timestamp,
        amountMl: event.metrics.volumeMl,
      });
    } else if (event.type === 'workout') {
      rec.activity.activeMinutes += event.metrics?.durationMinutes || 20;
      rec.activity.estimatedCaloriesBurned += event.metrics?.calories || 150;
    }

    rec.wellnessScore = calculateWellnessScore(rec);
    this.recordsCache.set(date, rec);
    this.persist();
  }

  public async getEvents(date?: string): Promise<HealthEvent[]> {
    this.init();
    if (date) {
      const rec = this.recordsCache.get(date);
      return rec ? rec.events : [];
    }

    const allEvents: HealthEvent[] = [];
    this.recordsCache.forEach((rec) => {
      allEvents.push(...rec.events);
    });
    allEvents.sort((a, b) => b.date.localeCompare(a.date) || b.timestamp.localeCompare(a.timestamp));
    return allEvents;
  }

  public async getWeightHistory(): Promise<WeightEntry[]> {
    this.init();
    return [...this.weightHistoryCache].sort((a, b) => a.date.localeCompare(b.date));
  }

  public async saveWeightEntry(entry: WeightEntry): Promise<void> {
    this.init();
    this.weightHistoryCache = this.weightHistoryCache.filter((w) => w.date !== entry.date);
    this.weightHistoryCache.push(entry);
    this.weightHistoryCache.sort((a, b) => a.date.localeCompare(b.date));

    // Also update day record weight if exists
    const rec = this.recordsCache.get(entry.date);
    if (rec) {
      rec.weight = entry.weightKg;
      this.recordsCache.set(entry.date, rec);
    }

    this.persist();
  }

  public resetAllData(): void {
    localStorage.removeItem(STORAGE_KEY_RECORDS);
    localStorage.removeItem(STORAGE_KEY_WEIGHTS);
    this.recordsCache.clear();
    this.weightHistoryCache = [];
    this.isInitialized = false;
    this.init();
  }
}

// Global Singleton instance
export const healthRepository = new MockHealthRepository();
