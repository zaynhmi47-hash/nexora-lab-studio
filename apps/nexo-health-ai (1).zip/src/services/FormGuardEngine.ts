import {
  FormGuardExerciseId,
  FormGuardExerciseConfig,
  BiomechanicalFrameState,
  LandmarkPoint,
  BodyPartHeatmapData,
  FormGuardPostSetReport,
} from '../types';
import { FORM_GUARD_EXERCISES } from '../data/formGuardExercises';

// Calculate angle in degrees between three points: A (first), B (vertex/joint), C (third)
export function calculateJointAngle(
  pointA: { x: number; y: number },
  pointB: { x: number; y: number },
  pointC: { x: number; y: number }
): number {
  const radians =
    Math.atan2(pointC.y - pointB.y, pointC.x - pointB.x) -
    Math.atan2(pointA.y - pointB.y, pointA.x - pointB.x);
  let angle = Math.abs((radians * 180.0) / Math.PI);
  if (angle > 180.0) {
    angle = 360.0 - angle;
  }
  return Math.round(angle);
}

// Generate realistic simulated skeleton landmarks based on exercise and motion progress (0.0 to 1.0)
export function generateSimulatedLandmarks(
  exerciseId: FormGuardExerciseId,
  cycleProgress: number, // 0 to 1 (sine-wave rep cycle)
  introduceError: boolean = false,
  errorType: string = 'none'
): Record<string, LandmarkPoint> {
  const sinVal = Math.sin(cycleProgress * Math.PI * 2);
  const normalizedPhase = (sinVal + 1) / 2; // 0 to 1

  // Default neutral standing skeleton
  const base: Record<string, LandmarkPoint> = {
    nose: { x: 0.5, y: 0.18, name: 'Nose' },
    left_shoulder: { x: 0.44, y: 0.28, name: 'Left Shoulder' },
    right_shoulder: { x: 0.56, y: 0.28, name: 'Right Shoulder' },
    left_elbow: { x: 0.38, y: 0.42, name: 'Left Elbow' },
    right_elbow: { x: 0.62, y: 0.42, name: 'Right Elbow' },
    left_wrist: { x: 0.36, y: 0.56, name: 'Left Wrist' },
    right_wrist: { x: 0.64, y: 0.56, name: 'Right Wrist' },
    left_hip: { x: 0.46, y: 0.54, name: 'Left Hip' },
    right_hip: { x: 0.54, y: 0.54, name: 'Right Hip' },
    left_knee: { x: 0.45, y: 0.74, name: 'Left Knee' },
    right_knee: { x: 0.55, y: 0.74, name: 'Right Knee' },
    left_ankle: { x: 0.45, y: 0.92, name: 'Left Ankle' },
    right_ankle: { x: 0.55, y: 0.92, name: 'Right Ankle' },
    left_heel: { x: 0.44, y: 0.94, name: 'Left Heel' },
    right_heel: { x: 0.56, y: 0.94, name: 'Right Heel' },
  };

  if (exerciseId === 'barbell_squat') {
    // Squat: Hips go down & back, knees bend forward/outward, torso inclines
    const depth = normalizedPhase * 0.22;
    base.nose.y = 0.18 + depth * 0.8;
    base.left_shoulder.y = 0.28 + depth * 0.8;
    base.right_shoulder.y = 0.28 + depth * 0.8;
    base.left_hip.y = 0.54 + depth;
    base.left_hip.x = 0.46 - normalizedPhase * 0.04; // hip goes back
    base.right_hip.y = 0.54 + depth;
    base.right_hip.x = 0.54 - normalizedPhase * 0.04;

    // Knees bend
    base.left_knee.y = 0.74 + depth * 0.2;
    base.right_knee.y = 0.74 + depth * 0.2;

    if (introduceError && (errorType === 'valgus' || errorType === 'all')) {
      // Valgus collapse (knees caving inward)
      base.left_knee.x = 0.45 + normalizedPhase * 0.05;
      base.right_knee.x = 0.55 - normalizedPhase * 0.05;
    } else {
      base.left_knee.x = 0.45 - normalizedPhase * 0.02;
      base.right_knee.x = 0.55 + normalizedPhase * 0.02;
    }

    if (introduceError && (errorType === 'lumbar_flexion' || errorType === 'all')) {
      // Butt wink / excessive forward lean
      base.left_shoulder.x = 0.44 - normalizedPhase * 0.08;
      base.right_shoulder.x = 0.56 - normalizedPhase * 0.08;
      base.nose.x = 0.5 - normalizedPhase * 0.09;
    }
  } else if (exerciseId === 'push_up') {
    // Horizontal layout for push-up
    const pushDepth = normalizedPhase * 0.15;
    base.nose = { x: 0.26, y: 0.45 + pushDepth, name: 'Nose' };
    base.left_shoulder = { x: 0.32, y: 0.48 + pushDepth, name: 'Left Shoulder' };
    base.right_shoulder = { x: 0.34, y: 0.44 + pushDepth, name: 'Right Shoulder' };

    base.left_wrist = { x: 0.32, y: 0.78, name: 'Left Wrist' };
    base.right_wrist = { x: 0.34, y: 0.74, name: 'Right Wrist' };

    // Elbow flare simulation
    if (introduceError && (errorType === 'elbow_flare' || errorType === 'sari_case' || errorType === 'all')) {
      // Elbow flaring out wide (T-shape)
      base.left_elbow = { x: 0.22, y: 0.62 + pushDepth * 0.5, name: 'Left Elbow' };
      base.right_elbow = { x: 0.28, y: 0.58 + pushDepth * 0.5, name: 'Right Elbow' };
    } else {
      // Proper 45-degree arrow tuck
      base.left_elbow = { x: 0.36, y: 0.64 + pushDepth * 0.5, name: 'Left Elbow' };
      base.right_elbow = { x: 0.38, y: 0.60 + pushDepth * 0.5, name: 'Right Elbow' };
    }

    // Core & hips
    if (introduceError && (errorType === 'hip_sag' || errorType === 'all')) {
      base.left_hip = { x: 0.54, y: 0.58 + pushDepth * 0.9, name: 'Left Hip' };
      base.right_hip = { x: 0.56, y: 0.56 + pushDepth * 0.9, name: 'Right Hip' };
    } else {
      base.left_hip = { x: 0.54, y: 0.52 + pushDepth * 0.6, name: 'Left Hip' };
      base.right_hip = { x: 0.56, y: 0.50 + pushDepth * 0.6, name: 'Right Hip' };
    }

    base.left_knee = { x: 0.68, y: 0.56 + pushDepth * 0.3, name: 'Left Knee' };
    base.right_knee = { x: 0.70, y: 0.54 + pushDepth * 0.3, name: 'Right Knee' };
    base.left_ankle = { x: 0.82, y: 0.62, name: 'Left Ankle' };
    base.right_ankle = { x: 0.84, y: 0.60, name: 'Right Ankle' };
  } else if (exerciseId === 'romanian_deadlift') {
    // RDL Hip hinge
    const hinge = normalizedPhase * 0.25;
    base.nose = { x: 0.38 - hinge * 0.5, y: 0.22 + hinge * 0.9, name: 'Nose' };
    base.left_shoulder = { x: 0.42 - hinge * 0.5, y: 0.30 + hinge * 0.8, name: 'Left Shoulder' };
    base.right_shoulder = { x: 0.44 - hinge * 0.5, y: 0.30 + hinge * 0.8, name: 'Right Shoulder' };
    base.left_hip = { x: 0.58 + hinge * 0.3, y: 0.54, name: 'Left Hip' }; // hips back
    base.right_hip = { x: 0.60 + hinge * 0.3, y: 0.54, name: 'Right Hip' };

    base.left_wrist = { x: 0.48 - hinge * 0.3, y: 0.58 + hinge * 0.6, name: 'Left Wrist' };
    base.right_wrist = { x: 0.50 - hinge * 0.3, y: 0.58 + hinge * 0.6, name: 'Right Wrist' };

    base.left_knee = { x: 0.50, y: 0.74, name: 'Left Knee' };
    base.right_knee = { x: 0.52, y: 0.74, name: 'Right Knee' };
    base.left_ankle = { x: 0.48, y: 0.92, name: 'Left Ankle' };
    base.right_ankle = { x: 0.50, y: 0.92, name: 'Right Ankle' };
  } else if (exerciseId === 'plank_hold') {
    base.nose = { x: 0.24, y: 0.48, name: 'Nose' };
    base.left_shoulder = { x: 0.30, y: 0.50, name: 'Left Shoulder' };
    base.right_shoulder = { x: 0.32, y: 0.48, name: 'Right Shoulder' };
    base.left_elbow = { x: 0.30, y: 0.70, name: 'Left Elbow' };
    base.right_elbow = { x: 0.32, y: 0.68, name: 'Right Elbow' };
    base.left_wrist = { x: 0.36, y: 0.70, name: 'Left Wrist' };
    base.right_wrist = { x: 0.38, y: 0.68, name: 'Right Wrist' };

    if (introduceError && errorType === 'hip_sag') {
      base.left_hip = { x: 0.54, y: 0.62, name: 'Left Hip' }; // Sagging down
      base.right_hip = { x: 0.56, y: 0.60, name: 'Right Hip' };
    } else if (introduceError && errorType === 'hip_pike') {
      base.left_hip = { x: 0.54, y: 0.40, name: 'Left Hip' }; // Piking up
      base.right_hip = { x: 0.56, y: 0.38, name: 'Right Hip' };
    } else {
      base.left_hip = { x: 0.54, y: 0.52, name: 'Left Hip' };
      base.right_hip = { x: 0.56, y: 0.50, name: 'Right Hip' };
    }

    base.left_knee = { x: 0.68, y: 0.54, name: 'Left Knee' };
    base.right_knee = { x: 0.70, y: 0.52, name: 'Right Knee' };
    base.left_ankle = { x: 0.82, y: 0.56, name: 'Left Ankle' };
    base.right_ankle = { x: 0.84, y: 0.54, name: 'Right Ankle' };
  } else if (exerciseId === 'warrior_yoga') {
    // Wide stance, front knee bent 90, arms horizontal
    base.nose = { x: 0.50, y: 0.22, name: 'Nose' };
    base.left_shoulder = { x: 0.46, y: 0.30, name: 'Left Shoulder' };
    base.right_shoulder = { x: 0.54, y: 0.30, name: 'Right Shoulder' };

    base.left_wrist = { x: 0.20, y: 0.30, name: 'Left Wrist' }; // Left arm extended
    base.right_wrist = { x: 0.80, y: 0.30, name: 'Right Wrist' }; // Right arm extended
    base.left_elbow = { x: 0.33, y: 0.30, name: 'Left Elbow' };
    base.right_elbow = { x: 0.67, y: 0.30, name: 'Right Elbow' };

    base.left_hip = { x: 0.47, y: 0.54, name: 'Left Hip' };
    base.right_hip = { x: 0.53, y: 0.54, name: 'Right Hip' };

    // Front knee (left) 90 deg
    base.left_knee = { x: 0.36, y: 0.72, name: 'Left Knee' };
    base.left_ankle = { x: 0.36, y: 0.90, name: 'Left Ankle' };

    // Rear leg (right) straight
    base.right_knee = { x: 0.66, y: 0.72, name: 'Right Knee' };
    base.right_ankle = { x: 0.76, y: 0.90, name: 'Right Ankle' };
  }

  return base;
}

// Evaluate biomechanical frame state from landmarks
export function evaluateFrameBiometrics(
  exerciseConfig: FormGuardExerciseConfig,
  landmarks: Record<string, LandmarkPoint>,
  currentRep: number,
  cycleProgress: number, // 0 to 1
  isSimulatedError: boolean = false,
  errorType: string = 'none'
): BiomechanicalFrameState {
  const activeCorrections: BiomechanicalFrameState['activeCorrections'] = [];
  const measuredAngles: BiomechanicalFrameState['measuredAngles'] = [];

  let formScore = 96;
  let statusVerdict: BiomechanicalFrameState['statusVerdict'] = 'OPTIMAL';
  let technicalFatigueDetected = false;
  let technicalFatigueConfidence = 0;

  // Determine current phase
  let currentPhase: BiomechanicalFrameState['currentPhase'] = 'eccentric';
  if (cycleProgress < 0.25) currentPhase = 'eccentric';
  else if (cycleProgress < 0.45) currentPhase = 'inflection_bottom';
  else if (cycleProgress < 0.75) currentPhase = 'concentric';
  else currentPhase = 'lockout_top';

  if (exerciseConfig.id === 'barbell_squat') {
    // 1. Knee flexion angle
    const kneeAngle = calculateJointAngle(
      landmarks.left_hip,
      landmarks.left_knee,
      landmarks.left_ankle
    );

    const isKneeGood = kneeAngle >= 75 && kneeAngle <= 105;
    measuredAngles.push({
      jointKey: 'knee_flexion',
      displayName: 'Kedalaman Lutut (Knee Angle)',
      currentAngle: kneeAngle,
      idealRange: [80, 95],
      status: isKneeGood ? 'good' : kneeAngle < 70 ? 'critical' : 'warning',
    });

    // 2. Spine angle
    const torsoAngle = calculateJointAngle(
      landmarks.left_shoulder,
      landmarks.left_hip,
      landmarks.left_knee
    );
    const isTorsoGood = torsoAngle >= 60;
    measuredAngles.push({
      jointKey: 'torso_inclination',
      displayName: 'Kemiringan Torso (Spine Angle)',
      currentAngle: torsoAngle,
      idealRange: [65, 85],
      status: isTorsoGood ? 'good' : 'warning',
    });

    if (isSimulatedError && (errorType === 'valgus' || errorType === 'all')) {
      formScore -= 35;
      statusVerdict = 'DANGER';
      activeCorrections.push({
        id: 'valgus_err',
        bodyPart: 'Lutut Kiri & Kanan (Medial Valgus)',
        message: 'Lutut mengarah ke dalam! Dorong lutut keluar sejajar ibu jari kaki.',
        severity: 'danger',
        arrowOrigin: { x: landmarks.left_knee.x, y: landmarks.left_knee.y },
        arrowDirection: { dx: -0.06, dy: 0 },
      });
    }

    if (isSimulatedError && (errorType === 'lumbar_flexion' || errorType === 'all')) {
      formScore -= 25;
      if (statusVerdict !== 'DANGER') statusVerdict = 'CAUTION';
      activeCorrections.push({
        id: 'lumbar_err',
        bodyPart: 'Punggung Bawah (Lumbar Spine)',
        message: 'Punggung mulai bungkuk di dasar squat. Tegakkan dada dan tahan core!',
        severity: 'caution',
        arrowOrigin: { x: landmarks.left_hip.x, y: landmarks.left_hip.y },
        arrowDirection: { dx: 0, dy: -0.06 },
      });
    }
  } else if (exerciseConfig.id === 'push_up') {
    // Push up elbow flare and core line
    let elbowFlareAngle = 48; // default optimal
    if (isSimulatedError && (errorType === 'elbow_flare' || errorType === 'sari_case' || errorType === 'all')) {
      elbowFlareAngle = 74; // Sari case study
    }

    measuredAngles.push({
      jointKey: 'elbow_flare',
      displayName: 'Sudut Siku ke Tubuh (Elbow Flare)',
      currentAngle: elbowFlareAngle,
      idealRange: [45, 60],
      status: elbowFlareAngle <= 60 ? 'good' : elbowFlareAngle > 70 ? 'critical' : 'warning',
    });

    let spineLinearity = 178;
    if (isSimulatedError && (errorType === 'hip_sag' || (errorType === 'sari_case' && currentRep >= 6))) {
      spineLinearity = 154; // hip sagging
    }

    measuredAngles.push({
      jointKey: 'spine_linearity',
      displayName: 'Kelurusan Core & Panggul',
      currentAngle: spineLinearity,
      idealRange: [175, 185],
      status: spineLinearity >= 170 ? 'good' : 'critical',
    });

    if (elbowFlareAngle > 70) {
      formScore -= 40;
      statusVerdict = 'DANGER';
      activeCorrections.push({
        id: 'elbow_flare_err',
        bodyPart: 'Siku Kiri (74° Flare)',
        message: 'Siku terbuka lebar (>70°)! Dekatkan siku ke rusuk (bentuk panah 45°).',
        severity: 'danger',
        arrowOrigin: { x: landmarks.left_elbow.x, y: landmarks.left_elbow.y },
        arrowDirection: { dx: 0.06, dy: 0 },
      });
    }

    if (spineLinearity < 165) {
      formScore -= 25;
      if (statusVerdict !== 'DANGER') statusVerdict = 'CAUTION';
      activeCorrections.push({
        id: 'hip_sag_err',
        bodyPart: 'Panggul & Core (Hip Drop)',
        message: 'Panggul amblas! Tarik pusar ke dalam dan kencangkan pantat.',
        severity: 'danger',
        arrowOrigin: { x: landmarks.left_hip.x, y: landmarks.left_hip.y },
        arrowDirection: { dx: 0, dy: -0.06 },
      });
    }

    if (errorType === 'sari_case' && currentRep >= 6) {
      technicalFatigueDetected = true;
      technicalFatigueConfidence = 92;
      statusVerdict = 'TECHNICAL_FATIGUE';
    }
  } else if (exerciseConfig.id === 'romanian_deadlift') {
    const hipHingeAngle = calculateJointAngle(
      landmarks.left_shoulder,
      landmarks.left_hip,
      landmarks.left_knee
    );

    measuredAngles.push({
      jointKey: 'hip_hinge',
      displayName: 'Sudut Hip Hinge',
      currentAngle: hipHingeAngle,
      idealRange: [50, 65],
      status: hipHingeAngle >= 45 && hipHingeAngle <= 70 ? 'good' : 'warning',
    });

    if (isSimulatedError && (errorType === 'spinal_rounding' || errorType === 'all')) {
      formScore -= 38;
      statusVerdict = 'DANGER';
      activeCorrections.push({
        id: 'rdl_spine_err',
        bodyPart: 'Tulang Belakang Lumbal',
        message: 'Punggung melengkung bungkuk! Tarik bahu ke belakang dan kunci lats.',
        severity: 'danger',
        arrowOrigin: { x: landmarks.left_shoulder.x, y: landmarks.left_shoulder.y },
        arrowDirection: { dx: 0, dy: -0.06 },
      });
    }
  } else if (exerciseConfig.id === 'plank_hold') {
    const bodyLineAngle = calculateJointAngle(
      landmarks.left_shoulder,
      landmarks.left_hip,
      landmarks.left_ankle
    );

    measuredAngles.push({
      jointKey: 'plank_alignment',
      displayName: 'Kelurusan Garis Tubuh',
      currentAngle: bodyLineAngle,
      idealRange: [175, 183],
      status: bodyLineAngle >= 172 && bodyLineAngle <= 185 ? 'good' : 'critical',
    });

    if (isSimulatedError && errorType === 'hip_sag') {
      formScore -= 35;
      statusVerdict = 'DANGER';
      activeCorrections.push({
        id: 'plank_sag',
        bodyPart: 'Panggul (Sagging)',
        message: 'Panggul turun amblas! Kencangkan gluteus dan perut.',
        severity: 'danger',
        arrowOrigin: { x: landmarks.left_hip.x, y: landmarks.left_hip.y },
        arrowDirection: { dx: 0, dy: -0.06 },
      });
    }
  } else {
    // Generic fallback
    measuredAngles.push({
      jointKey: 'primary_joint',
      displayName: 'Sudut Sendi Utama',
      currentAngle: 90,
      idealRange: [85, 95],
      status: 'good',
    });
  }

  // Cap score 0 to 100
  formScore = Math.max(20, Math.min(100, formScore));

  return {
    timestamp: Date.now(),
    repCount: currentRep,
    currentPhase,
    overallFormScore: formScore,
    statusVerdict,
    measuredAngles,
    activeCorrections,
    cadenceSecondsPerRep: 3.2,
    symmetryIndexPercent: isSimulatedError ? 72 : 94,
    technicalFatigueDetected,
    technicalFatigueConfidence,
  };
}

// Generate Post-Set Breakdown Report
export function generatePostSetReport(
  exerciseId: FormGuardExerciseId,
  totalReps: number,
  cleanReps: number,
  compromisedReps: number,
  averageScore: number,
  hadFatigueBreakdown: boolean,
  errorDistribution: Record<string, number>
): FormGuardPostSetReport {
  const exercise = FORM_GUARD_EXERCISES.find((e) => e.id === exerciseId) || FORM_GUARD_EXERCISES[0];

  let grade: FormGuardPostSetReport['techniqueGrade'] = 'A';
  if (averageScore >= 90) grade = 'S';
  else if (averageScore >= 80) grade = 'A';
  else if (averageScore >= 70) grade = 'B';
  else if (averageScore >= 60) grade = 'C';
  else grade = 'D';

  const bodyErrorHeatmap: BodyPartHeatmapData[] = [
    {
      bodyPartId: 'left_elbow',
      displayName: 'Siku Kiri (Left Elbow)',
      errorCount: errorDistribution['left_elbow'] || (exerciseId === 'push_up' ? 4 : 0),
      severityGrade: (errorDistribution['left_elbow'] || 0) > 3 ? 'red' : 'green',
      primaryIssue: 'Flaring >70° saat fase konsentrik',
      injuryRiskFactor: 'Rotator Cuff Anterior Impingement',
    },
    {
      bodyPartId: 'left_shoulder',
      displayName: 'Bahu Kiri (Left Deltoid)',
      errorCount: errorDistribution['left_shoulder'] || 2,
      severityGrade: 'yellow',
      primaryIssue: 'Shrugging mendekati leher saat repetisi akhir',
      injuryRiskFactor: 'Upper Trapezius Hyperactivity',
    },
    {
      bodyPartId: 'lumbar_spine',
      displayName: 'Tulang Belakang (Lumbar Spine)',
      errorCount: errorDistribution['lumbar_spine'] || (exerciseId === 'barbell_squat' ? 3 : 1),
      severityGrade: (errorDistribution['lumbar_spine'] || 0) > 2 ? 'yellow' : 'green',
      primaryIssue: 'Lumbar flexion / butt-wink di dasar gerakan',
      injuryRiskFactor: 'L4-L5 Disc Shear Stress',
    },
    {
      bodyPartId: 'left_knee',
      displayName: 'Lutut Kiri (Left Knee)',
      errorCount: errorDistribution['left_knee'] || (exerciseId === 'barbell_squat' ? 5 : 0),
      severityGrade: (errorDistribution['left_knee'] || 0) > 3 ? 'red' : 'green',
      primaryIssue: 'Medial valgus deviation saat naik',
      injuryRiskFactor: 'Patellofemoral & ACL Strain',
    },
    {
      bodyPartId: 'right_knee',
      displayName: 'Lutut Kanan (Right Knee)',
      errorCount: errorDistribution['right_knee'] || 1,
      severityGrade: 'green',
      primaryIssue: 'Sedikit asimetri stabil',
      injuryRiskFactor: 'Rendah',
    },
    {
      bodyPartId: 'hips',
      displayName: 'Panggul & Core (Pelvis)',
      errorCount: errorDistribution['hips'] || 2,
      severityGrade: 'yellow',
      primaryIssue: 'Hip drop / anti-extension fatigue pada repetisi 6-8',
      injuryRiskFactor: 'Lumbar Hyperextension',
    },
  ];

  return {
    exerciseId,
    exerciseName: exercise.name,
    totalReps,
    cleanReps,
    compromisedReps,
    techniqueScore: Math.round(averageScore),
    techniqueGrade: grade,
    durationSeconds: totalReps * 4 + 10,
    averageCadenceSec: 3.4,
    symmetryScore: hadFatigueBreakdown ? 74 : 93,
    failureTypeAnalysis: {
      classifiedFailure: hadFatigueBreakdown
        ? 'TECHNICAL_FORM_BREAKDOWN'
        : cleanReps >= totalReps
        ? 'PERFECT_COMPLETION'
        : 'PURE_MUSCULAR_FAILURE',
      failureOnsetRep: hadFatigueBreakdown ? Math.max(1, totalReps - 2) : undefined,
      explanation: hadFatigueBreakdown
        ? 'Penurunan kecepatan rep bersamaan dengan deviasi sudut kritis (>20%) menunjukkan kelelahan sistem koordinasi motorik/saraf sebelum otot gagal total.'
        : 'Gerakan dieksekusi dengan ritme konsisten dan stabilitas sendi dalam koridor biomekanika yang aman.',
      clinicalSafetyVerdict: hadFatigueBreakdown
        ? 'Keputusan AI menghentikan set pada titik ini berhasil mencegah cedera kompresi sendi.'
        : 'Sesi aman tanpa tanda kompresi sendi berbahaya.',
    },
    bodyErrorHeatmap,
    idealVsActualKinematics: [
      {
        jointName: exerciseId === 'push_up' ? 'Sudut Buka Siku (Elbow Flare)' : 'Sudut Kedalaman Panggul/Lutut',
        actualAngleAvg: exerciseId === 'push_up' ? 68 : 82,
        idealAngleTarget: exerciseId === 'push_up' ? 48 : 90,
        variancePercent: exerciseId === 'push_up' ? 41 : 9,
        biomechanicalImpact:
          exerciseId === 'push_up'
            ? 'Peningkatan gaya geser 3.2x pada tendon anterior deltoid saat siku melebar.'
            : 'Kedalaman panggul optimal memicu aktivasi serat gluteus maximus maksimal.',
      },
      {
        jointName: 'Kelurusan Tulang Belakang (Spine Neutrality)',
        actualAngleAvg: 168,
        idealAngleTarget: 180,
        variancePercent: 7,
        biomechanicalImpact: 'Tekanan facet lumbal tetap dalam batas toleransi aman fisiologis.',
      },
    ],
    correctivePrescription: {
      immediateAdvice:
        exerciseId === 'push_up'
          ? 'Prioritaskan posisi tangan selebar bahu dan putar telapak tangan sedikit ke luar (eksternal rotasi) untuk mengunci soket sendi bahu.'
          : 'Gunakan resistance band mini di atas lutut saat pemanasan untuk mengaktifkan gluteus medius.',
      rehabWarmupMovements: [
        {
          movement: 'Scapular Push-ups on Knees',
          repsDuration: '2 Sets x 10 Reps',
          targetBenefit: 'Aktivasi serratus anterior untuk stabilisasi tulang belikat.',
        },
        {
          movement: 'Band Pull-Aparts / Face Pulls',
          repsDuration: '2 Sets x 15 Reps',
          targetBenefit: 'Penguatan otot rotator cuff eksternal dan belikat.',
        },
      ],
      regressionProgressionAdvice:
        exerciseId === 'push_up'
          ? 'Jika siku masih melebar, lakukan Incline Push-Up (tangan di bangku 45°) selama 1 minggu sebelum kembali ke push-up lantai penuh.'
          : 'Lakukan Goblet Box Squat ke sasaran bangku 40cm untuk memprogram kedalaman konstan.',
    },
    crossModuleSync: {
      trainerModuleAction: 'Update program Modul 1: Menambahkan variasi Incline Push-up & Scapular Drills.',
      recoveryModuleAction: 'Kirim notifikasi Modul 3: Rekomendasi peregangan pectoralis minor & trigger point bola tenis pada bahu.',
      medicalTriageFlag: hadFatigueBreakdown && (errorDistribution['left_elbow'] || 0) > 5,
    },
  };
}
