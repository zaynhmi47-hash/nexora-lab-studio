import { LandmarkName, PoseLandmarks, PosePoint } from '../../types/bodyAI';

export const POSE_CONNECTIONS: [LandmarkName, LandmarkName][] = [
  // Head / Torso
  ['nose', 'leftEye'],
  ['nose', 'rightEye'],
  ['leftEye', 'leftEar'],
  ['rightEye', 'rightEar'],
  ['leftShoulder', 'rightShoulder'],
  ['leftShoulder', 'leftHip'],
  ['rightShoulder', 'rightHip'],
  ['leftHip', 'rightHip'],

  // Arms
  ['leftShoulder', 'leftElbow'],
  ['leftElbow', 'leftWrist'],
  ['rightShoulder', 'rightElbow'],
  ['rightElbow', 'rightWrist'],

  // Legs
  ['leftHip', 'leftKnee'],
  ['leftKnee', 'leftAnkle'],
  ['rightHip', 'rightKnee'],
  ['rightKnee', 'rightAnkle'],
];

export class PoseProcessor {
  private smoothedLandmarks: Partial<PoseLandmarks> = {};
  private smoothingAlpha = 0.65; // Weight for new frame (0 = all history, 1 = no smoothing)
  private lastProcessedTimestamp = 0;
  private targetFpsIntervalMs = 1000 / 30; // Target ~30 FPS throttling

  /**
   * Clears historical smoothing cache.
   */
  public reset(): void {
    this.smoothedLandmarks = {};
    this.lastProcessedTimestamp = 0;
  }

  /**
   * Throttles frame rate to prevent overheating/battery drain on mobile and excessive re-renders.
   */
  public shouldProcessFrame(now: number = performance.now()): boolean {
    if (now - this.lastProcessedTimestamp >= this.targetFpsIntervalMs) {
      this.lastProcessedTimestamp = now;
      return true;
    }
    return false;
  }

  /**
   * Smooths incoming raw landmarks using Exponential Moving Average (EMA).
   */
  public processAndSmooth(rawLandmarks: Partial<PoseLandmarks>): PoseLandmarks {
    const result: Partial<PoseLandmarks> = {};
    const keys = Object.keys(rawLandmarks) as LandmarkName[];

    for (const key of keys) {
      const raw = rawLandmarks[key];
      if (!raw) continue;

      const prev = this.smoothedLandmarks[key];
      if (!prev) {
        result[key] = { ...raw };
      } else {
        const vis = raw.visibility ?? 1;
        // If visibility dropped drastically, keep some confidence or update softly
        const alpha = Math.min(1, Math.max(0.1, this.smoothingAlpha * vis));

        result[key] = {
          x: prev.x * (1 - alpha) + raw.x * alpha,
          y: prev.y * (1 - alpha) + raw.y * alpha,
          z: raw.z !== undefined && prev.z !== undefined ? prev.z * (1 - alpha) + raw.z * alpha : raw.z,
          visibility: raw.visibility,
        };
      }
    }

    this.smoothedLandmarks = result;
    return result as PoseLandmarks;
  }

  /**
   * Draws the pose skeleton on an HTML5 canvas context.
   */
  public static drawSkeleton(
    ctx: CanvasRenderingContext2D,
    landmarks: Partial<PoseLandmarks>,
    width: number,
    height: number,
    formHealthScore: number = 85
  ): void {
    ctx.clearRect(0, 0, width, height);

    // Color based on live form score
    const strokeColor =
      formHealthScore >= 80 ? '#10b981' : formHealthScore >= 60 ? '#f59e0b' : '#ef4444';
    const jointFill =
      formHealthScore >= 80 ? '#059669' : formHealthScore >= 60 ? '#d97706' : '#dc2626';

    // 1. Draw connecting lines
    ctx.lineWidth = Math.max(3, Math.round(width * 0.006));
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = strokeColor;

    for (const [partA, partB] of POSE_CONNECTIONS) {
      const ptA = landmarks[partA];
      const ptB = landmarks[partB];

      if (ptA && ptB && (ptA.visibility ?? 1) > 0.4 && (ptB.visibility ?? 1) > 0.4) {
        ctx.beginPath();
        ctx.moveTo(ptA.x * width, ptA.y * height);
        ctx.lineTo(ptB.x * width, ptB.y * height);
        ctx.stroke();
      }
    }

    // 2. Draw key joint nodes
    const nodeRadius = Math.max(4, Math.round(width * 0.008));
    const keys = Object.keys(landmarks) as LandmarkName[];

    for (const key of keys) {
      const pt = landmarks[key];
      if (pt && (pt.visibility ?? 1) > 0.4) {
        const px = pt.x * width;
        const py = pt.y * height;

        // Outer glow
        ctx.beginPath();
        ctx.arc(px, py, nodeRadius + 2, 0, 2 * Math.PI);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        ctx.fill();

        // Inner node
        ctx.beginPath();
        ctx.arc(px, py, nodeRadius, 0, 2 * Math.PI);
        ctx.fillStyle = jointFill;
        ctx.fill();
      }
    }
  }
}
