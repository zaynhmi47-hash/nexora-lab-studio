import {
  FormScoreBreakdown,
  JointAngles,
  LiveFeedback,
  RepState,
  SingleRepData,
} from '../../types/bodyAI';
import { ExerciseDefinition } from '../../types/exercise';

export class FormAnalyzer {
  private exerciseDef: ExerciseDefinition;
  private recentIssues: Set<string> = new Set();
  private allSessionIssues: Set<string> = new Set();
  private lastFeedbackTime: number = 0;
  private feedbackCooldownMs: number = 1800; // Prevent spamming feedback audio/visuals
  private currentLiveScore: FormScoreBreakdown = {
    alignment: 100,
    depth: 100,
    stability: 100,
    symmetry: 100,
    tempo: 100,
    overall: 100,
  };

  constructor(exerciseDef: ExerciseDefinition) {
    this.exerciseDef = exerciseDef;
    this.reset();
  }

  public reset(): void {
    this.recentIssues.clear();
    this.allSessionIssues.clear();
    this.lastFeedbackTime = 0;
    this.currentLiveScore = {
      alignment: 100,
      depth: 100,
      stability: 100,
      symmetry: 100,
      tempo: 100,
      overall: 100,
    };
  }

  public getSessionIssues(): string[] {
    return Array.from(this.allSessionIssues);
  }

  /**
   * Transparent formula computing overall score from configurable weighted sub-metrics.
   */
  public static computeWeightedOverallScore(
    breakdown: Omit<FormScoreBreakdown, 'overall'>,
    weights: ExerciseDefinition['weights']
  ): number {
    const total =
      breakdown.alignment * weights.alignment +
      breakdown.depth * weights.depth +
      breakdown.stability * weights.stability +
      breakdown.symmetry * weights.symmetry +
      breakdown.tempo * weights.tempo;

    return Math.max(0, Math.min(100, Math.round(total)));
  }

  /**
   * Evaluates current frame angles against deterministic exercise rules.
   */
  public analyzeFrame(
    angles: JointAngles,
    repState: RepState,
    timestamp: number = Date.now()
  ): {
    score: FormScoreBreakdown;
    feedback?: LiveFeedback;
  } {
    let alignmentScore = 95;
    let depthScore = 95;
    let stabilityScore = 95;
    let symmetryScore = angles.kneeSymmetry || angles.elbowSymmetry || 95;
    let tempoScore = 90;

    let candidateFeedback: LiveFeedback | undefined = undefined;

    // Run exercise-specific rules
    for (const rule of this.exerciseDef.rules) {
      const result = rule.check(angles, repState);

      if (result.score < 80) {
        if (rule.id.includes('depth')) depthScore = Math.min(depthScore, result.score);
        if (rule.id.includes('alignment') || rule.id.includes('spine')) {
          alignmentScore = Math.min(alignmentScore, result.score);
        }
        if (rule.id.includes('stability') || rule.id.includes('torso') || rule.id.includes('balance')) {
          stabilityScore = Math.min(stabilityScore, result.score);
        }

        if (result.issue) {
          this.recentIssues.add(result.issue);
          this.allSessionIssues.add(result.issue);
        }

        // Check if cooldown elapsed to generate live feedback
        if (result.feedback && timestamp - this.lastFeedbackTime >= this.feedbackCooldownMs) {
          candidateFeedback = {
            id: `fb_${timestamp}`,
            message: result.feedback,
            type: result.score < 60 ? 'critical' : 'warning',
            timestamp,
          };
          this.lastFeedbackTime = timestamp;
        }
      }
    }

    const overall = FormAnalyzer.computeWeightedOverallScore(
      {
        alignment: alignmentScore,
        depth: depthScore,
        stability: stabilityScore,
        symmetry: symmetryScore,
        tempo: tempoScore,
      },
      this.exerciseDef.weights
    );

    this.currentLiveScore = {
      alignment: alignmentScore,
      depth: depthScore,
      stability: stabilityScore,
      symmetry: symmetryScore,
      tempo: tempoScore,
      overall,
    };

    return {
      score: this.currentLiveScore,
      feedback: candidateFeedback,
    };
  }

  /**
   * Computes aggregate score summary across all completed repetitions in the session.
   */
  public summarizeSessionScores(repsData: SingleRepData[]): {
    averageScore: number;
    scoreBreakdown: FormScoreBreakdown;
  } {
    if (!repsData || repsData.length === 0) {
      return {
        averageScore: this.currentLiveScore.overall,
        scoreBreakdown: this.currentLiveScore,
      };
    }

    const count = repsData.length;
    let sumAlignment = 0;
    let sumDepth = 0;
    let sumStability = 0;
    let sumSymmetry = 0;
    let sumTempo = 0;
    let sumOverall = 0;

    for (const r of repsData) {
      sumAlignment += r.scoreBreakdown.alignment;
      sumDepth += r.scoreBreakdown.depth;
      sumStability += r.scoreBreakdown.stability;
      sumSymmetry += r.scoreBreakdown.symmetry;
      sumTempo += r.scoreBreakdown.tempo;
      sumOverall += r.scoreBreakdown.overall;
    }

    const breakdown: FormScoreBreakdown = {
      alignment: Math.round(sumAlignment / count),
      depth: Math.round(sumDepth / count),
      stability: Math.round(sumStability / count),
      symmetry: Math.round(sumSymmetry / count),
      tempo: Math.round(sumTempo / count),
      overall: Math.round(sumOverall / count),
    };

    return {
      averageScore: breakdown.overall,
      scoreBreakdown: breakdown,
    };
  }
}
