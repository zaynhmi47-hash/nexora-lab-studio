import { PosePoint, PoseLandmarks, JointAngles } from '../../types/bodyAI';

/**
 * Calculates the interior angle in degrees at vertex point B between vector BA and BC.
 * @param a First point (e.g. Hip)
 * @param b Vertex point (e.g. Knee)
 * @param c Third point (e.g. Ankle)
 * @returns Angle in degrees [0, 180]
 */
export function calculateAngle(a: PosePoint, b: PosePoint, c: PosePoint): number {
  if (!a || !b || !c) return 180;

  // Vectors ba and bc
  const baX = a.x - b.x;
  const baY = a.y - b.y;
  const bcX = c.x - b.x;
  const bcY = c.y - b.y;

  // Dot product
  const dotProduct = baX * bcX + baY * bcY;

  // Magnitudes
  const magBA = Math.sqrt(baX * baX + baY * baY);
  const magBC = Math.sqrt(bcX * bcX + bcY * bcY);

  if (magBA === 0 || magBC === 0) {
    return 180;
  }

  // Cosine angle clamped to [-1, 1] to prevent NaN
  let cosTheta = dotProduct / (magBA * magBC);
  cosTheta = Math.max(-1, Math.min(1, cosTheta));

  const angleRad = Math.acos(cosTheta);
  const angleDeg = (angleRad * 180) / Math.PI;

  return Math.round(angleDeg * 10) / 10;
}

/**
 * Calculates Euclidean 2D distance between two normalized points.
 */
export function calculateDistance(a: PosePoint, b: PosePoint): number {
  if (!a || !b) return 0;
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}

/**
 * Calculates symmetry score (0 - 100%) between left and right limb angles.
 * A 0 degree difference gives 100%. A 30+ degree difference approaches lower scores.
 */
export function calculateSymmetry(leftAngle: number, rightAngle: number): number {
  const diff = Math.abs(leftAngle - rightAngle);
  const score = Math.max(0, 100 - diff * 3.33); // 30 deg diff = 0 score
  return Math.round(score);
}

/**
 * Calculates slope angle relative to horizontal plane (e.g. for spine or shoulders)
 */
export function calculateHorizontalSlope(a: PosePoint, b: PosePoint): number {
  if (!a || !b) return 0;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const angleRad = Math.atan2(Math.abs(dy), Math.abs(dx));
  return (angleRad * 180) / Math.PI;
}

/**
 * Extracts and computes all essential biometric joint angles from current pose landmarks.
 */
export function calculateAllJointAngles(landmarks: Partial<PoseLandmarks>): JointAngles {
  const {
    leftShoulder,
    rightShoulder,
    leftElbow,
    rightElbow,
    leftWrist,
    rightWrist,
    leftHip,
    rightHip,
    leftKnee,
    rightKnee,
    leftAnkle,
    rightAnkle,
    nose,
  } = landmarks;

  const defaultPoint: PosePoint = { x: 0.5, y: 0.5, visibility: 0 };

  // Knee Angles: Hip -> Knee -> Ankle
  const leftKneeAngle = calculateAngle(
    leftHip || defaultPoint,
    leftKnee || defaultPoint,
    leftAnkle || defaultPoint
  );

  const rightKneeAngle = calculateAngle(
    rightHip || defaultPoint,
    rightKnee || defaultPoint,
    rightAnkle || defaultPoint
  );

  // Elbow Angles: Shoulder -> Elbow -> Wrist
  const leftElbowAngle = calculateAngle(
    leftShoulder || defaultPoint,
    leftElbow || defaultPoint,
    leftWrist || defaultPoint
  );

  const rightElbowAngle = calculateAngle(
    rightShoulder || defaultPoint,
    rightElbow || defaultPoint,
    rightWrist || defaultPoint
  );

  // Hip Angles: Shoulder -> Hip -> Knee
  const leftHipAngle = calculateAngle(
    leftShoulder || defaultPoint,
    leftHip || defaultPoint,
    leftKnee || defaultPoint
  );

  const rightHipAngle = calculateAngle(
    rightShoulder || defaultPoint,
    rightHip || defaultPoint,
    rightKnee || defaultPoint
  );

  // Shoulder Angles: Elbow -> Shoulder -> Hip
  const leftShoulderAngle = calculateAngle(
    leftElbow || defaultPoint,
    leftShoulder || defaultPoint,
    leftHip || defaultPoint
  );

  const rightShoulderAngle = calculateAngle(
    rightElbow || defaultPoint,
    rightShoulder || defaultPoint,
    rightHip || defaultPoint
  );

  // Torso Angle relative to vertical (Shoulder midpoint to Hip midpoint)
  const shoulderMid: PosePoint = {
    x: ((leftShoulder?.x || 0.5) + (rightShoulder?.x || 0.5)) / 2,
    y: ((leftShoulder?.y || 0.5) + (rightShoulder?.y || 0.5)) / 2,
  };
  const hipMid: PosePoint = {
    x: ((leftHip?.x || 0.5) + (rightHip?.x || 0.5)) / 2,
    y: ((leftHip?.y || 0.5) + (rightHip?.y || 0.5)) / 2,
  };
  const verticalRef: PosePoint = {
    x: hipMid.x,
    y: hipMid.y - 0.5,
  };

  const torsoAngle = calculateAngle(shoulderMid, hipMid, verticalRef);

  // Hip Sag Angle (Spine alignment: Shoulder -> Hip -> Ankle)
  const ankleMid: PosePoint = {
    x: ((leftAnkle?.x || 0.5) + (rightAnkle?.x || 0.5)) / 2,
    y: ((leftAnkle?.y || 0.5) + (rightAnkle?.y || 0.5)) / 2,
  };
  const hipSagAngle = calculateAngle(shoulderMid, hipMid, ankleMid);

  // Neck Angle (Nose -> ShoulderMid -> HipMid)
  const neckAngle = calculateAngle(nose || defaultPoint, shoulderMid, hipMid);

  // Symmetries
  const kneeSymmetry = calculateSymmetry(leftKneeAngle, rightKneeAngle);
  const elbowSymmetry = calculateSymmetry(leftElbowAngle, rightElbowAngle);

  return {
    leftKneeAngle,
    rightKneeAngle,
    leftElbowAngle,
    rightElbowAngle,
    leftHipAngle,
    rightHipAngle,
    leftShoulderAngle,
    rightShoulderAngle,
    torsoAngle,
    hipSagAngle,
    neckAngle,
    kneeSymmetry,
    elbowSymmetry,
  };
}
