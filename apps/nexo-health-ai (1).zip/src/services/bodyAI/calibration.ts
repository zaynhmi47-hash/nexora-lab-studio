import { LandmarkName, PoseLandmarks, CalibrationResult, CalibrationStatus } from '../../types/bodyAI';
import { ExerciseDefinition } from '../../types/exercise';

export class CalibrationEvaluator {
  /**
   * Evaluates if user body framing and landmark visibility are ready for workout.
   */
  public static evaluateCalibration(
    landmarks: Partial<PoseLandmarks>,
    exerciseDef: ExerciseDefinition,
    isIndonesian: boolean = true
  ): CalibrationResult {
    if (!landmarks || Object.keys(landmarks).length === 0) {
      return {
        status: 'NO_BODY_DETECTED',
        message: isIndonesian ? 'Tubuh belum terdeteksi di kamera' : 'No body detected in camera frame',
        isReady: false,
        visibilityScore: 0,
        framingScore: 0,
        missingLandmarks: exerciseDef.requiredLandmarks,
        suggestion: isIndonesian
          ? 'Berdirilah di depan kamera agar tubuh Anda terlihat jelas.'
          : 'Step in front of the camera with adequate lighting.',
      };
    }

    // 1. Check required landmarks visibility
    const missing: LandmarkName[] = [];
    let totalVisibility = 0;
    let checkedCount = 0;

    for (const req of exerciseDef.requiredLandmarks) {
      const pt = landmarks[req];
      checkedCount++;
      if (!pt || (pt.visibility !== undefined && pt.visibility < 0.45)) {
        missing.push(req);
      } else {
        totalVisibility += pt.visibility ?? 0.8;
      }
    }

    const visibilityScore = Math.round((totalVisibility / checkedCount) * 100);

    if (missing.length > 2) {
      return {
        status: 'PARTIAL_BODY',
        message: isIndonesian ? 'Seluruh tubuh belum terlihat lengkap' : 'Full body not fully visible',
        isReady: false,
        visibilityScore,
        framingScore: 40,
        missingLandmarks: missing,
        suggestion: isIndonesian
          ? 'Pastikan kepala hingga pergelangan kaki terlihat di layar.'
          : 'Make sure your head to ankles are completely visible in frame.',
      };
    }

    // 2. Evaluate Framing & Distance via vertical span
    const nose = landmarks.nose || landmarks.leftEye || landmarks.rightEye;
    const ankle = landmarks.leftAnkle || landmarks.rightAnkle || landmarks.leftKnee;

    if (nose && ankle) {
      const bodyHeightSpan = Math.abs(ankle.y - nose.y);

      // If body takes > 88% of screen height -> Too close
      if (bodyHeightSpan > 0.88) {
        return {
          status: 'TOO_CLOSE',
          message: isIndonesian ? 'Terlalu dekat dengan kamera' : 'Too close to the camera',
          isReady: false,
          visibilityScore,
          framingScore: 50,
          missingLandmarks: missing,
          suggestion: isIndonesian
            ? 'Mundurlah sedikit (sekitar 1.5 - 2.5 meter) agar rentang gerak maksimal.'
            : 'Move slightly farther from camera (approx 1.5 - 2.5 meters).',
        };
      }

      // If body takes < 35% of screen height -> Too far
      if (bodyHeightSpan < 0.35) {
        return {
          status: 'TOO_FAR',
          message: isIndonesian ? 'Terlalu jauh dari kamera' : 'Too far from camera',
          isReady: false,
          visibilityScore,
          framingScore: 55,
          missingLandmarks: missing,
          suggestion: isIndonesian
            ? 'Majulah sedikit lebih dekat ke arah kamera.'
            : 'Move a little closer to the camera.',
        };
      }
    }

    // 3. Low visibility check
    if (visibilityScore < 60) {
      return {
        status: 'LOW_VISIBILITY',
        message: isIndonesian ? 'Pencahayaan kurang optimal' : 'Low lighting visibility',
        isReady: false,
        visibilityScore,
        framingScore: 65,
        missingLandmarks: missing,
        suggestion: isIndonesian
          ? 'Tingkatkan pencahayaan ruangan atau hindari backlight tajam.'
          : 'Increase room lighting or avoid strong backlight.',
      };
    }

    // 4. Perfect Framing Ready!
    return {
      status: 'PERFECT_FRAMING',
      message: isIndonesian ? 'Posisi sempurna! Siap memulai' : 'Good position. Ready to start!',
      isReady: true,
      visibilityScore: Math.max(85, visibilityScore),
      framingScore: 95,
      missingLandmarks: [],
      suggestion: isIndonesian
        ? 'Pertahankan posisi ini. Latihan akan segera dimulai.'
        : 'Hold this stance. Session will start shortly.',
    };
  }
}
