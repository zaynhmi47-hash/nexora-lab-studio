import { ExerciseType, JointAngles, RepState, SingleRepData } from '../../types/bodyAI';
import { ExerciseDefinition } from '../../types/exercise';

export interface RepCounterCallbackPayload {
  repNumber: number;
  state: RepState;
  repData?: SingleRepData;
}

export class RepCounterStateMachine {
  private exerciseDef: ExerciseDefinition;
  private currentState: RepState;
  private repCount: number = 0;
  private currentRepStartTime: number = 0;
  private descentStartTime: number = 0;
  private bottomStartTime: number = 0;
  private ascentStartTime: number = 0;
  private minAngleRecordedInRep: number = 180;
  private repHistory: SingleRepData[] = [];

  // Duration mode specific
  private plankHoldStartTime: number = 0;
  private totalPlankHeldSeconds: number = 0;
  private isPlankHolding: boolean = false;

  constructor(exerciseDef: ExerciseDefinition) {
    this.exerciseDef = exerciseDef;
    this.currentState = this.getInitialState();
    this.reset();
  }

  private getInitialState(): RepState {
    if (this.exerciseDef.type === 'pushup') return 'TOP';
    if (this.exerciseDef.type === 'plank') return 'START';
    return 'STANDING';
  }

  public reset(): void {
    this.currentState = this.getInitialState();
    this.repCount = 0;
    this.currentRepStartTime = 0;
    this.descentStartTime = 0;
    this.bottomStartTime = 0;
    this.ascentStartTime = 0;
    this.minAngleRecordedInRep = 180;
    this.repHistory = [];
    this.plankHoldStartTime = 0;
    this.totalPlankHeldSeconds = 0;
    this.isPlankHolding = false;
  }

  public getState(): RepState {
    return this.currentState;
  }

  public getRepCount(): number {
    return this.repCount;
  }

  public getRepHistory(): SingleRepData[] {
    return [...this.repHistory];
  }

  public getPlankHoldDurationSec(): number {
    if (this.isPlankHolding && this.plankHoldStartTime > 0) {
      const live = (Date.now() - this.plankHoldStartTime) / 1000;
      return Math.round(this.totalPlankHeldSeconds + live);
    }
    return Math.round(this.totalPlankHeldSeconds);
  }

  /**
   * Process a frame's angles through the deterministic finite state machine.
   * Returns true if a repetition just completed.
   */
  public update(
    angles: JointAngles,
    timestamp: number = Date.now()
  ): { repCompleted: boolean; stateChanged: boolean; state: RepState } {
    const prev = this.currentState;

    if (this.exerciseDef.mode === 'duration') {
      return this.updateDurationMode(angles, timestamp, prev);
    } else {
      return this.updateRepMode(angles, timestamp, prev);
    }
  }

  private updateDurationMode(
    angles: JointAngles,
    timestamp: number,
    prev: RepState
  ): { repCompleted: boolean; stateChanged: boolean; state: RepState } {
    // For Plank: Shoulder-Hip-Ankle line should be 155° - 195°
    const isPlankProper = angles.hipSagAngle >= 155 && angles.hipSagAngle <= 195;

    if (isPlankProper) {
      if (!this.isPlankHolding) {
        this.isPlankHolding = true;
        this.plankHoldStartTime = timestamp;
        this.currentState = 'HOLDING';
      }
    } else {
      if (this.isPlankHolding) {
        this.isPlankHolding = false;
        if (this.plankHoldStartTime > 0) {
          this.totalPlankHeldSeconds += (timestamp - this.plankHoldStartTime) / 1000;
          this.plankHoldStartTime = 0;
        }
        this.currentState = 'START';
      }
    }

    return {
      repCompleted: false,
      stateChanged: prev !== this.currentState,
      state: this.currentState,
    };
  }

  private updateRepMode(
    angles: JointAngles,
    timestamp: number,
    prev: RepState
  ): { repCompleted: boolean; stateChanged: boolean; state: RepState } {
    const thresholds = this.exerciseDef.targetRepAngleThresholds;

    // Determine primary movement joint angle
    let primaryAngle = 180;
    if (this.exerciseDef.type === 'squat' || this.exerciseDef.type === 'lunge') {
      primaryAngle = Math.min(angles.leftKneeAngle, angles.rightKneeAngle);
    } else if (this.exerciseDef.type === 'pushup') {
      primaryAngle = Math.min(angles.leftElbowAngle, angles.rightElbowAngle);
    }

    // Keep track of lowest depth reached in this rep
    if (this.currentState !== 'STANDING' && this.currentState !== 'TOP') {
      this.minAngleRecordedInRep = Math.min(this.minAngleRecordedInRep, primaryAngle);
    }

    let repCompleted = false;

    switch (this.currentState) {
      case 'STANDING':
      case 'TOP':
        // Trigger descent when angle breaks threshold with hysteresis
        if (primaryAngle < thresholds.triggerDescent) {
          this.currentState = 'DESCENDING';
          this.currentRepStartTime = timestamp;
          this.descentStartTime = timestamp;
          this.minAngleRecordedInRep = primaryAngle;
        }
        break;

      case 'DESCENDING':
        // Reached bottom depth threshold
        if (primaryAngle <= thresholds.bottomDepth) {
          this.currentState = 'BOTTOM';
          this.bottomStartTime = timestamp;
        }
        // User aborted descent without reaching bottom and returned to top
        else if (primaryAngle > thresholds.start) {
          this.currentState = this.exerciseDef.type === 'pushup' ? 'TOP' : 'STANDING';
        }
        break;

      case 'BOTTOM':
        // Starts pushing back up
        if (primaryAngle > thresholds.triggerAscent) {
          this.currentState = 'ASCENDING';
          this.ascentStartTime = timestamp;
        }
        break;

      case 'ASCENDING':
        // Fully returned to lockout/top position -> REP FINISHED!
        if (primaryAngle >= thresholds.completion) {
          const totalDuration = (timestamp - this.currentRepStartTime) / 1000;

          // Reject noise / flicker reps shorter than 0.8 seconds
          if (totalDuration >= 0.8) {
            this.repCount += 1;
            repCompleted = true;

            const eccentric = Math.max(0.3, (this.bottomStartTime - this.descentStartTime) / 1000);
            const concentric = Math.max(0.3, (timestamp - this.ascentStartTime) / 1000);

            const repRecord: SingleRepData = {
              repNumber: this.repCount,
              durationSec: Math.round(totalDuration * 10) / 10,
              eccentricDurationSec: Math.round(eccentric * 10) / 10,
              concentricDurationSec: Math.round(concentric * 10) / 10,
              maxDepthAngle: Math.round(this.minAngleRecordedInRep),
              scoreBreakdown: {
                alignment: 90,
                depth: this.minAngleRecordedInRep <= thresholds.bottomDepth ? 100 : 75,
                stability: 88,
                symmetry: angles.kneeSymmetry || angles.elbowSymmetry || 90,
                tempo: eccentric >= 1.2 ? 95 : 75,
                overall: 88,
              },
              issues: [],
            };

            this.repHistory.push(repRecord);
          }

          this.currentState = this.exerciseDef.type === 'pushup' ? 'TOP' : 'STANDING';
          this.minAngleRecordedInRep = 180;
        }
        break;

      default:
        this.currentState = this.getInitialState();
        break;
    }

    return {
      repCompleted,
      stateChanged: prev !== this.currentState,
      state: this.currentState,
    };
  }
}
