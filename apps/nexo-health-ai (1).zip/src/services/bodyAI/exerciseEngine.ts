import {
  ExerciseType,
  FormScoreBreakdown,
  JointAngles,
  LiveFeedback,
  PoseLandmarks,
  RepState,
  SingleRepData,
  WorkoutSessionSummary,
} from '../../types/bodyAI';
import { ExerciseDefinition } from '../../types/exercise';
import { calculateAllJointAngles } from './angleCalculator';
import { getExerciseDefinition } from './exercises';
import { FormAnalyzer } from './formAnalyzer';
import { RepCounterStateMachine } from './repCounter';

export interface EngineFrameOutput {
  angles: JointAngles;
  repState: RepState;
  repCount: number;
  durationSec: number;
  formScore: FormScoreBreakdown;
  liveFeedback?: LiveFeedback;
  repCompleted: boolean;
}

export class ExerciseEngine {
  private exerciseDef: ExerciseDefinition;
  private repCounter: RepCounterStateMachine;
  private formAnalyzer: FormAnalyzer;
  private sessionStartTime: number = 0;
  private isPaused: boolean = false;
  private pauseAccumulatedMs: number = 0;
  private pauseStartTimestamp: number = 0;

  constructor(exerciseType: ExerciseType) {
    this.exerciseDef = getExerciseDefinition(exerciseType);
    this.repCounter = new RepCounterStateMachine(this.exerciseDef);
    this.formAnalyzer = new FormAnalyzer(this.exerciseDef);
  }

  public setExercise(exerciseType: ExerciseType): void {
    this.exerciseDef = getExerciseDefinition(exerciseType);
    this.repCounter = new RepCounterStateMachine(this.exerciseDef);
    this.formAnalyzer = new FormAnalyzer(this.exerciseDef);
    this.reset();
  }

  public getDefinition(): ExerciseDefinition {
    return this.exerciseDef;
  }

  public startSession(): void {
    this.sessionStartTime = Date.now();
    this.isPaused = false;
    this.pauseAccumulatedMs = 0;
    this.pauseStartTimestamp = 0;
    this.repCounter.reset();
    this.formAnalyzer.reset();
  }

  public pauseSession(): void {
    if (!this.isPaused) {
      this.isPaused = true;
      this.pauseStartTimestamp = Date.now();
    }
  }

  public resumeSession(): void {
    if (this.isPaused) {
      this.isPaused = false;
      this.pauseAccumulatedMs += Date.now() - this.pauseStartTimestamp;
      this.pauseStartTimestamp = 0;
    }
  }

  public isSessionPaused(): boolean {
    return this.isPaused;
  }

  public reset(): void {
    this.sessionStartTime = 0;
    this.isPaused = false;
    this.pauseAccumulatedMs = 0;
    this.pauseStartTimestamp = 0;
    this.repCounter.reset();
    this.formAnalyzer.reset();
  }

  public getElapsedSeconds(): number {
    if (this.sessionStartTime === 0) return 0;
    const now = this.isPaused ? this.pauseStartTimestamp : Date.now();
    return Math.max(0, Math.floor((now - this.sessionStartTime - this.pauseAccumulatedMs) / 1000));
  }

  /**
   * Process a single incoming frame of pose landmarks.
   */
  public processFrame(landmarks: Partial<PoseLandmarks>): EngineFrameOutput {
    if (this.isPaused || this.sessionStartTime === 0) {
      const angles = calculateAllJointAngles(landmarks);
      return {
        angles,
        repState: this.repCounter.getState(),
        repCount: this.repCounter.getRepCount(),
        durationSec: this.getElapsedSeconds(),
        formScore: {
          alignment: 100,
          depth: 100,
          stability: 100,
          symmetry: 100,
          tempo: 100,
          overall: 100,
        },
        repCompleted: false,
      };
    }

    const timestamp = Date.now();

    // 1. Calculate joint angles
    const angles = calculateAllJointAngles(landmarks);

    // 2. Update Rep Counter FSM
    const { repCompleted, state } = this.repCounter.update(angles, timestamp);

    // 3. Analyze form metrics & feedback
    const { score, feedback } = this.formAnalyzer.analyzeFrame(angles, state, timestamp);

    const durationSec =
      this.exerciseDef.mode === 'duration'
        ? this.repCounter.getPlankHoldDurationSec()
        : this.getElapsedSeconds();

    return {
      angles,
      repState: state,
      repCount: this.repCounter.getRepCount(),
      durationSec,
      formScore: score,
      liveFeedback: feedback,
      repCompleted,
    };
  }

  /**
   * Generates a comprehensive, compact workout session summary.
   */
  public finishSession(): WorkoutSessionSummary {
    const repsHistory = this.repCounter.getRepHistory();
    const durationSeconds = this.getElapsedSeconds();
    const totalReps = this.repCounter.getRepCount();
    const { averageScore, scoreBreakdown } = this.formAnalyzer.summarizeSessionScores(repsHistory);
    const detectedIssues = this.formAnalyzer.getSessionIssues();

    // Estimated metabolic calories: MET * weight * time
    // Squats ~ 5.5 METs, Push-ups ~ 4.0 METs, Planks ~ 3.5 METs
    const met = this.exerciseDef.type === 'squat' ? 5.5 : this.exerciseDef.type === 'pushup' ? 4.5 : 3.8;
    const calories = Math.max(3, Math.round(((met * 3.5 * 68) / 200) * (durationSeconds / 60)));

    return {
      id: `workout_${Date.now()}`,
      exerciseType: this.exerciseDef.type,
      exerciseName: this.exerciseDef.name,
      startTime: new Date(this.sessionStartTime).toISOString(),
      endTime: new Date().toISOString(),
      durationSeconds,
      totalReps,
      formScore: averageScore,
      scoreBreakdown,
      repsData: repsHistory,
      detectedIssues,
      caloriesBurnedEstimate: calories,
    };
  }

  /**
   * Formats compact metrics JSON for optional Gemini AI Coaching (DO NOT send video frames).
   */
  public static createCompactGeminiPayload(summary: WorkoutSessionSummary): {
    exercise: string;
    reps: number;
    durationSeconds: number;
    formScore: number;
    scoreBreakdown: FormScoreBreakdown;
    detectedIssues: string[];
    repsDetailSummary: Array<{
      rep: number;
      durationSec: number;
      depthAngle: number;
      score: number;
    }>;
  } {
    return {
      exercise: summary.exerciseName,
      reps: summary.totalReps,
      durationSeconds: summary.durationSeconds,
      formScore: summary.formScore,
      scoreBreakdown: summary.scoreBreakdown,
      detectedIssues: summary.detectedIssues,
      repsDetailSummary: summary.repsData.map((r) => ({
        rep: r.repNumber,
        durationSec: r.durationSec,
        depthAngle: r.maxDepthAngle,
        score: r.scoreBreakdown.overall,
      })),
    };
  }
}
