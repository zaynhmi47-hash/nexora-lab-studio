import { calculateAngle, calculateDistance, calculateSymmetry } from './angleCalculator';
import { FormAnalyzer } from './formAnalyzer';
import { getExerciseDefinition } from './exercises';
import { RepCounterStateMachine } from './repCounter';
import { CalibrationEvaluator } from './calibration';
import { PoseLandmarks, JointAngles, PosePoint } from '../../types/bodyAI';

export interface TestResultItem {
  id: string;
  name: string;
  category: 'math' | 'state_transitions' | 'edge_cases' | 'calibration';
  passed: boolean;
  message: string;
  details?: Record<string, unknown>;
}

export interface BodyAITestSuiteReport {
  timestamp: string;
  totalTests: number;
  passedTests: number;
  failedTests: number;
  results: TestResultItem[];
}

export function runBodyAITestSuite(): BodyAITestSuiteReport {
  const results: TestResultItem[] = [];

  // 1. Math Tests: calculateAngle()
  try {
    // 90 degree right angle: (0, 1) -> (0, 0) -> (1, 0)
    const a: PosePoint = { x: 0, y: 1 };
    const b: PosePoint = { x: 0, y: 0 };
    const c: PosePoint = { x: 1, y: 0 };
    const angle90 = calculateAngle(a, b, c);
    const passed90 = Math.abs(angle90 - 90) < 0.5;
    results.push({
      id: 'math_angle_90',
      name: 'calculateAngle: 90° Perpendicular Angle',
      category: 'math',
      passed: passed90,
      message: passed90 ? `Calculated exact 90° (${angle90}°)` : `Expected 90°, got ${angle90}°`,
    });

    // 180 degree straight line: (0, 0) -> (1, 0) -> (2, 0)
    const p1: PosePoint = { x: 0, y: 0 };
    const p2: PosePoint = { x: 1, y: 0 };
    const p3: PosePoint = { x: 2, y: 0 };
    const angle180 = calculateAngle(p1, p2, p3);
    const passed180 = Math.abs(angle180 - 180) < 0.5;
    results.push({
      id: 'math_angle_180',
      name: 'calculateAngle: 180° Collinear Straight Line',
      category: 'math',
      passed: passed180,
      message: passed180 ? `Calculated exact 180° (${angle180}°)` : `Expected 180°, got ${angle180}°`,
    });
  } catch (err: any) {
    results.push({
      id: 'math_angle_err',
      name: 'calculateAngle: Execution Check',
      category: 'math',
      passed: false,
      message: `Error running calculateAngle: ${err.message}`,
    });
  }

  // 2. Math Tests: calculateDistance()
  try {
    const pA: PosePoint = { x: 0, y: 0 };
    const pB: PosePoint = { x: 3, y: 4 }; // 3-4-5 triangle
    const dist = calculateDistance(pA, pB);
    const passedDist = Math.abs(dist - 5) < 0.01;
    results.push({
      id: 'math_distance_euclidean',
      name: 'calculateDistance: 2D Euclidean Distance (3-4-5 Triangle)',
      category: 'math',
      passed: passedDist,
      message: passedDist ? `Calculated exact distance 5.0 (${dist})` : `Expected 5.0, got ${dist}`,
    });
  } catch (err: any) {
    results.push({
      id: 'math_distance_err',
      name: 'calculateDistance: Execution Check',
      category: 'math',
      passed: false,
      message: `Error: ${err.message}`,
    });
  }

  // 3. Math Tests: calculateSymmetry()
  try {
    const sym100 = calculateSymmetry(90, 90);
    const symLower = calculateSymmetry(90, 110);
    const passedSym = sym100 === 100 && symLower < 100 && symLower > 0;
    results.push({
      id: 'math_symmetry',
      name: 'calculateSymmetry: Angular Symmetry Function',
      category: 'math',
      passed: passedSym,
      message: passedSym
        ? `Identical angles = 100%, 20° asymmetry = ${symLower}%`
        : `Unexpected symmetry results: sym100=${sym100}, symLower=${symLower}`,
    });
  } catch (err: any) {
    results.push({
      id: 'math_symmetry_err',
      name: 'calculateSymmetry: Execution Check',
      category: 'math',
      passed: false,
      message: `Error: ${err.message}`,
    });
  }

  // 4. Math Tests: calculateFormScore()
  try {
    const weights = { alignment: 0.25, depth: 0.25, stability: 0.2, symmetry: 0.15, tempo: 0.15 };
    const breakdown = { alignment: 100, depth: 100, stability: 100, symmetry: 100, tempo: 100 };
    const score100 = FormAnalyzer.computeWeightedOverallScore(breakdown, weights);

    const breakdownMixed = { alignment: 80, depth: 60, stability: 90, symmetry: 70, tempo: 80 };
    const expected = Math.round(80 * 0.25 + 60 * 0.25 + 90 * 0.2 + 70 * 0.15 + 80 * 0.15);
    const scoreMixed = FormAnalyzer.computeWeightedOverallScore(breakdownMixed, weights);
    const passedScore = score100 === 100 && scoreMixed === expected;

    results.push({
      id: 'math_form_score',
      name: 'calculateFormScore: Configurable Weighted Overall Scoring',
      category: 'math',
      passed: passedScore,
      message: passedScore
        ? `Perfect form = 100%, Mixed form = ${scoreMixed}% (expected ${expected}%)`
        : `Score mismatch: score100=${score100}, scoreMixed=${scoreMixed}, expected=${expected}`,
    });
  } catch (err: any) {
    results.push({
      id: 'math_score_err',
      name: 'calculateFormScore: Execution Check',
      category: 'math',
      passed: false,
      message: `Error: ${err.message}`,
    });
  }

  // 5. State Machine Transition: Squat (STANDING -> DESCENDING -> BOTTOM -> ASCENDING -> STANDING -> REP + 1)
  try {
    const squatDef = getExerciseDefinition('squat');
    const fsm = new RepCounterStateMachine(squatDef);

    const dummyAngles = (knee: number): JointAngles => ({
      leftKneeAngle: knee,
      rightKneeAngle: knee,
      leftElbowAngle: 170,
      rightElbowAngle: 170,
      leftHipAngle: knee,
      rightHipAngle: knee,
      leftShoulderAngle: 90,
      rightShoulderAngle: 90,
      torsoAngle: 15,
      hipSagAngle: 175,
      neckAngle: 170,
      kneeSymmetry: 100,
      elbowSymmetry: 100,
    });

    let t = 1000;
    fsm.update(dummyAngles(170), t); // STANDING
    const s1 = fsm.getState();

    t += 300;
    fsm.update(dummyAngles(130), t); // DESCENDING
    const s2 = fsm.getState();

    t += 600;
    fsm.update(dummyAngles(85), t); // BOTTOM
    const s3 = fsm.getState();

    t += 400;
    fsm.update(dummyAngles(135), t); // ASCENDING
    const s4 = fsm.getState();

    t += 400;
    const res5 = fsm.update(dummyAngles(170), t); // STANDING -> REP + 1
    const s5 = fsm.getState();
    const reps = fsm.getRepCount();

    const passedSquat =
      s1 === 'STANDING' &&
      s2 === 'DESCENDING' &&
      s3 === 'BOTTOM' &&
      s4 === 'ASCENDING' &&
      s5 === 'STANDING' &&
      res5.repCompleted &&
      reps === 1;

    results.push({
      id: 'fsm_squat_cycle',
      name: 'State Machine: Squat Full Rep Cycle',
      category: 'state_transitions',
      passed: passedSquat,
      message: passedSquat
        ? 'Successfully completed STANDING->DESCENDING->BOTTOM->ASCENDING->STANDING (Rep Count = 1)'
        : `State sequence mismatch: s1=${s1}, s2=${s2}, s3=${s3}, s4=${s4}, s5=${s5}, reps=${reps}`,
    });
  } catch (err: any) {
    results.push({
      id: 'fsm_squat_err',
      name: 'State Machine: Squat Exception',
      category: 'state_transitions',
      passed: false,
      message: `Error: ${err.message}`,
    });
  }

  // 6. State Machine Transition: Push-Up (TOP -> DESCENDING -> BOTTOM -> ASCENDING -> TOP -> REP + 1)
  try {
    const pushupDef = getExerciseDefinition('pushup');
    const fsm = new RepCounterStateMachine(pushupDef);

    const dummyPushupAngles = (elbow: number): JointAngles => ({
      leftKneeAngle: 175,
      rightKneeAngle: 175,
      leftElbowAngle: elbow,
      rightElbowAngle: elbow,
      leftHipAngle: 175,
      rightHipAngle: 175,
      leftShoulderAngle: 80,
      rightShoulderAngle: 80,
      torsoAngle: 85,
      hipSagAngle: 175,
      neckAngle: 170,
      kneeSymmetry: 100,
      elbowSymmetry: 100,
    });

    let t = 2000;
    fsm.update(dummyPushupAngles(165), t); // TOP
    const s1 = fsm.getState();

    t += 300;
    fsm.update(dummyPushupAngles(120), t); // DESCENDING
    const s2 = fsm.getState();

    t += 500;
    fsm.update(dummyPushupAngles(80), t); // BOTTOM
    const s3 = fsm.getState();

    t += 400;
    fsm.update(dummyPushupAngles(130), t); // ASCENDING
    const s4 = fsm.getState();

    t += 400;
    const res5 = fsm.update(dummyPushupAngles(165), t); // TOP -> REP + 1
    const s5 = fsm.getState();
    const reps = fsm.getRepCount();

    const passedPushup =
      s1 === 'TOP' &&
      s2 === 'DESCENDING' &&
      s3 === 'BOTTOM' &&
      s4 === 'ASCENDING' &&
      s5 === 'TOP' &&
      res5.repCompleted &&
      reps === 1;

    results.push({
      id: 'fsm_pushup_cycle',
      name: 'State Machine: Push-Up Full Rep Cycle',
      category: 'state_transitions',
      passed: passedPushup,
      message: passedPushup
        ? 'Successfully completed TOP->DESCENDING->BOTTOM->ASCENDING->TOP (Rep Count = 1)'
        : `Pushup sequence mismatch: s1=${s1}, s2=${s2}, s3=${s3}, s4=${s4}, s5=${s5}, reps=${reps}`,
    });
  } catch (err: any) {
    results.push({
      id: 'fsm_pushup_err',
      name: 'State Machine: Push-Up Exception',
      category: 'state_transitions',
      passed: false,
      message: `Error: ${err.message}`,
    });
  }

  // 7. State Machine Transition: Plank Duration Mode
  try {
    const plankDef = getExerciseDefinition('plank');
    const fsm = new RepCounterStateMachine(plankDef);

    const properPlank: JointAngles = {
      leftKneeAngle: 175,
      rightKneeAngle: 175,
      leftElbowAngle: 90,
      rightElbowAngle: 90,
      leftHipAngle: 175,
      rightHipAngle: 175,
      leftShoulderAngle: 90,
      rightShoulderAngle: 90,
      torsoAngle: 90,
      hipSagAngle: 175, // Perfect 175° spine line
      neckAngle: 175,
      kneeSymmetry: 100,
      elbowSymmetry: 100,
    };

    let t = 10000;
    fsm.update(properPlank, t);
    const sHolding = fsm.getState();

    t += 5000; // Hold for 5 seconds
    fsm.update(properPlank, t);
    const holdDuration = fsm.getPlankHoldDurationSec();

    const passedPlank = sHolding === 'HOLDING' && holdDuration >= 4;
    results.push({
      id: 'fsm_plank_duration',
      name: 'State Machine: Plank Hold Duration Tracker',
      category: 'state_transitions',
      passed: passedPlank,
      message: passedPlank
        ? `Correctly tracked holding state for ${holdDuration}s`
        : `Plank failed: state=${sHolding}, duration=${holdDuration}`,
    });
  } catch (err: any) {
    results.push({
      id: 'fsm_plank_err',
      name: 'State Machine: Plank Exception',
      category: 'state_transitions',
      passed: false,
      message: `Error: ${err.message}`,
    });
  }

  // 8. Edge Case: Repeated Threshold Crossing / Noisy Movement (Debounce Check)
  try {
    const squatDef = getExerciseDefinition('squat');
    const fsm = new RepCounterStateMachine(squatDef);

    const dummy = (knee: number): JointAngles => ({
      leftKneeAngle: knee,
      rightKneeAngle: knee,
      leftElbowAngle: 170,
      rightElbowAngle: 170,
      leftHipAngle: knee,
      rightHipAngle: knee,
      leftShoulderAngle: 90,
      rightShoulderAngle: 90,
      torsoAngle: 15,
      hipSagAngle: 175,
      neckAngle: 170,
      kneeSymmetry: 100,
      elbowSymmetry: 100,
    });

    // Rapidly oscillate around 139° - 141° threshold (standing jitter)
    let t = 50000;
    fsm.update(dummy(170), t);
    for (let i = 0; i < 20; i++) {
      t += 50;
      fsm.update(dummy(i % 2 === 0 ? 139 : 141), t);
    }
    const reps = fsm.getRepCount();
    const passedNoisy = reps === 0;

    results.push({
      id: 'edge_noisy_threshold_crossing',
      name: 'Robustness: Noise & Threshold Jitter Debouncing',
      category: 'edge_cases',
      passed: passedNoisy,
      message: passedNoisy
        ? 'Successfully prevented phantom repetitions during high-frequency threshold oscillation'
        : `Failed: phantom reps triggered (${reps} reps)`,
    });
  } catch (err: any) {
    results.push({
      id: 'edge_noisy_err',
      name: 'Robustness: Noise check Exception',
      category: 'edge_cases',
      passed: false,
      message: `Error: ${err.message}`,
    });
  }

  // 9. Edge Case: Invalid / Null Landmarks Handling
  try {
    const aNull: any = null;
    const bValid: PosePoint = { x: 0.5, y: 0.5 };
    const angleNull = calculateAngle(aNull, bValid, bValid);
    const distNull = calculateDistance(aNull, bValid);

    const passedNull = angleNull === 180 && distNull === 0;
    results.push({
      id: 'edge_invalid_landmarks',
      name: 'Robustness: Null / Undefined Landmark Graceful Fallback',
      category: 'edge_cases',
      passed: passedNull,
      message: passedNull
        ? 'Safely handled null points without crashing or producing NaN'
        : `Failed: angleNull=${angleNull}, distNull=${distNull}`,
    });
  } catch (err: any) {
    results.push({
      id: 'edge_invalid_err',
      name: 'Robustness: Null check exception',
      category: 'edge_cases',
      passed: false,
      message: `Error: ${err.message}`,
    });
  }

  // 10. Calibration Test: Low Visibility & Partial Body Checks
  try {
    const squatDef = getExerciseDefinition('squat');

    // Partial landmarks: missing legs
    const partialLandmarks: Partial<PoseLandmarks> = {
      nose: { x: 0.5, y: 0.2, visibility: 0.9 },
      leftShoulder: { x: 0.4, y: 0.3, visibility: 0.9 },
      rightShoulder: { x: 0.6, y: 0.3, visibility: 0.9 },
    };

    const calibResult = CalibrationEvaluator.evaluateCalibration(partialLandmarks, squatDef, false);
    const passedPartial = !calibResult.isReady && calibResult.status === 'PARTIAL_BODY';

    results.push({
      id: 'calib_partial_body',
      name: 'Calibration: Partial Body Detection Guard',
      category: 'calibration',
      passed: passedPartial,
      message: passedPartial
        ? `Correctly blocked workout and identified missing legs (${calibResult.missingLandmarks.length} landmarks)`
        : `Failed: isReady=${calibResult.isReady}, status=${calibResult.status}`,
    });
  } catch (err: any) {
    results.push({
      id: 'calib_test_err',
      name: 'Calibration: Test Exception',
      category: 'calibration',
      passed: false,
      message: `Error: ${err.message}`,
    });
  }

  const passedTests = results.filter((r) => r.passed).length;

  return {
    timestamp: new Date().toISOString(),
    totalTests: results.length,
    passedTests,
    failedTests: results.length - passedTests,
    results,
  };
}
