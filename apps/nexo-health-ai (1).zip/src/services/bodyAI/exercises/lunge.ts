import { ExerciseDefinition } from '../../../types/exercise';
import { JointAngles } from '../../../types/bodyAI';

export const LungeExercise: ExerciseDefinition = {
  type: 'lunge',
  name: 'Forward / Static Lunge',
  nameId: 'Lunge Kaki Depan',
  category: 'lower_body',
  mode: 'reps',
  targetMuscles: ['Quadriceps', 'Gluteus Maximus', 'Hamstrings', 'Calves', 'Core'],
  targetMusclesId: ['Paha Depan', 'Bokong', 'Paha Belakang', 'Betis', 'Keseimbangan Inti'],
  difficulty: 'intermediate',
  idealDistanceMeters: '2.0 - 2.5 m',
  requiredLandmarks: [
    'leftShoulder',
    'rightShoulder',
    'leftHip',
    'rightHip',
    'leftKnee',
    'rightKnee',
    'leftAnkle',
    'rightAnkle',
  ],
  cameraSetupAdvice: 'Position camera from the side to capture both legs clearly.',
  cameraSetupAdviceId: 'Posisikan kamera dari samping agar kedua kaki terlihat jelas.',
  targetRepAngleThresholds: {
    start: 160,
    triggerDescent: 140,
    bottomDepth: 95, // ~90-95 degrees front knee
    triggerAscent: 120,
    completion: 160,
  },
  weights: {
    alignment: 0.25,
    depth: 0.25,
    stability: 0.25,
    symmetry: 0.10,
    tempo: 0.15,
  },
  defaultTargetReps: 10,
  defaultTargetDurationSec: 60,
  rules: [
    {
      id: 'lunge_depth',
      name: 'Lunge Depth',
      weight: 0.35,
      description: 'Lead knee should bend to approximately 90 degrees.',
      check: (angles: JointAngles, state: string) => {
        const leadKnee = Math.min(angles.leftKneeAngle, angles.rightKneeAngle);
        if (state === 'BOTTOM') {
          if (leadKnee <= 95) {
            return { score: 100, feedback: 'Kedalaman lunge sangat baik!' };
          }
          return {
            score: 70,
            issue: 'Lunge kurang dalam',
            feedback: 'Turunkan lutut belakang mendekati lantai.',
          };
        }
        return { score: 90 };
      },
    },
    {
      id: 'lunge_torso_verticality',
      name: 'Upright Torso',
      weight: 0.35,
      description: 'Keep torso upright over the pelvis, avoiding forward lean.',
      check: (angles: JointAngles) => {
        if (angles.torsoAngle > 35) {
          return {
            score: 65,
            issue: 'Tubuh condong ke depan',
            feedback: 'Tegakkan badan dan pandangan lurus ke depan.',
          };
        }
        return { score: 95 };
      },
    },
    {
      id: 'lunge_balance',
      name: 'Pelvic Balance',
      weight: 0.30,
      description: 'Maintain steady hips without twisting laterally.',
      check: (angles: JointAngles) => {
        if (angles.torsoAngle > 40) {
          return {
            score: 60,
            issue: 'Keseimbangan goyang',
            feedback: 'Fokuskan tumpuan pada tumit kaki depan.',
          };
        }
        return { score: 95 };
      },
    },
  ],
};
