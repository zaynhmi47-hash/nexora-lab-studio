import { ExerciseDefinition } from '../../../types/exercise';
import { JointAngles } from '../../../types/bodyAI';

export const PushupExercise: ExerciseDefinition = {
  type: 'pushup',
  name: 'Standard Push-Up',
  nameId: 'Push-Up Standar',
  category: 'upper_body',
  mode: 'reps',
  targetMuscles: ['Pectoralis Major', 'Triceps Brachii', 'Anterior Deltoids', 'Core'],
  targetMusclesId: ['Otot Dada', 'Trisep', 'Bahu Depan', 'Otot Inti'],
  difficulty: 'intermediate',
  idealDistanceMeters: '2.0 - 2.5 m',
  requiredLandmarks: [
    'leftShoulder',
    'rightShoulder',
    'leftElbow',
    'rightElbow',
    'leftWrist',
    'rightWrist',
    'leftHip',
    'rightHip',
    'leftAnkle',
    'rightAnkle',
  ],
  cameraSetupAdvice: 'Position camera on the floor or low stool from the side view.',
  cameraSetupAdviceId: 'Letakkan kamera di lantai atau bangku rendah dari sudut samping.',
  targetRepAngleThresholds: {
    start: 155,
    triggerDescent: 135,
    bottomDepth: 90, // < 90 is chest-to-deck depth
    triggerAscent: 120,
    completion: 155,
  },
  weights: {
    alignment: 0.30,
    depth: 0.25,
    stability: 0.20,
    symmetry: 0.15,
    tempo: 0.10,
  },
  defaultTargetReps: 10,
  defaultTargetDurationSec: 60,
  rules: [
    {
      id: 'pushup_depth',
      name: 'Elbow Depth',
      weight: 0.35,
      description: 'Elbows should reach 90 degrees or less at the bottom.',
      check: (angles: JointAngles, state: string) => {
        const minElbow = Math.min(angles.leftElbowAngle, angles.rightElbowAngle);
        if (state === 'BOTTOM') {
          if (minElbow <= 92) {
            return { score: 100, feedback: 'Kedalaman push-up sangat baik!' };
          }
          return {
            score: 65,
            issue: 'Kedalaman push-up kurang',
            feedback: 'Turunkan dada lebih dekat ke lantai hingga siku 90°.',
          };
        }
        return { score: 90 };
      },
    },
    {
      id: 'pushup_spine_alignment',
      name: 'Spine & Hip Alignment',
      weight: 0.35,
      description: 'Keep body in a straight plank line from shoulder to ankle.',
      check: (angles: JointAngles) => {
        // Spine alignment: 165 - 180 degrees
        if (angles.hipSagAngle < 155) {
          return {
            score: 55,
            issue: 'Pinggul melorot (Hip Sagging)',
            feedback: 'Kencangkan otot perut dan bokong, jangan biarkan pinggul melorot.',
          };
        }
        if (angles.hipSagAngle > 195) {
          return {
            score: 60,
            issue: 'Pinggul terlalu tinggi (Hip Piking)',
            feedback: 'Turunkan pinggul agar tubuh membentuk garis lurus.',
          };
        }
        return { score: 95 };
      },
    },
    {
      id: 'pushup_elbow_symmetry',
      name: 'Elbow Symmetry',
      weight: 0.20,
      description: 'Both arms should push simultaneously and symmetrically.',
      check: (angles: JointAngles) => {
        if (angles.elbowSymmetry < 75) {
          return {
            score: 70,
            issue: 'Dorongan tangan tidak seimbang',
            feedback: 'Dorong lantai secara merata dengan kedua telapak tangan.',
          };
        }
        return { score: 95 };
      },
    },
  ],
};
