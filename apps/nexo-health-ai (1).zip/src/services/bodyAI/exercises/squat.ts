import { ExerciseDefinition } from '../../../types/exercise';
import { JointAngles } from '../../../types/bodyAI';

export const SquatExercise: ExerciseDefinition = {
  type: 'squat',
  name: 'Bodyweight Squat',
  nameId: 'Squat Beban Tubuh',
  category: 'lower_body',
  mode: 'reps',
  targetMuscles: ['Quadriceps', 'Gluteus Maximus', 'Hamstrings', 'Core'],
  targetMusclesId: ['Paha Depan (Quadriceps)', 'Bokong (Glutes)', 'Paha Belakang', 'Otot Inti'],
  difficulty: 'beginner',
  idealDistanceMeters: '2.0 - 2.5 m',
  requiredLandmarks: [
    'leftShoulder',
    'rightShoulder',
    'leftHip',
    'rightHip',
    'leftKnee',
    'rightKnee',
    'leftAnkle',
    'rightAnkle',
  ],
  cameraSetupAdvice: 'Position camera sideways or at 45° angle, full body visible.',
  cameraSetupAdviceId: 'Posisikan kamera dari samping atau sudut 45°, seluruh tubuh terlihat.',
  targetRepAngleThresholds: {
    start: 160,
    triggerDescent: 140,
    bottomDepth: 100, // < 100 is good depth (parallel or deep)
    triggerAscent: 120,
    completion: 160,
  },
  weights: {
    alignment: 0.25,
    depth: 0.25,
    stability: 0.20,
    symmetry: 0.15,
    tempo: 0.15,
  },
  defaultTargetReps: 12,
  defaultTargetDurationSec: 60,
  rules: [
    {
      id: 'squat_depth',
      name: 'Squat Depth',
      weight: 0.35,
      description: 'Knee angle at the bottom should reach 90-100 degrees for optimal glute & quad activation.',
      check: (angles: JointAngles, state: string) => {
        const minKnee = Math.min(angles.leftKneeAngle, angles.rightKneeAngle);
        if (state === 'BOTTOM') {
          if (minKnee <= 95) {
            return { score: 100, feedback: 'Kedalaman sempurna!' };
          }
          if (minKnee <= 110) {
            return { score: 80, feedback: 'Turunkan pinggul sedikit lebih rendah lagi.' };
          }
          return { score: 55, issue: 'Squat kurang dalam', feedback: 'Turunkan badan hingga paha sejajar lantai.' };
        }
        return { score: 90 };
      },
    },
    {
      id: 'squat_torso_stability',
      name: 'Torso Stability',
      weight: 0.25,
      description: 'Avoid excessive forward lean of the chest and spine.',
      check: (angles: JointAngles) => {
        if (angles.torsoAngle > 48) {
          return {
            score: 60,
            issue: 'Dada terlalu condong ke depan',
            feedback: 'Jaga dada tetap tegak dan aktifkan otot perut.',
          };
        }
        return { score: 95 };
      },
    },
    {
      id: 'squat_knee_symmetry',
      name: 'Knee Symmetry & Alignment',
      weight: 0.25,
      description: 'Ensure balanced distribution between left and right knees.',
      check: (angles: JointAngles) => {
        if (angles.kneeSymmetry < 75) {
          return {
            score: 65,
            issue: 'Beban lutut tidak simetris',
            feedback: 'Distribusikan beban seimbang pada kedua kaki.',
          };
        }
        return { score: 95 };
      },
    },
  ],
};
