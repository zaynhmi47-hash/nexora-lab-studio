import { ExerciseDefinition } from '../../../types/exercise';
import { JointAngles } from '../../../types/bodyAI';

export const PlankExercise: ExerciseDefinition = {
  type: 'plank',
  name: 'Forearm / High Plank',
  nameId: 'Plank Penguatan Inti',
  category: 'core',
  mode: 'duration',
  targetMuscles: ['Rectus Abdominis', 'Transverse Abdominis', 'Gluteals', 'Deltoids', 'Lower Back'],
  targetMusclesId: ['Otot Perut (Core)', 'Bokong', 'Bahu Depan', 'Punggung Bawah'],
  difficulty: 'beginner',
  idealDistanceMeters: '2.0 - 2.5 m',
  requiredLandmarks: [
    'leftShoulder',
    'rightShoulder',
    'leftElbow',
    'rightElbow',
    'leftHip',
    'rightHip',
    'leftAnkle',
    'rightAnkle',
  ],
  cameraSetupAdvice: 'Position camera on the floor or low surface from side profile.',
  cameraSetupAdviceId: 'Posisikan kamera di lantai dari samping sejajar tubuh.',
  targetRepAngleThresholds: {
    start: 165,
    triggerDescent: 165,
    bottomDepth: 175,
    triggerAscent: 165,
    completion: 165,
  },
  weights: {
    alignment: 0.40,
    depth: 0.0,
    stability: 0.35,
    symmetry: 0.15,
    tempo: 0.10,
  },
  defaultTargetReps: 1,
  defaultTargetDurationSec: 45,
  rules: [
    {
      id: 'plank_spine_alignment',
      name: 'Spine & Pelvic Neutral Line',
      weight: 0.50,
      description: 'Body must form a straight line from shoulders through hips to heels (165-180°).',
      check: (angles: JointAngles) => {
        if (angles.hipSagAngle < 155) {
          return {
            score: 50,
            issue: 'Pinggul melorot (Hip Sagging)',
            feedback: 'Kencangkan perut dan angkat pinggul sedikit agar punggung lurus.',
          };
        }
        if (angles.hipSagAngle > 195) {
          return {
            score: 60,
            issue: 'Pinggul terlalu naik (Hip Piking)',
            feedback: 'Turunkan pinggul sejajar dengan garis bahu dan tumit.',
          };
        }
        return { score: 100, feedback: 'Posisi plank sangat lurus & stabil!' };
      },
    },
    {
      id: 'plank_shoulder_stability',
      name: 'Shoulder & Elbow Stack',
      weight: 0.30,
      description: 'Elbows/hands directly underneath the shoulders for joint safety.',
      check: (angles: JointAngles) => {
        const avgShoulder = (angles.leftShoulderAngle + angles.rightShoulderAngle) / 2;
        if (avgShoulder < 60 || avgShoulder > 120) {
          return {
            score: 70,
            issue: 'Posisi bahu kurang vertikal',
            feedback: 'Posisikan siku tegak lurus tepat di bawah bahu.',
          };
        }
        return { score: 95 };
      },
    },
    {
      id: 'plank_symmetry',
      name: 'Lateral Balance',
      weight: 0.20,
      description: 'Balanced weight distribution between left and right sides.',
      check: (angles: JointAngles) => {
        if (angles.elbowSymmetry < 80) {
          return {
            score: 75,
            issue: 'Tumpuan lengan tidak seimbang',
            feedback: 'Tekan kedua lengan secara seimbang ke lantai.',
          };
        }
        return { score: 95 };
      },
    },
  ],
};
