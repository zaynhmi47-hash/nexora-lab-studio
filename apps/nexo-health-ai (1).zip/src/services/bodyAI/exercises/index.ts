import { ExerciseDefinition } from '../../../types/exercise';
import { ExerciseType } from '../../../types/bodyAI';
import { SquatExercise } from './squat';
import { PushupExercise } from './pushup';
import { LungeExercise } from './lunge';
import { PlankExercise } from './plank';

export const EXERCISE_REGISTRY: Record<ExerciseType, ExerciseDefinition> = {
  squat: SquatExercise,
  pushup: PushupExercise,
  lunge: LungeExercise,
  plank: PlankExercise,
};

export function getExerciseDefinition(type: ExerciseType): ExerciseDefinition {
  return EXERCISE_REGISTRY[type] || EXERCISE_REGISTRY.squat;
}

export function getAllExercises(): ExerciseDefinition[] {
  return Object.values(EXERCISE_REGISTRY);
}

export { SquatExercise, PushupExercise, LungeExercise, PlankExercise };
