/**
 * AI Meal Planner & Grocery List Aggregator
 * STEP 5 Architecture
 *
 * Generates personalized daily and weekly meal plans based on UserProfile context.
 * Aggregates ingredients into structured grocery shopping lists.
 */

import { MealPlan, Meal, GroceryItem, MealType } from '../../types/nutrition';
import { UserProfile } from '../../types';

export class MealPlannerService {
  /**
   * Generates a structured meal plan (daily or weekly).
   */
  public static async generateMealPlan(
    planType: 'daily' | 'weekly' = 'daily',
    userProfile: Partial<UserProfile> = {}
  ): Promise<MealPlan> {
    const isIndonesian = userProfile.language !== 'en';
    const targetCalories = userProfile.dailyCalorieTarget || 2000;
    const targetProtein = userProfile.dailyProteinTargetG || 120;
    const targetCarbs = userProfile.dailyCarbsTargetG || 220;
    const targetFat = userProfile.dailyFatTargetG || 60;

    const goal = userProfile.primaryGoal || 'fitness';
    const cuisinePrefs = userProfile.cuisinePreferences?.join(', ') || (isIndonesian ? 'Nusantara & Asia Sehat' : 'Balanced Global');
    const dietPrefs = userProfile.dietPreferences?.join(', ') || (isIndonesian ? 'Halal, Tinggi Protein' : 'High Protein');
    const foodsToAvoid = userProfile.foodsToAvoid?.join(', ') || (isIndonesian ? 'Tidak ada pantangan' : 'None');

    try {
      // Build prompt for Gemini structured generation
      const prompt = `Buat meal plan ${planType === 'daily' ? 'Harian (1 Hari)' : 'Mingguan'} yang terstruktur dan lezat.
Profil Pengguna:
- Bahasa: ${userProfile.language || 'id'}
- Target Kalori Harian: ~${targetCalories} kcal
- Target Makronutrien: Protein ~${targetProtein}g, Karbohidrat ~${targetCarbs}g, Lemak ~${targetFat}g
- Tujuan Kebugaran: ${goal}
- Preferensi Masakan: ${cuisinePrefs}
- Preferensi Diet: ${dietPrefs}
- Makanan Dihindari / Alergi: ${foodsToAvoid}

Format JSON yang dibutuhkan:
{
  "title": "Judul Rencana Menu Sehat",
  "meals": [
    {
      "type": "breakfast" | "lunch" | "dinner" | "snack",
      "name": "Nama Hidangan",
      "estimatedCalories": 450,
      "estimatedProtein": 30,
      "estimatedCarbs": 45,
      "estimatedFat": 12,
      "ingredients": ["Bahan 1 (takaran)", "Bahan 2 (takaran)"],
      "portionDesc": "1 porsi sedang",
      "cookingTimeMinutes": 15,
      "healthBenefits": "Manfaat kesehatan singkat"
    }
  ],
  "nutritionTips": ["Tips 1", "Tips 2"]
}`;

      const res = await fetch('/api/ai/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          requestType: 'nutrition',
          relevantContext: {
            userProfile: {
              name: userProfile.name,
              primaryGoal: goal,
              dailyCalorieTarget: targetCalories,
              cuisinePreferences: userProfile.cuisinePreferences,
              dietPreferences: userProfile.dietPreferences,
              foodsToAvoid: userProfile.foodsToAvoid,
            },
          },
          language: userProfile.language || 'id',
        }),
      });

      if (!res.ok) {
        throw new Error('Meal plan generation API error');
      }

      const data = await res.json();
      const planData = data.data?.structuredData || data.data;

      let meals: Meal[] = [];
      let planTitle = isIndonesian ? 'Rencana Menu Sehat & Berenergi' : 'Balanced Energy Meal Plan';
      let tips: string[] = [];

      if (Array.isArray(planData?.meals) && planData.meals.length > 0) {
        meals = planData.meals.map((m: any, idx: number) => ({
          id: `meal_${Date.now()}_${idx}`,
          type: (m.type || 'lunch') as MealType,
          name: m.name || (isIndonesian ? 'Hidangan Seimbang' : 'Balanced Dish'),
          estimatedCalories: Number(m.estimatedCalories) || 450,
          estimatedProtein: Number(m.estimatedProtein) || 25,
          estimatedCarbs: Number(m.estimatedCarbs) || 50,
          estimatedFat: Number(m.estimatedFat) || 15,
          ingredients: Array.isArray(m.ingredients) ? m.ingredients : ['Bahan segar'],
          portionDesc: m.portionDesc || '1 porsi',
          cookingTimeMinutes: Number(m.cookingTimeMinutes) || 20,
          healthBenefits: m.healthBenefits || 'Mendukung asupan harian optimal',
        }));
        planTitle = planData.title || planTitle;
        tips = Array.isArray(planData.nutritionTips) ? planData.nutritionTips : [];
      } else {
        // Safe structured fallback meals
        meals = this.getDefaultTemplateMeals(isIndonesian, goal, targetCalories);
      }

      const groceryItems = this.aggregateGroceryList(meals);

      return {
        id: `plan_${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        planType,
        title: planTitle,
        targetCalories,
        targetProtein,
        targetCarbs,
        targetFat,
        meals,
        nutritionTips: tips.length > 0 ? tips : [
          isIndonesian ? 'Minum 1 gelas air putih 15 menit sebelum makan.' : 'Drink 1 glass of water 15 minutes before meals.',
          isIndonesian ? 'Utamakan metode memasak kukus, panggang, atau tumis sedikit minyak.' : 'Favor steaming, grilling, or light sautéing.',
        ],
        groceryItems,
        generatedAt: new Date().toISOString(),
        disclaimer: isIndonesian
          ? 'Estimasi gizi menu ini bersifat panduan referensi, bukan resep medis klinis.'
          : 'Nutritional estimates are informational guidelines, not clinical prescriptions.',
      };
    } catch (err) {
      console.warn('Meal plan generation fallback:', err);
      const fallbackMeals = this.getDefaultTemplateMeals(isIndonesian, goal, targetCalories);
      return {
        id: `plan_${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        planType,
        title: isIndonesian ? 'Rencana Menu Padat Gizi Harian' : 'High-Nutrient Daily Meal Plan',
        targetCalories,
        targetProtein,
        targetCarbs,
        targetFat,
        meals: fallbackMeals,
        nutritionTips: [
          isIndonesian ? 'Konsumsi protein dalam setiap waktu makan utama.' : 'Include protein with each main meal.',
          isIndonesian ? 'Penuhi setengah piring dengan sayuran aneka warna.' : 'Fill half your plate with colorful vegetables.',
        ],
        groceryItems: this.aggregateGroceryList(fallbackMeals),
        generatedAt: new Date().toISOString(),
        disclaimer: isIndonesian
          ? 'Rencana makan ini dibuat secara lokal berbasis kebutuhan kalori harian Anda.'
          : 'This meal plan was generated locally based on your daily caloric targets.',
      };
    }
  }

  /**
   * Aggregates raw ingredients from all meals in a plan into categorized Grocery items.
   */
  public static aggregateGroceryList(meals: Meal[]): GroceryItem[] {
    const list: GroceryItem[] = [];
    const itemMap = new Map<string, { amount: string; category: GroceryItem['category']; meal: string }>();

    for (const meal of meals) {
      for (const rawIng of meal.ingredients) {
        const cleaned = rawIng.trim();
        if (!cleaned) continue;

        // Categorize based on keywords
        const lower = cleaned.toLowerCase();
        let category: GroceryItem['category'] = 'other';

        if (lower.includes('bayam') || lower.includes('sayur') || lower.includes('brokoli') || lower.includes('tomat') || lower.includes('wortel') || lower.includes('timun') || lower.includes('alpukat') || lower.includes('buah') || lower.includes('pisang') || lower.includes('berry') || lower.includes('salad') || lower.includes('lettuce')) {
          category = 'produce';
        } else if (lower.includes('ayam') || lower.includes('salmon') || lower.includes('ikan') || lower.includes('telur') || lower.includes('daging') || lower.includes('tempe') || lower.includes('tahu') || lower.includes('udang') || lower.includes('beef') || lower.includes('protein')) {
          category = 'protein';
        } else if (lower.includes('susu') || lower.includes('yogurt') || lower.includes('keju') || lower.includes('cheese') || lower.includes('butter')) {
          category = 'dairy';
        } else if (lower.includes('nasi') || lower.includes('oat') || lower.includes('gandum') || lower.includes('quinoa') || lower.includes('roti') || lower.includes('beras') || lower.includes('rice') || lower.includes('bread')) {
          category = 'grains';
        } else if (lower.includes('minyak') || lower.includes('olive oil') || lower.includes('kecap') || lower.includes('garam') || lower.includes('lada') || lower.includes('bumbu') || lower.includes('chia')) {
          category = 'pantry';
        }

        if (!itemMap.has(cleaned)) {
          itemMap.set(cleaned, { amount: '1 porsi/satuan', category, meal: meal.name });
        }
      }
    }

    let idx = 0;
    itemMap.forEach((val, name) => {
      list.push({
        id: `groc_${Date.now()}_${idx++}`,
        name,
        category: val.category,
        amount: val.amount,
        isChecked: false,
        sourceMeal: val.meal,
      });
    });

    return list;
  }

  /**
   * Provides baseline template meals tailored to language & goal.
   */
  private static getDefaultTemplateMeals(
    isIndonesian: boolean,
    goal: string,
    targetCalories: number
  ): Meal[] {
    if (isIndonesian) {
      return [
        {
          id: `meal_def_1`,
          type: 'breakfast',
          name: 'Oatmeal Pisang & Telur Rebus',
          estimatedCalories: Math.round(targetCalories * 0.25),
          estimatedProtein: 22,
          estimatedCarbs: 48,
          estimatedFat: 10,
          ingredients: ['Oatmeal instan 40g', 'Pisang ambon 1 buah', 'Telur rebus 2 butir', 'Susu rendah lemak 150ml'],
          portionDesc: '1 mangkuk oatmeal + 2 telur',
          cookingTimeMinutes: 10,
          healthBenefits: 'Karbohidrat kompleks lepas lambat & protein tinggi mengawali hari.',
        },
        {
          id: `meal_def_2`,
          type: 'lunch',
          name: 'Nasi Merah, Dada Ayam Bakar & Sayur Asem',
          estimatedCalories: Math.round(targetCalories * 0.38),
          estimatedProtein: 38,
          estimatedCarbs: 65,
          estimatedFat: 14,
          ingredients: ['Nasi merah 150g', 'Dada ayam tanpa kulit 150g', 'Sayur asem bening 1 mangkuk', 'Tempe bacem panggang 1 potong'],
          portionDesc: '1 piring lengkap',
          cookingTimeMinutes: 25,
          healthBenefits: 'Tinggi serat, isoflavon nabati, dan protein murni pembentuk otot.',
        },
        {
          id: `meal_def_3`,
          type: 'dinner',
          name: 'Tumis Tahu Brokoli & Ikan Salmon/Kembung Panggang',
          estimatedCalories: Math.round(targetCalories * 0.28),
          estimatedProtein: 32,
          estimatedCarbs: 35,
          estimatedFat: 12,
          ingredients: ['Ikan kembung/salmon fillet 130g', 'Brokoli hijau 100g', 'Tahu putih 1 potong besar', 'Minyak zaitun 1 sdt', 'Bawang putih & kecap rendah sodium'],
          portionDesc: '1 porsi makan malam ringan',
          cookingTimeMinutes: 20,
          healthBenefits: 'Asam lemak Omega-3 dan antioksidan untuk perbaikan seluler saat tidur.',
        },
        {
          id: `meal_def_4`,
          type: 'snack',
          name: 'Greek Yogurt & Buah Pepaya/Berry',
          estimatedCalories: Math.round(targetCalories * 0.09),
          estimatedProtein: 12,
          estimatedCarbs: 20,
          estimatedFat: 3,
          ingredients: ['Greek yogurt plain 100g', 'Potongan buah pepaya/berry 80g', 'Biji chia 1 sdt'],
          portionDesc: '1 mangkuk kecil',
          cookingTimeMinutes: 3,
          healthBenefits: 'Probiotik baik untuk mikrobioma usus dan serat pencernaan.',
        },
      ];
    }

    return [
      {
        id: `meal_def_en_1`,
        type: 'breakfast',
        name: 'Avocado Toast & Poached Eggs',
        estimatedCalories: Math.round(targetCalories * 0.25),
        estimatedProtein: 20,
        estimatedCarbs: 40,
        estimatedFat: 14,
        ingredients: ['Whole grain bread 2 slices', 'Ripe avocado 1/2', 'Eggs 2 large', 'Cherry tomatoes'],
        portionDesc: '2 toasts with poached eggs',
        cookingTimeMinutes: 12,
        healthBenefits: 'Monounsaturated healthy fats paired with bioavailable protein.',
      },
      {
        id: `meal_def_en_2`,
        type: 'lunch',
        name: 'Grilled Chicken Quinoa Salad Bowl',
        estimatedCalories: Math.round(targetCalories * 0.38),
        estimatedProtein: 40,
        estimatedCarbs: 55,
        estimatedFat: 15,
        ingredients: ['Grilled chicken breast 150g', 'Cooked quinoa 1 cup', 'Mixed baby greens 2 cups', 'Cucumber & bell peppers', 'Olive oil vinaigrette'],
        portionDesc: '1 large salad bowl',
        cookingTimeMinutes: 20,
        healthBenefits: 'Complete amino acid profile and high micronutrient density.',
      },
      {
        id: `meal_def_en_3`,
        type: 'dinner',
        name: 'Baked Salmon, Sweet Potato & Steamed Asparagus',
        estimatedCalories: Math.round(targetCalories * 0.28),
        estimatedProtein: 34,
        estimatedCarbs: 38,
        estimatedFat: 14,
        ingredients: ['Wild salmon fillet 140g', 'Roasted sweet potato 1 medium', 'Steamed asparagus spears 1 cup', 'Lemon wedge & sea salt'],
        portionDesc: '1 dinner plate',
        cookingTimeMinutes: 25,
        healthBenefits: 'Rich in EPA/DHA Omega-3s and beta-carotene for recovery.',
      },
      {
        id: `meal_def_en_4`,
        type: 'snack',
        name: 'Greek Yogurt with Fresh Berries & Walnuts',
        estimatedCalories: Math.round(targetCalories * 0.09),
        estimatedProtein: 14,
        estimatedCarbs: 18,
        estimatedFat: 6,
        ingredients: ['Nonfat plain Greek yogurt 150g', 'Blueberries 50g', 'Crushed walnuts 15g'],
        portionDesc: '1 snack cup',
        cookingTimeMinutes: 2,
        healthBenefits: 'Gut microbiome friendly probiotics and slow-digesting casein.',
      },
    ];
  }
}
