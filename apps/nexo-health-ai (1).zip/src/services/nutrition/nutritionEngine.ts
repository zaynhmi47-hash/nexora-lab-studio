/**
 * Pure Deterministic Nutrition Engine
 * Performs all arithmetic, aggregation, and rule-based insights locally on-device.
 * Zero Gemini calls are used for basic math.
 */

import { FoodEntry, NutritionSummary, MealSummary, MealType, NutritionInsight } from '../../types/nutrition';
import { UserProfile } from '../../types';

export class NutritionEngine {
  /**
   * Calculates the full daily nutrition summary and progress against targets.
   */
  public static calculateDailySummary(
    entries: FoodEntry[],
    targetCalories: number = 2000,
    targetProtein: number = 120,
    targetCarbs: number = 220,
    targetFat: number = 60,
    dateString?: string
  ): NutritionSummary {
    const todayStr = dateString || new Date().toISOString().split('T')[0];
    const dayEntries = entries.filter((e) => e.createdAt.startsWith(todayStr));

    const breakfastSummary = this.calculateMealSummary(dayEntries, 'breakfast');
    const lunchSummary = this.calculateMealSummary(dayEntries, 'lunch');
    const dinnerSummary = this.calculateMealSummary(dayEntries, 'dinner');
    const snackSummary = this.calculateMealSummary(dayEntries, 'snack');

    let totalCalories = 0;
    let totalProtein = 0;
    let totalCarbs = 0;
    let totalFat = 0;
    let totalFiber = 0;
    let totalSodium = 0;

    for (const entry of dayEntries) {
      totalCalories += Math.round(Number(entry.estimatedCalories) || 0);
      totalProtein += Math.round(Number(entry.estimatedProtein) || 0);
      totalCarbs += Math.round(Number(entry.estimatedCarbs) || 0);
      totalFat += Math.round(Number(entry.estimatedFat) || 0);
      totalFiber += Math.round(Number(entry.estimatedFiber) || 0);
      totalSodium += Math.round(Number(entry.estimatedSodium) || 0);
    }

    const safeTargetCal = Math.max(1, targetCalories);
    const safeTargetProt = Math.max(1, targetProtein);
    const safeTargetCarb = Math.max(1, targetCarbs);
    const safeTargetFat = Math.max(1, targetFat);

    return {
      date: todayStr,
      calories: totalCalories,
      protein: totalProtein,
      carbs: totalCarbs,
      fat: totalFat,
      fiber: totalFiber,
      sodium: totalSodium,
      targetCalories: safeTargetCal,
      targetProtein: safeTargetProt,
      targetCarbs: safeTargetCarb,
      targetFat: safeTargetFat,
      mealsBreakdown: {
        breakfast: breakfastSummary,
        lunch: lunchSummary,
        dinner: dinnerSummary,
        snack: snackSummary,
      },
      calorieProgressPercent: Math.min(150, Math.round((totalCalories / safeTargetCal) * 100)),
      proteinProgressPercent: Math.min(150, Math.round((totalProtein / safeTargetProt) * 100)),
      carbsProgressPercent: Math.min(150, Math.round((totalCarbs / safeTargetCarb) * 100)),
      fatProgressPercent: Math.min(150, Math.round((totalFat / safeTargetFat) * 100)),
    };
  }

  /**
   * Calculates subtotal metrics for a specific meal category.
   */
  public static calculateMealSummary(entries: FoodEntry[], mealType: MealType): MealSummary {
    const mealItems = entries.filter((e) => e.mealType === mealType);
    let totalCalories = 0;
    let totalProtein = 0;
    let totalCarbs = 0;
    let totalFat = 0;

    for (const item of mealItems) {
      totalCalories += Math.round(Number(item.estimatedCalories) || 0);
      totalProtein += Math.round(Number(item.estimatedProtein) || 0);
      totalCarbs += Math.round(Number(item.estimatedCarbs) || 0);
      totalFat += Math.round(Number(item.estimatedFat) || 0);
    }

    return {
      mealType,
      totalCalories,
      totalProtein,
      totalCarbs,
      totalFat,
      entryCount: mealItems.length,
      items: mealItems,
    };
  }

  /**
   * Computes macronutrient caloric percentage split.
   * Protein = 4 kcal/g, Carbs = 4 kcal/g, Fat = 9 kcal/g.
   */
  public static calculateMacroPercentages(proteinG: number, carbsG: number, fatG: number): {
    proteinPct: number;
    carbsPct: number;
    fatPct: number;
  } {
    const pCal = proteinG * 4;
    const cCal = carbsG * 4;
    const fCal = fatG * 9;
    const totalCal = pCal + cCal + fCal;

    if (totalCal <= 0) {
      return { proteinPct: 0, carbsPct: 0, fatPct: 0 };
    }

    return {
      proteinPct: Math.round((pCal / totalCal) * 100),
      carbsPct: Math.round((cCal / totalCal) * 100),
      fatPct: Math.round((fCal / totalCal) * 100),
    };
  }

  /**
   * Generates rule-based, educational nutrition insights without medical claims.
   */
  public static generateNutritionInsights(
    summary: NutritionSummary,
    profile: Partial<UserProfile> = {}
  ): NutritionInsight[] {
    const isId = profile.language !== 'en';
    const insights: NutritionInsight[] = [];
    const nowIso = new Date().toISOString();

    // 1. Protein consistency check
    if (summary.protein >= summary.targetProtein * 0.9) {
      insights.push({
        id: `ins_protein_${Date.now()}_1`,
        type: 'positive',
        title: isId ? 'Konsistensi Asupan Protein' : 'Protein Target Achieved',
        message: isId
          ? `Bagus! Anda telah mencapai ${summary.protein}g dari target ${summary.targetProtein}g protein harian, mendukung pemulihan otot dan rasa kenyang.`
          : `Great work! You reached ${summary.protein}g of your ${summary.targetProtein}g protein target, supporting muscle recovery and satiety.`,
        category: 'protein',
        actionableTip: isId
          ? 'Pertahankan distribusi protein merata di tiap waktu makan.'
          : 'Keep distributing your protein evenly across your meals.',
        timestamp: nowIso,
      });
    } else if (summary.protein < summary.targetProtein * 0.5 && summary.calories > summary.targetCalories * 0.5) {
      insights.push({
        id: `ins_protein_${Date.now()}_2`,
        type: 'suggestion',
        title: isId ? 'Tingkatkan Porsi Protein' : 'Boost Protein Intake',
        message: isId
          ? `Asupan protein hari ini (${summary.protein}g) masih di bawah 50% target. Menambahkan sumber seperti telur, tempe, tahu, atau ayam tanpa kulit dapat membantu.`
          : `Your protein intake (${summary.protein}g) is below 50% of your target. Consider adding eggs, tofu, tempeh, or lean chicken.`,
        category: 'protein',
        actionableTip: isId
          ? 'Coba tambahkan cemilan berprotein tinggi seperti yogurt atau kacang panggang.'
          : 'Try adding a high-protein snack such as Greek yogurt or roasted nuts.',
        timestamp: nowIso,
      });
    }

    // 2. Calorie distribution balance
    const totalMealsLogged =
      (summary.mealsBreakdown.breakfast.entryCount > 0 ? 1 : 0) +
      (summary.mealsBreakdown.lunch.entryCount > 0 ? 1 : 0) +
      (summary.mealsBreakdown.dinner.entryCount > 0 ? 1 : 0);

    if (totalMealsLogged >= 3) {
      insights.push({
        id: `ins_balance_${Date.now()}_3`,
        type: 'positive',
        title: isId ? 'Distribusi Makanan Teratur' : 'Balanced Meal Schedule',
        message: isId
          ? 'Anda mencatat sarapan, makan siang, dan makan malam secara teratur hari ini. Pola makan terjadwal membantu menjaga stabilitas energi harian.'
          : 'You logged regular meals across breakfast, lunch, and dinner. Regular meal pacing supports stable all-day energy levels.',
        category: 'timing',
        timestamp: nowIso,
      });
    } else if (totalMealsLogged === 1 && summary.calories > 800) {
      insights.push({
        id: `ins_timing_${Date.now()}_4`,
        type: 'neutral',
        title: isId ? 'Jadwal Porsi Makanan' : 'Meal Pacing Note',
        message: isId
          ? 'Sebagian besar kalori terkonsentrasi dalam 1 waktu makan. Membagi porsi ke 2-3 sesi dapat mempermudah proses pencernaan.'
          : 'Most calories are concentrated in a single meal. Spacing nutrition into 2-3 meals can support digestion and steady energy.',
        category: 'timing',
        timestamp: nowIso,
      });
    }

    // 3. Calorie range notice
    if (summary.calories > summary.targetCalories * 1.15) {
      insights.push({
        id: `ins_cal_${Date.now()}_5`,
        type: 'warning',
        title: isId ? 'Estimasi Kalori di Atas Target' : 'Calories Over Target',
        message: isId
          ? `Total kalori (${summary.calories} kcal) melebihi target (${summary.targetCalories} kcal). Ini wajar terjadi sesekali, utamakan porsi sayuran dan air putih untuk sisa hari.`
          : `Total calories (${summary.calories} kcal) exceeded your target (${summary.targetCalories} kcal). Balance the rest of your day with fresh veggies and water.`,
        category: 'calories',
        actionableTip: isId
          ? 'Gunakan piring lebih kecil dan perbanyak minum air putih sebelum makan.'
          : 'Drink a glass of water before meals to assist natural portion control.',
        timestamp: nowIso,
      });
    } else if (summary.calories > 0 && summary.calories <= summary.targetCalories) {
      insights.push({
        id: `ins_cal_${Date.now()}_6`,
        type: 'positive',
        title: isId ? 'Kalori Terkendali Baik' : 'Caloric Range in Zone',
        message: isId
          ? `Asupan kalori harian Anda berada dalam kisaran target ideal (${summary.calories} / ${summary.targetCalories} kcal).`
          : `Your daily calorie intake is right on track within your target range (${summary.calories} / ${summary.targetCalories} kcal).`,
        category: 'calories',
        timestamp: nowIso,
      });
    }

    // 4. Default welcoming insight if no entries
    if (insights.length === 0) {
      insights.push({
        id: `ins_empty_${Date.now()}`,
        type: 'neutral',
        title: isId ? 'Mulai Catat Makanan Anda' : 'Start Logging Your Meals',
        message: isId
          ? 'Catat sarapan, makan siang, atau camilan Anda untuk melihat analisis makronutrien dan rekomendasi pola gizi harian.'
          : 'Log your breakfast, lunch, or snacks to view real-time macronutrient breakdown and healthy pacing insights.',
        category: 'balance',
        timestamp: nowIso,
      });
    }

    return insights;
  }
}
