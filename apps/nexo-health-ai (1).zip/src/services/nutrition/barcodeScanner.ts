/**
 * Barcode Lookup Service Interface
 * STEP 5 Prototype Architecture
 *
 * Provides lookupFoodByBarcode(barcode) with sample catalog and extensible interface.
 * Explicitly identifies all barcode results as sample catalog / mock data.
 */

import { BarcodeProduct, FoodEntry, MealType } from '../../types/nutrition';

export const SAMPLE_BARCODE_DATABASE: Record<string, BarcodeProduct> = {
  // Indonesian & Global Grocery Staples
  '8996001301014': {
    barcode: '8996001301014',
    name: 'Oatmeal Instan Utuh',
    brand: 'Quaker Oats',
    servingAmount: 35,
    servingUnit: 'g',
    estimatedCalories: 140,
    estimatedProtein: 4,
    estimatedCarbs: 24,
    estimatedFat: 3,
    estimatedFiber: 3.5,
    estimatedSodium: 0,
    category: 'grains',
    isSampleMock: true,
  },
  '8992753210012': {
    barcode: '8992753210012',
    name: 'Susu UHT Rendah Lemak High Calcium',
    brand: 'Ultra Milk Low Fat',
    servingAmount: 250,
    servingUnit: 'ml',
    estimatedCalories: 120,
    estimatedProtein: 8,
    estimatedCarbs: 12,
    estimatedFat: 3,
    estimatedSodium: 110,
    category: 'dairy',
    isSampleMock: true,
  },
  '8998866200451': {
    barcode: '8998866200451',
    name: 'Greek Yogurt Plain Tanpa Gula',
    brand: 'Biokul Greek',
    servingAmount: 100,
    servingUnit: 'g',
    estimatedCalories: 95,
    estimatedProtein: 10,
    estimatedCarbs: 4,
    estimatedFat: 4,
    estimatedSodium: 45,
    category: 'dairy',
    isSampleMock: true,
  },
  '8993175538019': {
    barcode: '8993175538019',
    name: 'Roti Gandum Utuh (Whole Wheat)',
    brand: 'Sari Roti Double Soft Gandum',
    servingAmount: 2,
    servingUnit: 'lembar',
    estimatedCalories: 160,
    estimatedProtein: 6,
    estimatedCarbs: 30,
    estimatedFat: 2,
    estimatedFiber: 4,
    estimatedSodium: 180,
    category: 'grains',
    isSampleMock: true,
  },
  '8992388123456': {
    barcode: '8992388123456',
    name: 'Tempe Kedelai Organik Segar',
    brand: 'Warung Sehat',
    servingAmount: 100,
    servingUnit: 'g',
    estimatedCalories: 190,
    estimatedProtein: 19,
    estimatedCarbs: 9,
    estimatedFat: 11,
    estimatedFiber: 6,
    estimatedSodium: 10,
    category: 'protein',
    isSampleMock: true,
  },
  '8999999123456': {
    barcode: '8999999123456',
    name: 'Whey Protein Isolate Vanila',
    brand: 'FitLife Nutrition',
    servingAmount: 30,
    servingUnit: 'scoop',
    estimatedCalories: 120,
    estimatedProtein: 25,
    estimatedCarbs: 2,
    estimatedFat: 1,
    estimatedSodium: 80,
    category: 'protein',
    isSampleMock: true,
  },
  '8991001234567': {
    barcode: '8991001234567',
    name: 'Kacang Almond Panggang Tanpa Garam',
    brand: 'East Bali Cashews / NutriNuts',
    servingAmount: 30,
    servingUnit: 'g',
    estimatedCalories: 175,
    estimatedProtein: 6,
    estimatedCarbs: 6,
    estimatedFat: 15,
    estimatedFiber: 3,
    estimatedSodium: 5,
    category: 'protein',
    isSampleMock: true,
  },
  '8997001928374': {
    barcode: '8997001928374',
    name: 'Dada Ayam Fillet Segar',
    brand: 'Fresh Farm Chicken',
    servingAmount: 150,
    servingUnit: 'g',
    estimatedCalories: 165,
    estimatedProtein: 35,
    estimatedCarbs: 0,
    estimatedFat: 3,
    estimatedSodium: 75,
    category: 'protein',
    isSampleMock: true,
  },
};

export class BarcodeService {
  /**
   * Looks up product nutrition data by barcode string.
   * Uses local prototype catalog in Step 5.
   */
  public static async lookupFoodByBarcode(barcode: string): Promise<BarcodeProduct | null> {
    // Simulate short network latency for realism
    await new Promise((resolve) => setTimeout(resolve, 300));

    const cleanCode = barcode.trim();
    if (SAMPLE_BARCODE_DATABASE[cleanCode]) {
      return { ...SAMPLE_BARCODE_DATABASE[cleanCode] };
    }

    // Dynamic fallback for any uncatalogued barcode in mock mode
    if (cleanCode.length >= 6) {
      return {
        barcode: cleanCode,
        name: `Produk Kemasan #${cleanCode.slice(-4)}`,
        brand: 'Sample Brand (Mock Data)',
        servingAmount: 100,
        servingUnit: 'g',
        estimatedCalories: 150,
        estimatedProtein: 5,
        estimatedCarbs: 20,
        estimatedFat: 5,
        estimatedFiber: 2,
        estimatedSodium: 100,
        category: 'other',
        isSampleMock: true,
      };
    }

    return null;
  }

  /**
   * Converts a BarcodeProduct to a FoodEntry ready for confirmation/logging.
   */
  public static convertToFoodEntry(
    product: BarcodeProduct,
    mealType: MealType = 'lunch'
  ): Omit<FoodEntry, 'id' | 'createdAt'> {
    return {
      name: `${product.name} ${product.brand ? `(${product.brand})` : ''}`,
      mealType,
      servingAmount: product.servingAmount,
      servingUnit: product.servingUnit,
      estimatedCalories: product.estimatedCalories,
      estimatedProtein: product.estimatedProtein,
      estimatedCarbs: product.estimatedCarbs,
      estimatedFat: product.estimatedFat,
      estimatedFiber: product.estimatedFiber,
      estimatedSodium: product.estimatedSodium,
      source: 'barcode',
      barcode: product.barcode,
      notes: 'Estimasi nilai gizi dari database barcode sampel (Mock Data Step 5).',
      isVerified: false,
    };
  }

  /**
   * Returns list of sample barcodes for easy testing in UI.
   */
  public static getSampleBarcodes(): BarcodeProduct[] {
    return Object.values(SAMPLE_BARCODE_DATABASE);
  }
}
