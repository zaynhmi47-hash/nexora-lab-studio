/**
 * Comprehensive Nutrition AI Unit Test Suite
 * Validates arithmetic correctness, AI pipeline, fallback handlers, and safety guards.
 */

import { NutritionEngine } from './nutritionEngine';
import { BarcodeService } from './barcodeScanner';
import { FoodVisionAnalyzer } from './foodVisionAnalyzer';
import { MealPlannerService } from './mealPlanner';
import { FoodEntry } from '../../types/nutrition';

export interface NutritionTestResult {
  id: string;
  name: string;
  category: 'math' | 'fsm' | 'ai_pipeline' | 'safety' | 'input_validation';
  passed: boolean;
  message: string;
  details?: Record<string, any>;
}

export interface NutritionTestSuiteReport {
  totalTests: number;
  passedTests: number;
  failedTests: number;
  executedAt: string;
  results: NutritionTestResult[];
}

export function runNutritionTestSuite(): NutritionTestSuiteReport {
  const results: NutritionTestResult[] = [];
  const today = new Date().toISOString().split('T')[0];

  // TEST 1: Manual Food Entry
  try {
    const entry: FoodEntry = {
      id: 'test_1',
      name: 'Nasi Merah Organik',
      mealType: 'lunch',
      servingAmount: 150,
      servingUnit: 'g',
      estimatedCalories: 210,
      estimatedProtein: 5,
      estimatedCarbs: 45,
      estimatedFat: 1,
      source: 'manual',
      createdAt: `${today}T12:00:00.000Z`,
    };
    const summary = NutritionEngine.calculateDailySummary([entry], 2000, 120, 220, 60, today);
    const passed = summary.calories === 210 && summary.protein === 5 && summary.carbs === 45 && summary.fat === 1;
    results.push({
      id: 'TC_NUT_01',
      name: '1. Manual Food Entry Single Item Calculation',
      category: 'math',
      passed,
      message: passed
        ? 'Successfully mapped 1 manual entry into calories (210 kcal) and macros.'
        : `Calculation mismatch: expected 210 kcal, got ${summary.calories}`,
    });
  } catch (err: any) {
    results.push({ id: 'TC_NUT_01', name: '1. Manual Food Entry', category: 'math', passed: false, message: err.message });
  }

  // TEST 2: Multiple Foods Summation
  try {
    const entries: FoodEntry[] = [
      {
        id: 'test_2a',
        name: 'Dada Ayam',
        mealType: 'lunch',
        servingAmount: 150,
        servingUnit: 'g',
        estimatedCalories: 250,
        estimatedProtein: 40,
        estimatedCarbs: 0,
        estimatedFat: 5,
        source: 'manual',
        createdAt: `${today}T12:30:00.000Z`,
      },
      {
        id: 'test_2b',
        name: 'Sayur Bayam',
        mealType: 'lunch',
        servingAmount: 100,
        servingUnit: 'g',
        estimatedCalories: 40,
        estimatedProtein: 3,
        estimatedCarbs: 6,
        estimatedFat: 1,
        source: 'manual',
        createdAt: `${today}T12:31:00.000Z`,
      },
    ];
    const lunchSummary = NutritionEngine.calculateMealSummary(entries, 'lunch');
    const passed = lunchSummary.totalCalories === 290 && lunchSummary.totalProtein === 43 && lunchSummary.entryCount === 2;
    results.push({
      id: 'TC_NUT_02',
      name: '2. Multiple Foods Summation & Meal Grouping',
      category: 'math',
      passed,
      message: passed
        ? 'Aggregated 2 meal items correctly (290 kcal, 43g Protein, 2 count).'
        : `Sum error: got ${lunchSummary.totalCalories} kcal, ${lunchSummary.totalProtein}g protein`,
    });
  } catch (err: any) {
    results.push({ id: 'TC_NUT_02', name: '2. Multiple Foods Summation', category: 'math', passed: false, message: err.message });
  }

  // TEST 3: Daily Summary & Macro Percentages
  try {
    const macroPercentages = NutritionEngine.calculateMacroPercentages(30, 50, 15);
    // 30*4=120, 50*4=200, 15*9=135. Total=455.
    // Prot: 120/455 ~ 26%, Carbs: 200/455 ~ 44%, Fat: 135/455 ~ 30%
    const passed = macroPercentages.proteinPct > 20 && macroPercentages.carbsPct > 35 && macroPercentages.fatPct > 20;
    results.push({
      id: 'TC_NUT_03',
      name: '3. Caloric Macro Ratio Calculation',
      category: 'math',
      passed,
      message: passed
        ? `Macro split computed accurately: Protein ${macroPercentages.proteinPct}%, Carbs ${macroPercentages.carbsPct}%, Fat ${macroPercentages.fatPct}%.`
        : 'Macro percentage ratio calculation outside expected range',
    });
  } catch (err: any) {
    results.push({ id: 'TC_NUT_03', name: '3. Daily Summary & Macros', category: 'math', passed: false, message: err.message });
  }

  // TEST 4: AI Meal Analysis Pipeline (Candidate decomposition)
  try {
    const fallbackRes = FoodVisionAnalyzer.generateFallbackAnalysis(true);
    const passed =
      fallbackRes.candidateFoods.length >= 2 &&
      fallbackRes.overallEstimatedCalories > 0 &&
      fallbackRes.isEstimateNotice.length > 0;
    results.push({
      id: 'TC_NUT_04',
      name: '4. AI Food Photo Analysis & Candidate Extraction',
      category: 'ai_pipeline',
      passed,
      message: passed
        ? `Extracted ${fallbackRes.candidateFoods.length} candidate items with transparent non-exact estimate label.`
        : 'Failed candidate extraction pipeline',
    });
  } catch (err: any) {
    results.push({ id: 'TC_NUT_04', name: '4. AI Meal Analysis', category: 'ai_pipeline', passed: false, message: err.message });
  }

  // TEST 5: Meal Planning & Grocery Aggregator
  try {
    const dummyMeals = [
      {
        id: 'm1',
        type: 'breakfast' as const,
        name: 'Oatmeal Buah',
        estimatedCalories: 300,
        estimatedProtein: 15,
        estimatedCarbs: 50,
        estimatedFat: 5,
        ingredients: ['Oatmeal 40g', 'Pisang 1 buah', 'Susu UHT 200ml'],
      },
      {
        id: 'm2',
        type: 'lunch' as const,
        name: 'Ayam Panggang Brokoli',
        estimatedCalories: 500,
        estimatedProtein: 45,
        estimatedCarbs: 30,
        estimatedFat: 12,
        ingredients: ['Dada Ayam 150g', 'Brokoli 100g', 'Minyak Zaitun 1 sdt'],
      },
    ];
    const groceries = MealPlannerService.aggregateGroceryList(dummyMeals);
    const hasProduce = groceries.some((g) => g.category === 'produce');
    const hasProtein = groceries.some((g) => g.category === 'protein');
    const passed = groceries.length >= 4 && hasProduce && hasProtein;
    results.push({
      id: 'TC_NUT_05',
      name: '5. Meal Plan Ingredient Aggregator into Grocery List',
      category: 'ai_pipeline',
      passed,
      message: passed
        ? `Aggregated ${groceries.length} categorized grocery items (Produce, Protein, Dairy, Grains).`
        : 'Grocery aggregation failed to categorize items correctly',
    });
  } catch (err: any) {
    results.push({ id: 'TC_NUT_05', name: '5. Meal Planning', category: 'ai_pipeline', passed: false, message: err.message });
  }

  // TEST 6: Barcode Interface & Sample Lookup
  try {
    const sampleProduct = BarcodeService.convertToFoodEntry(
      {
        barcode: '8996001301014',
        name: 'Oatmeal Instan Utuh',
        servingAmount: 35,
        servingUnit: 'g',
        estimatedCalories: 140,
        estimatedProtein: 4,
        estimatedCarbs: 24,
        estimatedFat: 3,
        isSampleMock: true,
      },
      'breakfast'
    );
    const passed = sampleProduct.source === 'barcode' && sampleProduct.estimatedCalories === 140 && sampleProduct.isVerified === false;
    results.push({
      id: 'TC_NUT_06',
      name: '6. Barcode Lookup Service Interface & Safe Typing',
      category: 'input_validation',
      passed,
      message: passed
        ? 'Converted barcode catalog item into FoodEntry with explicit mock attribution.'
        : 'Barcode conversion failed',
    });
  } catch (err: any) {
    results.push({ id: 'TC_NUT_06', name: '6. Barcode Interface', category: 'input_validation', passed: false, message: err.message });
  }

  // TEST 7: Invalid Input Handling
  try {
    const invalidEntry: FoodEntry = {
      id: 'test_inv',
      name: 'Invalid Food',
      mealType: 'snack',
      servingAmount: -50, // negative amount
      servingUnit: 'g',
      estimatedCalories: -200, // negative calorie
      estimatedProtein: NaN as any,
      estimatedCarbs: null as any,
      estimatedFat: undefined as any,
      source: 'manual',
      createdAt: `${today}T15:00:00.000Z`,
    };
    const safeSummary = NutritionEngine.calculateDailySummary([invalidEntry], 2000, 120, 220, 60, today);
    const passed = !isNaN(safeSummary.calories) && safeSummary.calories <= 0 && !isNaN(safeSummary.protein);
    results.push({
      id: 'TC_NUT_07',
      name: '7. Defensive Sanitization of Invalid / NaN Inputs',
      category: 'safety',
      passed,
      message: passed
        ? 'Safely handled negative and NaN macro values without crashing arithmetic engine.'
        : 'Engine produced NaN or unstable state on invalid input',
    });
  } catch (err: any) {
    results.push({ id: 'TC_NUT_07', name: '7. Invalid Input', category: 'safety', passed: false, message: err.message });
  }

  // TEST 8: Gemini Offline Fallback & Safety Guard
  try {
    const insights = NutritionEngine.generateNutritionInsights(
      {
        date: today,
        calories: 2600, // over target
        protein: 140,
        carbs: 320,
        fat: 80,
        fiber: 25,
        sodium: 2100,
        targetCalories: 2000,
        targetProtein: 120,
        targetCarbs: 220,
        targetFat: 60,
        mealsBreakdown: {
          breakfast: { mealType: 'breakfast', totalCalories: 600, totalProtein: 30, totalCarbs: 70, totalFat: 20, entryCount: 1, items: [] },
          lunch: { mealType: 'lunch', totalCalories: 1000, totalProtein: 60, totalCarbs: 120, totalFat: 30, entryCount: 1, items: [] },
          dinner: { mealType: 'dinner', totalCalories: 800, totalProtein: 40, totalCarbs: 100, totalFat: 25, entryCount: 1, items: [] },
          snack: { mealType: 'snack', totalCalories: 200, totalProtein: 10, totalCarbs: 30, totalFat: 5, entryCount: 1, items: [] },
        },
        calorieProgressPercent: 130,
        proteinProgressPercent: 116,
        carbsProgressPercent: 145,
        fatProgressPercent: 133,
      },
      { language: 'id' }
    );
    // Ensure no medical diagnosis is generated and warning is educational
    const hasDiagnosis = insights.some((i) => i.message.toLowerCase().includes('diagnosis') || i.message.toLowerCase().includes('obat'));
    const hasPositive = insights.some((i) => i.type === 'positive');
    const passed = !hasDiagnosis && hasPositive;
    results.push({
      id: 'TC_NUT_08',
      name: '8. Educational Wellness Insights Without Medical Diagnosis',
      category: 'safety',
      passed,
      message: passed
        ? 'Generated educational insights without clinical diagnosis or prescriptive medication advice.'
        : 'Detected forbidden medical diagnosis terminology',
    });
  } catch (err: any) {
    results.push({ id: 'TC_NUT_08', name: '8. Gemini Offline Safety', category: 'safety', passed: false, message: err.message });
  }

  // TEST 9: Empty Food Diary Handling
  try {
    const emptySummary = NutritionEngine.calculateDailySummary([], 2000, 120, 220, 60, today);
    const emptyInsights = NutritionEngine.generateNutritionInsights(emptySummary, { language: 'id' });
    const passed =
      emptySummary.calories === 0 &&
      emptySummary.calorieProgressPercent === 0 &&
      emptyInsights.length > 0;
    results.push({
      id: 'TC_NUT_09',
      name: '9. Empty Food Diary State & Welcoming Starter Guidance',
      category: 'input_validation',
      passed,
      message: passed
        ? 'Handled empty logs gracefully with 0 totals and supportive onboarding insight.'
        : 'Failed empty state test',
    });
  } catch (err: any) {
    results.push({ id: 'TC_NUT_09', name: '9. Empty Diary', category: 'input_validation', passed: false, message: err.message });
  }

  // TEST 10: User Edits AI Estimate Before Saving
  try {
    const aiCandidate = {
      id: 'cand_1',
      name: 'Nasi Putih',
      confidence: 0.9,
      servingAmount: 150,
      servingUnit: 'g',
      estimatedCalories: 200,
      estimatedProtein: 4,
      estimatedCarbs: 44,
      estimatedFat: 1,
    };
    // User adjusts serving amount to 200g (+33%)
    const userAdjustedScale = 200 / aiCandidate.servingAmount;
    const finalLoggedEntry: FoodEntry = {
      id: 'entry_user_adjusted',
      name: aiCandidate.name,
      mealType: 'lunch',
      servingAmount: 200,
      servingUnit: 'g',
      estimatedCalories: Math.round(aiCandidate.estimatedCalories * userAdjustedScale),
      estimatedProtein: Math.round(aiCandidate.estimatedProtein * userAdjustedScale),
      estimatedCarbs: Math.round(aiCandidate.estimatedCarbs * userAdjustedScale),
      estimatedFat: Math.round(aiCandidate.estimatedFat * userAdjustedScale),
      source: 'ai_photo',
      createdAt: `${today}T13:00:00.000Z`,
      notes: 'Porsi disesuaikan pengguna dari estimasi foto AI',
    };
    const passed = finalLoggedEntry.servingAmount === 200 && finalLoggedEntry.estimatedCalories === 267 && finalLoggedEntry.source === 'ai_photo';
    results.push({
      id: 'TC_NUT_10',
      name: '10. User Edits AI Portion Estimate Before Commitment',
      category: 'ai_pipeline',
      passed,
      message: passed
        ? 'Verified user modification of AI candidate portion prior to final food log commitment.'
        : 'Portion adjustment formula error',
    });
  } catch (err: any) {
    results.push({ id: 'TC_NUT_10', name: '10. User Edits AI', category: 'ai_pipeline', passed: false, message: err.message });
  }

  const passedTests = results.filter((r) => r.passed).length;

  return {
    totalTests: results.length,
    passedTests,
    failedTests: results.length - passedTests,
    executedAt: new Date().toISOString(),
    results,
  };
}
