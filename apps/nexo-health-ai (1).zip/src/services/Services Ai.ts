import { GoogleGenAI } from "@google/genai";

export interface GeneratedExercise {
  exerciseName: string;
  sets: number;
  reps: string;
  rest: string;
  tips: string;
}

export const generateWorkoutPlan = async (
  userGoal: string,
  fitnessLevel: string,
  availableEquipment: string,
  fatigueLevel: string = "Normal"
): Promise<GeneratedExercise[]> => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      // Graceful fallback plan
      return [
        {
          exerciseName: "Dynamic Warm-up & Hip Mobility",
          sets: 2,
          reps: "45 detik",
          rest: "30 detik",
          tips: "Fokus pada rentang gerak terkendali dan pernapasan stabil.",
        },
        {
          exerciseName: userGoal.toLowerCase().includes("otot") ? "Dumbbell Goblet Squat" : "Bodyweight Circuit",
          sets: 3,
          reps: "10-12 reps",
          rest: "60 detik",
          tips: "Jaga dada tegak dan tumpuan pada seluruh telapak kaki.",
        },
        {
          exerciseName: "Romanian Deadlift (RDL)",
          sets: 3,
          reps: "10-12 reps",
          rest: "60 detik",
          tips: "Kunci punggung lurus dan dorong pinggul ke belakang.",
        },
        {
          exerciseName: "Plank Hold with Shoulder Tap",
          sets: 3,
          reps: "30-45 detik",
          rest: "45 detik",
          tips: "Jaga panggul tetap stabil dan tidak bergoyang.",
        }
      ];
    }

    const ai = new GoogleGenAI({ apiKey });
    const prompt = `Bertindaklah sebagai Pelatih Pribadi Profesional bersertifikat.
Data Pengguna:
- Tujuan: ${userGoal}
- Level: ${fitnessLevel}
- Alat: ${availableEquipment}
- Tingkat Kelelahan Hari Ini: ${fatigueLevel}

TUGAS: Buatkan 1 sesi latihan harian yang aman dan efektif.
Format output WAJIB JSON murni array of objects:
[
  {
    "exerciseName": "Nama Gerakan",
    "sets": 3,
    "reps": "10-12 reps",
    "rest": "60s",
    "tips": "Tips teknik presisi"
  }
]
Hanya kembalikan JSON tanpa markdown / pembuka.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    const text = response.text || "";
    const cleanJson = text.replace(/```json/g, "").replace(/```/g, "").trim();
    return JSON.parse(cleanJson);
  } catch (error) {
    console.error("Error generating workout:", error);
    return [
      {
        exerciseName: "Bodyweight Warmup & Core Activation",
        sets: 3,
        reps: "12 reps",
        rest: "45 detik",
        tips: "Kontrol tempo gerakan.",
      },
      {
        exerciseName: "Split Squat & Push-Up Superset",
        sets: 3,
        reps: "10 reps per sisi",
        rest: "60 detik",
        tips: "Stabilkan otot inti.",
      },
    ];
  }
};

export const startCBTSession = async (
  userMessage: string,
  sessionHistory: string[]
): Promise<string> => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return "Terima kasih sudah berbagi. Saya mendengarkan apa yang kamu rasakan. Ceritakan lebih lanjut apa yang memicu perasaan ini?";
    }

    const ai = new GoogleGenAI({ apiKey });
    const historyContext = sessionHistory.length > 0
      ? `Riwayat Percakapan Sebelumnya:\n${sessionHistory.join('\n')}`
      : "Ini adalah awal sesi.";

    const prompt = `Bertindaklah sebagai Terapis CBT (Cognitive Behavioral Therapy) yang hangat, empatik, dan profesional.
PEDOMAN UTAMA:
1. Dengarkan aktif dan validasi perasaan pengguna.
2. Bantu pengguna mengidentifikasi 'Distorsi Kognitif'.
3. Ajukan pertanyaan reflektif yang memberdayakan.
4. Gunakan bahasa Indonesia yang santai namun sopan.

${historyContext}
Pesan Pengguna Terakhir: "${userMessage}"
Berikan respons terapis yang ringkas (maksimal 3 kalimat).`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text || "Saya memahami perasaanmu. Apa yang bisa kita lakukan bersama untuk membantumu merasa lebih tenang sekarang?";
  } catch (error) {
    console.error("Error CBT Session:", error);
    return "Saya di sini untuk mendengarkan. Terus ceritakan apa yang sedang kamu rasakan.";
  }
};
