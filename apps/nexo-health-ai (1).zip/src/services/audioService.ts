// Web Audio Service using HTML5 Audio API for meditation, sleep, and workout tones
let currentAudio: HTMLAudioElement | null = null;

export const playMeditationAudio = async (uri: string): Promise<HTMLAudioElement | null> => {
  try {
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.currentTime = 0;
    }

    currentAudio = new Audio(uri);
    currentAudio.loop = true;
    await currentAudio.play();
    return currentAudio;
  } catch (error) {
    console.warn("Audio playback notice:", error);
    return null;
  }
};

export const stopAudio = async (): Promise<void> => {
  try {
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.currentTime = 0;
      currentAudio = null;
    }
  } catch (error) {
    console.warn("Audio stop error:", error);
  }
};
