import { AIRequest, AIRequestType } from '../../types/ai';
import { UserProfile } from '../../types';
import { getGeneralContext } from './context/generalContext';
import { getFitnessContext } from './context/fitnessContext';
import { getNutritionContext } from './context/nutritionContext';
import { getHealthContext } from './context/healthContext';
import { get_today_activity, get_recent_activity } from './tools/activityTools';
import { get_sleep_summary, get_nutrition_summary } from './tools/healthTools';
import { ModelTier } from './aiConfig';

export interface RoutedPromptPackage {
  requestType: AIRequestType;
  modelTier: ModelTier;
  relevantContext: Record<string, any>;
  supplementalToolData?: Record<string, any>;
  isPotentialEmergency: boolean;
}

// Emergency keywords in Indonesian and English
const EMERGENCY_KEYWORDS = [
  'chest pain', 'sakit dada', 'nyeri dada', 'sesak napas', 'shortness of breath',
  'pingsan', 'fainting', 'unconscious', 'mati rasa sebelah', 'stroke', 'heart attack',
  'serangan jantung', 'muntah darah', 'vomiting blood', 'seizure', 'kejang',
  'overdose', 'kebas mendadak', 'lumpuh mendadak', 'pendarahan hebat', 'severe bleeding'
];

const FITNESS_KEYWORDS = [
  'latihan', 'workout', 'olahraga', 'gym', 'squat', 'push up', 'otot', 'muscle',
  'cardio', 'dumbbells', 'pushup', 'reps', 'set', 'leg day', 'hiit', 'stretching',
  'pemanasan', 'tdee', 'form', 'postur latihan'
];

const NUTRITION_KEYWORDS = [
  'makan', 'diet', 'kalori', 'calorie', 'protein', 'karbo', 'lemak', 'fat',
  'sarapan', 'makan siang', 'dinner', 'makan malam', 'snack', 'gizi', 'nutrisi',
  'air minum', 'hidrasi', 'resep', 'food', 'meal'
];

const SLEEP_KEYWORDS = [
  'tidur', 'sleep', 'insomnia', 'begadang', 'ngantuk', 'lelah', 'fatigue',
  'circadian', 'rem sleep', 'deep sleep', 'bangun pagi', 'mimpi', 'hrv'
];

/**
 * Classifies user prompt into the most appropriate domain, extracts only
 * relevant context, and checks safety red flags.
 */
export async function routeRequest(
  request: AIRequest,
  profile: Partial<UserProfile>
): Promise<RoutedPromptPackage> {
  const queryLower = request.message.toLowerCase();

  // 1. Emergency triage check
  const isPotentialEmergency = EMERGENCY_KEYWORDS.some((kw) => queryLower.includes(kw));
  if (isPotentialEmergency) {
    return {
      requestType: 'emergency_check',
      modelTier: 'simple', // prioritize fastest possible response
      relevantContext: getGeneralContext(profile),
      isPotentialEmergency: true,
    };
  }

  // Explicit type override from UI prompt cards
  if (request.requestType) {
    return assemblePayloadForType(request.requestType, profile, queryLower);
  }

  // 2. Keyword heuristic classification
  if (FITNESS_KEYWORDS.some((kw) => queryLower.includes(kw))) {
    return assemblePayloadForType('fitness', profile, queryLower);
  }

  if (NUTRITION_KEYWORDS.some((kw) => queryLower.includes(kw))) {
    return assemblePayloadForType('nutrition', profile, queryLower);
  }

  if (SLEEP_KEYWORDS.some((kw) => queryLower.includes(kw))) {
    return assemblePayloadForType('sleep', profile, queryLower);
  }

  return assemblePayloadForType('general', profile, queryLower);
}

async function assemblePayloadForType(
  type: AIRequestType,
  profile: Partial<UserProfile>,
  query: string
): Promise<RoutedPromptPackage> {
  switch (type) {
    case 'fitness': {
      const fitnessCtx = getFitnessContext(profile);
      let toolData: Record<string, any> | undefined;
      // If user asks about their progress or today's activity, fetch verified tool data
      if (query.includes('hari ini') || query.includes('progres') || query.includes('perkembangan') || query.includes('today')) {
        const todayAct = await get_today_activity();
        const recentAct = await get_recent_activity();
        toolData = { todayActivity: todayAct, weeklyOverview: recentAct };
      }
      return {
        requestType: 'fitness',
        modelTier: 'general',
        relevantContext: fitnessCtx,
        supplementalToolData: toolData,
        isPotentialEmergency: false,
      };
    }

    case 'nutrition': {
      const nutritionCtx = getNutritionContext(profile);
      let toolData: Record<string, any> | undefined;
      if (query.includes('hari ini') || query.includes('makan') || query.includes('today')) {
        const nutSummary = await get_nutrition_summary();
        toolData = { nutritionSummary: nutSummary };
      }
      return {
        requestType: 'nutrition',
        modelTier: 'general',
        relevantContext: nutritionCtx,
        supplementalToolData: toolData,
        isPotentialEmergency: false,
      };
    }

    case 'sleep': {
      const healthCtx = getHealthContext(profile);
      let toolData: Record<string, any> | undefined;
      if (query.includes('tadi malam') || query.includes('tidur') || query.includes('last night')) {
        const sleepSummary = await get_sleep_summary();
        toolData = { sleepArchitecture: sleepSummary };
      }
      return {
        requestType: 'sleep',
        modelTier: 'general',
        relevantContext: healthCtx,
        supplementalToolData: toolData,
        isPotentialEmergency: false,
      };
    }

    case 'health':
    case 'general':
    default: {
      const generalCtx = getGeneralContext(profile);
      let toolData: Record<string, any> | undefined;
      if (query.includes('perkembangan') || query.includes('analisis') || query.includes('progress')) {
        const todayAct = await get_today_activity();
        const sleep = await get_sleep_summary();
        const nutrition = await get_nutrition_summary();
        toolData = { todayAct, sleep, nutrition };
      }
      return {
        requestType: 'general',
        modelTier: 'general',
        relevantContext: generalCtx,
        supplementalToolData: toolData,
        isPotentialEmergency: false,
      };
    }
  }
}
