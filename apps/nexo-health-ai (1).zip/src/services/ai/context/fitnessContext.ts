import { UserProfile, EquipmentType, PrimaryGoalType, ActivityLevelType } from '../../../types';

export interface FitnessAiContext {
  primaryGoal: PrimaryGoalType;
  activityLevel: ActivityLevelType;
  exerciseFrequency: number;
  equipment: EquipmentType[];
  weightKg: number;
  heightCm: number;
  language: string;
  aiTone: string;
}

/**
 * Extracts minimal, targeted fitness context for workout guidance and training queries.
 * Avoids sending medical history or unrelated data.
 */
export function getFitnessContext(profile: Partial<UserProfile>): FitnessAiContext {
  const goal = (profile.primaryGoal || (profile.fitnessGoal === 'weight_loss' ? 'weight_loss' : profile.fitnessGoal === 'muscle_gain' ? 'muscle_gain' : 'fitness')) as PrimaryGoalType;
  const equip: EquipmentType[] = profile.equipment && profile.equipment.length > 0 ? profile.equipment : ['none'];

  return {
    primaryGoal: goal,
    activityLevel: (profile.activityLevel || 'moderate') as ActivityLevelType,
    exerciseFrequency: profile.exerciseFrequency ?? 3,
    equipment: equip,
    weightKg: profile.weightKg || 65,
    heightCm: profile.heightCm || 170,
    language: profile.language || 'id',
    aiTone: profile.aiTone || 'friendly',
  };
}
