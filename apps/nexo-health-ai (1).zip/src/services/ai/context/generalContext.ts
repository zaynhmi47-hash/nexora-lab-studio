import { UserProfile } from '../../../types';

export interface GeneralAiContext {
  userName: string;
  age: number;
  gender: string;
  primaryGoal: string;
  secondaryGoals: string[];
  language: string;
  aiTone: string;
  units: string;
  sleepTargetHours: number;
}

/**
 * Extracts minimal, privacy-first general context for standard conversations.
 */
export function getGeneralContext(profile: Partial<UserProfile>): GeneralAiContext {
  return {
    userName: profile.name || 'Friend',
    age: profile.age || 25,
    gender: profile.gender || 'other',
    primaryGoal: profile.primaryGoal || (profile.fitnessGoal === 'weight_loss' ? 'weight_loss' : 'fitness'),
    secondaryGoals: profile.secondaryGoals || ['better_sleep'],
    language: profile.language || 'id',
    aiTone: profile.aiTone || 'friendly',
    units: profile.units || 'metric',
    sleepTargetHours: profile.sleepTargetHours || profile.dailySleepTargetHours || 7.5,
  };
}
