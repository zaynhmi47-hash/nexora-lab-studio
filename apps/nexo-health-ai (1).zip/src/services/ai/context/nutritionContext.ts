import { UserProfile, PrimaryGoalType, ActivityLevelType } from '../../../types';

export interface NutritionAiContext {
  primaryGoal: PrimaryGoalType;
  weightKg: number;
  heightCm: number;
  age: number;
  gender: string;
  activityLevel: ActivityLevelType;
  dailyCalorieTarget: number;
  dailyWaterTargetMl: number;
  language: string;
  aiTone: string;
}

/**
 * Extracts minimal, targeted nutrition context for meal planning and dietary questions.
 */
export function getNutritionContext(profile: Partial<UserProfile>): NutritionAiContext {
  const goal = (profile.primaryGoal || (profile.fitnessGoal === 'weight_loss' ? 'weight_loss' : 'fitness')) as PrimaryGoalType;

  return {
    primaryGoal: goal,
    weightKg: profile.weightKg || 65,
    heightCm: profile.heightCm || 170,
    age: profile.age || 25,
    gender: profile.gender || 'other',
    activityLevel: (profile.activityLevel || 'moderate') as ActivityLevelType,
    dailyCalorieTarget: profile.dailyCalorieTarget || 2000,
    dailyWaterTargetMl: profile.dailyWaterTargetMl || 2500,
    language: profile.language || 'id',
    aiTone: profile.aiTone || 'friendly',
  };
}
