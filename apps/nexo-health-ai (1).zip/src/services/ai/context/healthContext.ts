import { UserProfile } from '../../../types';

export interface HealthAiContext {
  sleepTargetHours: number;
  bedtime: string;
  wakeTime: string;
  dailyWaterTargetMl: number;
  secondaryGoals: string[];
  restingHeartRateBpm?: number;
  language: string;
  aiTone: string;
}

/**
 * Extracts minimal, targeted lifestyle & wellness context for sleep, recovery, and stress hygiene.
 */
export function getHealthContext(profile: Partial<UserProfile>): HealthAiContext {
  return {
    sleepTargetHours: profile.sleepTargetHours || profile.dailySleepTargetHours || 7.5,
    bedtime: profile.bedtime || '23:00',
    wakeTime: profile.wakeTime || '07:00',
    dailyWaterTargetMl: profile.dailyWaterTargetMl || 2500,
    secondaryGoals: (profile.secondaryGoals as string[]) || ['better_sleep', 'energy_boost'],
    restingHeartRateBpm: 65,
    language: profile.language || 'id',
    aiTone: profile.aiTone || 'friendly',
  };
}
