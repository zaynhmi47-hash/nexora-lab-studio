export interface SleepSummaryData {
  lastNightDurationHours: number;
  sleepQualityScore: number; // 0-100
  deepSleepMin: number;
  remSleepMin: number;
  lightSleepMin: number;
  bedtime: string;
  wakeTime: string;
  hrvAverageMs: number;
}

export interface NutritionSummaryData {
  caloriesConsumedToday: number;
  targetCalories: number;
  proteinGrams: number;
  targetProteinGrams: number;
  waterIntakeMl: number;
  targetWaterMl: number;
  loggedMealsCount: number;
  dietQualityRating: number; // 1-10
}

/**
 * Mock tool interface to fetch verified sleep architecture data.
 */
export async function get_sleep_summary(): Promise<SleepSummaryData> {
  return {
    lastNightDurationHours: 7.2,
    sleepQualityScore: 84,
    deepSleepMin: 95,
    remSleepMin: 110,
    lightSleepMin: 227,
    bedtime: '23:15',
    wakeTime: '06:30',
    hrvAverageMs: 58,
  };
}

/**
 * Mock tool interface to fetch verified daily nutrition metrics.
 */
export async function get_nutrition_summary(): Promise<NutritionSummaryData> {
  return {
    caloriesConsumedToday: 1650,
    targetCalories: 2100,
    proteinGrams: 98,
    targetProteinGrams: 130,
    waterIntakeMl: 1800,
    targetWaterMl: 2500,
    loggedMealsCount: 3,
    dietQualityRating: 8.5,
  };
}
