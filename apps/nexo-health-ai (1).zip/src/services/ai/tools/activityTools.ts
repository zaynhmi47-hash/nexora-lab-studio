export interface TodayActivityData {
  steps: number;
  activeMinutes: number;
  caloriesBurned: number;
  distanceKm: number;
  standHours: number;
  lastWorkout?: {
    type: string;
    durationMin: number;
    caloriesBurned: number;
    timestamp: string;
  };
}

export interface RecentActivitySummary {
  weeklyAverageSteps: number;
  weeklyActiveDays: number;
  totalWorkoutsThisWeek: number;
  completionRatePercent: number;
}

/**
 * Mock tool interface to fetch today's actual activity metrics.
 * In Step 3, returns verified structured activity data so AI never hallucinates numbers.
 */
export async function get_today_activity(): Promise<TodayActivityData> {
  return {
    steps: 6420,
    activeMinutes: 38,
    caloriesBurned: 340,
    distanceKm: 4.8,
    standHours: 9,
    lastWorkout: {
      type: 'Brisk Walking & Bodyweight Core',
      durationMin: 30,
      caloriesBurned: 180,
      timestamp: new Date().toISOString(),
    },
  };
}

/**
 * Mock tool interface to fetch recent activity history across the past 7 days.
 */
export async function get_recent_activity(): Promise<RecentActivitySummary> {
  return {
    weeklyAverageSteps: 7250,
    weeklyActiveDays: 4,
    totalWorkoutsThisWeek: 3,
    completionRatePercent: 85,
  };
}
