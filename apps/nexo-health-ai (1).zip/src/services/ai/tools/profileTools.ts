import { UserProfile } from '../../../types';
import { INITIAL_USER_PROFILE } from '../../../data/sampleData';

/**
 * Mock tool interface to safely read verified user profile data.
 */
export async function get_user_profile(customProfile?: Partial<UserProfile>): Promise<Partial<UserProfile>> {
  if (customProfile && customProfile.name) {
    return customProfile;
  }
  return INITIAL_USER_PROFILE;
}
