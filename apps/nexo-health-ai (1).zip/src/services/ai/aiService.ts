import { AIRequest, AIResponse, AIMessage, AIResponseType } from '../../types/ai';
import { UserProfile } from '../../types';
import { routeRequest } from './router';
import { AI_CONFIG, getModelForTier } from './aiConfig';
import { buildSystemInstruction } from './prompts/healthCoach';

/**
 * Main AI Health Coach service handling prompt assembly, sliding message windowing,
 * server API communication, and response transformation.
 */
export class AIHealthCoachService {
  /**
   * Generates an AI response for the given user message.
   */
  public static async generateResponse(
    request: AIRequest,
    profile: Partial<UserProfile> = {}
  ): Promise<AIResponse> {
    const rawMessage = (request.message || '').trim();
    if (!rawMessage) {
      return {
        messageId: `msg_${Date.now()}`,
        content: profile.language === 'en'
          ? 'Please enter a health or fitness question so I can assist you.'
          : 'Silakan ketik pertanyaan kesehatan atau kebugaran Anda agar saya dapat membantu.',
        type: 'clarification',
        followUpSuggestions: [
          profile.language === 'en' ? 'What workout should I do today?' : 'Latihan apa yang cocok hari ini?',
          profile.language === 'en' ? 'What should I eat?' : 'Apa yang sebaiknya saya makan?',
          profile.language === 'en' ? 'How to improve my sleep?' : 'Bagaimana meningkatkan kualitas tidur?',
        ],
      };
    }

    try {
      // 1. Route query and extract ONLY minimal relevant context
      const routePackage = await routeRequest(request, profile);
      const language = (profile.language || request.language || 'id');
      const aiTone = (profile.aiTone || request.aiTone || 'friendly');
      const systemInstruction = buildSystemInstruction(language, aiTone);
      const modelToUse = getModelForTier(routePackage.modelTier);

      // 2. Token Optimization: Windowing conversation history (last N messages)
      const windowedHistory = (request.conversationHistory || [])
        .slice(-AI_CONFIG.MAX_RECENT_MESSAGES_WINDOW)
        .map((m) => ({
          role: m.role,
          content: m.content,
        }));

      // 3. Dispatch to secure backend endpoint (/api/ai/coach)
      const payload = {
        message: rawMessage,
        requestType: routePackage.requestType,
        relevantContext: routePackage.relevantContext,
        supplementalToolData: routePackage.supplementalToolData,
        isPotentialEmergency: routePackage.isPotentialEmergency,
        history: windowedHistory,
        language,
        aiTone,
        modelName: modelToUse,
        systemInstruction,
      };

      const response = await fetch(AI_CONFIG.API_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      const resData = await response.json();
      if (!resData.success || !resData.data) {
        throw new Error(resData.error || 'Invalid response payload from AI Engine');
      }

      const data = resData.data;

      return {
        messageId: `ai_${Date.now()}`,
        content: data.content,
        type: (data.type || 'text') as AIResponseType,
        structuredData: data.structuredData,
        followUpSuggestions: data.followUpSuggestions || [],
        warnings: data.warnings || [],
        modelUsed: resData.modelUsed || modelToUse,
      };
    } catch (err: any) {
      console.warn('AI Health Coach request failed or offline, falling back to local safety handler:', err);
      return this.generateFallbackResponse(request, profile, err?.message);
    }
  }

  /**
   * Deterministic, safe fallback handler for network issues or test scenarios
   */
  private static generateFallbackResponse(
    request: AIRequest,
    profile: Partial<UserProfile>,
    errorDetail?: string
  ): AIResponse {
    const isIndonesian = profile.language !== 'en';
    const query = (request.message || '').toLowerCase();

    // Check emergency in fallback mode
    if (
      query.includes('dada') ||
      query.includes('chest') ||
      query.includes('sesak') ||
      query.includes('breath') ||
      query.includes('pingsan')
    ) {
      return {
        messageId: `ai_emerg_${Date.now()}`,
        content: isIndonesian
          ? 'PERHATIAN: Gejala yang Anda jelaskan berpotensi serius. AI Health Coach BUKAN pengganti dokter. Mohon segera beristirahat dalam posisi nyaman dan hubungi layanan medis darurat (119/112) atau kunjungi IGD terdekat.'
          : 'WARNING: The symptoms described may be critical. AI Health Coach is NOT a doctor. Please rest in a comfortable position and seek emergency medical attention (911/urgent care) immediately.',
        type: 'emergency_guidance',
        structuredData: {
          title: isIndonesian ? 'Peringatan Keselamatan Medis Darurat' : 'Urgent Medical Safety Warning',
          category: 'safety',
          urgencyLevel: 'critical_emergency',
          keyPoints: [
            isIndonesian ? 'Segera cari bantuan medis darurat' : 'Seek immediate emergency evaluation',
            isIndonesian ? 'Jangan mengemudi sendiri' : 'Do not drive yourself',
            isIndonesian ? 'Duduk atau berbaring dalam posisi aman' : 'Rest in a supportive seated position',
          ],
          actionItems: [
            isIndonesian ? 'Hubungi nomor darurat 119/112' : 'Call 911 or emergency services',
            isIndonesian ? 'Beritahu orang terdekat di sekitar Anda' : 'Notify someone nearby immediately',
          ],
          disclaimer: isIndonesian
            ? 'Bantuan edukasi kebugaran AI, bukan diagnosis medis.'
            : 'Informational wellness AI only, not a medical diagnosis.',
        },
        followUpSuggestions: [
          isIndonesian ? 'Nomor kontak darurat' : 'Emergency contacts',
          isIndonesian ? 'Apa yang harus dilakukan saat menunggu?' : 'What to do while waiting?',
        ],
      };
    }

    // Standard fallback when server is unreachable
    return {
      messageId: `ai_err_${Date.now()}`,
      content: isIndonesian
        ? 'Maaf, saya tidak dapat memproses permintaan tersebut saat ini. Silakan coba lagi.'
        : "Sorry, I couldn't process that request right now. Please try again.",
      type: 'warning',
      error: errorDetail || 'Request failed',
      followUpSuggestions: [
        isIndonesian ? 'Coba lagi' : 'Try Again',
        isIndonesian ? 'Latihan apa yang cocok hari ini?' : 'What workout should I do today?',
      ],
    };
  }
}
