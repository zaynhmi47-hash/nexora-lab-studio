/**
 * Configurable model identifiers for Health AI Gemini Integration.
 * Models can be switched or upgraded without modifying UI components.
 */
export const AI_CONFIG = {
  // Fast model for simple Q&A, greetings, follow-up clarification
  SIMPLE_MODEL: 'gemini-3.7-flash',
  
  // General health guidance, nutrition advice, workout recommendations
  GENERAL_MODEL: 'gemini-3.7-flash',
  
  // Deep biomechanics reasoning, complex multi-factorial triage
  COMPLEX_MODEL: 'gemini-3.7-flash',

  // Default parameters
  DEFAULT_TEMPERATURE: 0.3,
  
  // Token optimization: sliding window of messages sent to model
  MAX_RECENT_MESSAGES_WINDOW: 6,
  
  // Maximum summary tokens
  MAX_SUMMARY_ITEMS: 3,
  
  // Fallback endpoint for production/local proxy
  API_ENDPOINT: '/api/ai/coach',
};

export type ModelTier = 'simple' | 'general' | 'complex';

export function getModelForTier(tier: ModelTier = 'general'): string {
  switch (tier) {
    case 'simple':
      return AI_CONFIG.SIMPLE_MODEL;
    case 'complex':
      return AI_CONFIG.COMPLEX_MODEL;
    case 'general':
    default:
      return AI_CONFIG.GENERAL_MODEL;
  }
}
