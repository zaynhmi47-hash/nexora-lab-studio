import {
  DailyHealthRecord,
  WellnessScore,
  WellnessScoreComponents,
} from '../../types/health';

export interface WellnessEngineWeights {
  activity: number;
  sleep: number;
  nutrition: number;
  hydration: number;
  consistency: number;
}

export const DEFAULT_WELLNESS_WEIGHTS: WellnessEngineWeights = {
  activity: 0.25,
  sleep: 0.25,
  nutrition: 0.20,
  hydration: 0.15,
  consistency: 0.15,
};

export const WELLNESS_SCORE_DISCLAIMER =
  'Wellness Score is an educational estimate based on your tracked habits and is not a medical assessment.';

export const WELLNESS_SCORE_DISCLAIMER_ID =
  'Wellness Score adalah estimasi edukatif berdasarkan kebiasaan harian Anda dan bukan penilaian medis.';

/**
 * Calculates the Daily Wellness Score deterministically on-device without calling Gemini.
 * Bounded strictly between 0 and 100.
 */
export function calculateWellnessScore(
  record: Partial<DailyHealthRecord>,
  weights: WellnessEngineWeights = DEFAULT_WELLNESS_WEIGHTS,
  isIndonesian: boolean = false
): WellnessScore {
  // 1. Activity Component (0-100)
  let activityScore = 50; // default baseline if no goals configured
  let activityMsg = isIndonesian ? 'Belum ada aktivitas tercatat.' : 'No activity logged yet.';
  if (record.activity) {
    const stepsRatio = record.activity.stepsGoal > 0
      ? Math.min(record.activity.steps / record.activity.stepsGoal, 1.2)
      : 0;
    const activeMinRatio = record.activity.activeMinutesGoal > 0
      ? Math.min(record.activity.activeMinutes / record.activity.activeMinutesGoal, 1.2)
      : 0;

    const blendedActivity = (stepsRatio * 0.6 + activeMinRatio * 0.4) * 100;
    activityScore = Math.min(Math.max(Math.round(blendedActivity), 0), 100);

    if (activityScore >= 90) {
      activityMsg = isIndonesian
        ? `Luar biasa! ${record.activity.steps.toLocaleString()} langkah & ${record.activity.activeMinutes} mnt aktif melampaui target.`
        : `Outstanding! ${record.activity.steps.toLocaleString()} steps & ${record.activity.activeMinutes} active mins met your goals.`;
    } else if (activityScore >= 60) {
      activityMsg = isIndonesian
        ? `Bagus! ${record.activity.steps.toLocaleString()} langkah tercatat hari ini.`
        : `Good progress! ${record.activity.steps.toLocaleString()} steps recorded today.`;
    } else {
      activityMsg = isIndonesian
        ? `Tingkatkan gerak aktif untuk mencapai target ${record.activity.stepsGoal.toLocaleString()} langkah.`
        : `Add light movement to reach your ${record.activity.stepsGoal.toLocaleString()} steps goal.`;
    }
  }

  // 2. Sleep Component (0-100)
  let sleepScore = 60; // baseline
  let sleepMsg = isIndonesian ? 'Belum ada catatan durasi tidur.' : 'No sleep logged yet.';
  if (record.sleep && record.sleep.sleepDurationHours > 0) {
    const duration = record.sleep.sleepDurationHours;
    const goal = record.sleep.sleepGoalHours || 8.0;

    // Ideal duration window: 7 - 9 hours
    let durationScore = 100;
    if (duration < 6) {
      durationScore = Math.max(40, Math.round((duration / 6) * 70));
    } else if (duration > 10) {
      durationScore = 80;
    } else {
      const diff = Math.abs(duration - goal);
      durationScore = Math.max(70, Math.round(100 - diff * 15));
    }

    const consistency = record.sleep.sleepConsistencyScore || 75;
    sleepScore = Math.min(Math.max(Math.round(durationScore * 0.7 + consistency * 0.3), 0), 100);

    sleepMsg = isIndonesian
      ? `Durasi tidur Anda tercatat ${duration} jam (Target: ${goal} jam).`
      : `Your tracked sleep duration was ${duration} hours (Goal: ${goal}h).`;
  }

  // 3. Nutrition Component (0-100)
  let nutritionScore = 50;
  let nutritionMsg = isIndonesian ? 'Belum ada makanan dicatat.' : 'No meals logged yet.';
  if (record.nutrition) {
    const { caloriesConsumed, caloriesGoal, loggedMealsCount, proteinG } = record.nutrition;
    if (caloriesGoal > 0 && caloriesConsumed > 0) {
      const ratio = caloriesConsumed / caloriesGoal;
      let calorieScore = 100;
      if (ratio < 0.7) {
        calorieScore = Math.max(40, Math.round((ratio / 0.7) * 75));
      } else if (ratio > 1.3) {
        calorieScore = Math.max(40, Math.round(100 - (ratio - 1.3) * 100));
      } else {
        calorieScore = Math.round(100 - Math.abs(1 - ratio) * 60);
      }

      const mealFrequencyBonus = Math.min(loggedMealsCount * 10, 30);
      const proteinBonus = proteinG > 50 ? 10 : 0;

      nutritionScore = Math.min(Math.max(Math.round(calorieScore * 0.7 + mealFrequencyBonus + proteinBonus), 0), 100);

      nutritionMsg = isIndonesian
        ? `${caloriesConsumed} / ${caloriesGoal} kcal (${loggedMealsCount} kali makan dicatat).`
        : `${caloriesConsumed} / ${caloriesGoal} kcal (${loggedMealsCount} meal entries logged).`;
    } else if (loggedMealsCount > 0) {
      nutritionScore = 70;
      nutritionMsg = isIndonesian
        ? `${loggedMealsCount} menu tercatat hari ini.`
        : `${loggedMealsCount} food items logged today.`;
    }
  }

  // 4. Hydration Component (0-100)
  let hydrationScore = 50;
  let hydrationMsg = isIndonesian ? 'Belum ada konsumsi air dicatat.' : 'No water intake logged yet.';
  if (record.hydration) {
    const { waterIntakeMl, waterGoalMl } = record.hydration;
    if (waterGoalMl > 0) {
      const ratio = Math.min(waterIntakeMl / waterGoalMl, 1.2);
      hydrationScore = Math.min(Math.max(Math.round(ratio * 100), 0), 100);

      if (hydrationScore >= 100) {
        hydrationMsg = isIndonesian
          ? `Target hidrasi tercapai: ${(waterIntakeMl / 1000).toFixed(1)}L / ${(waterGoalMl / 1000).toFixed(1)}L!`
          : `Hydration target achieved: ${(waterIntakeMl / 1000).toFixed(1)}L / ${(waterGoalMl / 1000).toFixed(1)}L!`;
      } else {
        hydrationMsg = isIndonesian
          ? `${(waterIntakeMl / 1000).toFixed(1)}L tercapai dari target ${(waterGoalMl / 1000).toFixed(1)}L.`
          : `${(waterIntakeMl / 1000).toFixed(1)}L achieved of ${(waterGoalMl / 1000).toFixed(1)}L goal.`;
      }
    }
  }

  // 5. Consistency Component (0-100)
  let consistencyScore = 60;
  let consistencyMsg = isIndonesian ? 'Membangun ritme kebiasaan harian.' : 'Building daily habit rhythm.';
  const eventsCount = record.events ? record.events.length : 0;
  if (eventsCount > 0) {
    // Check diversity of events (workout, meal, water, sleep)
    const eventTypes = new Set(record.events?.map((e) => e.type));
    const varietyBonus = eventTypes.size * 18;
    const countBonus = Math.min(eventsCount * 5, 28);
    consistencyScore = Math.min(Math.max(varietyBonus + countBonus, 30), 100);

    consistencyMsg = isIndonesian
      ? `${eventsCount} aktivitas tercatat dalam ${eventTypes.size} kategori kesehatan.`
      : `${eventsCount} activities logged across ${eventTypes.size} health categories.`;
  }

  // Total Weighted Blend
  const totalWeight =
    weights.activity +
    weights.sleep +
    weights.nutrition +
    weights.hydration +
    weights.consistency;

  const rawOverall =
    (activityScore * weights.activity +
      sleepScore * weights.sleep +
      nutritionScore * weights.nutrition +
      hydrationScore * weights.hydration +
      consistencyScore * weights.consistency) /
    (totalWeight || 1);

  const finalScore = Math.min(Math.max(Math.round(rawOverall), 0), 100);

  let status: WellnessScore['status'] = 'fair';
  if (finalScore >= 85) status = 'optimal';
  else if (finalScore >= 70) status = 'good';
  else if (finalScore >= 50) status = 'fair';
  else status = 'needs_attention';

  const components: WellnessScoreComponents = {
    activity: activityScore,
    sleep: sleepScore,
    nutrition: nutritionScore,
    hydration: hydrationScore,
    consistency: consistencyScore,
  };

  return {
    score: finalScore,
    status,
    components,
    breakdownDetails: {
      activityMessage: activityMsg,
      sleepMessage: sleepMsg,
      nutritionMessage: nutritionMsg,
      hydrationMessage: hydrationMsg,
      consistencyMessage: consistencyMsg,
    },
    educationalDisclaimer: isIndonesian
      ? WELLNESS_SCORE_DISCLAIMER_ID
      : WELLNESS_SCORE_DISCLAIMER,
    lastCalculated: new Date().toISOString(),
  };
}
