import { DailyHealthRecord } from '../../types/health';
import { UserProfile } from '../../types';

export interface HabitConsistencyItem {
  id: string;
  name: string;
  nameEn: string;
  plannedTarget: number;
  completedCount: number;
  unit: string;
  percentage: number;
  statusText: string;
}

export interface ConsistencyReport {
  plannedHabits: number;
  completedHabits: number;
  percentage: number;
  summaryMessage: string;
  habits: HabitConsistencyItem[];
}

/**
 * Evaluates weekly habit adherence with purely non-shaming, constructive feedback.
 */
export function calculateHabitConsistency(
  records: DailyHealthRecord[],
  userProfile?: Partial<UserProfile>,
  isIndonesian: boolean = false
): ConsistencyReport {
  const recentDays = records.slice(-7);
  const totalDays = Math.max(recentDays.length, 1);

  // 1. Workouts Consistency (e.g. goal 3-4 days/week)
  const targetWorkouts = 3;
  let actualWorkouts = 0;
  for (const day of recentDays) {
    const hasWorkout = day.events?.some((e) => e.type === 'workout') || (day.activity?.activeMinutes >= 20);
    if (hasWorkout) actualWorkouts += 1;
  }
  const workoutPct = Math.min(Math.round((actualWorkouts / targetWorkouts) * 100), 100);

  // 2. Hydration Target Met Days
  const targetHydrationDays = 7;
  let actualHydrationDays = 0;
  for (const day of recentDays) {
    if (day.hydration && day.hydration.waterIntakeMl >= (day.hydration.waterGoalMl * 0.85)) {
      actualHydrationDays += 1;
    }
  }
  const hydrationPct = Math.min(Math.round((actualHydrationDays / targetHydrationDays) * 100), 100);

  // 3. Sleep Target Met Days
  const targetSleepDays = 7;
  let actualSleepDays = 0;
  for (const day of recentDays) {
    if (day.sleep && day.sleep.sleepDurationHours >= 6.5) {
      actualSleepDays += 1;
    }
  }
  const sleepPct = Math.min(Math.round((actualSleepDays / targetSleepDays) * 100), 100);

  // 4. Nutrition Logged Days
  const targetNutritionDays = 7;
  let actualNutritionDays = 0;
  for (const day of recentDays) {
    if (day.nutrition && day.nutrition.loggedMealsCount > 0) {
      actualNutritionDays += 1;
    }
  }
  const nutritionPct = Math.min(Math.round((actualNutritionDays / targetNutritionDays) * 100), 100);

  const habits: HabitConsistencyItem[] = [
    {
      id: 'workout_habit',
      name: 'Sesi Latihan Kebugaran',
      nameEn: 'Fitness Workouts',
      plannedTarget: targetWorkouts,
      completedCount: actualWorkouts,
      unit: isIndonesian ? 'sesi' : 'sessions',
      percentage: workoutPct,
      statusText: isIndonesian
        ? `${actualWorkouts} dari ${targetWorkouts} sesi latihan tercapai.`
        : `${actualWorkouts} of ${targetWorkouts} planned sessions completed.`,
    },
    {
      id: 'hydration_habit',
      name: 'Target Hidrasi Harian',
      nameEn: 'Daily Hydration Target',
      plannedTarget: targetHydrationDays,
      completedCount: actualHydrationDays,
      unit: isIndonesian ? 'hari' : 'days',
      percentage: hydrationPct,
      statusText: isIndonesian
        ? `${actualHydrationDays} dari ${targetHydrationDays} hari mencapai target air.`
        : `${actualHydrationDays} of ${targetHydrationDays} days hit water target.`,
    },
    {
      id: 'sleep_habit',
      name: 'Kualitas & Durasi Tidur',
      nameEn: 'Sleep Rest & Recovery',
      plannedTarget: targetSleepDays,
      completedCount: actualSleepDays,
      unit: isIndonesian ? 'malam' : 'nights',
      percentage: sleepPct,
      statusText: isIndonesian
        ? `${actualSleepDays} dari ${targetSleepDays} malam waktu tidur optimal.`
        : `${actualSleepDays} of ${targetSleepDays} nights optimal sleep.`,
    },
    {
      id: 'nutrition_habit',
      name: 'Pencatatan Makanan',
      nameEn: 'Meal Tracking',
      plannedTarget: targetNutritionDays,
      completedCount: actualNutritionDays,
      unit: isIndonesian ? 'hari' : 'days',
      percentage: nutritionPct,
      statusText: isIndonesian
        ? `${actualNutritionDays} dari ${targetNutritionDays} hari mencatat asupan makanan.`
        : `${actualNutritionDays} of ${targetNutritionDays} days meals logged.`,
    },
  ];

  const totalPlanned = targetWorkouts + targetHydrationDays + targetSleepDays + targetNutritionDays;
  const totalCompleted = actualWorkouts + actualHydrationDays + actualSleepDays + actualNutritionDays;
  const overallPercentage = Math.round((totalCompleted / totalPlanned) * 100);

  let summaryMessage = '';
  if (isIndonesian) {
    if (overallPercentage >= 80) {
      summaryMessage = 'Ritme kebiasaan Anda sangat konsisten dan membangun fondasi kebugaran yang kokoh.';
    } else if (overallPercentage >= 50) {
      summaryMessage = 'Progres konsistensi yang baik! Terus jaga ritme bertahap tanpa perlu memaksakan diri.';
    } else {
      summaryMessage = 'Langkah awal yang baik. Pilih satu kebiasaan kecil untuk difokuskan hari ini.';
    }
  } else {
    if (overallPercentage >= 80) {
      summaryMessage = 'Your habit rhythm is remarkably strong, building a solid foundation for long-term health.';
    } else if (overallPercentage >= 50) {
      summaryMessage = 'Good consistent progress! Keep building steady momentum one day at a time.';
    } else {
      summaryMessage = 'Every small positive choice counts. Focus on one small habit today.';
    }
  }

  return {
    plannedHabits: totalPlanned,
    completedHabits: totalCompleted,
    percentage: overallPercentage,
    summaryMessage,
    habits,
  };
}
