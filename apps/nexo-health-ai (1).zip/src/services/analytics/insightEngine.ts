import {
  DailyHealthRecord,
  WeeklyReport,
  AIHealthInsight,
  HealthTrend,
} from '../../types/health';
import { UserProfile } from '../../types';

export interface CompactDailyHealthContext {
  wellnessScore: number;
  activity: {
    steps: number;
    activeMinutes: number;
    caloriesBurned: number;
  };
  sleep: {
    durationHours: number;
    consistencyScore: number;
  };
  hydration: {
    liters: number;
    goalMet: boolean;
  };
  nutrition: {
    caloriesConsumed: number;
    proteinG: number;
  };
  primaryGoal: string;
  focusArea: string;
}

export interface CompactWeeklyHealthContext {
  wellnessScore: {
    current: number;
    previous: number;
    delta: number;
  };
  activity: {
    totalWorkouts: number;
    totalActiveMinutes: number;
    avgDailySteps: number;
  };
  sleep: {
    avgHours: number;
    consistencyScore: number;
  };
  hydration: {
    avgLiters: number;
    adherenceDays: number;
  };
  nutrition: {
    loggedDays: number;
    avgCalories: number;
  };
  consistencyPct: number;
  primaryGoal: string;
}

/**
 * Token Optimization: Extracts ONLY compact, aggregated metrics for Gemini interpretation.
 * Never sends full database, raw video frames, or unbounded event histories.
 */
export function getDailyHealthContext(
  record: Partial<DailyHealthRecord>,
  profile?: Partial<UserProfile>
): CompactDailyHealthContext {
  const steps = record.activity?.steps || 0;
  const activeMinutes = record.activity?.activeMinutes || 0;
  const waterMl = record.hydration?.waterIntakeMl || 0;
  const waterGoal = record.hydration?.waterGoalMl || 2500;
  const sleepHours = record.sleep?.sleepDurationHours || 0;

  // Determine focus area algorithmically
  let focusArea = 'hydration';
  if (waterMl < waterGoal * 0.7) {
    focusArea = 'hydration';
  } else if (steps < 5000) {
    focusArea = 'daily_movement';
  } else if (sleepHours < 6.5) {
    focusArea = 'sleep_recovery';
  } else {
    focusArea = 'active_momentum';
  }

  return {
    wellnessScore: record.wellnessScore?.score || 75,
    activity: {
      steps,
      activeMinutes,
      caloriesBurned: record.activity?.estimatedCaloriesBurned || 0,
    },
    sleep: {
      durationHours: sleepHours,
      consistencyScore: record.sleep?.sleepConsistencyScore || 75,
    },
    hydration: {
      liters: Number((waterMl / 1000).toFixed(1)),
      goalMet: waterMl >= waterGoal,
    },
    nutrition: {
      caloriesConsumed: record.nutrition?.caloriesConsumed || 0,
      proteinG: record.nutrition?.proteinG || 0,
    },
    primaryGoal: profile?.primaryGoal || 'general_fitness',
    focusArea,
  };
}

/**
 * Token Optimization: Extracts compact weekly summary for Gemini report interpretation.
 */
export function getWeeklyHealthContext(
  report: WeeklyReport,
  profile?: Partial<UserProfile>
): CompactWeeklyHealthContext {
  return {
    wellnessScore: report.wellnessScore,
    activity: {
      totalWorkouts: report.activity.workoutsCount,
      totalActiveMinutes: report.activity.totalActiveMinutes,
      avgDailySteps: report.activity.averageDailySteps,
    },
    sleep: {
      avgHours: report.sleep.averageHours,
      consistencyScore: report.sleep.consistencyScore,
    },
    hydration: {
      avgLiters: report.hydration.averageLiters,
      adherenceDays: report.hydration.targetMetDays,
    },
    nutrition: {
      loggedDays: report.nutrition.loggedDays,
      avgCalories: report.nutrition.averageCalories,
    },
    consistencyPct: report.consistency.percentage,
    primaryGoal: profile?.primaryGoal || report.goalProgress.primaryGoal || 'general_fitness',
  };
}

/**
 * Generates immediate, deterministic, non-medical health insights on-device.
 */
export function generateLocalHealthInsight(
  record: Partial<DailyHealthRecord>,
  trends: HealthTrend[] = [],
  isIndonesian: boolean = false
): AIHealthInsight {
  const score = record.wellnessScore?.score || 75;
  const water = record.hydration?.waterIntakeMl || 0;
  const waterGoal = record.hydration?.waterGoalMl || 2500;
  const sleep = record.sleep?.sleepDurationHours || 7.0;
  const steps = record.activity?.steps || 6000;

  const positiveAreas: string[] = [];
  const suggestions: string[] = [];
  let focusArea = 'hydration';

  if (water >= waterGoal * 0.8) {
    positiveAreas.push(
      isIndonesian
        ? `Hidrasi prima: ${(water / 1000).toFixed(1)}L air terjaga`
        : `Great hydration: ${(water / 1000).toFixed(1)}L water consumed`
    );
  } else {
    suggestions.push(
      isIndonesian
        ? `Minum 1 gelas air (250ml) untuk mendekati target ${(waterGoal / 1000).toFixed(1)}L`
        : `Drink 1 glass of water (250ml) to move closer to your ${(waterGoal / 1000).toFixed(1)}L goal`
    );
    focusArea = 'hydration';
  }

  if (sleep >= 7.0) {
    positiveAreas.push(
      isIndonesian
        ? `Waktu tidur optimal (${sleep} jam) mendukung pemulihan energi`
        : `Optimal sleep duration (${sleep}h) supports recovery and vitality`
    );
  } else {
    suggestions.push(
      isIndonesian
        ? 'Siapkan rutinitas santai 30 menit sebelum tidur untuk kualitas istirahat lebih dalam'
        : 'Prepare a 30-min wind-down ritual before bedtime for deeper restorative sleep'
    );
    if (focusArea === 'hydration' && water >= waterGoal * 0.8) focusArea = 'sleep';
  }

  if (steps >= 7000) {
    positiveAreas.push(
      isIndonesian
        ? `Langkah aktif harian (${steps.toLocaleString()}) sangat baik`
        : `Strong daily movement pace (${steps.toLocaleString()} steps)`
    );
  } else {
    suggestions.push(
      isIndonesian
        ? 'Sempatkan jalan santai 10 menit setelah makan siang atau sore hari'
        : 'Take a brisk 10-minute walk after lunch or in the early evening'
    );
  }

  if (positiveAreas.length === 0) {
    positiveAreas.push(
      isIndonesian
        ? 'Konsistensi mencatat data kesehatan secara berkala'
        : 'Consistent tracking of daily health habits'
    );
  }

  let headline = '';
  let summary = '';
  let category: AIHealthInsight['category'] = 'positive';

  if (score >= 80) {
    category = 'positive';
    headline = isIndonesian ? 'Ritme Kebugaran Harmonis' : 'Harmonious Wellness Rhythm';
    summary = isIndonesian
      ? `Skor Wellness harian Anda mencapai ${score}/100. Keseimbangan antara aktivitas fisik, hidrasi, dan istirahat berada di zona optimal.`
      : `Your Daily Wellness Score is ${score}/100. Balanced activity, hydration, and recovery are supporting your vitality.`;
  } else if (score >= 60) {
    category = 'suggestion';
    headline = isIndonesian ? 'Progres Stabil & Terjaga' : 'Steady & Consistent Progress';
    summary = isIndonesian
      ? `Skor Wellness Anda berada di ${score}/100. Anda memiliki fondasi yang baik; sedikit penyesuaian pada ${focusArea} akan meningkatkan skor Anda.`
      : `Your Wellness Score is ${score}/100. A solid baseline is established; small adjustments in ${focusArea} can elevate your energy.`;
  } else {
    category = 'neutral';
    headline = isIndonesian ? 'Fokus Peningkatan Hari Ini' : 'Daily Opportunity Focus';
    summary = isIndonesian
      ? `Skor Wellness berada di ${score}/100. Mulailah dengan langkah ringan: cukupi hidrasi air putih dan prioritaskan istirahat malam.`
      : `Your Wellness Score is ${score}/100. Start with simple actions: hit your hydration target and prioritize rest tonight.`;
  }

  return {
    id: `insight_${Date.now()}`,
    category,
    headline,
    summary,
    positiveAreas,
    suggestions,
    focusArea,
    generatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    isAiGenerated: false,
  };
}

/**
 * Builds weekly aggregation report deterministically from last 7 days of records.
 */
export function buildWeeklyReport(
  records: DailyHealthRecord[],
  profile?: Partial<UserProfile>,
  isIndonesian: boolean = false
): WeeklyReport {
  const recent7 = records.slice(-7);
  const prior7 = records.slice(-14, -7);

  // 1. Wellness Score Delta
  const currentAvgScore = recent7.length > 0
    ? Math.round(recent7.reduce((sum, r) => sum + (r.wellnessScore?.score || 70), 0) / recent7.length)
    : 75;
  const previousAvgScore = prior7.length > 0
    ? Math.round(prior7.reduce((sum, r) => sum + (r.wellnessScore?.score || 70), 0) / prior7.length)
    : Math.max(currentAvgScore - 4, 60);
  const delta = currentAvgScore - previousAvgScore;

  // 2. Activity Aggregations
  let totalWorkouts = 0;
  let totalActiveMins = 0;
  let totalSteps = 0;
  let totalCaloriesBurned = 0;

  for (const r of recent7) {
    const workouts = r.events?.filter((e) => e.type === 'workout').length || 0;
    totalWorkouts += workouts > 0 ? workouts : (r.activity?.activeMinutes >= 25 ? 1 : 0);
    totalActiveMins += r.activity?.activeMinutes || 0;
    totalSteps += r.activity?.steps || 0;
    totalCaloriesBurned += r.activity?.estimatedCaloriesBurned || 0;
  }

  const avgSteps = recent7.length > 0 ? Math.round(totalSteps / recent7.length) : 0;

  // 3. Sleep Aggregations
  let totalSleepHours = 0;
  let totalSleepConsistency = 0;
  let sleepTargetMetDays = 0;

  for (const r of recent7) {
    const hours = r.sleep?.sleepDurationHours || 0;
    totalSleepHours += hours;
    totalSleepConsistency += r.sleep?.sleepConsistencyScore || 75;
    if (hours >= 6.8) sleepTargetMetDays += 1;
  }
  const avgSleepHours = recent7.length > 0 ? Number((totalSleepHours / recent7.length).toFixed(1)) : 7.2;
  const avgSleepConsistency = recent7.length > 0 ? Math.round(totalSleepConsistency / recent7.length) : 78;

  // 4. Hydration Aggregations
  let totalWaterMl = 0;
  let hydrationTargetMetDays = 0;

  for (const r of recent7) {
    const water = r.hydration?.waterIntakeMl || 0;
    totalWaterMl += water;
    if (water >= (r.hydration?.waterGoalMl || 2500) * 0.85) {
      hydrationTargetMetDays += 1;
    }
  }
  const avgWaterLiters = recent7.length > 0
    ? Number((totalWaterMl / recent7.length / 1000).toFixed(1))
    : 2.1;

  // 5. Nutrition Aggregations
  let loggedNutritionDays = 0;
  let totalCalories = 0;
  let totalProtein = 0;

  for (const r of recent7) {
    if (r.nutrition && r.nutrition.loggedMealsCount > 0) {
      loggedNutritionDays += 1;
      totalCalories += r.nutrition.caloriesConsumed;
      totalProtein += r.nutrition.proteinG;
    }
  }
  const avgCalories = loggedNutritionDays > 0 ? Math.round(totalCalories / loggedNutritionDays) : 2050;
  const avgProtein = loggedNutritionDays > 0 ? Math.round(totalProtein / loggedNutritionDays) : 115;

  // 6. Consistency
  const plannedHabits = 28; // 4 habits * 7 days
  const completedHabits = totalWorkouts + hydrationTargetMetDays + sleepTargetMetDays + loggedNutritionDays;
  const consistencyPct = Math.min(Math.round((completedHabits / plannedHabits) * 100), 100);

  // 7. Goal Progress
  const primaryGoal = profile?.primaryGoal || 'Kebugaran & Vitalitas';
  const progressPct = Math.min(Math.round((currentAvgScore * 0.5 + consistencyPct * 0.5)), 100);
  const status: WeeklyReport['goalProgress']['status'] =
    progressPct >= 75 ? 'accelerating' : progressPct >= 50 ? 'on_track' : 'lagging';

  const goalSummary = isIndonesian
    ? `Progres menuju sasaran "${primaryGoal}" berjalan konsisten dengan kepatuhan kebiasaan ${consistencyPct}%.`
    : `Progress toward "${primaryGoal}" is advancing steadily with ${consistencyPct}% habit consistency.`;

  const now = new Date();
  const startDate = new Date(now.getTime() - 6 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const endDate = now.toISOString().split('T')[0];

  return {
    id: `weekly_rep_${Date.now()}`,
    weekStartDate: startDate,
    weekEndDate: endDate,
    wellnessScore: {
      current: currentAvgScore,
      previous: previousAvgScore,
      delta,
    },
    activity: {
      workoutsCount: totalWorkouts,
      totalActiveMinutes: totalActiveMins,
      averageDailySteps: avgSteps,
      totalCaloriesBurned,
    },
    sleep: {
      averageHours: avgSleepHours,
      consistencyScore: avgSleepConsistency,
      targetMetDays: sleepTargetMetDays,
    },
    hydration: {
      averageLiters: avgWaterLiters,
      targetMetDays: hydrationTargetMetDays,
    },
    nutrition: {
      loggedDays: loggedNutritionDays,
      averageCalories: avgCalories,
      averageProteinG: avgProtein,
    },
    consistency: {
      plannedHabits,
      completedHabits,
      percentage: consistencyPct,
    },
    goalProgress: {
      primaryGoal,
      progressPercentage: progressPct,
      status,
      summary: goalSummary,
    },
    aiInsight: {
      id: `ai_rep_insight_${Date.now()}`,
      category: delta >= 0 ? 'positive' : 'suggestion',
      headline: isIndonesian ? 'Evaluasi Mingguan Personal' : 'Weekly Intelligence Summary',
      summary: isIndonesian
        ? `Dalam 7 hari terakhir, skor wellness rata-rata Anda berada di angka ${currentAvgScore} (${delta >= 0 ? '+' : ''}${delta} poin vs pekan lalu). Fokus utama yang paling konsisten adalah hidrasi dan rutinitas latihan.`
        : `Over the past 7 days, your average wellness score reached ${currentAvgScore} (${delta >= 0 ? '+' : ''}${delta} pts vs prior week). Hydration and workout pacing showed the highest consistency.`,
      positiveAreas: isIndonesian
        ? [`${totalWorkouts} sesi olahraga diselesaikan`, `${hydrationTargetMetDays}/7 hari target air tercapai`]
        : [`${totalWorkouts} workout sessions completed`, `${hydrationTargetMetDays}/7 days hydration target met`],
      suggestions: isIndonesian
        ? ['Pertahankan waktu tidur konsisten di akhir pekan', 'Tingkatkan asupan serat saat makan siang']
        : ['Maintain consistent sleep timing over the weekend', 'Incorporate more dietary fiber during lunch'],
      focusArea: 'recovery_consistency',
      generatedAt: new Date().toLocaleDateString(),
      isAiGenerated: false,
    },
  };
}
