import { DailyHealthRecord, HealthTrend, HealthTrendDirection, WeightEntry } from '../../types/health';

/**
 * Calculates multi-day health trends deterministically comparing recent period to prior period.
 */
export function calculateMetricTrend(
  metric: HealthTrend['metric'],
  records: DailyHealthRecord[],
  weights: WeightEntry[] = [],
  isIndonesian: boolean = false
): HealthTrend {
  // Sort records chronologically ascending (oldest -> newest)
  const sorted = [...records].sort((a, b) => a.date.localeCompare(b.date));

  // If we have fewer than 3 records, we have insufficient data
  if (sorted.length < 3) {
    return {
      metric,
      direction: 'insufficient_data',
      currentValue: 0,
      description: isIndonesian ? 'Belum cukup data riwayat.' : 'Not enough data yet.',
      period: '7d',
      hasSufficientData: false,
    };
  }

  // Split into recent window (last 3-7 days) and prior window
  const halfLength = Math.max(Math.floor(sorted.length / 2), 1);
  const priorWindow = sorted.slice(0, halfLength);
  const recentWindow = sorted.slice(halfLength);

  const getMetricValue = (rec: DailyHealthRecord): number => {
    switch (metric) {
      case 'wellness':
        return rec.wellnessScore?.score || 65;
      case 'steps':
        return rec.activity?.steps || 0;
      case 'active_minutes':
        return rec.activity?.activeMinutes || 0;
      case 'sleep':
        return rec.sleep?.sleepDurationHours || 0;
      case 'hydration':
        return rec.hydration?.waterIntakeMl || 0;
      case 'nutrition':
        return rec.nutrition?.caloriesConsumed || 0;
      case 'weight':
        return rec.weight || 0;
      default:
        return 0;
    }
  };

  const calculateAverage = (arr: DailyHealthRecord[]): number => {
    const valid = arr.map(getMetricValue).filter((v) => v > 0);
    if (valid.length === 0) return 0;
    return valid.reduce((acc, curr) => acc + curr, 0) / valid.length;
  };

  let priorAvg = calculateAverage(priorWindow);
  let recentAvg = calculateAverage(recentWindow);

  // Special case for weight if passed in weights array
  if (metric === 'weight' && weights.length >= 2) {
    const sortedWeights = [...weights].sort((a, b) => a.date.localeCompare(b.date));
    const recentW = sortedWeights.slice(-Math.min(3, sortedWeights.length));
    const priorW = sortedWeights.slice(0, Math.max(1, sortedWeights.length - recentW.length));
    recentAvg = recentW.reduce((sum, w) => sum + w.weightKg, 0) / recentW.length;
    priorAvg = priorW.reduce((sum, w) => sum + w.weightKg, 0) / priorW.length;
  }

  if (recentAvg === 0 || priorAvg === 0) {
    return {
      metric,
      direction: 'insufficient_data',
      currentValue: recentAvg,
      description: isIndonesian ? 'Belum cukup data riwayat.' : 'Not enough data yet.',
      period: '7d',
      hasSufficientData: false,
    };
  }

  const delta = recentAvg - priorAvg;
  const percentageChange = Math.round((delta / priorAvg) * 100);

  // Thresholds for trend direction
  let direction: HealthTrendDirection = 'stable';
  const absChange = Math.abs(percentageChange);

  // For weight, "improving" depends on user goal, but standard neutral change < 1% is stable
  if (metric === 'weight') {
    if (absChange < 1.0) {
      direction = 'stable';
    } else if (delta < 0) {
      direction = 'improving'; // standard healthy gradual shift
    } else {
      direction = 'declining';
    }
  } else {
    if (absChange < 4.0) {
      direction = 'stable';
    } else if (delta > 0) {
      direction = 'improving';
    } else {
      direction = 'declining';
    }
  }

  let description = '';
  if (isIndonesian) {
    if (direction === 'improving') {
      description = `Meningkat +${percentageChange}% dibanding pekan lalu.`;
    } else if (direction === 'declining') {
      description = `Menurun ${percentageChange}% dibanding pekan lalu.`;
    } else {
      description = 'Stabil konsisten dengan periode sebelumnya.';
    }
  } else {
    if (direction === 'improving') {
      description = `Trending up +${percentageChange}% compared to prior period.`;
    } else if (direction === 'declining') {
      description = `Trending down ${percentageChange}% compared to prior period.`;
    } else {
      description = 'Consistent and stable compared to prior period.';
    }
  }

  return {
    metric,
    direction,
    currentValue: Number(recentAvg.toFixed(1)),
    previousValue: Number(priorAvg.toFixed(1)),
    percentageChange,
    description,
    period: '7d',
    hasSufficientData: true,
  };
}

/**
 * Calculates a comprehensive suite of health trends across all primary wellness domains.
 */
export function calculateAllTrends(
  records: DailyHealthRecord[],
  weights: WeightEntry[] = [],
  isIndonesian: boolean = false
): HealthTrend[] {
  const metrics: HealthTrend['metric'][] = [
    'wellness',
    'steps',
    'active_minutes',
    'sleep',
    'hydration',
    'nutrition',
    'weight',
  ];

  return metrics.map((m) => calculateMetricTrend(m, records, weights, isIndonesian));
}
