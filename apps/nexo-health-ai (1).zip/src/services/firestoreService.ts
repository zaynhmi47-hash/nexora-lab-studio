import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  getDocs,
  query,
  orderBy,
  limit,
  onSnapshot,
  writeBatch,
  Unsubscribe
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { UserProfile, DailyLog, MealItem, WorkoutPlan, ModularHealthDataEntry, HabitItem } from '../types';

export const DEFAULT_CLEAN_PROFILE: UserProfile = {
  id: 'usr_default',
  name: 'User',
  email: '',
  age: 25,
  gender: 'male',
  heightCm: 170,
  weightKg: 65,
  targetWeightKg: 65,
  fitnessGoal: 'maintenance',
  activityLevel: 'moderate',
  dailyWaterTargetMl: 2500,
  dailyCalorieTarget: 2000,
  dailyCarbsTargetG: 220,
  dailyProteinTargetG: 120,
  dailyFatTargetG: 60,
  dailyStepsTarget: 8000,
  dailySleepTargetHours: 8,
  streakCount: 1,
  level: 1,
  xp: 0,
  xpNextLevel: 1000,
  language: 'id',
  autoTranslateAdvice: true,
  subscriptionPlan: 'free',
  subscriptionStatus: 'active',
  planActiveUntil: '2027-01-01',
  clinicName: 'Klinik Sehat Mandiri',
  patientSlotsUsed: 0,
  teamMembersCount: 1,
};

export const getTodayDateKey = () => new Date().toISOString().split('T')[0];

export const DEFAULT_CLEAN_DAILY_LOG: DailyLog = {
  date: getTodayDateKey(),
  waterIntakeMl: 0,
  caloriesConsumed: 0,
  carbsG: 0,
  proteinG: 0,
  fatG: 0,
  stepsCount: 0,
  sleepHours: 0,
  weightKg: 65,
};

// LocalStorage Fallback keys
const LS_PROFILE_KEY = 'nexo_user_profile_v2';
const LS_DAILY_LOG_KEY = 'nexo_daily_log_v2';
const LS_MEALS_KEY = 'nexo_meals_v2';
const LS_MODULAR_LOGS_KEY = 'nexo_modular_logs_v2';
const LS_WORKOUTS_KEY = 'nexo_workouts_v2';

export class FirestoreDataService {
  /**
   * Get effective user ID
   */
  static getUserId(): string | null {
    return auth.currentUser ? auth.currentUser.uid : null;
  }

  /**
   * Load or initialize User Profile from Firestore
   */
  static async loadUserProfile(fallbackUid?: string): Promise<UserProfile> {
    const uid = fallbackUid || this.getUserId();
    if (!uid) {
      const cached = localStorage.getItem(LS_PROFILE_KEY);
      if (cached) {
        try {
          return JSON.parse(cached);
        } catch {
          // ignore error
        }
      }
      return DEFAULT_CLEAN_PROFILE;
    }

    try {
      const userDocRef = doc(db, 'users', uid);
      const snap = await getDoc(userDocRef);

      if (snap.exists()) {
        const data = snap.data() as UserProfile;
        localStorage.setItem(LS_PROFILE_KEY, JSON.stringify(data));
        return data;
      } else {
        // Initialize fresh profile for new user
        const initialProfile: UserProfile = {
          ...DEFAULT_CLEAN_PROFILE,
          id: uid,
          name: auth.currentUser?.displayName || auth.currentUser?.email?.split('@')[0] || 'Pengguna NexoHealth',
          email: auth.currentUser?.email || '',
        };
        await setDoc(userDocRef, initialProfile);
        localStorage.setItem(LS_PROFILE_KEY, JSON.stringify(initialProfile));
        return initialProfile;
      }
    } catch (err) {
      console.warn('Firestore loadUserProfile fallback to localStorage:', err);
      const cached = localStorage.getItem(LS_PROFILE_KEY);
      if (cached) {
        try { return JSON.parse(cached); } catch {}
      }
      return DEFAULT_CLEAN_PROFILE;
    }
  }

  /**
   * Save User Profile to Firestore & Cache
   */
  static async saveUserProfile(profile: UserProfile): Promise<void> {
    localStorage.setItem(LS_PROFILE_KEY, JSON.stringify(profile));
    const uid = this.getUserId();
    if (!uid) return;

    try {
      const userDocRef = doc(db, 'users', uid);
      await setDoc(userDocRef, { ...profile, id: uid, updatedAt: new Date().toISOString() }, { merge: true });
    } catch (err) {
      console.warn('Error saving user profile to Firestore:', err);
    }
  }

  /**
   * Load Daily Log for specific date
   */
  static async loadDailyLog(dateKey: string = getTodayDateKey()): Promise<DailyLog> {
    const uid = this.getUserId();
    if (!uid) {
      const cached = localStorage.getItem(`${LS_DAILY_LOG_KEY}_${dateKey}`);
      if (cached) {
        try { return JSON.parse(cached); } catch {}
      }
      return { ...DEFAULT_CLEAN_DAILY_LOG, date: dateKey };
    }

    try {
      const logDocRef = doc(db, 'users', uid, 'daily_logs', dateKey);
      const snap = await getDoc(logDocRef);
      if (snap.exists()) {
        const data = snap.data() as DailyLog;
        localStorage.setItem(`${LS_DAILY_LOG_KEY}_${dateKey}`, JSON.stringify(data));
        return data;
      } else {
        const initialLog: DailyLog = { ...DEFAULT_CLEAN_DAILY_LOG, date: dateKey };
        await setDoc(logDocRef, initialLog);
        localStorage.setItem(`${LS_DAILY_LOG_KEY}_${dateKey}`, JSON.stringify(initialLog));
        return initialLog;
      }
    } catch (err) {
      console.warn('Firestore loadDailyLog fallback:', err);
      const cached = localStorage.getItem(`${LS_DAILY_LOG_KEY}_${dateKey}`);
      if (cached) {
        try { return JSON.parse(cached); } catch {}
      }
      return { ...DEFAULT_CLEAN_DAILY_LOG, date: dateKey };
    }
  }

  /**
   * Save Daily Log
   */
  static async saveDailyLog(dailyLog: DailyLog): Promise<void> {
    const dateKey = dailyLog.date || getTodayDateKey();
    localStorage.setItem(`${LS_DAILY_LOG_KEY}_${dateKey}`, JSON.stringify(dailyLog));
    const uid = this.getUserId();
    if (!uid) return;

    try {
      const logDocRef = doc(db, 'users', uid, 'daily_logs', dateKey);
      await setDoc(logDocRef, { ...dailyLog, updatedAt: new Date().toISOString() }, { merge: true });
    } catch (err) {
      console.warn('Error saving daily log to Firestore:', err);
    }
  }

  /**
   * Load Meals from Firestore
   */
  static async loadMeals(): Promise<MealItem[]> {
    const uid = this.getUserId();
    if (!uid) {
      const cached = localStorage.getItem(LS_MEALS_KEY);
      if (cached) {
        try { return JSON.parse(cached); } catch {}
      }
      return [];
    }

    try {
      const mealsCol = collection(db, 'users', uid, 'meals');
      const q = query(mealsCol, orderBy('timestamp', 'desc'), limit(50));
      const snap = await getDocs(q);
      const list: MealItem[] = [];
      snap.forEach((d) => list.push({ ...(d.data() as MealItem), id: d.id }));
      localStorage.setItem(LS_MEALS_KEY, JSON.stringify(list));
      return list;
    } catch (err) {
      console.warn('Firestore loadMeals fallback:', err);
      const cached = localStorage.getItem(LS_MEALS_KEY);
      return cached ? JSON.parse(cached) : [];
    }
  }

  /**
   * Save / Add Meal to Firestore
   */
  static async saveMeal(meal: MealItem): Promise<void> {
    const uid = this.getUserId();
    const existing = await this.loadMeals();
    const updated = [meal, ...existing.filter((m) => m.id !== meal.id)];
    localStorage.setItem(LS_MEALS_KEY, JSON.stringify(updated));

    if (!uid) return;
    try {
      const mealDoc = doc(db, 'users', uid, 'meals', meal.id);
      await setDoc(mealDoc, { ...meal, createdAt: new Date().toISOString() });
    } catch (err) {
      console.warn('Error saving meal to Firestore:', err);
    }
  }

  /**
   * Delete Meal
   */
  static async deleteMeal(mealId: string): Promise<void> {
    const existing = await this.loadMeals();
    const updated = existing.filter((m) => m.id !== mealId);
    localStorage.setItem(LS_MEALS_KEY, JSON.stringify(updated));

    const uid = this.getUserId();
    if (!uid) return;
    try {
      await deleteDoc(doc(db, 'users', uid, 'meals', mealId));
    } catch (err) {
      console.warn('Error deleting meal from Firestore:', err);
    }
  }

  /**
   * Load Modular Logs from Firestore
   */
  static async loadModularLogs(): Promise<ModularHealthDataEntry[]> {
    const uid = this.getUserId();
    if (!uid) {
      const cached = localStorage.getItem(LS_MODULAR_LOGS_KEY);
      if (cached) {
        try { return JSON.parse(cached); } catch {}
      }
      return [];
    }

    try {
      const logsCol = collection(db, 'users', uid, 'modular_logs');
      const q = query(logsCol, orderBy('timestamp', 'desc'), limit(100));
      const snap = await getDocs(q);
      const list: ModularHealthDataEntry[] = [];
      snap.forEach((d) => list.push({ ...(d.data() as ModularHealthDataEntry), id: d.id }));
      localStorage.setItem(LS_MODULAR_LOGS_KEY, JSON.stringify(list));
      return list;
    } catch (err) {
      console.warn('Firestore loadModularLogs fallback:', err);
      const cached = localStorage.getItem(LS_MODULAR_LOGS_KEY);
      return cached ? JSON.parse(cached) : [];
    }
  }

  /**
   * Save Modular Health Log to Firestore
   */
  static async saveModularLog(entry: ModularHealthDataEntry): Promise<void> {
    const existing = await this.loadModularLogs();
    const updated = [entry, ...existing.filter((e) => e.id !== entry.id)];
    localStorage.setItem(LS_MODULAR_LOGS_KEY, JSON.stringify(updated));

    const uid = this.getUserId();
    if (!uid) return;
    try {
      const docRef = doc(db, 'users', uid, 'modular_logs', entry.id);
      await setDoc(docRef, { ...entry, createdAt: new Date().toISOString() });
    } catch (err) {
      console.warn('Error saving modular log to Firestore:', err);
    }
  }

  /**
   * Delete Modular Health Log
   */
  static async deleteModularLog(logId: string): Promise<void> {
    const existing = await this.loadModularLogs();
    const updated = existing.filter((e) => e.id !== logId);
    localStorage.setItem(LS_MODULAR_LOGS_KEY, JSON.stringify(updated));

    const uid = this.getUserId();
    if (!uid) return;
    try {
      await deleteDoc(doc(db, 'users', uid, 'modular_logs', logId));
    } catch (err) {
      console.warn('Error deleting modular log from Firestore:', err);
    }
  }

  /**
   * Clear All User Data (GDPR / Clean Reset)
   */
  static async clearAllUserData(): Promise<void> {
    localStorage.removeItem(LS_PROFILE_KEY);
    localStorage.removeItem(LS_DAILY_LOG_KEY);
    localStorage.removeItem(`${LS_DAILY_LOG_KEY}_${getTodayDateKey()}`);
    localStorage.removeItem(LS_MEALS_KEY);
    localStorage.removeItem(LS_MODULAR_LOGS_KEY);
    localStorage.removeItem(LS_WORKOUTS_KEY);

    const uid = this.getUserId();
    if (!uid) return;

    try {
      const batch = writeBatch(db);
      // Delete user root document
      batch.delete(doc(db, 'users', uid));
      await batch.commit();

      // Delete subcollections documents
      const collectionsToDelete = ['meals', 'modular_logs', 'daily_logs', 'workouts', 'habits'];
      for (const colName of collectionsToDelete) {
        const snap = await getDocs(collection(db, 'users', uid, colName));
        for (const d of snap.docs) {
          await deleteDoc(d.ref);
        }
      }
    } catch (err) {
      console.warn('Error clearing user data from Firestore:', err);
    }
  }

  /**
   * Subscribe to real-time modular logs
   */
  static subscribeModularLogs(callback: (logs: ModularHealthDataEntry[]) => void): Unsubscribe | null {
    const uid = this.getUserId();
    if (!uid) return null;

    try {
      const logsCol = collection(db, 'users', uid, 'modular_logs');
      const q = query(logsCol, orderBy('timestamp', 'desc'), limit(50));
      return onSnapshot(q, (snap) => {
        const list: ModularHealthDataEntry[] = [];
        snap.forEach((d) => list.push({ ...(d.data() as ModularHealthDataEntry), id: d.id }));
        localStorage.setItem(LS_MODULAR_LOGS_KEY, JSON.stringify(list));
        callback(list);
      }, (err) => {
        console.warn('Firestore modular logs snapshot error:', err);
      });
    } catch (err) {
      console.warn('Failed to subscribe modular logs:', err);
      return null;
    }
  }
}
