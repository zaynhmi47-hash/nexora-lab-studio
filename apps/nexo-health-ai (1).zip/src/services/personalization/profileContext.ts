import { UserProfile, PrimaryGoalType, ActivityLevelType, EquipmentType, AiToneType } from '../../types';

export interface FitnessAiContext {
  userSummary: string;
  primaryGoal: PrimaryGoalType;
  activityLevel: ActivityLevelType;
  exerciseFrequency: number;
  equipment: EquipmentType[];
  heightCm: number;
  weightKg: number;
  aiTone: AiToneType;
  language: string;
  units: string;
}

export interface NutritionAiContext {
  userSummary: string;
  primaryGoal: PrimaryGoalType;
  currentWeightKg: number;
  targetWeightKg: number;
  heightCm: number;
  age: number;
  gender: string;
  activityLevel: ActivityLevelType;
  dailyCalorieTarget: number;
  dailyWaterTargetMl: number;
  aiTone: AiToneType;
  language: string;
  units: string;
}

export interface GeneralHealthAiContext {
  userSummary: string;
  age: number;
  gender: string;
  primaryGoal: PrimaryGoalType;
  secondaryGoals: string[];
  sleepTargetHours: number;
  bedtime: string;
  wakeTime: string;
  activityLevel: ActivityLevelType;
  aiTone: AiToneType;
  language: string;
  units: string;
}

/**
 * Returns a compact, targeted AI context for fitness and workout planning.
 * Avoids sending unnecessary medical or unrelated data to preserve privacy & token efficiency.
 */
export function getFitnessContext(profile: UserProfile): FitnessAiContext {
  const goal = profile.primaryGoal || (profile.fitnessGoal === 'weight_loss' ? 'weight_loss' : profile.fitnessGoal === 'muscle_gain' ? 'muscle_gain' : 'fitness');
  const equip: EquipmentType[] = profile.equipment && profile.equipment.length > 0 ? profile.equipment : ['none'];
  const freq = profile.exerciseFrequency ?? 3;

  return {
    userSummary: `${profile.name}, ${profile.age}yo, ${profile.gender}, ${profile.heightCm}cm, ${profile.weightKg}kg`,
    primaryGoal: goal,
    activityLevel: profile.activityLevel || 'moderate',
    exerciseFrequency: freq,
    equipment: equip,
    heightCm: profile.heightCm,
    weightKg: profile.weightKg,
    aiTone: profile.aiTone || 'friendly',
    language: profile.language || 'id',
    units: profile.units || 'metric',
  };
}

/**
 * Returns a compact, targeted AI context for nutrition, calorie calculation, and meal scanning.
 */
export function getNutritionContext(profile: UserProfile): NutritionAiContext {
  const goal = profile.primaryGoal || (profile.fitnessGoal === 'weight_loss' ? 'weight_loss' : 'fitness');

  return {
    userSummary: `${profile.name}, ${profile.age}yo, ${profile.gender}`,
    primaryGoal: goal,
    currentWeightKg: profile.weightKg,
    targetWeightKg: profile.targetWeightKg || profile.weightKg,
    heightCm: profile.heightCm,
    age: profile.age,
    gender: profile.gender,
    activityLevel: profile.activityLevel || 'moderate',
    dailyCalorieTarget: profile.dailyCalorieTarget || 2000,
    dailyWaterTargetMl: profile.dailyWaterTargetMl || 2500,
    aiTone: profile.aiTone || 'friendly',
    language: profile.language || 'id',
    units: profile.units || 'metric',
  };
}

/**
 * Returns a compact, targeted AI context for lifestyle, sleep hygiene, and general wellness habits.
 */
export function getGeneralHealthContext(profile: UserProfile): GeneralHealthAiContext {
  return {
    userSummary: `${profile.name}, ${profile.age}yo, ${profile.gender}`,
    age: profile.age,
    gender: profile.gender,
    primaryGoal: profile.primaryGoal || 'fitness',
    secondaryGoals: profile.secondaryGoals || ['better_sleep'],
    sleepTargetHours: profile.sleepTargetHours || profile.dailySleepTargetHours || 7.5,
    bedtime: profile.bedtime || '23:00',
    wakeTime: profile.wakeTime || '07:00',
    activityLevel: profile.activityLevel || 'moderate',
    aiTone: profile.aiTone || 'friendly',
    language: profile.language || 'id',
    units: profile.units || 'metric',
  };
}

/**
 * Helper to construct an AI System Prompt Prefix using tone & language constraints.
 */
export function getToneSystemPrompt(tone: AiToneType = 'friendly', language = 'id'): string {
  const toneDirectives: Record<AiToneType, string> = {
    friendly: 'Maintain an encouraging, empathetic, and uplifting tone. Celebrate small wins and use supportive language.',
    clinical: 'Maintain a precise, objective, evidence-based clinical advisory tone. Focus strictly on physiological and biomechanical rationale.',
    motivational: 'Maintain a high-energy, disciplined athletic coach persona. Inspire action and drive accountability.',
    calm: 'Maintain a peaceful, mindful, restorative tone. Emphasize breathing, stress relief, and gradual sustainable progress.',
  };

  return `[AI Persona]: ${toneDirectives[tone] || toneDirectives.friendly}\n[Target Language]: ${language}`;
}
