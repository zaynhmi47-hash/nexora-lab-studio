/**
 * Real-time Computer Vision Video Motion Tracker
 * Processes video stream frames in browser memory (<15ms latency)
 * Uses Frame Differencing, Optical Centroid Tracking, and Kinematic Phase Detection
 */

export interface MotionAnalysisResult {
  motionEnergy: number; // 0 to 100%
  centroidX: number; // 0 to 1 (normalized horizontal position of motion center)
  centroidY: number; // 0 to 1 (normalized vertical position of motion center)
  verticalDisplacement: number; // -1 to 1 (normalized vertical movement delta)
  horizontalDisplacement: number; // -1 to 1 (normalized horizontal movement delta)
  motionDirection: 'descending' | 'ascending' | 'holding' | 'stationary';
  cycleProgress: number; // 0.0 to 1.0 (inferred rep cycle phase from real video motion)
  detectedRepIncrement: boolean;
  isFormCompromised: boolean;
  asymmetryScore: number; // 0 to 100% (difference between left and right quadrant motion)
  tempoSpeed: number; // Movement velocity in pixels/sec or normalized units
  motionHeatPoints: { x: number; y: number; intensity: number }[];
}

export class VideoMotionTracker {
  private prevFrameData: Uint8ClampedArray | null = null;
  private offscreenCanvas: HTMLCanvasElement;
  private offscreenCtx: CanvasRenderingContext2D | null;
  private width: number = 160; // downscaled width for 60fps real-time processing
  private height: number = 120; // downscaled height
  
  // Kinematic Rep Cycle Tracking State
  private currentPhase: 'top' | 'descending' | 'bottom' | 'ascending' = 'top';
  private currentDepth: number = 0; // 0 (top) to 1 (deepest bottom)
  private lowestDepthReached: number = 0;
  private repCycleProgress: number = 0;
  private lastPhaseChangeTime: number = Date.now();
  private smoothedCentroidY: number = 0.5;
  private baselineY: number = 0.5;
  private isCalibrated: boolean = false;
  private calibrationFrames: number = 0;

  // Configuration
  private sensitivity: number = 1.0; // 0.5 (low) to 2.0 (high)
  private minMotionThreshold: number = 4; // minimum pixel delta to count as motion

  constructor(sensitivityMultiplier: number = 1.0) {
    this.sensitivity = sensitivityMultiplier;
    this.offscreenCanvas = document.createElement('canvas');
    this.offscreenCanvas.width = this.width;
    this.offscreenCanvas.height = this.height;
    this.offscreenCtx = this.offscreenCanvas.getContext('2d', { willReadFrequently: true });
  }

  public setSensitivity(level: 'low' | 'medium' | 'high' | 'ultra') {
    switch (level) {
      case 'low':
        this.sensitivity = 0.6;
        this.minMotionThreshold = 7;
        break;
      case 'medium':
        this.sensitivity = 1.0;
        this.minMotionThreshold = 5;
        break;
      case 'high':
        this.sensitivity = 1.5;
        this.minMotionThreshold = 3;
        break;
      case 'ultra':
        this.sensitivity = 2.0;
        this.minMotionThreshold = 2;
        break;
    }
  }

  public resetCalibration() {
    this.isCalibrated = false;
    this.calibrationFrames = 0;
    this.currentPhase = 'top';
    this.currentDepth = 0;
    this.lowestDepthReached = 0;
    this.repCycleProgress = 0;
    this.prevFrameData = null;
  }

  /**
   * Process a single video frame from HTMLVideoElement or HTMLCanvasElement
   */
  public processFrame(videoElement: HTMLVideoElement | HTMLCanvasElement): MotionAnalysisResult {
    const defaultResult: MotionAnalysisResult = {
      motionEnergy: 0,
      centroidX: 0.5,
      centroidY: 0.5,
      verticalDisplacement: 0,
      horizontalDisplacement: 0,
      motionDirection: 'stationary',
      cycleProgress: this.repCycleProgress,
      detectedRepIncrement: false,
      isFormCompromised: false,
      asymmetryScore: 0,
      tempoSpeed: 0,
      motionHeatPoints: [],
    };

    if (!this.offscreenCtx) return defaultResult;

    const vWidth = videoElement instanceof HTMLVideoElement ? videoElement.videoWidth : videoElement.width;
    const vHeight = videoElement instanceof HTMLVideoElement ? videoElement.videoHeight : videoElement.height;

    if (!vWidth || !vHeight || vWidth === 0 || vHeight === 0) {
      return defaultResult;
    }

    // Draw downscaled frame to offscreen canvas
    try {
      this.offscreenCtx.drawImage(videoElement, 0, 0, this.width, this.height);
      const imgData = this.offscreenCtx.getImageData(0, 0, this.width, this.height);
      const currentPixels = imgData.data;

      if (!this.prevFrameData || this.prevFrameData.length !== currentPixels.length) {
        this.prevFrameData = new Uint8ClampedArray(currentPixels);
        return defaultResult;
      }

      let totalDiff = 0;
      let motionPixelsCount = 0;
      let sumX = 0;
      let sumY = 0;
      let leftSideMotion = 0;
      let rightSideMotion = 0;
      const heatPoints: { x: number; y: number; intensity: number }[] = [];

      // Grid sampling (sample every 2 pixels for performance)
      const step = 2;
      for (let y = 0; y < this.height; y += step) {
        for (let x = 0; x < this.width; x += step) {
          const idx = (y * this.width + x) * 4;

          // Grayscale luminance difference
          const rDiff = Math.abs(currentPixels[idx] - this.prevFrameData[idx]);
          const gDiff = Math.abs(currentPixels[idx + 1] - this.prevFrameData[idx + 1]);
          const bDiff = Math.abs(currentPixels[idx + 2] - this.prevFrameData[idx + 2]);
          const pixelDelta = (rDiff + gDiff + bDiff) / 3;

          if (pixelDelta > this.minMotionThreshold) {
            totalDiff += pixelDelta;
            motionPixelsCount++;
            sumX += x;
            sumY += y;

            if (x < this.width / 2) {
              leftSideMotion += pixelDelta;
            } else {
              rightSideMotion += pixelDelta;
            }

            // Sample heat points
            if (pixelDelta > 15 && heatPoints.length < 24) {
              heatPoints.push({
                x: x / this.width,
                y: y / this.height,
                intensity: Math.min(1, pixelDelta / 60),
              });
            }
          }
        }
      }

      // Update previous frame
      this.prevFrameData.set(currentPixels);

      // Compute motion metrics
      const totalSampledPixels = (this.width / step) * (this.height / step);
      const rawEnergy = (motionPixelsCount / totalSampledPixels) * 100 * this.sensitivity;
      const motionEnergy = Math.min(100, Math.round(rawEnergy * 1.8));

      // Calculate optical centroid
      let rawCentroidX = 0.5;
      let rawCentroidY = 0.5;
      if (motionPixelsCount > 8) {
        rawCentroidX = sumX / motionPixelsCount / this.width;
        rawCentroidY = sumY / motionPixelsCount / this.height;
      }

      // Initial baseline calibration during first frames of session
      if (!this.isCalibrated) {
        this.calibrationFrames++;
        if (this.calibrationFrames === 1) {
          this.baselineY = rawCentroidY;
        } else {
          this.baselineY = this.baselineY * 0.9 + rawCentroidY * 0.1;
        }
        if (this.calibrationFrames > 20) {
          this.isCalibrated = true;
        }
      }

      // Smooth centroid to remove video noise jitter
      const smoothingAlpha = 0.25;
      this.smoothedCentroidY = this.smoothedCentroidY * (1 - smoothingAlpha) + rawCentroidY * smoothingAlpha;

      // Vertical displacement relative to baseline
      const verticalDelta = this.smoothedCentroidY - this.baselineY;
      const horizontalDisplacement = rawCentroidX - 0.5;

      // Compute Asymmetry (Left vs Right body motion balance)
      const totalSideMotion = leftSideMotion + rightSideMotion;
      let asymmetryScore = 0;
      if (totalSideMotion > 100) {
        const diff = Math.abs(leftSideMotion - rightSideMotion);
        asymmetryScore = Math.min(100, Math.round((diff / totalSideMotion) * 100));
      }

      // Determine movement direction & velocity
      let motionDirection: 'descending' | 'ascending' | 'holding' | 'stationary' = 'stationary';
      const now = Date.now();
      const timeDeltaSec = Math.max(0.016, (now - this.lastPhaseChangeTime) / 1000);
      const tempoSpeed = Math.abs(verticalDelta) / timeDeltaSec;

      let detectedRepIncrement = false;
      let isFormCompromised = asymmetryScore > 48 || (tempoSpeed > 2.5 && motionEnergy > 70);

      // Rep Cycle & Phase State Machine based on Real Motion
      if (motionEnergy > 3) {
        // Map vertical displacement to depth (0.0 to 1.0)
        // Downward movement increases depth
        const depthScaling = 4.0 * this.sensitivity;
        const estimatedDepth = Math.max(0, Math.min(1.0, verticalDelta * depthScaling + (rawEnergy > 10 ? 0.3 : 0)));
        this.currentDepth = this.currentDepth * 0.7 + estimatedDepth * 0.3;

        if (this.currentDepth > this.lowestDepthReached) {
          this.lowestDepthReached = this.currentDepth;
        }

        // Detect transitions:
        // Top -> Descending -> Bottom -> Ascending -> Top (Rep completed!)
        if (this.currentPhase === 'top' && this.currentDepth > 0.25) {
          this.currentPhase = 'descending';
          motionDirection = 'descending';
          this.repCycleProgress = 0.25;
        } else if (this.currentPhase === 'descending') {
          motionDirection = 'descending';
          this.repCycleProgress = 0.25 + (this.currentDepth * 0.25);
          if (this.currentDepth > 0.6 || (this.lowestDepthReached > 0.5 && this.currentDepth < this.lowestDepthReached - 0.1)) {
            this.currentPhase = 'bottom';
            motionDirection = 'holding';
            this.repCycleProgress = 0.5;
          }
        } else if (this.currentPhase === 'bottom') {
          if (this.currentDepth < 0.45) {
            this.currentPhase = 'ascending';
            motionDirection = 'ascending';
            this.repCycleProgress = 0.75;
          } else {
            motionDirection = 'holding';
            this.repCycleProgress = 0.5;
          }
        } else if (this.currentPhase === 'ascending') {
          motionDirection = 'ascending';
          this.repCycleProgress = 0.75 + ((1.0 - this.currentDepth) * 0.25);
          if (this.currentDepth < 0.2) {
            // Full rep completed!
            this.currentPhase = 'top';
            this.lowestDepthReached = 0;
            this.repCycleProgress = 1.0;
            detectedRepIncrement = true;
          }
        }
      } else {
        motionDirection = 'stationary';
      }

      return {
        motionEnergy,
        centroidX: rawCentroidX,
        centroidY: rawCentroidY,
        verticalDisplacement: verticalDelta,
        horizontalDisplacement,
        motionDirection,
        cycleProgress: Math.min(1.0, Math.max(0.0, this.repCycleProgress)),
        detectedRepIncrement,
        isFormCompromised,
        asymmetryScore,
        tempoSpeed: Math.round(tempoSpeed * 10) / 10,
        motionHeatPoints: heatPoints,
      };
    } catch (err) {
      console.warn('Motion tracking error:', err);
      return defaultResult;
    }
  }
}
