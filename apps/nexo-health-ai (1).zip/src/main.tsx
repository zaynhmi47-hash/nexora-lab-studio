import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { ProfileProvider } from './context/ProfileContext.tsx';
import { ConversationProvider } from './context/ConversationContext.tsx';
import { NutritionProvider } from './context/NutritionContext.tsx';
import { HealthProvider } from './context/HealthContext.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ProfileProvider>
      <ConversationProvider>
        <NutritionProvider>
          <HealthProvider>
            <App />
          </HealthProvider>
        </NutritionProvider>
      </ConversationProvider>
    </ProfileProvider>
  </StrictMode>,
);



