export type LanguageCode = 'id' | 'en' | 'ja' | 'pt' | 'es' | 'de' | 'fr' | 'ar';

export interface LanguageOption {
  code: LanguageCode;
  name: string;
  flag: string;
}

export type ModuleCategory =
  | 'all'
  | 'sport_physical'
  | 'nutrition_metabolism'
  | 'mental_emotional'
  | 'preventive_medical'
  | 'cross_module_ecosystem';

export type HealthModuleId =
  // KELOMPOK A: KESEHATAN FISIK & OLAHRAGA (1-5)
  | 'm1_adaptive_trainer'
  | 'm2_form_cv'
  | 'm3_active_recovery'
  | 'm4_sport_performance'
  | 'm5_posture_ergonomics'
  // KELOMPOK B: NUTRISI & METABOLISME (6-10)
  | 'm6_ai_dietitian'
  | 'm7_food_scanner'
  | 'm8_smart_hydration'
  | 'm9_supplement_manager'
  | 'm10_mindful_eating'
  // KELOMPOK C: KESEHATAN MENTAL & EMOSIONAL (11-15)
  | 'm11_cbt_therapy'
  | 'm12_emotion_stress_map'
  | 'm13_adaptive_meditation'
  | 'm14_mental_resilience'
  | 'm15_sleep_rituals'
  // KELOMPOK D: MEDIS PREVENTIF & MONITORING (16-20)
  | 'm16_doctor_triage'
  | 'm17_electronic_health_record'
  | 'm18_vitals_wearables'
  | 'm19_longevity_screening'
  | 'm20_hormonal_reproductive'
  // INTEGRASI EKOSISTEM
  | 'ecosystem_orchestrator';

export interface HealthModuleMetadata {
  id: HealthModuleId;
  moduleNumber: number;
  category: ModuleCategory;
  categoryName: string;
  categoryNameEn: string;
  title: string;
  titleEn: string;
  shortDesc: string;
  shortDescEn: string;
  aiAdvantage: string;
  aiAdvantageEn: string;
  icon: string;
  tag: string;
  badgeColor: string;
}

export interface ModularHealthDataEntry {
  id: string;
  moduleId: HealthModuleId;
  moduleName: string;
  category: 'fitness' | 'nutrition' | 'mental' | 'medical' | 'general';
  timestamp: string; // ISO string
  summaryTitle: string;
  metrics: Record<string, string | number | boolean>;
  tags: string[];
  notes?: string;
  aiAnalystFlag?: 'optimal' | 'attention_needed' | 'critical_alert';
  xpAwarded: number;
}

export type SubscriptionPlanType = 'free' | 'pro' | 'business' | 'enterprise';

export type GenderType = 'male' | 'female' | 'other' | 'prefer_not_to_say';
export type PrimaryGoalType = 'fitness' | 'weight_loss' | 'muscle_gain' | 'endurance' | 'stress_relief' | 'healthy_aging';
export type SecondaryGoalType =
  | 'better_sleep'
  | 'posture_correction'
  | 'flexibility'
  | 'habit_consistency'
  | 'nutrition_balance'
  | 'injury_prevention'
  | 'cardiovascular_health'
  | 'energy_boost';
export type ActivityLevelType = 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
export type EquipmentType =
  | 'none'
  | 'dumbbells'
  | 'resistance_bands'
  | 'full_gym'
  | 'kettlebells'
  | 'pullup_bar'
  | 'cardio_machines'
  | 'yoga_mat';
export type UnitSystemType = 'metric' | 'imperial';
export type AiToneType = 'friendly' | 'clinical' | 'motivational' | 'calm';

export interface NotificationPreferences {
  dailyReminders: boolean;
  workoutAlerts: boolean;
  hydrationNudges: boolean;
  weeklyProgress: boolean;
}

export interface BasicInfo {
  name: string;
  age: number;
  gender: GenderType;
  heightCm: number;
  weightKg: number;
}

export interface GoalsInfo {
  primaryGoal: PrimaryGoalType;
  secondaryGoals: SecondaryGoalType[];
}

export interface LifestyleInfo {
  activityLevel: ActivityLevelType;
  exerciseFrequency: number; // 0-7 days/week
  sleepTargetHours: number; // 4-12 hours
  bedtime: string; // HH:MM
  wakeTime: string; // HH:MM
  equipment: EquipmentType[];
}

export interface PreferencesInfo {
  language: LanguageCode;
  units: UnitSystemType;
  aiTone: AiToneType;
  notifications: NotificationPreferences;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  age: number;
  gender: GenderType;
  heightCm: number;
  weightKg: number;
  targetWeightKg: number;
  fitnessGoal: 'weight_loss' | 'muscle_gain' | 'maintenance' | 'endurance';
  primaryGoal?: PrimaryGoalType;
  secondaryGoals?: SecondaryGoalType[];
  activityLevel: ActivityLevelType;
  exerciseFrequency?: number;
  sleepTargetHours?: number;
  bedtime?: string;
  wakeTime?: string;
  equipment?: EquipmentType[];
  units?: UnitSystemType;
  aiTone?: AiToneType;
  notifications?: NotificationPreferences;
  hasCompletedOnboarding?: boolean;
  dailyWaterTargetMl: number;
  dailyCalorieTarget: number;
  dailyCarbsTargetG: number;
  dailyProteinTargetG: number;
  dailyFatTargetG: number;
  dailyStepsTarget: number;
  dailySleepTargetHours: number;
  streakCount: number;
  level: number;
  xp: number;
  xpNextLevel: number;
  language: LanguageCode;
  autoTranslateAdvice: boolean;
  subscriptionPlan?: SubscriptionPlanType;
  subscriptionStatus?: 'active' | 'trial' | 'expired';
  planActiveUntil?: string;
  clinicName?: string;
  patientSlotsUsed?: number;
  teamMembersCount?: number;
  cuisinePreferences?: string[];
  dietPreferences?: string[];
  foodsToAvoid?: string[];
}

export interface DailyLog {
  date: string; // YYYY-MM-DD
  waterIntakeMl: number;
  caloriesConsumed: number;
  carbsG: number;
  proteinG: number;
  fatG: number;
  stepsCount: number;
  sleepHours: number;
  weightKg: number;
  heartRateAvg?: number;
  stressLevel?: number; // 1-10
}

export interface MealItem {
  id: string;
  name: string;
  timestamp: string;
  category: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  calories: number;
  carbsG: number;
  proteinG: number;
  fatG: number;
  healthRating: number; // 1 to 10
  imageUrl?: string;
  detectedObjects?: string[];
  aiAdvice?: string;
  micronutrients?: {
    fiberG?: number;
    sodiumMg?: number;
    potassiumMg?: number;
    vitaminCPercent?: number;
  };
}

export interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: string;
  durationSec?: number;
  targetMuscle: string;
  instructions: string;
  completed?: boolean;
}

export interface WorkoutPlan {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedDurationMin: number;
  estimatedCaloriesBurned: number;
  exercises: Exercise[];
  createdAt: string;
  sorenessAdjusted?: boolean;
}

export interface HabitItem {
  id: string;
  titleKey: string;
  defaultTitle: string;
  icon: string;
  target: string;
  completedToday: boolean;
  category: 'hydration' | 'nutrition' | 'fitness' | 'recovery' | 'mindset';
  xpReward: number;
}

export interface AchievementBadge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
  progressPercent: number;
}

export interface FirestoreSchemaNode {
  collection: string;
  docId: string;
  data: Record<string, any>;
  subcollections?: FirestoreSchemaNode[];
}

export interface SportActivityLog {
  id: string;
  name: string;
  category: 'running' | 'cycling' | 'badminton' | 'futsal' | 'swimming' | 'basketball' | 'yoga' | 'tennis' | 'other';
  durationMin: number;
  caloriesBurned: number;
  distanceKm?: number;
  paceAvg?: string;
  avgHeartRate?: number;
  timestamp: string;
  notes?: string;
}

// Cross-Module Autonomous Event System
export interface CrossModuleEvent {
  id: string;
  timestamp: string;
  triggerEvent: string;
  sourceModule: string;
  automatedActions: {
    targetModule: string;
    actionDescription: string;
    status: 'applied' | 'pending';
    badge: string;
  }[];
}

// Modul 1: AI Coach Core Comprehensive Types
export interface BiometricAssessment {
  age: number;
  weightKg: number;
  heightCm: number;
  bodyFatPercent?: number;
  injuryHistory: string[];
  mobilityRestrictions: string[];
  specificGoal: string;
  availableEquipment: string;
  dailyTimeMin: number;
  psychologicalPreference: 'hardcore_hiit' | 'hypertrophy_strength' | 'calm_flow_mobility' | 'balanced_control';
  assessmentDate?: string;
  periodizationPlan?: {
    programTitle: string;
    tagline: string;
    biomechanicalFocus: string;
    readinessBaselineScore: number;
    weeklyRoadmap: {
      weekNumber: number;
      phaseName: string;
      primaryFocus: string;
      keyExercises: string[];
      injuryPreventionCue: string;
    }[];
    coachPrescription: string;
  };
}

export interface DailyReadinessData {
  energyLevel: number; // 1-10
  sleepHours: number;
  sleepQuality: number; // 0-100%
  hrvMs: number;
  restingHrBpm: number;
  domsSorenessLevel: number; // 1-10
  soreMuscles: string[];
  readinessScore: number;
  trainingStatus: 'PEAK_OVERLOAD' | 'STANDARD_PROGRESSION' | 'ACTIVE_RECOVERY' | 'DELOAD_MOBILITY';
  readinessVerdict: string;
  volumeIntensityAdjustment: string;
  targetRpeRange: string;
  warmupSequence5Min: {
    movementName: string;
    durationSec: number;
    targetArea: string;
    purpose: string;
  }[];
  coachInsight: string;
}

export interface ExerciseSubstitutionItem {
  name: string;
  targetMuscle: string;
  whyItIsSafer: string;
  equipmentNeeded: string;
  recommendedSetsReps: string;
}

export interface SubstitutionResult {
  originalExercise: string;
  biomechanicalConflict: string;
  alternatives: ExerciseSubstitutionItem[];
  rehabTip: string;
}

export interface PostWorkoutRecoveryData {
  sessionVerdict: string;
  recoveryStatus: string;
  optimalNutritionWindowMin: number;
  proteinTargetGrams: number;
  carbsTargetGrams: number;
  recommendedMealExamples: string[];
  hydrationRecommendationMl: number;
  coolDownStretches: {
    stretchName: string;
    durationSec: number;
    muscleTargeted: string;
  }[];
  nextSessionAdjustment: string;
}

// ==========================================
// MODUL 2: FORMGUARD AI (COMPUTER VISION & BIOMECHANICS)
// ==========================================

export type FormGuardExerciseId =
  | 'barbell_squat'
  | 'push_up'
  | 'romanian_deadlift'
  | 'plank_hold'
  | 'overhead_press'
  | 'warrior_yoga';

export interface FormGuardExerciseConfig {
  id: FormGuardExerciseId;
  name: string;
  nameEn: string;
  category: 'lower_body' | 'upper_body' | 'core_stability' | 'mobility_flow';
  primaryTarget: string;
  criticalAngles: {
    name: string;
    idealMin: number;
    idealMax: number;
    unit: string;
    dangerThresholdBelow?: number;
    dangerThresholdAbove?: number;
    riskDescription: string;
  }[];
  commonMistakes: {
    title: string;
    triggerCondition: string;
    audioCueId: string;
    audioCueEn: string;
    bodyPart: 'neck' | 'left_shoulder' | 'right_shoulder' | 'left_elbow' | 'right_elbow' | 'lumbar_spine' | 'hips' | 'left_knee' | 'right_knee' | 'ankles';
    severity: 'caution' | 'danger';
    correctionArrowDirection: 'up' | 'down' | 'left' | 'right' | 'outward' | 'inward';
  }[];
  recommendedCameraPlacement: string;
  idealDepthCadence: string;
}

export interface LandmarkPoint {
  x: number; // 0.0 - 1.0 (normalized)
  y: number; // 0.0 - 1.0 (normalized)
  z?: number;
  visibility?: number; // 0.0 - 1.0
  name: string;
}

export interface BiomechanicalFrameState {
  timestamp: number;
  repCount: number;
  currentPhase: 'eccentric' | 'inflection_bottom' | 'concentric' | 'lockout_top' | 'holding';
  overallFormScore: number; // 0 - 100
  statusVerdict: 'OPTIMAL' | 'CAUTION' | 'DANGER' | 'TECHNICAL_FATIGUE';
  measuredAngles: {
    jointKey: string;
    displayName: string;
    currentAngle: number;
    idealRange: [number, number];
    status: 'good' | 'warning' | 'critical';
  }[];
  activeCorrections: {
    id: string;
    bodyPart: string;
    message: string;
    severity: 'caution' | 'danger';
    arrowOrigin: { x: number; y: number };
    arrowDirection: { dx: number; dy: number };
  }[];
  cadenceSecondsPerRep: number;
  symmetryIndexPercent: number; // 0-100%
  technicalFatigueDetected: boolean;
  technicalFatigueConfidence: number; // 0-100%
}

export interface BodyPartHeatmapData {
  bodyPartId: 'neck' | 'left_shoulder' | 'right_shoulder' | 'left_elbow' | 'right_elbow' | 'lumbar_spine' | 'hips' | 'left_knee' | 'right_knee' | 'ankles';
  displayName: string;
  errorCount: number;
  severityGrade: 'green' | 'yellow' | 'red';
  primaryIssue: string;
  injuryRiskFactor: string;
}

export interface FormGuardPostSetReport {
  exerciseId: FormGuardExerciseId;
  exerciseName: string;
  totalReps: number;
  cleanReps: number;
  compromisedReps: number;
  techniqueScore: number; // 0-100
  techniqueGrade: 'S' | 'A' | 'B' | 'C' | 'D';
  durationSeconds: number;
  averageCadenceSec: number;
  symmetryScore: number; // 0-100
  failureTypeAnalysis: {
    classifiedFailure: 'PURE_MUSCULAR_FAILURE' | 'TECHNICAL_FORM_BREAKDOWN' | 'PERFECT_COMPLETION' | 'PREMATURE_TERMINATION';
    failureOnsetRep?: number;
    explanation: string;
    clinicalSafetyVerdict: string;
  };
  bodyErrorHeatmap: BodyPartHeatmapData[];
  idealVsActualKinematics: {
    jointName: string;
    actualAngleAvg: number;
    idealAngleTarget: number;
    variancePercent: number;
    biomechanicalImpact: string;
  }[];
  correctivePrescription: {
    immediateAdvice: string;
    rehabWarmupMovements: {
      movement: string;
      repsDuration: string;
      targetBenefit: string;
    }[];
    regressionProgressionAdvice: string;
  };
  crossModuleSync: {
    trainerModuleAction: string;
    recoveryModuleAction: string;
    medicalTriageFlag: boolean;
  };
}

export interface CaseStudySariProfile {
  personaName: string;
  age: number;
  fitnessLevel: string;
  complaint: string;
  exerciseTested: string;
  rootCauseDetectedByFormGuard: string;
  measuredMetrics: {
    metric: string;
    measuredValue: string;
    safeRange: string;
    riskStatus: 'critical' | 'warning' | 'optimal';
  }[];
  aiAudioInterventions: string[];
  autonomousResolution: {
    immediateCorrection: string;
    regressionRecommended: string;
    accessoryExercise: string;
    progressAfter2Weeks: string;
  };
}

// ==========================================
// MODUL 3: RECOVERY LAB AI TYPES
// ==========================================

export type PainSensationType = 'sharp' | 'tight' | 'fatigued';

export type BodyPartId =
  | 'head_neck'
  | 'traps'
  | 'left_shoulder'
  | 'right_shoulder'
  | 'chest'
  | 'upper_back'
  | 'lower_back'
  | 'left_elbow'
  | 'right_elbow'
  | 'forearms'
  | 'core_abs'
  | 'left_hip_flexor'
  | 'right_hip_flexor'
  | 'glutes'
  | 'left_quadriceps'
  | 'right_quadriceps'
  | 'left_hamstring'
  | 'right_hamstring'
  | 'left_knee'
  | 'right_knee'
  | 'left_calf'
  | 'right_calf'
  | 'left_achilles_ankle'
  | 'right_achilles_ankle'
  | 'left_plantar_heel'
  | 'right_plantar_heel';

export interface BodyPainPoint {
  id: string;
  bodyPartId: BodyPartId;
  name: string;
  nameEn: string;
  view: 'front' | 'back';
  side: 'left' | 'right' | 'center' | 'bilateral';
  sensation: PainSensationType;
  severity: number; // 1 - 10 VAS scale
  notes?: string;
  probableCause?: string;
  anatomicalConnection?: string;
}

export type RecoveryModality =
  | 'foam_rolling'
  | 'static_stretch'
  | 'dynamic_mobility'
  | 'pnf_stretch'
  | 'diaphragmatic_breathing'
  | 'ice_rice_protocol'
  | 'contrast_hydrotherapy'
  | 'heat_sauna'
  | 'percussion_massage';

export interface RecoveryStep {
  id: string;
  title: string;
  modality: RecoveryModality;
  durationSeconds: number;
  targetArea: string;
  instructions: string[];
  triggerPointCue?: string;
  audioPrompt?: string;
  breathingPattern?: {
    inhaleSec: number;
    holdSec: number;
    exhaleSec: number;
    pauseSec: number;
  };
  safetyWarning?: string;
}

export interface RecoveryRoutine {
  id: string;
  title: string;
  subtitle: string;
  category: 'tightness' | 'cns_fatigue' | 'mild_strain_rice' | 'desk_worker_decompression' | 'contrast_hydro' | 'post_run_fascia';
  durationMinutes: number;
  targetPainPoints: string[];
  aiClinicalRationale: string;
  steps: RecoveryStep[];
  cnsParasympatheticGainPercent: number;
  estimatedPainReliefPercent: number;
  hydrationTip: string;
  antiInflammatoryDietTip: string;
  crossModuleSyncDirectives: {
    trainerModuleAction: string;
    formGuardVigilanceArea?: string;
    nutritionRehabRecommendation: string;
    telemedicineFlag: boolean;
  };
}

export interface ContrastCycleStep {
  phase: 'cold' | 'hot' | 'rest' | 'dry_brush';
  temperatureDesc: string;
  durationSec: number;
  actionGuidance: string;
  physiologicalEffect: string;
}

export interface ContrastProtocol {
  id: string;
  title: string;
  goal: 'anti_inflammation' | 'muscle_relaxation' | 'cns_reset' | 'delayed_doms_clearance';
  totalDurationMin: number;
  temperatureCold: string;
  temperatureHot: string;
  cycles: ContrastCycleStep[];
  postTherapyAdvice: string;
  contraindications: string[];
}

export interface WearableRecoveryMetrics {
  hrvRmssdMs: number;
  hrvBaselineMs: number;
  hrvStatus: 'optimal' | 'moderate' | 'severely_depleted';
  sleepQualityPercent: number;
  deepSleepDurationMinutes: number;
  morningStiffnessIndex: number; // 1-10
  cnsRecoveryScore: number; // 0-100
  suggestedWorkoutIntensityFactor: number; // e.g. 0.6 (60% load) or 1.0
  isDeloadRecommended: boolean;
  recoverySummaryText: string;
}

export interface CaseStudyAndiProfile {
  personaName: string;
  age: number;
  sport: string;
  chiefComplaint: string;
  affectedArea: string;
  sensationType: PainSensationType;
  severityVas: number;
  aiDiagnosis: {
    primaryCondition: string;
    underlyingBiomechanics: string;
    correlatedActivity: string;
  };
  immediateActions: string[];
  guidedRehabProtocol: {
    dayRange: string;
    phaseName: string;
    actions: string[];
  }[];
  crossModuleIntegration: {
    trainerModuleSubstitution: string;
    formGuardNextFocus: string;
    nutritionAntiInflammatory: string;
  };
  outcomeAfterOneWeek: {
    painScoreBefore: number;
    painScoreAfter: number;
    recoveryVerdict: string;
    returnToRunSafetyCheck: string;
  };
}

// ==========================================
// MODUL 4: PERFORMANCE PULSE (PELACAK PERFORMA SPESIFIK)
// ==========================================
export type SportDisciplineType = 'strength' | 'cardio' | 'hiit_calisthenics' | 'court_field_sport';

export interface StrengthPerformanceLog {
  id: string;
  exerciseName: string;
  weightKg: number;
  reps: number;
  sets: number;
  rpe: number; // 1-10 (Rate of Perceived Exertion)
  estimated1RmEpleyKg: number; // Weight * (1 + Reps/30)
  estimated1RmBrzyckiKg: number; // Weight * (36 / (37 - Reps))
  totalVolumeKg: number; // Weight * Reps * Sets
  trainingDensityKgPerMin?: number;
  isPersonalRecord: boolean;
  previous1RmKg?: number;
  barbellVelocityMs?: number; // m/s
  date: string;
  notes?: string;
}

export interface HeartRateZoneDistribution {
  zone1RecoverySec: number; // < 60% Max HR (Warmup & Active Recovery)
  zone2AerobicBaseSec: number; // 60-70% Max HR (Fat Burn & Aerobic Base)
  zone3TempoSec: number; // 70-80% Max HR (Aerobic Endurance)
  zone4ThresholdSec: number; // 80-90% Max HR (Lactate Threshold)
  zone5AnaerobicSec: number; // > 90% Max HR (VO2 Max & Sprint)
}

export interface CardioPerformanceLog {
  id: string;
  activityType: 'running' | 'cycling' | 'swimming' | 'rowing';
  title: string;
  distanceKm: number;
  durationSec: number;
  avgPaceMinPerKm: string; // e.g. "5'30\"/km"
  avgHeartRateBpm: number;
  maxHeartRateBpm: number;
  cadenceSpm: number; // Steps per minute or RPM
  elevationGainM: number;
  runningEconomyIndex: number; // e.g. Speed(m/min) / HR ratio
  powerWattsAvg?: number;
  powerWattsPerKg?: number;
  caloriesBurned: number;
  heartRateZones: HeartRateZoneDistribution;
  isPersonalRecord?: boolean;
  date: string;
  notes?: string;
  weatherCondition?: string;
  shoesGearUsed?: string;
}

export interface HiitPerformanceLog {
  id: string;
  routineName: string;
  roundsCompleted: number;
  targetRounds: number;
  workIntervalSec: number;
  restIntervalSec: number;
  averageHeartRateBpm: number;
  intensityConsistencyPercent: number;
  calisthenicsRepCounts: {
    exerciseName: string;
    reps: number;
    maxHoldSec?: number;
  }[];
  date: string;
  notes?: string;
}

export interface CourtSportPerformanceLog {
  id: string;
  sport: 'badminton' | 'basketball' | 'futsal_football' | 'tennis';
  matchName: string;
  durationMin: number;
  totalDistanceCoveredKm: number;
  sprintBurstCount: number;
  topSprintSpeedKmh: number;
  highIntensityDistanceKm: number;
  agilityDirectionChangesCount: number;
  caloriesBurned: number;
  avgHeartRateBpm: number;
  matchOutcome?: 'win' | 'loss' | 'draw' | 'practice';
  date: string;
  notes?: string;
}

export interface PersonalRecordItem {
  id: string;
  discipline: SportDisciplineType;
  metricName: string; // e.g. "1RM Barbell Back Squat", "5K Run Fastest Pace", "Max Pull-Ups"
  recordValue: number;
  recordUnit: string; // "kg", "min/km", "reps", "km/h", "km"
  recordValueFormatted: string; // "140 kg", "22:15 min", "24 reps"
  dateAchieved: string;
  previousRecordValue?: number;
  badgeIcon: string;
  targetNextGoal: number;
  targetNextGoalFormatted: string;
  aiPredictionCommentary: string;
  confidenceScorePercent: number;
}

export interface WeeklyPerformanceReport {
  weekRange: string;
  totalStrengthVolumeKg: number;
  totalStrengthSets: number;
  totalCardioDistanceKm: number;
  totalActiveTimeHours: number;
  personalRecordsUnlockedCount: number;
  trainingLoadStatus: 'optimal' | 'overreaching' | 'deload_recommended' | 'undertrained';
  aerobicEfficiencyDeltaPercent: number; // e.g. +4.2%
  strengthVolumeDeltaPercent: number; // e.g. +8.5%
  sleepToPerformanceCorrelation: string;
  aiCoachDirectives: {
    headline: string;
    actionableTips: string[];
    riskWarning?: string;
    crossModuleDirectives: {
      trainerWeightAdjustment: string;
      recoveryPrescription: string;
      nutritionCarbAdjustment: string;
    };
  };
}

export interface CaseStudyRinaProfile {
  personaName: string;
  age: number;
  sport: string;
  goal: string;
  initialStruggle: string;
  baselineData: {
    paceAvgMinKm: string;
    avgHeartRateBpm: number;
    dominantZone: string;
    weeklyDistanceKm: number;
    cadenceSpm: number;
    runningEconomyScore: number;
  };
  aiDiagnosis: {
    primaryMistake: string; // "Junk Miles Syndrome"
    physiologicalCause: string;
    lactateThresholdDisparity: string;
  };
  intervention8020Plan: {
    zone2AerobicPercentage: number; // 80%
    highIntensityPercentage: number; // 20%
    weeklySchedule: {
      day: string;
      workoutType: string;
      targetZone: string;
      targetPace: string;
      purpose: string;
    }[];
  };
  outcomeAfter4Weeks: {
    easyRunPaceChange: string; // 7:00 -> 6:30 min/km
    averageHeartRateDropBpm: number; // -12 bpm in Zone 2
    vo2MaxImprovement: string;
    runningEconomyDeltaPercent: number;
    marathonReadinessVerdict: string;
  };
  takeawayPrinciples: string[];
}

// =================================================================
// MODUL 5: POSTUREGUARD AI (KESEHATAN POSTUR & ERGONOMI KERJA)
// =================================================================

export type PostureAnomalyType =
  | 'forward_head'
  | 'slouching'
  | 'shoulder_hunch'
  | 'asymmetrical_shoulder'
  | 'leg_crossing'
  | 'optimal';

export interface PostureLiveMetrics {
  craniovertebralAngle: number; // Normal > 50°, Bad < 48°
  thoracicKyphosisAngle: number; // Normal 25-40°, Slouch > 45°
  shoulderSymmetryDeltaDeg: number; // 0-2° ideal, > 4° asymmetrical
  cervicalSpineLoadKg: number; // Head load: 0° -> 5kg, 15° -> 12kg, 30° -> 18kg, 45° -> 22kg, 60° -> 27kg
  currentPostureState: 'optimal' | 'mild_risk' | 'severe_risk';
  activeAnomaly: PostureAnomalyType;
  consecutiveBadPostureSec: number;
  dailyPostureScore: number; // 0-100
  totalTrackedMinutesToday: number;
  uprightMinutesToday: number;
  slouchedMinutesToday: number;
  flowStateProtectionActive: boolean;
  hapticOrVisualAlertEnabled: boolean;
  audioSpeechAlertEnabled: boolean;
}

export interface DeskYogaExercise {
  id: string;
  title: string;
  titleEn: string;
  category: 'neck_cervical' | 'thoracic_back' | 'shoulder_chest' | 'wrist_hands' | 'hips_lumbar' | 'eyes_20_20';
  targetArea: string;
  durationSec: number;
  repsOrHold: string;
  instructions: string[];
  biomechanicalBenefit: string;
  contraindications?: string;
  recommendedFrequency: string;
}

export interface ErgonomicAuditItem {
  id: string;
  category: 'monitor' | 'chair_lumbar' | 'keyboard_mouse' | 'foot_placement' | 'lighting_eyes';
  title: string;
  idealStandard: string;
  currentStatus: 'ideal' | 'needs_adjustment' | 'high_risk';
  userChoiceOption?: string;
  actionableFix: string;
  biomechanicalReason: string;
  recommendedGear?: {
    name: string;
    benefit: string;
    estimatedPriceIdr: string;
  };
}

export interface PostureHourlyHeatmapPoint {
  hourLabel: string; // '09:00', '10:00', etc.
  score: number; // 0-100
  dominantAnomaly: PostureAnomalyType;
  slouchPercentage: number;
  microBreakTaken: boolean;
}

export interface CaseStudyBudiProfile {
  personaName: string;
  role: string;
  age: number;
  dailyScreenTimeHours: number;
  initialComplaint: string; // Tension headache 15:00, neck stiffness, right trap knot
  baselinePostureMetrics: {
    forwardHeadDistanceCm: number; // 10 cm
    craniovertebralAngle: number; // 38° (Severe Text Neck)
    cervicalSpineLoadKg: number; // 24.5 kg pressure on C5-C7
    rightShoulderElevationDeg: number; // 5.2° tilt from flat mouse
    dailyPostureScore: number; // 48/100
  };
  aiInterventionPlan: {
    workstationAdjustments: string[];
    equipmentPrescriptions: string[];
    deskYogaMicroBreaks: string[];
    adaptiveAlertCadence: string;
  };
  clinicalOutcomeAfter14Days: {
    headacheFrequencyReductionPercent: number; // -85%
    craniovertebralAngleIncrease: number; // 38° -> 52°
    cervicalSpineLoadReductionKg: number; // 24.5 kg -> 6.2 kg
    dailyPostureScoreFinal: number; // 88/100
    productivityRatingDeltaPercent: number; // +28%
  };
  keyTakeaways: string[];
}

// =================================================================
// MODUL 16 & FITUR UTAMA: KONSULTASI DOKTER AI KLINIS & ANAMNESIS
// =================================================================

export type DoctorTriageLevel = 'GREEN_MILD' | 'YELLOW_OBSERVE' | 'RED_EMERGENCY';

export interface ClinicalVitals {
  systolicBp?: number;
  diastolicBp?: number;
  heartRateBpm?: number;
  bodyTempCelsius?: number;
  oxygenSaturationPercent?: number;
  respirationRatePerMin?: number;
}

export interface ClinicalIntakeForm {
  patientName: string;
  patientAge: number;
  patientGender: 'male' | 'female' | 'other';
  chiefComplaint: string; // Keluhan utama
  symptomDuration: string; // e.g., "Sejak 2 hari lalu", "Tadi pagi mendadak"
  painScaleVas: number; // 0 - 10
  painCharacter: 'stabbing' | 'pulsating' | 'burning' | 'dull_aching' | 'cramping' | 'tightness' | 'none';
  associatedSymptoms: string[]; // ['Demam', 'Mual/Muntah', 'Pusing Berputar', 'Batuk', 'Sesak Napas', 'Diare', dll]
  existingConditions: string[]; // ['Hipertensi', 'Diabetes Melitus', 'Asma/Alergi', 'Maag/GERD', 'Kolesterol Tinggi']
  currentMedications: string; // Obat yang sedang diminum
  drugOrFoodAllergies: string; // Alergi obat/makanan
  lifestyleFactors: {
    sleepHoursLastNight: number;
    stressLevel: number; // 1-10
    waterIntakeLiters: number;
    recentUnusualDietOrActivity: string;
  };
  vitals: ClinicalVitals;
}

export interface ClinicalExaminationResult {
  consultationId: string;
  timestamp: string;
  triageLevel: DoctorTriageLevel;
  triageVerdict: string;
  redFlagsWarning: string[];
  primaryDiagnosis: {
    conditionName: string;
    conditionNameEn: string;
    confidenceScorePercent: number;
    clinicalReasoning: string;
    pathophysiologySummary: string;
  };
  differentialDiagnoses: {
    conditionName: string;
    probabilityLevel: 'high' | 'moderate' | 'low';
    reason: string;
  }[];
  prescriptionAndHomeCare: {
    nonPharmacologicalCare: {
      category: string;
      title: string;
      actionGuidance: string;
    }[];
    otcMedicationGuidance: {
      medicineName: string;
      dosageAdvice: string;
      contraindications: string;
    }[];
    recommendedLabTests: string[];
    lifestyleAdjustments: string[];
    warningSignsToHospital: string[];
  };
  empatheticClosingMessage: string;
}

export interface DoctorChatMessage {
  id: string;
  sender: 'doctor' | 'patient';
  text: string;
  timestamp: string;
  specialistTitle?: string;
}

export * from './types/health';






