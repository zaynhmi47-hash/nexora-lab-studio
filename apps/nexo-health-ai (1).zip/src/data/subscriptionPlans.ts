import { SubscriptionPlanType } from '../types';

export interface PlanFeatureItem {
  id: string;
  name: string;
  nameEn: string;
  category: 'core' | 'ai_modules' | 'clinical_business' | 'security_support';
  description: string;
  descriptionEn: string;
  tiers: {
    free: boolean | string;
    pro: boolean | string;
    business: boolean | string;
    enterprise: boolean | string;
  };
}

export interface SubscriptionPlanInfo {
  id: SubscriptionPlanType;
  name: string;
  nameEn: string;
  tagline: string;
  taglineEn: string;
  priceMonthlyIdr: number;
  priceYearlyIdr: number;
  priceMonthlyUsd: number;
  priceYearlyUsd: number;
  badge: string;
  badgeColor: string;
  isPopular?: boolean;
  highlightText?: string;
  highlightTextEn?: string;
  description: string;
  descriptionEn: string;
  keyBenefits: string[];
  keyBenefitsEn: string[];
  limits: {
    scansPerDay: number | 'unlimited';
    modulesAllowed: number | 'all';
    patientSlots: number;
    teamMembers: number;
    ehrExport: boolean;
    aiDoctorPriority: boolean;
    apiAccess: boolean;
    customClinicBranding: boolean;
    dedicatedAccountManager: boolean;
  };
}

export const SUBSCRIPTION_PLANS: SubscriptionPlanInfo[] = [
  {
    id: 'free',
    name: 'Gratis (Starter)',
    nameEn: 'Free (Starter)',
    tagline: 'Pemantauan kesehatan dasar mandiri',
    taglineEn: 'Essential personal health logging',
    priceMonthlyIdr: 0,
    priceYearlyIdr: 0,
    priceMonthlyUsd: 0,
    priceYearlyUsd: 0,
    badge: 'GRATIS',
    badgeColor: 'bg-slate-100 text-slate-700 border-slate-300',
    description: 'Cocok untuk pengguna individu yang ingin mulai mencatat pola makan, hidrasi, dan olahraga.',
    descriptionEn: 'Ideal for individuals starting out with basic calorie, water, and fitness habits.',
    keyBenefits: [
      '5 Modul Kesehatan Utama (Trainer, Diet, Hidrasi, dll)',
      'Pemindai Makanan AI (Maksimal 3x/hari)',
      'Pencatatan Hidrasi, Langkah & Kalori Harian',
      'Penyimpanan Offline & Sinkronisasi Dasar',
      'Akses Komunitas Sehat',
    ],
    keyBenefitsEn: [
      '5 Essential Health Modules',
      'AI Food Scanner (Max 3 scans/day)',
      'Daily Hydration, Steps & Calorie Tracker',
      'Offline Local Storage & Basic Sync',
      'Community Health Feed Access',
    ],
    limits: {
      scansPerDay: 3,
      modulesAllowed: 5,
      patientSlots: 1,
      teamMembers: 1,
      ehrExport: false,
      aiDoctorPriority: false,
      apiAccess: false,
      customClinicBranding: false,
      dedicatedAccountManager: false,
    },
  },
  {
    id: 'pro',
    name: 'AI Health Pro',
    nameEn: 'AI Health Pro',
    tagline: 'Kecerdasan buatan medis personal tanpa batas',
    taglineEn: 'Unlimited personal AI medical intelligence',
    priceMonthlyIdr: 79000,
    priceYearlyIdr: 790000,
    priceMonthlyUsd: 5.99,
    priceYearlyUsd: 59.99,
    badge: 'POPULAR PRO',
    badgeColor: 'bg-emerald-500 text-white shadow-emerald-500/20 shadow-md',
    isPopular: true,
    highlightText: 'Paling Diminati Pengguna Personal',
    highlightTextEn: 'Most Popular for Individuals',
    description: 'Buka seluruh 20 modul kesehatan terpadu, pemindai makanan AI tanpa batas, serta konsultasi dokter AI 24/7.',
    descriptionEn: 'Unlock all 20 integrated modules, unlimited visual food scans, and 24/7 interactive AI doctor advice.',
    keyBenefits: [
      'Akses Penuh Semua 20 Modul Kesehatan Google Health',
      'Pemindai Makanan AI Gemini 2.5 Tanpa Batas',
      'Konsultasi Dokter AI Suara & Teks Interaktif 24/7',
      'Analisis Postur Tubuh & Koreksi Gerak Computer Vision',
      'Pelacakan Longevity, Hormonal & Terapi CBT',
      'Ekspor Cadangan Lengkap Riwayat Kesehatan (JSON/PDF)',
    ],
    keyBenefitsEn: [
      'Full Access to all 20 Google Health Ecosystem Modules',
      'Unlimited Gemini 2.5 Food & Meal Vision Scanner',
      '24/7 Interactive Voice & Text AI Doctor Consults',
      'Computer Vision Exercise & Posture Biomechanics',
      'Longevity Screening, Hormonal & CBT Therapy Tools',
      'Complete Health History Export (JSON & PDF)',
    ],
    limits: {
      scansPerDay: 'unlimited',
      modulesAllowed: 'all',
      patientSlots: 1,
      teamMembers: 1,
      ehrExport: true,
      aiDoctorPriority: true,
      apiAccess: false,
      customClinicBranding: false,
      dedicatedAccountManager: false,
    },
  },
  {
    id: 'business',
    name: 'Bisnis / Klinik Hub',
    nameEn: 'Business / Clinic Hub',
    tagline: 'Solusi lengkap dokter, klinik, gym & konsultan gizi',
    taglineEn: 'Complete suite for doctors, clinics, gyms & dietitians',
    priceMonthlyIdr: 249000,
    priceYearlyIdr: 2490000,
    priceMonthlyUsd: 16.99,
    priceYearlyUsd: 169.99,
    badge: 'BISNIS KLINIK',
    badgeColor: 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-md',
    highlightText: 'Rekomendasi untuk Praktisi & Klinik',
    highlightTextEn: 'Recommended for Clinics & Doctors',
    description: 'Kelola hingga 50 pasien sekaligus, buat resep digital berlogo klinik, integrasi tim dokter, serta akses prioritas tinggi.',
    descriptionEn: 'Manage up to 50 patients, generate branded digital prescriptions, team collaboration, and high-priority AI.',
    keyBenefits: [
      'Semua Fitur AI Health Pro Termasuk',
      'Dasbor Manajemen Pasien / Klien (Hingga 50 Pasien)',
      'Generator Resep Digital & Rekam Medis (EHR) Berstandar Klinis',
      'Kolaborasi 5 Akun Staf / Dokter / Ahli Gizi',
      'Kustomisasi Branding & Logo Klinik pada Lembar Hasil',
      'Prioritas Komputasi AI Engine Gemini 2.5 Ultra Super Cepat',
      'Akses API & Webhook Sinkronisasi Sistem Medis (SIMRS)',
      'Dukungan VIP CS Prioritas & Sesi Onboarding Tim',
    ],
    keyBenefitsEn: [
      'All AI Health Pro Features Included',
      'Multi-Patient / Client Management Hub (Up to 50 slots)',
      'Clinical-grade Digital Prescription & EHR Generator',
      '5 Team / Doctor / Dietitian Collaborative Seats',
      'Custom Clinic Branding & Logo on Medical Reports',
      'Ultra-Fast Priority Compute Gemini 2.5 AI Engine',
      'API & Webhook Access for Hospital System (SIMRS) Sync',
      'VIP Priority Support & Team Onboarding Session',
    ],
    limits: {
      scansPerDay: 'unlimited',
      modulesAllowed: 'all',
      patientSlots: 50,
      teamMembers: 5,
      ehrExport: true,
      aiDoctorPriority: true,
      apiAccess: true,
      customClinicBranding: true,
      dedicatedAccountManager: false,
    },
  },
  {
    id: 'enterprise',
    name: 'Enterprise Hospital Hub',
    nameEn: 'Enterprise Hospital Hub',
    tagline: 'Infrastruktur rumah sakit & jaringan kesehatan berskala besar',
    taglineEn: 'Large hospital networks & enterprise health systems',
    priceMonthlyIdr: 599000,
    priceYearlyIdr: 5990000,
    priceMonthlyUsd: 39.99,
    priceYearlyUsd: 399.99,
    badge: 'ENTERPRISE',
    badgeColor: 'bg-slate-900 text-amber-300 border border-amber-400/40 shadow-md',
    description: 'Dirancang untuk jaringan rumah sakit, asuransi, dan korporasi dengan kebutuhan pasien tanpa batas dan integrasi server khusus.',
    descriptionEn: 'Engineered for hospitals, insurance groups, and corporations requiring unlimited seats and custom deployments.',
    keyBenefits: [
      'Semua Fitur Paket Bisnis Termasuk',
      'Kapasitas Pasien & Akun Tenaga Medis Tanpa Batas',
      'Integrasi Server On-Premise / Cloud Mandiri Khusus',
      'SLA Uptime Kritis 99.99% & Perjanjian BAA HIPAA/GDPR',
      'Custom LLM Fine-Tuning Sesuai Database Medis RS',
      'Manajer Akun & Dokter Konsultan Khusus (Dedicated Account Manager)',
    ],
    keyBenefitsEn: [
      'All Business Features Included',
      'Unlimited Patient Slots & Unlimited Medical Staff Seats',
      'Dedicated On-Premise or Private Cloud Deployment',
      '99.99% Mission-Critical SLA & Custom BAA / GDPR Agreements',
      'Custom LLM Model Fine-Tuning for Hospital Protocols',
      'Dedicated Medical Success Manager & 24/7 SLA Hotline',
    ],
    limits: {
      scansPerDay: 'unlimited',
      modulesAllowed: 'all',
      patientSlots: 99999,
      teamMembers: 99999,
      ehrExport: true,
      aiDoctorPriority: true,
      apiAccess: true,
      customClinicBranding: true,
      dedicatedAccountManager: true,
    },
  },
];

export const ALL_FEATURES_MATRIX: PlanFeatureItem[] = [
  // KATEGORI 1: KECERDASAN BUATAN & DIAGNOSTIK
  {
    id: 'feat_food_scanner',
    name: 'Pemindai Makanan & Gizi AI Gemini',
    nameEn: 'Gemini Food & Nutrition AI Scanner',
    category: 'ai_modules',
    description: 'Deteksi otomatis kalori, makronutrien, dan estimasi porsi dari foto makanan dengan computer vision.',
    descriptionEn: 'Auto-detect calories, macros, and portion estimate from photos with computer vision.',
    tiers: { free: '3x / Hari', pro: 'Tanpa Batas', business: 'Tanpa Batas', enterprise: 'Tanpa Batas' },
  },
  {
    id: 'feat_modules_count',
    name: 'Akses 20 Modul Kesehatan Terpadu',
    nameEn: 'Access to 20 Integrated Modules',
    category: 'ai_modules',
    description: 'Mencakup kebugaran fisik, perbaikan postur, gizi, CBT kesehatan mental, umur panjang, & hormon.',
    descriptionEn: 'Covers physical fitness, posture CV, nutrition, mental CBT, longevity, and hormonal tracking.',
    tiers: { free: '5 Modul Dasar', pro: '20 Modul Lengkap', business: '20 Modul Lengkap', enterprise: '20 Modul Lengkap' },
  },
  {
    id: 'feat_ai_doctor',
    name: 'Konsultasi Dokter AI Suara & Teks 24/7',
    nameEn: '24/7 Voice & Text AI Doctor Consults',
    category: 'ai_modules',
    description: 'Tanya jawab triase medis, interpretasi laboratorium, dan rekomendasi klinis instan.',
    descriptionEn: 'Instant medical triage, lab interpretation, and doctor recommendations anytime.',
    tiers: { free: 'Terbatas (Teks Standar)', pro: 'Prioritas & Suara AI', business: 'Super Cepat Ultra AI', enterprise: 'Dedicated Private Model' },
  },
  {
    id: 'feat_cv_posture',
    name: 'Analisis Biomekanika Gerak & Postur CV',
    nameEn: 'CV Posture & Motion Biomechanics',
    category: 'ai_modules',
    description: 'Pelacakan sudut sendi, kelurusan tulang belakang, dan pencegahan cedera olahraga.',
    descriptionEn: 'Joint tracking, spinal alignment, and injury prevention in real-time.',
    tiers: { free: false, pro: true, business: true, enterprise: true },
  },

  // KATEGORI 2: MANAJEMEN PASIEN & KLINIK (BISNIS)
  {
    id: 'feat_patient_management',
    name: 'Dasbor Manajemen Multi-Pasien / Klien',
    nameEn: 'Multi-Patient / Client Management Hub',
    category: 'clinical_business',
    description: 'Monitor data kesehatan banyak klien, progres terapi, riwayat laboratorium, dan catatan dokter.',
    descriptionEn: 'Monitor multiple client health metrics, therapy progress, lab history, and clinical notes.',
    tiers: { free: '1 Profil', pro: '1 Profil Mandiri', business: 'Hingga 50 Pasien', enterprise: 'Pasien Tanpa Batas' },
  },
  {
    id: 'feat_prescription_generator',
    name: 'Generator Resep Digital & Rekam Medis (EHR)',
    nameEn: 'Digital Prescription & EHR Generator',
    category: 'clinical_business',
    description: 'Cetak lembar resep obat, diagnosis kode ICD-10 otomatis, dan tanda tangan digital dokter.',
    descriptionEn: 'Issue digital prescriptions, auto-suggest ICD-10 codes, and clinical signatures.',
    tiers: { free: false, pro: false, business: true, enterprise: true },
  },
  {
    id: 'feat_team_seats',
    name: 'Akun Kolaborasi Tim Medis / Staf',
    nameEn: 'Medical Team & Staff Collaborative Seats',
    category: 'clinical_business',
    description: 'Tambahkan dokter spesialis, perawat, resepsionis, atau pelatih gym ke dalam satu dasbor bersama.',
    descriptionEn: 'Add specialists, nurses, receptionists, or trainers to a unified workspace.',
    tiers: { free: '1 Akun', pro: '1 Akun', business: '5 Akun Staf', enterprise: 'Staf Tanpa Batas' },
  },
  {
    id: 'feat_clinic_branding',
    name: 'Kustomisasi Logo & Identitas Klinik',
    nameEn: 'Custom Clinic Logo & White-Label Reports',
    category: 'clinical_business',
    description: 'Tampilkan nama klinik, logo, kop surat resmi, dan kontak pada semua laporan pasien.',
    descriptionEn: 'Display clinic name, logo, letterhead, and contacts on all exported patient summaries.',
    tiers: { free: false, pro: false, business: true, enterprise: true },
  },

  // KATEGORI 3: INTEGRASI & SISTEM
  {
    id: 'feat_api_webhook',
    name: 'Akses API & Webhook Sinkronisasi SIMRS',
    nameEn: 'API & Webhook Integration for SIMRS',
    category: 'security_support',
    description: 'Sinkronisasi data otomatis dengan sistem rumah sakit eksternal, Google Cloud, atau IoT alat medis.',
    descriptionEn: 'Auto-sync health records with hospital information systems (SIMRS), Google Cloud, and IoT devices.',
    tiers: { free: false, pro: false, business: true, enterprise: true },
  },
  {
    id: 'feat_data_export',
    name: 'Ekspor Data Riwayat (JSON & PDF Medis)',
    nameEn: 'Full Data Export (JSON & Medical PDF)',
    category: 'security_support',
    description: 'Unduh seluruh log biomarker, menu makan, dan rekam medis terenkripsi.',
    descriptionEn: 'Download all biomarker logs, meal plans, and encrypted medical records.',
    tiers: { free: 'JSON Dasar', pro: 'JSON + PDF Medis', business: 'JSON + PDF Medis Bulk', enterprise: 'Bulk Data Warehouse Sync' },
  },
  {
    id: 'feat_cloud_security',
    name: 'Keamanan Sandboxed HIPAA & Firestore AES-256',
    nameEn: 'HIPAA Sandbox & Firestore AES-256 Security',
    category: 'security_support',
    description: 'Perlindungan rekam medis terlindungi aturan peran (RBAC) dan enkripsi ujung-ke-ujung.',
    descriptionEn: 'End-to-end encryption with role-based access control rules.',
    tiers: { free: true, pro: true, business: true, enterprise: true },
  },
  {
    id: 'feat_support_level',
    name: 'Tingkat Dukungan Pelanggan & Onboarding',
    nameEn: 'Customer Support & Onboarding',
    category: 'security_support',
    description: 'Jalur bantuan dan kecepatan penanganan kendala teknis.',
    descriptionEn: 'Help desk response times and dedicated technical onboarding.',
    tiers: { free: 'Komunitas', pro: 'Email Prioritas 24 Jam', business: 'VIP WhatsApp & Telepon 24/7', enterprise: 'Dedicated Manager & SLA 99.99%' },
  },
];

export function getPlanDetails(planId?: SubscriptionPlanType): SubscriptionPlanInfo {
  return SUBSCRIPTION_PLANS.find((p) => p.id === planId) || SUBSCRIPTION_PLANS[0];
}

export function isFeatureAccessible(
  userPlan: SubscriptionPlanType | undefined,
  featureId: 'food_scanner_unlimited' | 'all_20_modules' | 'patient_hub' | 'prescription_generator' | 'clinic_branding' | 'api_access'
): boolean {
  const plan = userPlan || 'free';
  if (plan === 'enterprise') return true;
  if (plan === 'business') return true;
  if (plan === 'pro') {
    return featureId === 'food_scanner_unlimited' || featureId === 'all_20_modules';
  }
  return false;
}
