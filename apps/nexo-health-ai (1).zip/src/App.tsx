import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Header } from './components/layout/Header';
import { TabType } from './components/layout/NavBar';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { UserDrawerNav } from './components/layout/UserDrawerNav';
import { AutoLocalizationBanner } from './components/banners/AutoLocalizationBanner';
import { LandingView } from './screens/LandingScreen';
import { CoachScreen } from './screens/CoachScreen';
import { HealthScreen } from './screens/HealthScreen';
import { BodyAIScreen } from './screens/BodyAIScreen';
import { DoctorConsultationScreen } from './screens/DoctorConsultationScreen';
import { DashboardView } from './screens/DashboardScreen';
import { ModuleHubView } from './screens/ModuleHubScreen';
import { NutritionScannerView } from './screens/NutritionScreen';
import { WorkoutGeneratorView } from './screens/WorkoutScreen';
import { FormGuardScreen } from './screens/FormGuardScreen';
import { RecoveryScreen } from './screens/RecoveryScreen';
import { SportScreen } from './screens/SportScreen';
import { PostureScreen } from './screens/PostureScreen';
import { SmartHydrationScreen } from './screens/SmartHydrationScreen';
import { SupplementManagerScreen } from './screens/SupplementManagerScreen';
import { MindfulEatingScreen } from './screens/MindfulEatingScreen';
import { CbtTherapyScreen } from './screens/CbtTherapyScreen';
import { EmotionStressScreen } from './screens/EmotionStressScreen';
import { AdaptiveMeditationScreen } from './screens/AdaptiveMeditationScreen';
import { MentalResilienceScreen } from './screens/MentalResilienceScreen';
import { SleepRitualsScreen } from './screens/SleepRitualsScreen';
import { EhrScreen } from './screens/EhrScreen';
import { VitalsWearableScreen } from './screens/VitalsWearableScreen';
import { LongevityBioAgeScreen } from './screens/LongevityBioAgeScreen';
import { HormonalHealthScreen } from './screens/HormonalHealthScreen';
import { GamificationView } from './screens/GamificationScreen';
import { BusinessHubScreen } from './screens/BusinessHubScreen';
import { PricingPlansView } from './components/subscription/PricingPlansView';
import { FirestoreSchemaView } from './screens/FirestoreScreen';
import { AuthModal } from './components/modals/AuthModal';
import { AddModularDataModal } from './components/modals/AddModularDataModal';
import { OnboardingFlow } from './components/onboarding/OnboardingFlow';

import { UserProfile, DailyLog, MealItem, WorkoutPlan, LanguageCode, SportActivityLog, HealthModuleId, ModularHealthDataEntry } from './types';
import { INITIAL_USER_PROFILE, INITIAL_DAILY_LOG, SAMPLE_MEAL_PRESETS, SAMPLE_MODULAR_LOGS } from './data/sampleData';
import { auth, onAuthStateChanged, signOut, User } from './lib/firebase';
import { FirestoreDataService, DEFAULT_CLEAN_PROFILE, DEFAULT_CLEAN_DAILY_LOG } from './services/firestoreService';

export default function App() {
  const [userProfile, setUserProfile] = useState<UserProfile>(INITIAL_USER_PROFILE);
  const [dailyLog, setDailyLog] = useState<DailyLog>(INITIAL_DAILY_LOG);
  const [loggedMeals, setLoggedMeals] = useState<MealItem[]>(SAMPLE_MEAL_PRESETS);
  const [modularLogs, setModularLogs] = useState<ModularHealthDataEntry[]>(SAMPLE_MODULAR_LOGS);
  const [activeTab, setActiveTab] = useState<TabType>('landing');
  const [selectedModuleId, setSelectedModuleId] = useState<HealthModuleId | undefined>(undefined);
  const [isAddDataModalOpen, setIsAddDataModalOpen] = useState(false);
  const [addDataModuleId, setAddDataModuleId] = useState<HealthModuleId | undefined>(undefined);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);

  // Listen to Firebase Auth State & Sync Live Firestore Data
  useEffect(() => {
    let unsubscribeSnapshot: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      try {
        if (user) {
          const profile = await FirestoreDataService.loadUserProfile(user.uid);
          setUserProfile(profile);
          const log = await FirestoreDataService.loadDailyLog();
          setDailyLog(log);
          const meals = await FirestoreDataService.loadMeals();
          if (meals.length > 0) setLoggedMeals(meals);
          const logs = await FirestoreDataService.loadModularLogs();
          if (logs.length > 0) setModularLogs(logs);

          // Real-time listener for modular logs
          const unsub = FirestoreDataService.subscribeModularLogs((liveLogs) => {
            if (liveLogs && liveLogs.length > 0) {
              setModularLogs(liveLogs);
            }
          });
          if (unsub) unsubscribeSnapshot = unsub;
        } else {
          // Fallback load
          const profile = await FirestoreDataService.loadUserProfile();
          setUserProfile(profile);
          const log = await FirestoreDataService.loadDailyLog();
          setDailyLog(log);
          const meals = await FirestoreDataService.loadMeals();
          if (meals.length > 0) setLoggedMeals(meals);
          const logs = await FirestoreDataService.loadModularLogs();
          if (logs.length > 0) setModularLogs(logs);
        }
      } catch (err) {
        console.warn('Error syncing initial Firestore data:', err);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeSnapshot) unsubscribeSnapshot();
    };
  }, []);

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setCurrentUser(null);
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  // Handle Water Hydration Logging
  const handleAddWater = (amountMl: number) => {
    const updatedWater = dailyLog.waterIntakeMl + amountMl;
    const newLog = { ...dailyLog, waterIntakeMl: updatedWater };
    setDailyLog(newLog);
    FirestoreDataService.saveDailyLog(newLog);

    // Award XP if daily target reached
    if (updatedWater >= userProfile.dailyWaterTargetMl && dailyLog.waterIntakeMl < userProfile.dailyWaterTargetMl) {
      awardXp(50);
    }
  };

  // Handle New Meal Saved from Scanner or Quick Form
  const handleLogMeal = (meal: MealItem) => {
    const updatedMeals = [meal, ...loggedMeals];
    setLoggedMeals(updatedMeals);
    FirestoreDataService.saveMeal(meal);

    const newLog: DailyLog = {
      ...dailyLog,
      caloriesConsumed: dailyLog.caloriesConsumed + meal.calories,
      carbsG: dailyLog.carbsG + meal.carbsG,
      proteinG: dailyLog.proteinG + meal.proteinG,
      fatG: dailyLog.fatG + meal.fatG,
    };
    setDailyLog(newLog);
    FirestoreDataService.saveDailyLog(newLog);

    awardXp(75);
  };

  // Handle Delete Meal
  const handleDeleteMeal = async (mealId: string) => {
    setLoggedMeals((prev) => prev.filter((m) => m.id !== mealId));
    await FirestoreDataService.deleteMeal(mealId);
  };

  // Handle Weight Update
  const handleUpdateWeight = (weightKg: number) => {
    const newLog = { ...dailyLog, weightKg };
    setDailyLog(newLog);
    FirestoreDataService.saveDailyLog(newLog);

    const newProfile = { ...userProfile, weightKg };
    setUserProfile(newProfile);
    FirestoreDataService.saveUserProfile(newProfile);
  };

  // Handle Completed Workout
  const handleFinishWorkout = (workout: WorkoutPlan) => {
    awardXp(120);
    const newProfile = { ...userProfile, streakCount: userProfile.streakCount + 1 };
    setUserProfile(newProfile);
    FirestoreDataService.saveUserProfile(newProfile);
  };

  // Handle Completed Sport Activity
  const handleLogSportActivity = (activity: SportActivityLog) => {
    awardXp(Math.max(50, activity.durationMin * 3));
    const newProfile = { ...userProfile, streakCount: userProfile.streakCount + 1 };
    setUserProfile(newProfile);
    FirestoreDataService.saveUserProfile(newProfile);
  };

  // Helper to add XP and handle Level Progression
  const awardXp = (amount: number) => {
    setUserProfile((prev) => {
      let newXp = prev.xp + amount;
      let newLevel = prev.level;
      let newNextLevel = prev.xpNextLevel;

      if (newXp >= prev.xpNextLevel) {
        newLevel += 1;
        newNextLevel += 1000;
      }

      const updated = {
        ...prev,
        xp: newXp,
        level: newLevel,
        xpNextLevel: newNextLevel,
      };
      FirestoreDataService.saveUserProfile(updated);
      return updated;
    });
  };

  const handleLanguageChange = (lang: LanguageCode) => {
    const newProfile = { ...userProfile, language: lang };
    setUserProfile(newProfile);
    FirestoreDataService.saveUserProfile(newProfile);
  };

  const handleUpdateProfile = (updated: Partial<UserProfile>) => {
    const newProfile = { ...userProfile, ...updated };
    setUserProfile(newProfile);
    FirestoreDataService.saveUserProfile(newProfile);
  };

  const handleOpenAddDataModal = (moduleId?: HealthModuleId | string) => {
    setAddDataModuleId(moduleId as HealthModuleId | undefined);
    setIsAddDataModalOpen(true);
  };

  const handleSaveModularLog = (entry: ModularHealthDataEntry) => {
    setModularLogs((prev) => [entry, ...prev.filter((e) => e.id !== entry.id)]);
    FirestoreDataService.saveModularLog(entry);
    awardXp(entry.xpAwarded || 50);

    // Sync water if hydration log
    if (entry.moduleId === 'm8_smart_hydration' && entry.metrics.intakeMl) {
      const ml = Number(String(entry.metrics.intakeMl).replace(/[^0-9]/g, ''));
      if (!isNaN(ml) && ml > 0) {
        setDailyLog((prev) => {
          const updatedLog = {
            ...prev,
            waterIntakeMl: Math.min(prev.waterIntakeMl + ml, 5000),
          };
          FirestoreDataService.saveDailyLog(updatedLog);
          return updatedLog;
        });
      }
    }
  };

  const handleDeleteModularLog = async (logId: string) => {
    setModularLogs((prev) => prev.filter((e) => e.id !== logId));
    await FirestoreDataService.deleteModularLog(logId);
  };

  const handleClearAllUserData = async () => {
    await FirestoreDataService.clearAllUserData();
    setUserProfile(DEFAULT_CLEAN_PROFILE);
    setDailyLog(DEFAULT_CLEAN_DAILY_LOG);
    setLoggedMeals([]);
    setModularLogs([]);
  };

  const handleCompleteOnboarding = async (data: Partial<UserProfile>) => {
    const weight = data.weightKg || userProfile.weightKg || 58;
    const height = data.heightCm || userProfile.heightCm || 167;
    const age = data.age || userProfile.age || 26;
    const gender = data.gender || userProfile.gender || 'other';
    const activityLevel = data.activityLevel || userProfile.activityLevel || 'moderate';
    const goal = data.primaryGoal || userProfile.primaryGoal || 'fitness';

    // Calculate BMR (Mifflin-St Jeor equation)
    let bmr = 10 * weight + 6.25 * height - 5 * age;
    if (gender === 'male') {
      bmr += 5;
    } else if (gender === 'female') {
      bmr -= 161;
    } else {
      bmr -= 78;
    }

    // Activity multiplier
    const activityMultipliers: Record<string, number> = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      very_active: 1.9,
    };
    const tdee = Math.round(bmr * (activityMultipliers[activityLevel] || 1.55));

    // Goal adjustment for calories
    let calorieTarget = tdee;
    if (goal === 'weight_loss') calorieTarget = Math.round(tdee - 400);
    else if (goal === 'muscle_gain') calorieTarget = Math.round(tdee + 350);

    // Water target (ml) ~ 35ml per kg of bodyweight
    const waterTarget = Math.round(weight * 35);

    // Macronutrient targets (Grams)
    let proteinGrams = Math.round(weight * 1.8);
    if (goal === 'muscle_gain') proteinGrams = Math.round(weight * 2.2);
    else if (goal === 'weight_loss') proteinGrams = Math.round(weight * 2.0);

    const fatGrams = Math.round((calorieTarget * 0.25) / 9);
    const carbsGrams = Math.max(50, Math.round((calorieTarget - (proteinGrams * 4 + fatGrams * 9)) / 4));

    const updated: UserProfile = {
      ...userProfile,
      ...data,
      dailyCalorieTarget: calorieTarget,
      dailyWaterTargetMl: waterTarget,
      targetProteinG: proteinGrams,
      targetCarbsG: carbsGrams,
      targetFatG: fatGrams,
      hasCompletedOnboarding: true,
      onboardingCompletedAt: new Date().toISOString(),
      xpPoints: (userProfile.xpPoints || 0) + 150,
    };

    setUserProfile(updated);
    setIsOnboardingOpen(false);
    await FirestoreDataService.saveUserProfile(updated);
  };

  const handleSelectModuleFromDrawer = (moduleId: HealthModuleId) => {
    if (moduleId === 'm1_adaptive_trainer') {
      setActiveTab('workout');
    } else if (moduleId === 'm2_form_cv') {
      setActiveTab('form_guard');
    } else if (moduleId === 'm3_active_recovery') {
      setActiveTab('recovery');
    } else if (moduleId === 'm4_sport_performance') {
      setActiveTab('sport');
    } else if (moduleId === 'm5_posture_ergonomics') {
      setActiveTab('posture');
    } else if (moduleId === 'm6_ai_dietitian' || moduleId === 'm7_food_scanner') {
      setActiveTab('nutrition');
    } else if (moduleId === 'm8_smart_hydration') {
      setActiveTab('smart_hydration');
    } else if (moduleId === 'm9_supplement_manager') {
      setActiveTab('supplement_manager');
    } else if (moduleId === 'm10_mindful_eating') {
      setActiveTab('mindful_eating');
    } else if (moduleId === 'm11_cbt_therapy') {
      setActiveTab('cbt_therapy');
    } else if (moduleId === 'm12_emotion_stress_map') {
      setActiveTab('emotion_stress');
    } else if (moduleId === 'm13_adaptive_meditation') {
      setActiveTab('adaptive_meditation');
    } else if (moduleId === 'm14_mental_resilience') {
      setActiveTab('mental_resilience');
    } else if (moduleId === 'm15_sleep_rituals') {
      setActiveTab('sleep_rituals');
    } else if (moduleId === 'm16_doctor_triage') {
      setActiveTab('doctor_consultation');
    } else if (moduleId === 'm17_electronic_health_record') {
      setActiveTab('ehr');
    } else if (moduleId === 'm18_vitals_wearables') {
      setActiveTab('vitals_wearables');
    } else if (moduleId === 'm19_longevity_screening') {
      setActiveTab('longevity_bioage');
    } else if (moduleId === 'm20_hormonal_reproductive') {
      setActiveTab('hormonal_health');
    } else {
      setSelectedModuleId(moduleId);
      setActiveTab('modules_hub');
    }
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-slate-50 text-slate-900 font-sans flex flex-col selection:bg-emerald-500 selection:text-white">
      {/* Top Banner for Device Locale Auto-Localization */}
      <AutoLocalizationBanner
        currentLanguage={userProfile.language}
        onSelectLanguage={handleLanguageChange}
      />

      {/* Main Header with User Avatar & Fast Navigation */}
      <Header
        userProfile={userProfile}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLanguageChange={handleLanguageChange}
        currentUser={currentUser}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenDrawer={() => setIsDrawerOpen(true)}
        onSelectSpecificModule={handleSelectModuleFromDrawer}
      />

      {/* User Settings & Account Slide-Out Drawer Navigation */}
      <UserDrawerNav
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        userProfile={userProfile}
        dailyLog={dailyLog}
        onUpdateProfile={handleUpdateProfile}
        onLanguageChange={handleLanguageChange}
        currentUser={currentUser}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onSignOut={handleSignOut}
        onNavigateTab={(tab) => setActiveTab(tab)}
        loggedMeals={loggedMeals}
        modularLogs={modularLogs}
        onClearAllUserData={handleClearAllUserData}
        onStartOnboarding={() => setIsOnboardingOpen(true)}
      />

      {/* View Router with padding bottom for Mobile Navigation Footer and smooth Framer Motion transitions */}
      <main className="flex-1 w-full max-w-full overflow-x-hidden pb-28 sm:pb-32 lg:pb-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="w-full"
          >
            {activeTab === 'landing' && (
              <LandingView
                userProfile={userProfile}
                dailyLog={dailyLog}
                onNavigateTab={(tab) => setActiveTab(tab)}
                onSelectModule={handleSelectModuleFromDrawer}
                onAddWater={handleAddWater}
                onStartOnboarding={() => setIsOnboardingOpen(true)}
              />
            )}

            {activeTab === 'coach' && (
              <CoachScreen
                onNavigateTab={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'health' && (
              <HealthScreen
                onNavigateToTab={(tab) => setActiveTab(tab as TabType)}
                onNavigateToModule={(mod) => handleSelectModuleFromDrawer(mod as any)}
              />
            )}

            {activeTab === 'body_ai' && (
              <BodyAIScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
              />
            )}

            {activeTab === 'doctor_consultation' && (
              <DoctorConsultationScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab)}
                onBackToHome={() => setActiveTab('landing')}
              />
            )}

            {activeTab === 'modules_hub' && (
              <ModuleHubView
                userProfile={userProfile}
                initialModuleId={selectedModuleId}
                onNavigateTab={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'dashboard' && (
              <DashboardView
                userProfile={userProfile}
                dailyLog={dailyLog}
                loggedMeals={loggedMeals}
                modularLogs={modularLogs}
                onAddWater={handleAddWater}
                onLogMeal={handleLogMeal}
                onUpdateWeight={handleUpdateWeight}
                onNavigateToNutrition={() => setActiveTab('nutrition')}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId)}
              />
            )}

            {activeTab === 'nutrition' && (
              <NutritionScannerView
                userProfile={userProfile}
                onSaveMealToDashboard={handleLogMeal}
                onNavigateTab={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'workout' && (
              <WorkoutGeneratorView
                userProfile={userProfile}
                onFinishWorkout={handleFinishWorkout}
                onLogMeal={handleLogMeal}
                onNavigateTab={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'form_guard' && (
              <FormGuardScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
              />
            )}

            {activeTab === 'recovery' && (
              <RecoveryScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
              />
            )}

            {activeTab === 'sport' && (
              <SportScreen
                userProfile={userProfile}
                onLogSportActivity={handleLogSportActivity}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
              />
            )}

            {activeTab === 'posture' && (
              <PostureScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm5_posture_ergonomics')}
              />
            )}

            {activeTab === 'smart_hydration' && (
              <SmartHydrationScreen
                userProfile={userProfile}
                dailyLog={dailyLog}
                onAddWater={handleAddWater}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm8_smart_hydration')}
              />
            )}

            {activeTab === 'supplement_manager' && (
              <SupplementManagerScreen
                userProfile={userProfile}
                dailyLog={dailyLog}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm9_supplement_manager')}
              />
            )}

            {activeTab === 'mindful_eating' && (
              <MindfulEatingScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm10_mindful_eating')}
              />
            )}

            {activeTab === 'cbt_therapy' && (
              <CbtTherapyScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm11_cbt_therapy')}
              />
            )}

            {activeTab === 'emotion_stress' && (
              <EmotionStressScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm12_emotion_stress')}
              />
            )}

            {activeTab === 'adaptive_meditation' && (
              <AdaptiveMeditationScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm13_adaptive_meditation')}
              />
            )}

            {activeTab === 'mental_resilience' && (
              <MentalResilienceScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm14_mental_resilience')}
              />
            )}

            {activeTab === 'sleep_rituals' && (
              <SleepRitualsScreen
                userProfile={userProfile}
                dailyLog={dailyLog}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm15_sleep_rituals')}
              />
            )}

            {activeTab === 'ehr' && (
              <EhrScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm17_ehr')}
              />
            )}

            {activeTab === 'vitals_wearables' && (
              <VitalsWearableScreen
                userProfile={userProfile}
                dailyLog={dailyLog}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm18_vitals_wearables')}
              />
            )}

            {activeTab === 'longevity_bioage' && (
              <LongevityBioAgeScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm19_longevity_bioage')}
              />
            )}

            {activeTab === 'hormonal_health' && (
              <HormonalHealthScreen
                userProfile={userProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                onAwardXp={(xp) => awardXp(xp)}
                onOpenAddDataModal={(modId) => handleOpenAddDataModal(modId || 'm20_hormonal_health')}
              />
            )}

            {activeTab === 'gamification' && (
              <GamificationView
                userProfile={userProfile}
                onUpdateXpAndStreak={(xp) => awardXp(xp)}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
              />
            )}

            {activeTab === 'business_hub' && (
              <BusinessHubScreen
                userProfile={userProfile}
                onUpdateProfile={handleUpdateProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                modularLogs={modularLogs}
              />
            )}

            {activeTab === 'pricing' && (
              <PricingPlansView
                userProfile={userProfile}
                onUpdateProfile={handleUpdateProfile}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
              />
            )}

            {activeTab === 'firestore' && (
              <FirestoreSchemaView
                onClearAllUserData={handleClearAllUserData}
                onNavigateTab={(tab) => setActiveTab(tab as TabType)}
                userProfile={userProfile}
                dailyLog={dailyLog}
                loggedMeals={loggedMeals}
                modularLogs={modularLogs}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Mobile Fixed Bottom Navigation Bar */}
      <MobileBottomNav
        userProfile={userProfile}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        language={userProfile.language}
        currentUser={currentUser}
        onSignOut={handleSignOut}
      />

      {/* Cross-Module Data Entry Modal */}
      <AddModularDataModal
        isOpen={isAddDataModalOpen}
        onClose={() => setIsAddDataModalOpen(false)}
        userProfile={userProfile}
        initialModuleId={addDataModuleId}
        onSaveDataEntry={handleSaveModularLog}
      />

      {/* 14-Step Personal Health Profile Onboarding Modal */}
      {isOnboardingOpen && (
        <OnboardingFlow
          initialProfile={userProfile}
          onComplete={handleCompleteOnboarding}
          onCancel={() => setIsOnboardingOpen(false)}
        />
      )}
    </div>
  );
}
