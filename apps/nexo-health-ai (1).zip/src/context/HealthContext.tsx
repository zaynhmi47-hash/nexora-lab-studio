import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  DailyHealthRecord,
  HealthEvent,
  WeightEntry,
  WellnessScore,
  HealthTrend,
  WeeklyReport,
  AIHealthInsight,
  SleepMetrics,
  ActivityMetrics,
} from '../types/health';
import { healthRepository } from '../services/health/healthRepository';
import {
  calculateWellnessScore,
  calculateAllTrends,
  buildWeeklyReport,
  generateLocalHealthInsight,
  getDailyHealthContext,
  getWeeklyHealthContext,
} from '../services/analytics';
import { useProfile } from './ProfileContext';

interface HealthContextType {
  todayRecord: DailyHealthRecord;
  records: DailyHealthRecord[];
  weightHistory: WeightEntry[];
  wellnessScore: WellnessScore;
  trends: HealthTrend[];
  weeklyReport: WeeklyReport;
  events: HealthEvent[];
  dailyAiBrief: AIHealthInsight | null;
  isLoading: boolean;
  isGeneratingAiBrief: boolean;
  isGeneratingWeeklyReport: boolean;

  // Action methods
  addWater: (amountMl: number) => Promise<void>;
  logSleep: (metrics: Partial<SleepMetrics>) => Promise<void>;
  logWeight: (weightKg: number, note?: string) => Promise<void>;
  logActivity: (metrics: Partial<ActivityMetrics>) => Promise<void>;
  addHealthEvent: (event: Omit<HealthEvent, 'id'>) => Promise<void>;
  generateDailyAiBrief: () => Promise<AIHealthInsight>;
  generateWeeklyAiReport: () => Promise<WeeklyReport>;
  refreshHealthData: () => Promise<void>;
  resetTestData: () => void;
}

const HealthContext = createContext<HealthContextType | undefined>(undefined);

function getTodayString(): string {
  return new Date().toISOString().split('T')[0];
}

const DEFAULT_TODAY_RECORD: DailyHealthRecord = {
  date: getTodayString(),
  activity: {
    steps: 7200,
    stepsGoal: 8000,
    activeMinutes: 38,
    activeMinutesGoal: 45,
    distanceKm: 5.4,
    estimatedCaloriesBurned: 320,
  },
  sleep: {
    sleepDurationHours: 7.5,
    sleepGoalHours: 8.0,
    bedtime: '23:00',
    wakeTime: '06:30',
    sleepConsistencyScore: 84,
    qualityRating: 'good',
  },
  hydration: {
    waterIntakeMl: 1850,
    waterGoalMl: 2500,
    hydrationEntries: [
      { id: 'hyd_init_1', timestamp: '08:00', amountMl: 350 },
      { id: 'hyd_init_2', timestamp: '11:30', amountMl: 500 },
      { id: 'hyd_init_3', timestamp: '14:45', amountMl: 500 },
      { id: 'hyd_init_4', timestamp: '18:00', amountMl: 500 },
    ],
  },
  nutrition: {
    caloriesConsumed: 1850,
    caloriesGoal: 2100,
    proteinG: 110,
    carbsG: 210,
    fatG: 55,
    loggedMealsCount: 3,
  },
  weight: 72.0,
  events: [],
};

export const HealthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { userProfile } = useProfile();
  const isIndonesian = userProfile.language !== 'en';

  const [records, setRecords] = useState<DailyHealthRecord[]>([]);
  const [weightHistory, setWeightHistory] = useState<WeightEntry[]>([]);
  const [todayRecord, setTodayRecord] = useState<DailyHealthRecord>(DEFAULT_TODAY_RECORD);
  const [dailyAiBrief, setDailyAiBrief] = useState<AIHealthInsight | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isGeneratingAiBrief, setIsGeneratingAiBrief] = useState<boolean>(false);
  const [isGeneratingWeeklyReport, setIsGeneratingWeeklyReport] = useState<boolean>(false);

  // Load initial data from Repository
  const loadData = useCallback(async () => {
    try {
      setIsLoading(true);
      const allRecs = await healthRepository.getRecords();
      const weights = await healthRepository.getWeightHistory();
      const todayStr = getTodayString();
      let today = await healthRepository.getDailyRecord(todayStr);

      if (!today) {
        today = {
          ...DEFAULT_TODAY_RECORD,
          date: todayStr,
        };
        today.wellnessScore = calculateWellnessScore(today, undefined, isIndonesian);
        await healthRepository.saveHealthRecord(today);
        allRecs.push(today);
      }

      setRecords(allRecs);
      setWeightHistory(weights);
      setTodayRecord(today);

      // Initialize default local insight
      setDailyAiBrief(generateLocalHealthInsight(today, [], isIndonesian));
    } catch (e) {
      console.warn('Error loading health repository:', e);
    } finally {
      setIsLoading(false);
    }
  }, [isIndonesian]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Memoized Wellness Score for today
  const wellnessScore = useMemo(() => {
    return calculateWellnessScore(todayRecord, undefined, isIndonesian);
  }, [todayRecord, isIndonesian]);

  // Memoized Health Trends
  const trends = useMemo(() => {
    return calculateAllTrends(records, weightHistory, isIndonesian);
  }, [records, weightHistory, isIndonesian]);

  // Memoized Weekly Report
  const weeklyReport = useMemo(() => {
    return buildWeeklyReport(records, userProfile, isIndonesian);
  }, [records, userProfile, isIndonesian]);

  // Chronological list of today's events
  const events = useMemo(() => {
    const evs = todayRecord.events || [];
    return [...evs].sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  }, [todayRecord.events]);

  // Action: Add Water
  const addWater = useCallback(async (amountMl: number) => {
    const todayStr = getTodayString();
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newEvent: HealthEvent = {
      id: `ev_water_${Date.now()}`,
      type: 'water',
      timestamp: timeStr,
      date: todayStr,
      title: isIndonesian ? 'Minum Air Putih' : 'Hydration Log',
      description: isIndonesian
        ? `+${amountMl} ml air putih segar`
        : `+${amountMl} ml fresh water`,
      source: 'manual',
      metrics: { volumeMl: amountMl },
    };

    const updatedRecord: DailyHealthRecord = {
      ...todayRecord,
      hydration: {
        ...todayRecord.hydration,
        waterIntakeMl: (todayRecord.hydration?.waterIntakeMl || 0) + amountMl,
        hydrationEntries: [
          ...(todayRecord.hydration?.hydrationEntries || []),
          { id: `hyd_${Date.now()}`, timestamp: timeStr, amountMl },
        ],
      },
      events: [newEvent, ...(todayRecord.events || [])],
    };

    updatedRecord.wellnessScore = calculateWellnessScore(updatedRecord, undefined, isIndonesian);

    setTodayRecord(updatedRecord);
    setRecords((prev) => prev.map((r) => (r.date === todayStr ? updatedRecord : r)));
    await healthRepository.saveHealthRecord(updatedRecord);
  }, [todayRecord, isIndonesian]);

  // Action: Log Sleep
  const logSleep = useCallback(async (metrics: Partial<SleepMetrics>) => {
    const todayStr = getTodayString();
    const duration = metrics.sleepDurationHours || 7.5;
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newEvent: HealthEvent = {
      id: `ev_sleep_${Date.now()}`,
      type: 'sleep',
      timestamp: metrics.wakeTime || timeStr,
      date: todayStr,
      title: isIndonesian ? 'Pencatatan Tidur' : 'Sleep Tracking',
      description: isIndonesian
        ? `Waktu tidur ${duration} jam (${metrics.bedtime || '23:00'} - ${metrics.wakeTime || '07:00'})`
        : `Tracked ${duration}h sleep duration (${metrics.bedtime || '23:00'} - ${metrics.wakeTime || '07:00'})`,
      source: 'manual',
      metrics: { durationMinutes: Math.round(duration * 60) },
    };

    const updatedRecord: DailyHealthRecord = {
      ...todayRecord,
      sleep: {
        ...todayRecord.sleep,
        ...metrics,
        sleepDurationHours: duration,
      },
      events: [newEvent, ...(todayRecord.events || [])],
    };

    updatedRecord.wellnessScore = calculateWellnessScore(updatedRecord, undefined, isIndonesian);

    setTodayRecord(updatedRecord);
    setRecords((prev) => prev.map((r) => (r.date === todayStr ? updatedRecord : r)));
    await healthRepository.saveHealthRecord(updatedRecord);
  }, [todayRecord, isIndonesian]);

  // Action: Log Weight
  const logWeight = useCallback(async (weightKg: number, note?: string) => {
    const todayStr = getTodayString();
    const timeStr = new Date().toISOString();

    const weightEntry: WeightEntry = {
      id: `weight_${Date.now()}`,
      date: todayStr,
      timestamp: timeStr,
      weightKg,
      note,
      trend: 'stable',
    };

    const newEvent: HealthEvent = {
      id: `ev_weight_${Date.now()}`,
      type: 'weight',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      date: todayStr,
      title: isIndonesian ? 'Penimbangan Berat Badan' : 'Weight Check-in',
      description: `${weightKg} kg ${note ? `• ${note}` : ''}`,
      source: 'manual',
      metrics: { weightKg },
    };

    const updatedRecord: DailyHealthRecord = {
      ...todayRecord,
      weight: weightKg,
      events: [newEvent, ...(todayRecord.events || [])],
    };

    updatedRecord.wellnessScore = calculateWellnessScore(updatedRecord, undefined, isIndonesian);

    setTodayRecord(updatedRecord);
    setWeightHistory((prev) => [...prev.filter((w) => w.date !== todayStr), weightEntry]);
    setRecords((prev) => prev.map((r) => (r.date === todayStr ? updatedRecord : r)));

    await healthRepository.saveWeightEntry(weightEntry);
    await healthRepository.saveHealthRecord(updatedRecord);
  }, [todayRecord, isIndonesian]);

  // Action: Log Activity
  const logActivity = useCallback(async (metrics: Partial<ActivityMetrics>) => {
    const todayStr = getTodayString();
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newEvent: HealthEvent = {
      id: `ev_act_${Date.now()}`,
      type: 'activity',
      timestamp: timeStr,
      date: todayStr,
      title: isIndonesian ? 'Pencatatan Gerak Aktif' : 'Activity Log',
      description: `${metrics.steps || 0} langkah • ${metrics.activeMinutes || 0} menit aktif`,
      source: 'manual',
      metrics: {
        steps: metrics.steps,
        durationMinutes: metrics.activeMinutes,
        calories: metrics.estimatedCaloriesBurned,
      },
    };

    const updatedRecord: DailyHealthRecord = {
      ...todayRecord,
      activity: {
        ...todayRecord.activity,
        ...metrics,
      },
      events: [newEvent, ...(todayRecord.events || [])],
    };

    updatedRecord.wellnessScore = calculateWellnessScore(updatedRecord, undefined, isIndonesian);

    setTodayRecord(updatedRecord);
    setRecords((prev) => prev.map((r) => (r.date === todayStr ? updatedRecord : r)));
    await healthRepository.saveHealthRecord(updatedRecord);
  }, [todayRecord, isIndonesian]);

  // Action: Add Generic Health Event
  const addHealthEvent = useCallback(async (eventData: Omit<HealthEvent, 'id'>) => {
    const fullEvent: HealthEvent = {
      ...eventData,
      id: `ev_${Date.now()}`,
    };

    await healthRepository.addHealthEvent(fullEvent);
    const updatedToday = await healthRepository.getDailyRecord(getTodayString());
    if (updatedToday) {
      setTodayRecord(updatedToday);
      setRecords((prev) => prev.map((r) => (r.date === updatedToday.date ? updatedToday : r)));
    }
  }, []);

  // Action: Generate Daily AI Brief via Gemini API
  const generateDailyAiBrief = useCallback(async (): Promise<AIHealthInsight> => {
    setIsGeneratingAiBrief(true);
    try {
      // 1. Token Optimization: Build compact daily context
      const compactContext = getDailyHealthContext(todayRecord, userProfile);

      const prompt = isIndonesian
        ? 'Berikan ringkasan harian kesehatan (Daily AI Brief) berbasis data wellness hari ini. Sertakan poin positif, saran yang membangun, dan fokus utama. Gunakan nada suportif dan jangan memberikan diagnosis medis.'
        : 'Generate a supportive Daily AI Brief based on today\'s wellness analytics. Highlight positive achievements, helpful adjustments, and a key focus area. Do not provide medical diagnoses.';

      const response = await fetch('/api/ai/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          requestType: 'general',
          relevantContext: compactContext,
          language: userProfile.language || 'id',
        }),
      });

      if (response.ok) {
        const resJson = await response.json();
        const data = resJson.data;

        const aiInsight: AIHealthInsight = {
          id: `brief_${Date.now()}`,
          category: wellnessScore.score >= 75 ? 'positive' : 'suggestion',
          headline: data?.structuredData?.title || (isIndonesian ? 'Brief Kesehatan Harian AI' : 'Daily AI Health Brief'),
          summary: data?.content || (isIndonesian ? 'Keseimbangan gaya hidup Anda terjaga stabil hari ini.' : 'Your daily lifestyle balance is steady today.'),
          positiveAreas: data?.structuredData?.keyPoints || [
            isIndonesian ? 'Konsistensi pencatatan aktivitas dan hidrasi' : 'Consistent tracking of activity and hydration',
          ],
          suggestions: data?.structuredData?.actionItems || [
            isIndonesian ? 'Cukupi 250ml air sebelum istirahat malam' : 'Drink 250ml water before evening wind-down',
          ],
          focusArea: compactContext.focusArea,
          generatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isAiGenerated: true,
        };

        setDailyAiBrief(aiInsight);
        return aiInsight;
      }
      throw new Error('API brief response not ok');
    } catch (e) {
      console.warn('AI Brief fallback triggered:', e);
      const fallback = generateLocalHealthInsight(todayRecord, trends, isIndonesian);
      setDailyAiBrief(fallback);
      return fallback;
    } finally {
      setIsGeneratingAiBrief(false);
    }
  }, [todayRecord, userProfile, isIndonesian, wellnessScore.score, trends]);

  // Action: Generate Weekly AI Report interpretation
  const generateWeeklyAiReport = useCallback(async (): Promise<WeeklyReport> => {
    setIsGeneratingWeeklyReport(true);
    try {
      const baseReport = buildWeeklyReport(records, userProfile, isIndonesian);
      const compactWeeklyCtx = getWeeklyHealthContext(baseReport, userProfile);

      const prompt = isIndonesian
        ? 'Analisis performa mingguan kesehatan pengguna dari ringkasan data terlampir. Berikan evaluasi suportif tentang konsistensi kebiasaan dan kemajuan sasaran.'
        : 'Analyze weekly health analytics from the compact context. Provide an encouraging progress evaluation on habit consistency and goal momentum.';

      const response = await fetch('/api/ai/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          requestType: 'general',
          relevantContext: compactWeeklyCtx,
          language: userProfile.language || 'id',
        }),
      });

      if (response.ok) {
        const resJson = await response.json();
        const data = resJson.data;

        const enrichedReport: WeeklyReport = {
          ...baseReport,
          aiInsight: {
            id: `ai_rep_${Date.now()}`,
            category: baseReport.wellnessScore.delta >= 0 ? 'positive' : 'suggestion',
            headline: data?.structuredData?.title || (isIndonesian ? 'Laporan Mingguan Personal AI' : 'Personal Weekly AI Review'),
            summary: data?.content || baseReport.aiInsight?.summary || '',
            positiveAreas: data?.structuredData?.keyPoints || baseReport.aiInsight?.positiveAreas || [],
            suggestions: data?.structuredData?.actionItems || baseReport.aiInsight?.suggestions || [],
            focusArea: 'holistic_consistency',
            generatedAt: new Date().toLocaleDateString(),
            isAiGenerated: true,
          },
        };
        return enrichedReport;
      }
      return baseReport;
    } catch (e) {
      console.warn('Weekly report AI interpretation fallback:', e);
      return buildWeeklyReport(records, userProfile, isIndonesian);
    } finally {
      setIsGeneratingWeeklyReport(false);
    }
  }, [records, userProfile, isIndonesian]);

  const refreshHealthData = useCallback(async () => {
    await loadData();
  }, [loadData]);

  const resetTestData = useCallback(() => {
    healthRepository.resetAllData();
    loadData();
  }, [loadData]);

  const value = useMemo(
    () => ({
      todayRecord,
      records,
      weightHistory,
      wellnessScore,
      trends,
      weeklyReport,
      events,
      dailyAiBrief,
      isLoading,
      isGeneratingAiBrief,
      isGeneratingWeeklyReport,
      addWater,
      logSleep,
      logWeight,
      logActivity,
      addHealthEvent,
      generateDailyAiBrief,
      generateWeeklyAiReport,
      refreshHealthData,
      resetTestData,
    }),
    [
      todayRecord,
      records,
      weightHistory,
      wellnessScore,
      trends,
      weeklyReport,
      events,
      dailyAiBrief,
      isLoading,
      isGeneratingAiBrief,
      isGeneratingWeeklyReport,
      addWater,
      logSleep,
      logWeight,
      logActivity,
      addHealthEvent,
      generateDailyAiBrief,
      generateWeeklyAiReport,
      refreshHealthData,
      resetTestData,
    ]
  );

  return <HealthContext.Provider value={value}>{children}</HealthContext.Provider>;
};

export const useHealth = (): HealthContextType => {
  const context = useContext(HealthContext);
  if (!context) {
    throw new Error('useHealth must be used within a HealthProvider');
  }
  return context;
};
