import React, { createContext, useContext, useState, useCallback, ReactNode, useMemo } from 'react';
import { AIMessage, AIRequestType, AIResponse } from '../types/ai';
import { useProfile } from './ProfileContext';
import { AIHealthCoachService } from '../services/ai/aiService';

interface ConversationContextType {
  messages: AIMessage[];
  isLoading: boolean;
  isThinking: boolean;
  suggestedPrompts: string[];
  lastFailedMessage: string | null;
  sendMessage: (text: string, requestType?: AIRequestType) => Promise<void>;
  retryLastMessage: () => Promise<void>;
  clearConversation: () => void;
  sendSuggestedPrompt: (promptText: string) => Promise<void>;
}

const ConversationContext = createContext<ConversationContextType | undefined>(undefined);

export const DEFAULT_SUGGESTED_PROMPTS_ID = [
  'Latihan apa yang cocok hari ini?',
  'Apa yang sebaiknya saya makan?',
  'Bagaimana meningkatkan kualitas tidur?',
  'Bagaimana menjaga hidrasi?',
  'Analisis perkembangan saya',
];

export const DEFAULT_SUGGESTED_PROMPTS_EN = [
  'What workout should I do today?',
  'What should I eat for my goals?',
  'How can I improve my sleep quality?',
  'How should I stay hydrated?',
  'Analyze my current progress',
];

function createWelcomeMessage(isIndonesian: boolean, userName: string, primaryGoal?: string): AIMessage {
  const goalText = isIndonesian
    ? primaryGoal === 'muscle_gain' ? 'membangun massa otot' : primaryGoal === 'weight_loss' ? 'penurunan berat badan' : 'kebugaran holistik'
    : primaryGoal === 'muscle_gain' ? 'muscle hypertrophy' : primaryGoal === 'weight_loss' ? 'weight management' : 'holistic fitness';

  return {
    id: `welcome_${Date.now()}`,
    role: 'assistant',
    content: isIndonesian
      ? `Halo **${userName}**! Saya **AI Health Coach** Anda. Saya siap mendampingi perjalanan ${goalText}, nutrisi harian, jadwal tidur, dan kebiasaan sehat Anda. Ada yang ingin Anda diskusikan atau tanyakan hari ini?`
      : `Hello **${userName}**! I am your **AI Health Coach**. I'm here to guide your journey in ${goalText}, daily nutrition, sleep hygiene, and healthy habits. What would you like to explore today?`,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    responseType: 'text',
    suggestedPrompts: isIndonesian ? DEFAULT_SUGGESTED_PROMPTS_ID : DEFAULT_SUGGESTED_PROMPTS_EN,
  };
}

export const ConversationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { profile } = useProfile();
  const isIndonesian = profile.language !== 'en';

  const [messages, setMessages] = useState<AIMessage[]>(() => [
    createWelcomeMessage(isIndonesian, profile.name || 'Alex', profile.primaryGoal),
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastFailedMessage, setLastFailedMessage] = useState<string | null>(null);

  const suggestedPrompts = useMemo(() => {
    if (messages.length > 0) {
      const lastAssistantMsg = [...messages].reverse().find((m) => m.role === 'assistant' && m.suggestedPrompts && m.suggestedPrompts.length > 0);
      if (lastAssistantMsg?.suggestedPrompts) {
        return lastAssistantMsg.suggestedPrompts;
      }
    }
    return isIndonesian ? DEFAULT_SUGGESTED_PROMPTS_ID : DEFAULT_SUGGESTED_PROMPTS_EN;
  }, [messages, isIndonesian]);

  const clearConversation = useCallback(() => {
    setMessages([createWelcomeMessage(isIndonesian, profile.name || 'Alex', profile.primaryGoal)]);
    setLastFailedMessage(null);
    setIsLoading(false);
  }, [isIndonesian, profile.name, profile.primaryGoal]);

  const sendMessage = useCallback(
    async (text: string, requestType?: AIRequestType) => {
      const trimmed = text.trim();
      if (!trimmed || isLoading) return;

      const userMsg: AIMessage = {
        id: `user_${Date.now()}`,
        role: 'user',
        content: trimmed,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, userMsg]);
      setIsLoading(true);
      setLastFailedMessage(null);

      try {
        const response: AIResponse = await AIHealthCoachService.generateResponse(
          {
            message: trimmed,
            requestType,
            conversationHistory: [...messages, userMsg],
            userProfile: profile,
            language: profile.language,
            aiTone: profile.aiTone,
          },
          profile
        );

        const assistantMsg: AIMessage = {
          id: response.messageId || `ai_${Date.now()}`,
          role: 'assistant',
          content: response.content,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          responseType: response.type,
          structuredData: response.structuredData,
          suggestedPrompts: response.followUpSuggestions && response.followUpSuggestions.length > 0
            ? response.followUpSuggestions
            : isIndonesian ? DEFAULT_SUGGESTED_PROMPTS_ID : DEFAULT_SUGGESTED_PROMPTS_EN,
          isError: !!response.error,
          modelUsed: response.modelUsed,
        };

        setMessages((prev) => [...prev, assistantMsg]);

        if (response.error) {
          setLastFailedMessage(trimmed);
        }
      } catch (err: any) {
        console.error('Failed to send message:', err);
        setLastFailedMessage(trimmed);

        const errorMsg: AIMessage = {
          id: `err_${Date.now()}`,
          role: 'assistant',
          content: isIndonesian
            ? 'Maaf, saya tidak dapat memproses permintaan tersebut saat ini.'
            : "Sorry, I couldn't process that request.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          responseType: 'warning',
          isError: true,
          suggestedPrompts: isIndonesian ? ['Coba lagi', ...DEFAULT_SUGGESTED_PROMPTS_ID.slice(0, 2)] : ['Try Again', ...DEFAULT_SUGGESTED_PROMPTS_EN.slice(0, 2)],
        };

        setMessages((prev) => [...prev, errorMsg]);
      } finally {
        setIsLoading(false);
      }
    },
    [isLoading, messages, profile, isIndonesian]
  );

  const retryLastMessage = useCallback(async () => {
    if (lastFailedMessage) {
      await sendMessage(lastFailedMessage);
    }
  }, [lastFailedMessage, sendMessage]);

  const sendSuggestedPrompt = useCallback(
    async (promptText: string) => {
      await sendMessage(promptText);
    },
    [sendMessage]
  );

  const value = useMemo(
    () => ({
      messages,
      isLoading,
      isThinking: isLoading,
      suggestedPrompts,
      lastFailedMessage,
      sendMessage,
      retryLastMessage,
      clearConversation,
      sendSuggestedPrompt,
    }),
    [messages, isLoading, suggestedPrompts, lastFailedMessage, sendMessage, retryLastMessage, clearConversation, sendSuggestedPrompt]
  );

  return <ConversationContext.Provider value={value}>{children}</ConversationContext.Provider>;
};

export const useConversation = (): ConversationContextType => {
  const context = useContext(ConversationContext);
  if (!context) {
    throw new Error('useConversation must be used within a ConversationProvider');
  }
  return context;
};
