import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  FoodEntry,
  NutritionSummary,
  MealPlan,
  GroceryItem,
  NutritionInsight,
  MealType,
} from '../types/nutrition';
import { NutritionEngine } from '../services/nutrition/nutritionEngine';
import { MealPlannerService } from '../services/nutrition/mealPlanner';
import { useProfile } from './ProfileContext';

interface NutritionContextType {
  foodEntries: FoodEntry[];
  dailySummary: NutritionSummary;
  insights: NutritionInsight[];
  currentMealPlan: MealPlan | null;
  groceryList: GroceryItem[];
  isGeneratingPlan: boolean;
  addFood: (entry: Omit<FoodEntry, 'id' | 'createdAt'>) => FoodEntry;
  removeFood: (id: string) => void;
  updateFood: (id: string, updates: Partial<FoodEntry>) => void;
  getDailySummary: (date?: string) => NutritionSummary;
  clearDay: (date?: string) => void;
  generateMealPlan: (type?: 'daily' | 'weekly') => Promise<MealPlan>;
  toggleGroceryItem: (id: string) => void;
  addGroceryItem: (item: Omit<GroceryItem, 'id' | 'isChecked'>) => void;
  removeGroceryItem: (id: string) => void;
  clearCheckedGroceryItems: () => void;
  addMealPlanToGroceries: (plan: MealPlan) => void;
}

const NutritionContext = createContext<NutritionContextType | undefined>(undefined);

const STORAGE_KEY_FOOD = 'health_ai_food_entries_v1';
const STORAGE_KEY_GROCERY = 'health_ai_grocery_list_v1';
const STORAGE_KEY_MEALPLAN = 'health_ai_meal_plan_v1';

// Initial realistic default entries for a vibrant starter day
const createDefaultInitialEntries = (): FoodEntry[] => {
  const today = new Date().toISOString().split('T')[0];
  return [
    {
      id: 'entry_init_1',
      name: 'Oatmeal Pisang & Susu Rendah Lemak',
      mealType: 'breakfast',
      servingAmount: 1,
      servingUnit: 'mangkuk (250g)',
      estimatedCalories: 340,
      estimatedProtein: 14,
      estimatedCarbs: 58,
      estimatedFat: 6,
      estimatedFiber: 6,
      estimatedSodium: 85,
      source: 'manual',
      createdAt: `${today}T07:30:00.000Z`,
      healthRating: 9.0,
      isVerified: false,
    },
    {
      id: 'entry_init_2',
      name: 'Telur Rebus Omega-3 (2 Butir)',
      mealType: 'breakfast',
      servingAmount: 2,
      servingUnit: 'butir (100g)',
      estimatedCalories: 140,
      estimatedProtein: 13,
      estimatedCarbs: 1,
      estimatedFat: 10,
      estimatedSodium: 120,
      source: 'manual',
      createdAt: `${today}T07:45:00.000Z`,
      healthRating: 9.2,
      isVerified: false,
    },
    {
      id: 'entry_init_3',
      name: 'Nasi Merah, Dada Ayam Panggang & Brokoli',
      mealType: 'lunch',
      servingAmount: 1,
      servingUnit: 'porsi piring seimbang',
      estimatedCalories: 520,
      estimatedProtein: 42,
      estimatedCarbs: 60,
      estimatedFat: 12,
      estimatedFiber: 5,
      estimatedSodium: 240,
      source: 'ai_photo',
      createdAt: `${today}T12:30:00.000Z`,
      notes: 'Dipindai dengan AI Food Vision & disesuaikan porsi',
      healthRating: 9.5,
      isVerified: false,
    },
  ];
};

export const NutritionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { userProfile } = useProfile();

  // 1. Food Entries State
  const [foodEntries, setFoodEntries] = useState<FoodEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_FOOD);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Failed to load food entries from storage:', e);
    }
    return createDefaultInitialEntries();
  });

  // 2. Grocery List State
  const [groceryList, setGroceryList] = useState<GroceryItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_GROCERY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to load grocery list:', e);
    }
    return [
      { id: 'groc_1', name: 'Dada Ayam Fillet Segar (500g)', category: 'protein', amount: '500g', isChecked: false, sourceMeal: 'Makan Siang' },
      { id: 'groc_2', name: 'Brokoli Hijau Segar', category: 'produce', amount: '2 bonggol', isChecked: true, sourceMeal: 'Makan Malam' },
      { id: 'groc_3', name: 'Telur Ayam Omega-3 (1 Tray)', category: 'protein', amount: '10 butir', isChecked: false, sourceMeal: 'Sarapan' },
      { id: 'groc_4', name: 'Oatmeal Gandum Utuh', category: 'grains', amount: '1 bungkus 500g', isChecked: false, sourceMeal: 'Sarapan' },
      { id: 'groc_5', name: 'Greek Yogurt Plain', category: 'dairy', amount: '2 cup', isChecked: false, sourceMeal: 'Snack' },
    ];
  });

  // 3. Active Meal Plan State
  const [currentMealPlan, setCurrentMealPlan] = useState<MealPlan | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_MEALPLAN);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to load meal plan:', e);
    }
    return null;
  });

  const [isGeneratingPlan, setIsGeneratingPlan] = useState<boolean>(false);

  // Sync state changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_FOOD, JSON.stringify(foodEntries));
    } catch (e) {
      console.warn('Storage sync error:', e);
    }
  }, [foodEntries]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_GROCERY, JSON.stringify(groceryList));
    } catch (e) {
      console.warn('Storage sync error:', e);
    }
  }, [groceryList]);

  useEffect(() => {
    try {
      if (currentMealPlan) {
        localStorage.setItem(STORAGE_KEY_MEALPLAN, JSON.stringify(currentMealPlan));
      }
    } catch (e) {
      console.warn('Storage sync error:', e);
    }
  }, [currentMealPlan]);

  // Derived Daily Summary (Deterministic Math, 0 Gemini calls)
  const dailySummary = useMemo(() => {
    const calTarget = userProfile?.dailyCalorieTarget || 2000;
    const protTarget = userProfile?.dailyProteinTargetG || 120;
    const carbTarget = userProfile?.dailyCarbsTargetG || 220;
    const fatTarget = userProfile?.dailyFatTargetG || 60;
    return NutritionEngine.calculateDailySummary(foodEntries, calTarget, protTarget, carbTarget, fatTarget);
  }, [foodEntries, userProfile]);

  // Derived Insights
  const insights = useMemo(() => {
    return NutritionEngine.generateNutritionInsights(dailySummary, userProfile);
  }, [dailySummary, userProfile]);

  // Add Food Entry
  const addFood = (entry: Omit<FoodEntry, 'id' | 'createdAt'>): FoodEntry => {
    const newEntry: FoodEntry = {
      ...entry,
      id: `food_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
      isVerified: entry.isVerified ?? false,
    };
    setFoodEntries((prev) => [newEntry, ...prev]);
    return newEntry;
  };

  // Remove Food Entry
  const removeFood = (id: string) => {
    setFoodEntries((prev) => prev.filter((e) => e.id !== id));
  };

  // Update Food Entry
  const updateFood = (id: string, updates: Partial<FoodEntry>) => {
    setFoodEntries((prev) =>
      prev.map((e) => (e.id === id ? { ...e, ...updates } : e))
    );
  };

  // Get specific date summary
  const getDailySummary = (date?: string): NutritionSummary => {
    const calTarget = userProfile?.dailyCalorieTarget || 2000;
    const protTarget = userProfile?.dailyProteinTargetG || 120;
    const carbTarget = userProfile?.dailyCarbsTargetG || 220;
    const fatTarget = userProfile?.dailyFatTargetG || 60;
    return NutritionEngine.calculateDailySummary(foodEntries, calTarget, protTarget, carbTarget, fatTarget, date);
  };

  // Clear Day Entries
  const clearDay = (date?: string) => {
    const targetDate = date || new Date().toISOString().split('T')[0];
    setFoodEntries((prev) => prev.filter((e) => !e.createdAt.startsWith(targetDate)));
  };

  // Generate Meal Plan via Service
  const generateMealPlan = async (type: 'daily' | 'weekly' = 'daily'): Promise<MealPlan> => {
    try {
      setIsGeneratingPlan(true);
      const plan = await MealPlannerService.generateMealPlan(type, userProfile);
      setCurrentMealPlan(plan);
      return plan;
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  // Grocery Item Toggles & Additions
  const toggleGroceryItem = (id: string) => {
    setGroceryList((prev) =>
      prev.map((item) => (item.id === id ? { ...item, isChecked: !item.isChecked } : item))
    );
  };

  const addGroceryItem = (item: Omit<GroceryItem, 'id' | 'isChecked'>) => {
    const newItem: GroceryItem = {
      ...item,
      id: `groc_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      isChecked: false,
    };
    setGroceryList((prev) => [newItem, ...prev]);
  };

  const removeGroceryItem = (id: string) => {
    setGroceryList((prev) => prev.filter((item) => item.id !== id));
  };

  const clearCheckedGroceryItems = () => {
    setGroceryList((prev) => prev.filter((item) => !item.isChecked));
  };

  const addMealPlanToGroceries = (plan: MealPlan) => {
    if (plan.groceryItems && plan.groceryItems.length > 0) {
      setGroceryList((prev) => {
        const existingNames = new Set(prev.map((i) => i.name.toLowerCase()));
        const newItems = plan.groceryItems!.filter((i) => !existingNames.has(i.name.toLowerCase()));
        return [...prev, ...newItems];
      });
    }
  };

  return (
    <NutritionContext.Provider
      value={{
        foodEntries,
        dailySummary,
        insights,
        currentMealPlan,
        groceryList,
        isGeneratingPlan,
        addFood,
        removeFood,
        updateFood,
        getDailySummary,
        clearDay,
        generateMealPlan,
        toggleGroceryItem,
        addGroceryItem,
        removeGroceryItem,
        clearCheckedGroceryItems,
        addMealPlanToGroceries,
      }}
    >
      {children}
    </NutritionContext.Provider>
  );
};

export const useNutrition = () => {
  const context = useContext(NutritionContext);
  if (!context) {
    throw new Error('useNutrition must be used within a NutritionProvider');
  }
  return context;
};
