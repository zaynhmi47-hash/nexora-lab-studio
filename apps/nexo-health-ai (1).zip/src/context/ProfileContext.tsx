import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import { UserProfile, LanguageCode } from '../types';
import { INITIAL_USER_PROFILE } from '../data/sampleData';
import { MOCK_PROFILE } from '../data/mockProfile';
import { FirestoreDataService } from '../services/firestoreService';

interface ProfileContextType {
  profile: UserProfile;
  userProfile: UserProfile;
  isLoading: boolean;
  updateProfile: (updates: Partial<UserProfile>) => void;
  resetProfile: () => void;
  completeOnboarding: (customData?: Partial<UserProfile>) => void;
  startOnboarding: () => void;
  isOnboardingOpen: boolean;
  setIsOnboardingOpen: (isOpen: boolean) => void;
}

const ProfileContext = createContext<ProfileContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'healthai_user_profile_v2';

export const ProfileProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        return { ...INITIAL_USER_PROFILE, ...JSON.parse(saved) };
      }
    } catch {
      // Fallback
    }
    return INITIAL_USER_PROFILE;
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(() => {
    // If onboarding not completed yet, open it by default for first-time users
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (!saved) return false; // let user click or can be set to true
      const parsed = JSON.parse(saved);
      return !parsed.hasCompletedOnboarding;
    } catch {
      return false;
    }
  });

  // Sync with Firestore when profile changes
  const updateProfile = (updates: Partial<UserProfile>) => {
    setProfile((prev) => {
      const updated = { ...prev, ...updates };
      try {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
      } catch (err) {
        console.warn('Could not save to localStorage:', err);
      }
      FirestoreDataService.saveUserProfile(updated);
      return updated;
    });
  };

  const resetProfile = () => {
    setProfile(INITIAL_USER_PROFILE);
    try {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    } catch (err) {
      console.warn('Could not clear localStorage:', err);
    }
    FirestoreDataService.saveUserProfile(INITIAL_USER_PROFILE);
  };

  const completeOnboarding = (customData?: Partial<UserProfile>) => {
    setProfile((prev) => {
      // Calculate dynamic recommended calories & macros based on new profile
      const weight = customData?.weightKg ?? prev.weightKg ?? 60;
      const height = customData?.heightCm ?? prev.heightCm ?? 170;
      const age = customData?.age ?? prev.age ?? 25;
      const gender = customData?.gender ?? prev.gender ?? 'other';
      const goal = customData?.primaryGoal ?? prev.primaryGoal ?? 'fitness';

      // Harris-Benedict BMR formula
      let bmr = 10 * weight + 6.25 * height - 5 * age + (gender === 'male' ? 5 : gender === 'female' ? -161 : 0);
      if (bmr < 1200) bmr = 1500;

      // Activity multiplier
      const actLevel = customData?.activityLevel ?? prev.activityLevel ?? 'moderate';
      const mult = actLevel === 'sedentary' ? 1.2 : actLevel === 'light' ? 1.375 : actLevel === 'moderate' ? 1.55 : actLevel === 'active' ? 1.725 : 1.9;
      let tdee = Math.round(bmr * mult);

      if (goal === 'weight_loss') tdee = Math.max(1400, tdee - 400);
      else if (goal === 'muscle_gain') tdee += 350;

      const proteinG = Math.round(weight * 1.8);
      const fatG = Math.round((tdee * 0.25) / 9);
      const carbsG = Math.max(100, Math.round((tdee - (proteinG * 4 + fatG * 9)) / 4));
      const waterMl = Math.round(weight * 35);

      const updated: UserProfile = {
        ...prev,
        ...customData,
        dailyCalorieTarget: tdee,
        dailyProteinTargetG: proteinG,
        dailyFatTargetG: fatG,
        dailyCarbsTargetG: carbsG,
        dailyWaterTargetMl: Math.max(2000, waterMl),
        hasCompletedOnboarding: true,
      };

      try {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
      } catch (err) {
        console.warn('Could not save profile:', err);
      }
      FirestoreDataService.saveUserProfile(updated);
      return updated;
    });

    setIsOnboardingOpen(false);
  };

  const startOnboarding = () => {
    setIsOnboardingOpen(true);
  };

  const value = useMemo(
    () => ({
      profile,
      userProfile: profile,
      isLoading,
      updateProfile,
      resetProfile,
      completeOnboarding,
      startOnboarding,
      isOnboardingOpen,
      setIsOnboardingOpen,
    }),
    [profile, isLoading, isOnboardingOpen]
  );

  return <ProfileContext.Provider value={value}>{children}</ProfileContext.Provider>;
};

export const useProfile = (): ProfileContextType => {
  const context = useContext(ProfileContext);
  if (!context) {
    throw new Error('useProfile must be used within a ProfileProvider');
  }
  return context;
};
