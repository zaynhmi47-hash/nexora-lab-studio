import React, { useState } from 'react';
import {
  Sparkles,
  Info,
  Activity,
  Moon,
  Utensils,
  Droplets,
  CheckCircle2,
  TrendingUp,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { WellnessScore as IWellnessScore } from '../../types/health';

interface WellnessScoreProps {
  score: IWellnessScore;
  isIndonesian?: boolean;
}

export const WellnessScore: React.FC<WellnessScoreProps> = ({
  score,
  isIndonesian = false,
}) => {
  const [showDetails, setShowDetails] = useState(false);

  const getStatusColor = (val: number) => {
    if (val >= 85) return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
    if (val >= 70) return 'text-teal-400 bg-teal-500/10 border-teal-500/30';
    if (val >= 50) return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
    return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
  };

  const getStatusLabel = (status: IWellnessScore['status']) => {
    if (isIndonesian) {
      switch (status) {
        case 'optimal':
          return 'Optimal & Prima';
        case 'good':
          return 'Sangat Baik';
        case 'fair':
          return 'Cukup Stabil';
        case 'needs_attention':
          return 'Perlu Perhatian';
      }
    }
    switch (status) {
      case 'optimal':
        return 'Optimal';
      case 'good':
        return 'Good';
      case 'fair':
        return 'Fair';
      case 'needs_attention':
        return 'Needs Focus';
    }
  };

  const componentsList = [
    {
      id: 'activity',
      label: isIndonesian ? 'Aktivitas & Gerak' : 'Activity & Steps',
      score: score.components.activity,
      weight: '25%',
      icon: Activity,
      color: 'text-amber-400',
      barColor: 'bg-amber-400',
      message: score.breakdownDetails.activityMessage,
    },
    {
      id: 'sleep',
      label: isIndonesian ? 'Tidur & Pemulihan' : 'Sleep & Rest',
      score: score.components.sleep,
      weight: '25%',
      icon: Moon,
      color: 'text-indigo-400',
      barColor: 'bg-indigo-400',
      message: score.breakdownDetails.sleepMessage,
    },
    {
      id: 'nutrition',
      label: isIndonesian ? 'Pola Makan & Gizi' : 'Nutrition & Meals',
      score: score.components.nutrition,
      weight: '20%',
      icon: Utensils,
      color: 'text-emerald-400',
      barColor: 'bg-emerald-400',
      message: score.breakdownDetails.nutritionMessage,
    },
    {
      id: 'hydration',
      label: isIndonesian ? 'Hidrasi Air Putih' : 'Hydration',
      score: score.components.hydration,
      weight: '15%',
      icon: Droplets,
      color: 'text-sky-400',
      barColor: 'bg-sky-400',
      message: score.breakdownDetails.hydrationMessage,
    },
    {
      id: 'consistency',
      label: isIndonesian ? 'Konsistensi Rutinitas' : 'Habit Consistency',
      score: score.components.consistency,
      weight: '15%',
      icon: CheckCircle2,
      color: 'text-teal-400',
      barColor: 'bg-teal-400',
      message: score.breakdownDetails.consistencyMessage,
    },
  ];

  return (
    <div
      id="wellness-score-card"
      className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl relative overflow-hidden transition-all"
    >
      {/* Background Ambient Glow */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Main Score Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span>{isIndonesian ? 'PERSONAL HEALTH ANALYTICS' : 'PERSONAL HEALTH INTELLIGENCE'}</span>
            </span>
            <span
              className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${getStatusColor(
                score.score
              )}`}
            >
              {getStatusLabel(score.status)}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-white">
            {isIndonesian ? 'Daily Wellness Score' : 'Daily Wellness Score'}
          </h2>
          <p className="text-xs text-slate-400 max-w-lg">
            {isIndonesian
              ? 'Indeks komprehensif gaya hidup sehat yang memadukan aktivitas fisik, tidur, nutrisi, hidrasi, dan konsistensi harian.'
              : 'Comprehensive lifestyle wellness metric blending physical movement, sleep recovery, nutrition pacing, hydration, and habit adherence.'}
          </p>
        </div>

        {/* Score Number Badge */}
        <div className="flex items-center gap-4 bg-slate-950/80 p-3.5 sm:p-4 rounded-2xl border border-slate-800 self-start sm:self-auto shrink-0 shadow-inner">
          <div className="text-right">
            <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
              {isIndonesian ? 'Skor Hari Ini' : 'Today Score'}
            </div>
            <div className="text-3xl sm:text-4xl font-black text-emerald-400 font-mono leading-none">
              {score.score}
              <span className="text-xs text-slate-500 font-normal">/100</span>
            </div>
          </div>

          {/* Mini Gauge Ring */}
          <div className="relative w-12 h-12 flex items-center justify-center">
            <svg className="w-12 h-12 -rotate-90" viewBox="0 0 48 48">
              <circle
                cx="24"
                cy="24"
                r="19"
                className="stroke-slate-800"
                strokeWidth="5"
                fill="none"
              />
              <circle
                cx="24"
                cy="24"
                r="19"
                className="stroke-emerald-400 transition-all duration-700"
                strokeWidth="5"
                strokeDasharray="119.38"
                strokeDashoffset={119.38 - (119.38 * score.score) / 100}
                strokeLinecap="round"
                fill="none"
              />
            </svg>
            <TrendingUp className="w-4 h-4 text-emerald-400 absolute" />
          </div>
        </div>
      </div>

      {/* 5 Component Bars */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-6 pt-5 border-t border-slate-800/80">
        {componentsList.map((comp) => {
          const Icon = comp.icon;
          return (
            <div
              key={comp.id}
              className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2 hover:border-slate-700 transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Icon className={`w-3.5 h-3.5 ${comp.color}`} />
                  <span className="text-[11px] font-semibold text-slate-300 truncate">
                    {comp.label}
                  </span>
                </div>
                <span className="text-[10px] font-mono text-slate-400">{comp.weight}</span>
              </div>

              <div className="flex items-baseline justify-between">
                <span className="text-base font-black text-white font-mono">{comp.score}</span>
                <span className="text-[10px] text-slate-500">/100</span>
              </div>

              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${comp.barColor}`}
                  style={{ width: `${Math.min(comp.score, 100)}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Expandable Breakdown Details */}
      <div className="mt-4 pt-3 border-t border-slate-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <button
          onClick={() => setShowDetails(!showDetails)}
          className="text-xs text-slate-400 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer self-start"
        >
          <span>{showDetails ? (isIndonesian ? 'Sembunyikan Rincian' : 'Hide Breakdown') : (isIndonesian ? 'Lihat Rincian Analisis' : 'View Detailed Breakdown')}</span>
          {showDetails ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>

        {/* Mandatory Subtle Non-Medical Explanation */}
        <div className="flex items-center gap-1.5 text-[10px] sm:text-[11px] text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="italic">
            {score.educationalDisclaimer ||
              (isIndonesian
                ? 'Wellness Score adalah estimasi edukatif berdasarkan kebiasaan harian Anda dan bukan penilaian medis.'
                : 'Wellness Score is an educational estimate based on your tracked habits and is not a medical assessment.')}
          </span>
        </div>
      </div>

      {showDetails && (
        <div className="mt-4 p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-2.5 animate-in fade-in">
          <div className="font-bold text-white text-xs mb-1">
            {isIndonesian ? 'Catatan Diagnostik Kebiasaan Hari Ini:' : "Today's Habit Diagnostic Notes:"}
          </div>
          {componentsList.map((c) => (
            <div key={c.id} className="flex items-start gap-2 text-slate-300">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
              <div>
                <strong className="text-slate-200">{c.label}:</strong> {c.message}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
