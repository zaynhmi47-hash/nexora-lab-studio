import React, { useState } from 'react';
import {
  Moon,
  Clock,
  Sparkles,
  Bed,
  Sun,
  ShieldCheck,
  Edit2,
  Check,
} from 'lucide-react';
import { SleepMetrics } from '../../types/health';

interface SleepCardProps {
  sleep: SleepMetrics;
  isIndonesian?: boolean;
  onSaveSleep: (metrics: Partial<SleepMetrics>) => Promise<void>;
}

export const SleepCard: React.FC<SleepCardProps> = ({
  sleep,
  isIndonesian = false,
  onSaveSleep,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [duration, setDuration] = useState(sleep.sleepDurationHours.toString());
  const [bedtime, setBedtime] = useState(sleep.bedtime || '23:00');
  const [wakeTime, setWakeTime] = useState(sleep.wakeTime || '06:30');

  const handleSave = async () => {
    const numDuration = parseFloat(duration);
    if (!isNaN(numDuration) && numDuration > 0) {
      await onSaveSleep({
        sleepDurationHours: numDuration,
        bedtime,
        wakeTime,
        sleepConsistencyScore: numDuration >= 7 ? 85 : 70,
        qualityRating: numDuration >= 7 ? 'good' : 'fair',
      });
      setIsEditing(false);
    }
  };

  const durationNum = sleep.sleepDurationHours || 7.5;
  const goalNum = sleep.sleepGoalHours || 8.0;
  const progressPct = Math.min(Math.round((durationNum / goalNum) * 100), 125);

  return (
    <div
      id="sleep-tracking-card"
      className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
            <Moon className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              {isIndonesian ? 'Pelacakan Tidur & Pemulihan' : 'Sleep Tracking & Recovery'}
            </h3>
            <span className="text-[11px] text-slate-400">
              {isIndonesian ? 'Kualitas & Konsistensi Ritme Sirkadian' : 'Circadian Rhythm & Recovery'}
            </span>
          </div>
        </div>

        <button
          onClick={() => setIsEditing(!isEditing)}
          className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer"
        >
          <Edit2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {isEditing ? (
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 animate-in fade-in">
          <div className="text-xs font-bold text-slate-200">
            {isIndonesian ? 'Ubah Catatan Tidur Hari Ini' : 'Update Today\'s Sleep'}
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">
                {isIndonesian ? 'Durasi (Jam)' : 'Hours'}
              </label>
              <input
                type="number"
                step="0.5"
                min="1"
                max="16"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">
                {isIndonesian ? 'Waktu Tidur' : 'Bedtime'}
              </label>
              <input
                type="text"
                value={bedtime}
                onChange={(e) => setBedtime(e.target.value)}
                placeholder="23:00"
                className="w-full px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">
                {isIndonesian ? 'Waktu Bangun' : 'Wake-up'}
              </label>
              <input
                type="text"
                value={wakeTime}
                onChange={(e) => setWakeTime(e.target.value)}
                placeholder="06:30"
                className="w-full px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button
              onClick={() => setIsEditing(false)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:text-white"
            >
              {isIndonesian ? 'Batal' : 'Cancel'}
            </button>
            <button
              onClick={handleSave}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Simpan' : 'Save'}</span>
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* Main Stat & Progress */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-1">
              <div className="text-[11px] text-slate-400 font-semibold">
                {isIndonesian ? 'Durasi Tercatat' : 'Tracked Sleep Duration'}
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-indigo-400 font-mono">
                  {durationNum}
                </span>
                <span className="text-xs text-slate-400">jam / target {goalNum} jam</span>
              </div>

              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mt-2">
                <div
                  className="h-full bg-indigo-400 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(progressPct, 100)}%` }}
                />
              </div>
            </div>

            {/* Bedtime & Wake Time */}
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <div className="flex items-center gap-1 text-[10px] text-slate-400">
                  <Bed className="w-3 h-3 text-indigo-400" />
                  <span>{isIndonesian ? 'Mulai Tidur' : 'Bedtime'}</span>
                </div>
                <div className="text-sm font-bold text-white font-mono">{sleep.bedtime || '23:00'}</div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-1 text-[10px] text-slate-400">
                  <Sun className="w-3 h-3 text-amber-400" />
                  <span>{isIndonesian ? 'Bangun' : 'Wake-up'}</span>
                </div>
                <div className="text-sm font-bold text-white font-mono">{sleep.wakeTime || '06:30'}</div>
              </div>

              <div className="col-span-2 pt-1 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                <span>{isIndonesian ? 'Skor Konsistensi' : 'Consistency Score'}</span>
                <span className="text-indigo-300 font-bold">{sleep.sleepConsistencyScore || 82}%</span>
              </div>
            </div>
          </div>

          {/* Educational Safety Caption */}
          <div className="flex items-center gap-1.5 text-[10px] text-slate-500 pt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span className="italic">
              {isIndonesian
                ? 'Waktu tidur tercatat diestimasi dari input perangkat/pengguna dan bukan diagnosis gangguan tidur klinis.'
                : 'Tracked sleep duration is an informational wellness metric, not a clinical sleep disorder evaluation.'}
            </span>
          </div>
        </>
      )}
    </div>
  );
};
