import React, { useState } from 'react';
import {
  Droplets,
  Plus,
  ShieldCheck,
  Check,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { HydrationMetrics } from '../../types/health';

interface HydrationCardProps {
  hydration: HydrationMetrics;
  isIndonesian?: boolean;
  onAddWater: (amountMl: number) => Promise<void>;
}

export const HydrationCard: React.FC<HydrationCardProps> = ({
  hydration,
  isIndonesian = false,
  onAddWater,
}) => {
  const [customAmount, setCustomAmount] = useState('250');
  const [isAddingCustom, setIsAddingCustom] = useState(false);

  const waterIntake = hydration.waterIntakeMl || 0;
  const waterGoal = hydration.waterGoalMl || 2500;
  const progressPct = Math.min(Math.round((waterIntake / waterGoal) * 100), 125);
  const remainingMl = Math.max(waterGoal - waterIntake, 0);

  const handleCustomAdd = async () => {
    const amt = parseInt(customAmount, 10);
    if (!isNaN(amt) && amt > 0) {
      await onAddWater(amt);
      setIsAddingCustom(false);
    }
  };

  return (
    <div
      id="hydration-tracking-card"
      className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-48 h-48 bg-sky-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center">
            <Droplets className="w-5 h-5 text-sky-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              {isIndonesian ? 'Pelacakan Hidrasi Cerdas' : 'Smart Hydration Tracking'}
            </h3>
            <span className="text-[11px] text-slate-400">
              {isIndonesian ? 'Keseimbangan Cairan Elektrolit Harian' : 'Daily Fluid & Electrolyte Balance'}
            </span>
          </div>
        </div>

        <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-xl bg-sky-500/10 text-sky-300 border border-sky-500/20">
          {progressPct}%
        </span>
      </div>

      {/* Progress & Target Overview */}
      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-2">
        <div className="flex items-baseline justify-between">
          <div>
            <span className="text-3xl font-black text-sky-400 font-mono">
              {(waterIntake / 1000).toFixed(2)}
            </span>
            <span className="text-xs font-semibold text-slate-400 ml-1">L</span>
          </div>
          <div className="text-right text-xs text-slate-400">
            Target: <span className="font-bold text-white">{(waterGoal / 1000).toFixed(1)} L</span>
            {remainingMl > 0 && (
              <span className="block text-[10px] text-sky-300">
                ({remainingMl} ml lagi)
              </span>
            )}
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-sky-400 rounded-full transition-all duration-500"
            style={{ width: `${Math.min(progressPct, 100)}%` }}
          />
        </div>
      </div>

      {/* Quick Add Buttons */}
      <div className="space-y-2">
        <div className="text-xs font-bold text-slate-300 flex items-center justify-between">
          <span>{isIndonesian ? 'Tambah Cepat Air Putih:' : 'Quick Add Hydration:'}</span>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
          {[
            { label: '+250 ml', val: 250, desc: isIndonesian ? 'Gelas' : 'Glass' },
            { label: '+500 ml', val: 500, desc: isIndonesian ? 'Botol Kecil' : 'Bottle' },
            { label: '+750 ml', val: 750, desc: isIndonesian ? 'Tumbler' : 'Tumbler' },
          ].map((btn) => (
            <button
              key={btn.val}
              onClick={() => onAddWater(btn.val)}
              className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-sky-500/50 hover:bg-sky-950/20 text-center transition-all cursor-pointer group"
            >
              <div className="text-xs font-black text-sky-400 group-hover:scale-105 transition-transform">
                {btn.label}
              </div>
              <div className="text-[9px] text-slate-500">{btn.desc}</div>
            </button>
          ))}

          <button
            onClick={() => setIsAddingCustom(!isAddingCustom)}
            className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-center transition-all cursor-pointer"
          >
            <div className="text-xs font-bold text-white flex items-center justify-center gap-1">
              <Plus className="w-3 h-3" />
              <span>{isIndonesian ? 'Kustom' : 'Custom'}</span>
            </div>
            <div className="text-[9px] text-slate-500">{isIndonesian ? 'Input ml' : 'Input ml'}</div>
          </button>
        </div>
      </div>

      {/* Custom Amount Drawer */}
      {isAddingCustom && (
        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center gap-2 animate-in fade-in">
          <input
            type="number"
            step="50"
            min="50"
            max="2000"
            value={customAmount}
            onChange={(e) => setCustomAmount(e.target.value)}
            className="flex-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono"
            placeholder="Jumlah ml..."
          />
          <button
            onClick={handleCustomAdd}
            className="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Tambah' : 'Add'}</span>
          </button>
        </div>
      )}

      {/* Recent Entries */}
      {hydration.hydrationEntries && hydration.hydrationEntries.length > 0 && (
        <div className="space-y-1.5 pt-1">
          <div className="text-[11px] font-semibold text-slate-400">
            {isIndonesian ? 'Riwayat Hari Ini:' : 'Today Entries:'}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {hydration.hydrationEntries.slice(-6).map((entry) => (
              <span
                key={entry.id}
                className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300"
              >
                {entry.timestamp} • +{entry.amountMl}ml
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div className="flex items-center gap-1.5 text-[10px] text-slate-500 pt-1">
        <ShieldCheck className="w-3.5 h-3.5 text-sky-400 shrink-0" />
        <span className="italic">
          {isIndonesian
            ? 'Target hidrasi adalah estimasi gaya hidup yang disesuaikan dengan berat & cuaca, bukan resep medis universal.'
            : 'Hydration goal is a personalized lifestyle estimation, not a universal medical prescription.'}
        </span>
      </div>
    </div>
  );
};
