import React, { useState } from 'react';
import {
  Clock,
  Dumbbell,
  Utensils,
  Droplets,
  Moon,
  Scale,
  Activity,
  Plus,
  Filter,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { HealthEvent, HealthEventType } from '../../types/health';

interface HealthTimelineProps {
  events: HealthEvent[];
  isIndonesian?: boolean;
  onAddEventClick?: () => void;
}

export const HealthTimeline: React.FC<HealthTimelineProps> = ({
  events,
  isIndonesian = false,
  onAddEventClick,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<HealthEventType | 'all'>('all');

  const filteredEvents = events.filter((e) => {
    if (selectedFilter === 'all') return true;
    return e.type === selectedFilter;
  });

  const getEventIcon = (type: HealthEventType) => {
    switch (type) {
      case 'workout':
        return { icon: Dumbbell, color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/30' };
      case 'meal':
        return { icon: Utensils, color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/30' };
      case 'water':
        return { icon: Droplets, color: 'text-sky-400', bg: 'bg-sky-500/10 border-sky-500/30' };
      case 'sleep':
        return { icon: Moon, color: 'text-indigo-400', bg: 'bg-indigo-500/10 border-indigo-500/30' };
      case 'weight':
        return { icon: Scale, color: 'text-purple-400', bg: 'bg-purple-500/10 border-purple-500/30' };
      case 'activity':
        return { icon: Activity, color: 'text-teal-400', bg: 'bg-teal-500/10 border-teal-500/30' };
    }
  };

  const getSourceBadge = (source: HealthEvent['source']) => {
    switch (source) {
      case 'body_ai':
        return (
          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
            Body AI
          </span>
        );
      case 'nutrition_ai':
        return (
          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
            Nutrition AI
          </span>
        );
      case 'health_connect':
        return (
          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-teal-500/10 text-teal-300 border border-teal-500/20">
            Health Connect
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div id="health-timeline-card" className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-2xl">
      {/* Header & Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <span>{isIndonesian ? 'Timeline Aktivitas & Riwayat Harian' : 'Daily Health Timeline'}</span>
          </h3>
          <p className="text-xs text-slate-400">
            {isIndonesian
              ? 'Arsip kronologis terintegrasi dari latihan Body AI, makanan, hidrasi, dan istirahat.'
              : 'Chronological unified stream of workouts, nutrition logs, water, and sleep.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onAddEventClick && (
            <button
              onClick={onAddEventClick}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Catat Event' : 'Add Event'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs border-b border-slate-800/80">
        {[
          { id: 'all', label: isIndonesian ? 'Semua' : 'All' },
          { id: 'workout', label: isIndonesian ? 'Latihan' : 'Workouts' },
          { id: 'meal', label: isIndonesian ? 'Makanan' : 'Meals' },
          { id: 'water', label: isIndonesian ? 'Hidrasi' : 'Water' },
          { id: 'sleep', label: isIndonesian ? 'Tidur' : 'Sleep' },
          { id: 'weight', label: isIndonesian ? 'Berat' : 'Weight' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedFilter(tab.id as any)}
            className={`px-3 py-1 rounded-xl font-semibold transition-all cursor-pointer whitespace-nowrap ${
              selectedFilter === tab.id
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Chronological Event Stream */}
      {filteredEvents.length === 0 ? (
        <div className="p-8 text-center rounded-2xl bg-slate-950/60 border border-dashed border-slate-800 text-slate-400 space-y-2">
          <Clock className="w-8 h-8 mx-auto text-slate-600" />
          <div className="text-xs font-semibold">
            {isIndonesian ? 'Belum ada aktivitas yang dicatat.' : 'No health events recorded for this filter.'}
          </div>
          <p className="text-[11px] text-slate-500">
            {isIndonesian
              ? 'Lakukan latihan Body AI, scan makanan, atau catat air putih untuk mengisi timeline.'
              : 'Complete a Body AI workout, log a meal, or add hydration to populate your timeline.'}
          </p>
        </div>
      ) : (
        <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-800">
          {filteredEvents.map((event) => {
            const config = getEventIcon(event.type);
            const Icon = config.icon;

            return (
              <div key={event.id} className="relative group">
                {/* Node Bullet Icon */}
                <div
                  className={`absolute -left-6 top-1 w-5 h-5 rounded-full flex items-center justify-center border ${config.bg} bg-slate-900`}
                >
                  <Icon className={`w-2.5 h-2.5 ${config.color}`} />
                </div>

                {/* Event Card Content */}
                <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/80 hover:border-slate-700 transition-all space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-white">{event.title}</span>
                      {getSourceBadge(event.source)}
                    </div>
                    <span className="text-[10px] font-mono text-slate-400 shrink-0">
                      {event.timestamp}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    {event.description}
                  </p>

                  {/* Extra metric pills */}
                  {event.metrics && (
                    <div className="flex items-center gap-2 pt-1 flex-wrap text-[10px] text-slate-400 font-mono">
                      {event.metrics.calories && (
                        <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                          {event.metrics.calories} kcal
                        </span>
                      )}
                      {event.metrics.durationMinutes && (
                        <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                          {event.metrics.durationMinutes} mnt
                        </span>
                      )}
                      {event.metrics.volumeMl && (
                        <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                          {event.metrics.volumeMl} ml
                        </span>
                      )}
                      {event.metrics.reps && (
                        <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                          {event.metrics.reps} reps
                        </span>
                      )}
                      {event.metrics.weightKg && (
                        <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                          {event.metrics.weightKg} kg
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
