import React from 'react';
import {
  Sparkles,
  CheckCircle2,
  Lightbulb,
  ArrowRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { AIHealthInsight } from '../../types/health';

interface AIInsightCardProps {
  insight: AIHealthInsight;
  isIndonesian?: boolean;
  onRefresh?: () => void;
  isLoading?: boolean;
}

export const AIInsightCard: React.FC<AIInsightCardProps> = ({
  insight,
  isIndonesian = false,
  onRefresh,
  isLoading = false,
}) => {
  const getCategoryTheme = () => {
    switch (insight.category) {
      case 'positive':
        return {
          badgeBg: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
          icon: Zap,
          iconColor: 'text-emerald-400',
        };
      case 'suggestion':
        return {
          badgeBg: 'bg-teal-500/10 text-teal-300 border-teal-500/30',
          icon: Lightbulb,
          iconColor: 'text-teal-400',
        };
      case 'warning':
        return {
          badgeBg: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
          icon: Lightbulb,
          iconColor: 'text-amber-400',
        };
      default:
        return {
          badgeBg: 'bg-slate-800 text-slate-300 border-slate-700',
          icon: Sparkles,
          iconColor: 'text-slate-400',
        };
    }
  };

  const theme = getCategoryTheme();
  const Icon = theme.icon;

  return (
    <div
      id="ai-insight-card"
      className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-60 h-60 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              {isIndonesian ? 'AI Health Insight' : 'AI Health Insight'}
            </h4>
            <span className="text-[10px] text-slate-500 font-mono">
              {insight.generatedAt} {insight.isAiGenerated && '• Gemini 3.7 Flash'}
            </span>
          </div>
        </div>

        <span
          className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full border ${theme.badgeBg}`}
        >
          {insight.focusArea.replace(/_/g, ' ')}
        </span>
      </div>

      {/* Headline & Summary */}
      <div className="space-y-1.5">
        <h3 className="text-base font-black text-white">{insight.headline}</h3>
        <p className="text-xs text-slate-300 leading-relaxed">{insight.summary}</p>
      </div>

      {/* Positive Areas & Constructive Suggestions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
        {insight.positiveAreas && insight.positiveAreas.length > 0 && (
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-2">
            <div className="text-[11px] font-bold text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Pencapaian Positif' : 'Positive Momentum'}</span>
            </div>
            <ul className="space-y-1 text-xs text-slate-300">
              {insight.positiveAreas.map((item, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <span className="text-emerald-400 font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {insight.suggestions && insight.suggestions.length > 0 && (
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-2">
            <div className="text-[11px] font-bold text-teal-400 flex items-center gap-1.5">
              <Lightbulb className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Saran Penyesuaian' : 'Constructive Action'}</span>
            </div>
            <ul className="space-y-1 text-xs text-slate-300">
              {insight.suggestions.map((item, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <span className="text-teal-400 font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Educational Safety Disclaimer */}
      <div className="flex items-center gap-1.5 text-[10px] text-slate-500 pt-1 border-t border-slate-800/50">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
        <span className="italic">
          {isIndonesian
            ? 'Rekomendasi AI bersifat edukasi gaya hidup kebugaran dan bukan saran medis atau resep pengobatan.'
            : 'AI insights provide wellness and lifestyle coaching, not medical diagnoses or prescriptive treatment.'}
        </span>
      </div>
    </div>
  );
};
