import React, { useState } from 'react';
import {
  Scale,
  Plus,
  TrendingDown,
  TrendingUp,
  Minus,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { WeightEntry } from '../../types/health';

interface WeightChartProps {
  weights: WeightEntry[];
  currentWeight?: number;
  isIndonesian?: boolean;
  onLogWeight: (weightKg: number, note?: string) => Promise<void>;
}

export const WeightChart: React.FC<WeightChartProps> = ({
  weights,
  currentWeight = 72.0,
  isIndonesian = false,
  onLogWeight,
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [inputWeight, setInputWeight] = useState(currentWeight.toString());
  const [note, setNote] = useState('');
  const [viewWindow, setViewWindow] = useState<'7d' | '30d'>('7d');

  const sortedWeights = [...weights].sort((a, b) => a.date.localeCompare(b.date));
  const activeWeights = viewWindow === '7d' ? sortedWeights.slice(-7) : sortedWeights.slice(-30);

  const latest = sortedWeights.length > 0 ? sortedWeights[sortedWeights.length - 1].weightKg : currentWeight;
  const first = activeWeights.length > 1 ? activeWeights[0].weightKg : latest;
  const delta = Number((latest - first).toFixed(1));

  const handleSaveWeight = async () => {
    const w = parseFloat(inputWeight);
    if (!isNaN(w) && w > 20 && w < 300) {
      await onLogWeight(w, note.trim() || undefined);
      setIsAdding(false);
      setNote('');
    }
  };

  // SVG Chart Calculations
  const minWeight = Math.min(...activeWeights.map((w) => w.weightKg), latest) - 1;
  const maxWeight = Math.max(...activeWeights.map((w) => w.weightKg), latest) + 1;
  const range = Math.max(maxWeight - minWeight, 2);

  const chartWidth = 500;
  const chartHeight = 140;
  const paddingX = 40;
  const paddingY = 25;

  const points = activeWeights.map((w, idx) => {
    const x =
      activeWeights.length === 1
        ? chartWidth / 2
        : paddingX + (idx / (activeWeights.length - 1)) * (chartWidth - paddingX * 2);
    const y =
      chartHeight -
      paddingY -
      ((w.weightKg - minWeight) / range) * (chartHeight - paddingY * 2);
    return { x, y, ...w };
  });

  const polylinePoints = points.map((p) => `${p.x},${p.y}`).join(' ');

  return (
    <div
      id="weight-tracking-card"
      className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-48 h-48 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
            <Scale className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              {isIndonesian ? 'Pelacakan Berat Badan' : 'Weight Tracking & Composition'}
            </h3>
            <span className="text-[11px] text-slate-400">
              {isIndonesian ? 'Tren Komposisi Tubuh Bertahap' : 'Gradual Body Trend & Rhythm'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex rounded-xl bg-slate-950 p-0.5 border border-slate-800 text-[10px] font-mono">
            <button
              onClick={() => setViewWindow('7d')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewWindow === '7d' ? 'bg-purple-600 text-white font-bold' : 'text-slate-400'
              }`}
            >
              7 Hari
            </button>
            <button
              onClick={() => setViewWindow('30d')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewWindow === '30d' ? 'bg-purple-600 text-white font-bold' : 'text-slate-400'
              }`}
            >
              30 Hari
            </button>
          </div>

          <button
            onClick={() => setIsAdding(!isAdding)}
            className="p-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition-all cursor-pointer shadow-md"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Metric Stat */}
      <div className="flex items-baseline justify-between p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80">
        <div>
          <div className="text-[11px] text-slate-400 font-semibold">
            {isIndonesian ? 'Berat Saat Ini' : 'Current Weight'}
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-black text-white font-mono">{latest}</span>
            <span className="text-xs font-semibold text-slate-400">kg</span>
          </div>
        </div>

        {/* Delta */}
        <div className="text-right">
          <div className="text-[11px] text-slate-400 font-semibold">
            {viewWindow === '7d'
              ? isIndonesian
                ? 'Perubahan 7 Hari'
                : '7-Day Change'
              : isIndonesian
              ? 'Perubahan 30 Hari'
              : '30-Day Change'}
          </div>
          <div className="flex items-center justify-end gap-1 font-mono text-sm font-bold">
            {delta < 0 ? (
              <span className="text-emerald-400 flex items-center">
                <TrendingDown className="w-3.5 h-3.5 mr-0.5" />
                {delta} kg
              </span>
            ) : delta > 0 ? (
              <span className="text-purple-400 flex items-center">
                <TrendingUp className="w-3.5 h-3.5 mr-0.5" />
                +{delta} kg
              </span>
            ) : (
              <span className="text-slate-400 flex items-center">
                <Minus className="w-3.5 h-3.5 mr-0.5" />
                0.0 kg
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Add Weight Form */}
      {isAdding && (
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 animate-in fade-in">
          <div className="text-xs font-bold text-slate-200">
            {isIndonesian ? 'Catat Timbangan Hari Ini' : 'Log New Weigh-in'}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">
                {isIndonesian ? 'Berat (kg)' : 'Weight (kg)'}
              </label>
              <input
                type="number"
                step="0.1"
                min="20"
                max="300"
                value={inputWeight}
                onChange={(e) => setInputWeight(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-1">
                {isIndonesian ? 'Catatan (opsional)' : 'Note (optional)'}
              </label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder={isIndonesian ? 'mis. Pagi sebelum makan' : 'e.g. Morning fasting'}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button
              onClick={() => setIsAdding(false)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:text-white"
            >
              {isIndonesian ? 'Batal' : 'Cancel'}
            </button>
            <button
              onClick={handleSaveWeight}
              className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Simpan' : 'Save'}</span>
            </button>
          </div>
        </div>
      )}

      {/* SVG Chart Visualization */}
      <div className="w-full h-36 bg-slate-950/80 rounded-2xl border border-slate-800/80 p-2 relative overflow-hidden flex items-center justify-center">
        {points.length <= 1 ? (
          <div className="text-xs text-slate-500 font-mono text-center">
            {isIndonesian ? 'Catat beberapa hari untuk melihat grafik tren.' : 'Log across multiple days to view chart.'}
          </div>
        ) : (
          <svg
            className="w-full h-full overflow-visible"
            viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            preserveAspectRatio="none"
          >
            {/* Horizontal Guide Lines */}
            <line
              x1={paddingX}
              y1={paddingY}
              x2={chartWidth - paddingX}
              y2={paddingY}
              stroke="#334155"
              strokeDasharray="3 3"
              strokeWidth="0.8"
            />
            <line
              x1={paddingX}
              y1={chartHeight / 2}
              x2={chartWidth - paddingX}
              y2={chartHeight / 2}
              stroke="#334155"
              strokeDasharray="3 3"
              strokeWidth="0.8"
            />
            <line
              x1={paddingX}
              y1={chartHeight - paddingY}
              x2={chartWidth - paddingX}
              y2={chartHeight - paddingY}
              stroke="#334155"
              strokeDasharray="3 3"
              strokeWidth="0.8"
            />

            {/* Polyline Path */}
            <polyline
              fill="none"
              stroke="#a855f7"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={polylinePoints}
            />

            {/* Data Dots & Value Labels */}
            {points.map((p, idx) => (
              <g key={idx}>
                <circle
                  cx={p.x}
                  cy={p.y}
                  r="4"
                  className="fill-purple-400 stroke-slate-900"
                  strokeWidth="2"
                />
                <text
                  x={p.x}
                  y={p.y - 8}
                  textAnchor="middle"
                  fill="#e2e8f0"
                  fontSize="9"
                  fontFamily="monospace"
                  fontWeight="bold"
                >
                  {p.weightKg}
                </text>
                <text
                  x={p.x}
                  y={chartHeight - 6}
                  textAnchor="middle"
                  fill="#64748b"
                  fontSize="8"
                  fontFamily="monospace"
                >
                  {p.date.slice(5)}
                </text>
              </g>
            ))}
          </svg>
        )}
      </div>

      {/* Safety Disclaimer */}
      <div className="flex items-center gap-1.5 text-[10px] text-slate-500 pt-1">
        <ShieldCheck className="w-3.5 h-3.5 text-purple-400 shrink-0" />
        <span className="italic">
          {isIndonesian
            ? 'Fluktuasi berat harian dipengaruhi kadar air dan glikogen, bukan tolok ukur instan lemak tubuh.'
            : 'Daily weight fluctuations reflect fluid & glycogen shifts, not instantaneous fat changes.'}
        </span>
      </div>
    </div>
  );
};
