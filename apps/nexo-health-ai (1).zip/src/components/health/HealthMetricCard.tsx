import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  HelpCircle,
  LucideIcon,
} from 'lucide-react';
import { HealthTrendDirection } from '../../types/health';

interface HealthMetricCardProps {
  title: string;
  value: string | number;
  unit?: string;
  goal?: string | number;
  progressPercentage?: number;
  icon: LucideIcon;
  iconColor?: string;
  iconBgColor?: string;
  trendDirection?: HealthTrendDirection;
  trendText?: string;
  subtitle?: string;
  onClick?: () => void;
}

export const HealthMetricCard: React.FC<HealthMetricCardProps> = ({
  title,
  value,
  unit,
  goal,
  progressPercentage,
  icon: Icon,
  iconColor = 'text-emerald-400',
  iconBgColor = 'bg-emerald-500/10 border-emerald-500/20',
  trendDirection,
  trendText,
  subtitle,
  onClick,
}) => {
  const getTrendBadge = () => {
    if (!trendDirection || trendDirection === 'insufficient_data') {
      return (
        <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 border border-slate-700 flex items-center gap-1">
          <HelpCircle className="w-2.5 h-2.5" />
          <span>{trendText || 'Data awal'}</span>
        </span>
      );
    }

    if (trendDirection === 'improving') {
      return (
        <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 flex items-center gap-1">
          <TrendingUp className="w-2.5 h-2.5 text-emerald-400" />
          <span>{trendText || 'Meningkat'}</span>
        </span>
      );
    }

    if (trendDirection === 'declining') {
      return (
        <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/20 flex items-center gap-1">
          <TrendingDown className="w-2.5 h-2.5 text-amber-400" />
          <span>{trendText || 'Menurun'}</span>
        </span>
      );
    }

    return (
      <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1">
        <Minus className="w-2.5 h-2.5 text-slate-400" />
        <span>{trendText || 'Stabil'}</span>
      </span>
    );
  };

  return (
    <div
      onClick={onClick}
      className={`p-4 sm:p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-lg transition-all ${
        onClick ? 'cursor-pointer hover:border-slate-700 hover:bg-slate-850' : ''
      }`}
    >
      {/* Top Header Row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center border ${iconBgColor}`}
          >
            <Icon className={`w-4 h-4 ${iconColor}`} />
          </div>
          <span className="text-xs font-bold text-slate-300">{title}</span>
        </div>
        {getTrendBadge()}
      </div>

      {/* Main Metric Value */}
      <div className="space-y-0.5">
        <div className="flex items-baseline gap-1.5">
          <span className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight">
            {typeof value === 'number' ? value.toLocaleString() : value}
          </span>
          {unit && <span className="text-xs font-semibold text-slate-400">{unit}</span>}
        </div>

        {goal && (
          <div className="text-[11px] text-slate-400">
            Target: <span className="font-semibold text-slate-300">{goal}</span>
          </div>
        )}
      </div>

      {/* Progress Bar (Optional) */}
      {typeof progressPercentage === 'number' && (
        <div className="space-y-1">
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                progressPercentage >= 100 ? 'bg-emerald-400' : 'bg-teal-500'
              }`}
              style={{ width: `${Math.min(progressPercentage, 100)}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono">
            <span>{progressPercentage}% tercapai</span>
            {subtitle && <span>{subtitle}</span>}
          </div>
        </div>
      )}
    </div>
  );
};
