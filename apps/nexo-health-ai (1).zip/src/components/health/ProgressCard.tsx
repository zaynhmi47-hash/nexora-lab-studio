import React from 'react';
import {
  Target,
  CheckCircle2,
  TrendingUp,
  Sparkles,
  Award,
  Flame,
  ShieldCheck,
} from 'lucide-react';
import { WeeklyReport } from '../../types/health';

interface ProgressCardProps {
  report: WeeklyReport;
  isIndonesian?: boolean;
}

export const ProgressCard: React.FC<ProgressCardProps> = ({
  report,
  isIndonesian = false,
}) => {
  const goal = report.goalProgress;

  const getStatusBadge = (status: WeeklyReport['goalProgress']['status']) => {
    if (status === 'accelerating') {
      return (
        <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
          <Flame className="w-3 h-3 text-emerald-400" />
          <span>{isIndonesian ? 'Akselerasi Tinggi' : 'Accelerating'}</span>
        </span>
      );
    }
    if (status === 'on_track') {
      return (
        <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/30 flex items-center gap-1">
          <CheckCircle2 className="w-3 h-3 text-teal-400" />
          <span>{isIndonesian ? 'Sesuai Target' : 'On Track'}</span>
        </span>
      );
    }
    return (
      <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 flex items-center gap-1">
        <Sparkles className="w-3 h-3 text-amber-400" />
        <span>{isIndonesian ? 'Membangun Ritme' : 'Building Momentum'}</span>
      </span>
    );
  };

  return (
    <div
      id="goal-progress-card"
      className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-48 h-48 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center">
            <Target className="w-5 h-5 text-teal-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              {isIndonesian ? 'Progres Sasaran Kesehatan' : 'Health Goal Momentum'}
            </h3>
            <span className="text-[11px] text-slate-400">
              {isIndonesian ? 'Keterhubungan Tujuan & Konsistensi Harian' : 'Connecting Habits to Personal Goals'}
            </span>
          </div>
        </div>

        {getStatusBadge(goal.status)}
      </div>

      {/* Main Goal Banner */}
      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="text-[10px] text-teal-400 font-mono font-bold uppercase tracking-wider">
              {isIndonesian ? 'Sasaran Utama' : 'Primary Goal'}
            </div>
            <div className="text-base sm:text-lg font-black text-white">
              {goal.primaryGoal}
            </div>
          </div>

          <div className="text-right">
            <div className="text-2xl font-black text-teal-400 font-mono">
              {goal.progressPercentage}%
            </div>
            <div className="text-[10px] text-slate-400">
              {isIndonesian ? 'Kepatuhan Pekanan' : 'Weekly Adherence'}
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-teal-400 rounded-full transition-all duration-500"
            style={{ width: `${Math.min(goal.progressPercentage, 100)}%` }}
          />
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          {goal.summary}
        </p>
      </div>

      {/* 4 Core Weekly Habit Trackers (Non-shaming) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-1">
          <div className="text-[10px] text-slate-400 font-semibold">
            {isIndonesian ? 'Latihan Fisik' : 'Workouts'}
          </div>
          <div className="text-sm font-bold text-white font-mono">
            {report.activity.workoutsCount} / 3 <span className="text-[10px] text-slate-400">sesi</span>
          </div>
          <div className="text-[10px] text-emerald-400 font-mono">
            {Math.round((report.activity.workoutsCount / 3) * 100)}%
          </div>
        </div>

        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-1">
          <div className="text-[10px] text-slate-400 font-semibold">
            {isIndonesian ? 'Target Air' : 'Water Days'}
          </div>
          <div className="text-sm font-bold text-white font-mono">
            {report.hydration.targetMetDays} / 7 <span className="text-[10px] text-slate-400">hari</span>
          </div>
          <div className="text-[10px] text-sky-400 font-mono">
            {Math.round((report.hydration.targetMetDays / 7) * 100)}%
          </div>
        </div>

        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-1">
          <div className="text-[10px] text-slate-400 font-semibold">
            {isIndonesian ? 'Tidur 7+ Jam' : 'Sleep 7h+'}
          </div>
          <div className="text-sm font-bold text-white font-mono">
            {report.sleep.targetMetDays} / 7 <span className="text-[10px] text-slate-400">malam</span>
          </div>
          <div className="text-[10px] text-indigo-400 font-mono">
            {Math.round((report.sleep.targetMetDays / 7) * 100)}%
          </div>
        </div>

        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-1">
          <div className="text-[10px] text-slate-400 font-semibold">
            {isIndonesian ? 'Catat Makanan' : 'Meal Logs'}
          </div>
          <div className="text-sm font-bold text-white font-mono">
            {report.nutrition.loggedDays} / 7 <span className="text-[10px] text-slate-400">hari</span>
          </div>
          <div className="text-[10px] text-teal-400 font-mono">
            {Math.round((report.nutrition.loggedDays / 7) * 100)}%
          </div>
        </div>
      </div>

      {/* Safety Footer */}
      <div className="flex items-center gap-1.5 text-[10px] text-slate-500 pt-1">
        <ShieldCheck className="w-3.5 h-3.5 text-teal-400 shrink-0" />
        <span className="italic">
          {isIndonesian
            ? 'Setiap pilihan positif kecil membangun konsistensi yang berkelanjutan.'
            : 'Every small sustainable choice reinforces positive lifestyle momentum.'}
        </span>
      </div>
    </div>
  );
};
