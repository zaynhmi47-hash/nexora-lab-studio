import React from 'react';
import {
  Calendar,
  Sparkles,
  TrendingUp,
  Activity,
  Moon,
  Droplets,
  Utensils,
  CheckCircle2,
  ShieldCheck,
  Bot,
  RefreshCw,
} from 'lucide-react';
import { WeeklyReport as IWeeklyReport } from '../../types/health';
import { AIInsightCard } from './AIInsightCard';

interface WeeklyReportProps {
  report: IWeeklyReport;
  isIndonesian?: boolean;
  onAskAi: () => Promise<void>;
  isGeneratingAi?: boolean;
}

export const WeeklyReport: React.FC<WeeklyReportProps> = ({
  report,
  isIndonesian = false,
  onAskAi,
  isGeneratingAi = false,
}) => {
  const delta = report.wellnessScore.delta;

  return (
    <div
      id="weekly-health-report-container"
      className="space-y-6"
    >
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/30 font-semibold flex items-center gap-1">
                <Calendar className="w-3 h-3 text-teal-400" />
                <span>{report.weekStartDate} — {report.weekEndDate}</span>
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {isIndonesian ? 'Laporan Mingguan Kesehatan Personal' : 'Weekly Personal Health Report'}
            </h2>
            <p className="text-xs text-slate-400 max-w-xl">
              {isIndonesian
                ? 'Ringkasan performa 7 hari terakhir yang mengagregasi latihan fisik, istirahat, pola makan, dan hidrasi harian.'
                : 'Comprehensive 7-day retrospective tracking physical activity, sleep consistency, nutrition, and hydration.'}
            </p>
          </div>

          {/* Wellness Score 7-Day Average */}
          <div className="flex items-center gap-4 bg-slate-950 p-4 rounded-2xl border border-slate-800 shrink-0">
            <div className="text-right">
              <div className="text-[10px] text-slate-400 font-semibold uppercase">
                {isIndonesian ? 'Rerata Wellness 7-Hari' : '7-Day Avg Wellness'}
              </div>
              <div className="text-3xl font-black text-teal-400 font-mono">
                {report.wellnessScore.current}
                <span className="text-xs text-slate-500 font-normal">/100</span>
              </div>
            </div>

            <div className="text-xs font-mono font-bold px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 text-slate-300">
              {delta >= 0 ? (
                <span className="text-emerald-400">+{delta} pts</span>
              ) : (
                <span className="text-amber-400">{delta} pts</span>
              )}
            </div>
          </div>
        </div>

        {/* 4 Core Weekly Pillars */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-800">
          {/* 1. Activity */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
              <Activity className="w-4 h-4 text-amber-400" />
              <span>{isIndonesian ? 'Aktivitas Fisik' : 'Physical Activity'}</span>
            </div>
            <div className="text-lg font-black text-white font-mono">
              {report.activity.workoutsCount} <span className="text-xs font-normal text-slate-400">sesi latihan</span>
            </div>
            <div className="text-[11px] text-slate-400">
              {report.activity.averageDailySteps.toLocaleString()} {isIndonesian ? 'langkah/hari' : 'avg steps/day'}
            </div>
          </div>

          {/* 2. Sleep */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
              <Moon className="w-4 h-4 text-indigo-400" />
              <span>{isIndonesian ? 'Tidur & Istirahat' : 'Sleep & Recovery'}</span>
            </div>
            <div className="text-lg font-black text-white font-mono">
              {report.sleep.averageHours} <span className="text-xs font-normal text-slate-400">jam/malam</span>
            </div>
            <div className="text-[11px] text-slate-400">
              {report.sleep.targetMetDays}/7 {isIndonesian ? 'hari tercapai' : 'days target met'}
            </div>
          </div>

          {/* 3. Hydration */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
              <Droplets className="w-4 h-4 text-sky-400" />
              <span>{isIndonesian ? 'Hidrasi Harian' : 'Hydration'}</span>
            </div>
            <div className="text-lg font-black text-white font-mono">
              {report.hydration.averageLiters} <span className="text-xs font-normal text-slate-400">L/hari</span>
            </div>
            <div className="text-[11px] text-slate-400">
              {report.hydration.targetMetDays}/7 {isIndonesian ? 'hari target' : 'days target'}
            </div>
          </div>

          {/* 4. Nutrition */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
              <Utensils className="w-4 h-4 text-emerald-400" />
              <span>{isIndonesian ? 'Nutrisi & Gizi' : 'Nutrition'}</span>
            </div>
            <div className="text-lg font-black text-white font-mono">
              {report.nutrition.loggedDays}/7 <span className="text-xs font-normal text-slate-400">hari dicatat</span>
            </div>
            <div className="text-[11px] text-slate-400">
              ~{report.nutrition.averageCalories} kcal/hari
            </div>
          </div>
        </div>

        {/* AI Action Button */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-800">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              {isIndonesian
                ? `Tingkat Kepatuhan Kebiasaan Pekanan: ${report.consistency.percentage}%`
                : `Weekly Habit Consistency Rate: ${report.consistency.percentage}%`}
            </span>
          </div>

          <button
            onClick={onAskAi}
            disabled={isGeneratingAi}
            className="px-4 py-2 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg cursor-pointer transition-all disabled:opacity-50"
          >
            {isGeneratingAi ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Bot className="w-4 h-4 text-emerald-200" />
            )}
            <span>
              {isGeneratingAi
                ? (isIndonesian ? 'Menganalisis Progres...' : 'Analyzing Progress...')
                : (isIndonesian ? 'Tanyakan Evaluasi Progres ke AI' : 'Ask AI About My Progress')}
            </span>
          </button>
        </div>
      </div>

      {/* AI Insight Card Section */}
      {report.aiInsight && (
        <AIInsightCard
          insight={report.aiInsight}
          isIndonesian={isIndonesian}
        />
      )}

      {/* Safety Footer */}
      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-slate-500 text-xs flex items-center gap-2">
        <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
        <span className="italic">
          {isIndonesian
            ? 'Laporan ini dihitung secara edukatif dari data gaya hidup harian Anda. Tidak ditujukan untuk diagnosis atau pengobatan medis klinis.'
            : 'This report provides educational lifestyle analytics derived from your tracked habits. Not intended for medical diagnosis or clinical treatment.'}
        </span>
      </div>
    </div>
  );
};
