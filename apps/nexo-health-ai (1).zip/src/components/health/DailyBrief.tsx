import React from 'react';
import {
  Sparkles,
  RefreshCw,
  Zap,
  CheckCircle2,
  Lightbulb,
  ShieldCheck,
} from 'lucide-react';
import { AIHealthInsight } from '../../types/health';

interface DailyBriefProps {
  brief: AIHealthInsight | null;
  isIndonesian?: boolean;
  onRefresh: () => Promise<void>;
  isLoading?: boolean;
}

export const DailyBrief: React.FC<DailyBriefProps> = ({
  brief,
  isIndonesian = false,
  onRefresh,
  isLoading = false,
}) => {
  if (!brief) return null;

  return (
    <div
      id="daily-ai-brief-card"
      className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-xl relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
            <Zap className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <span>{isIndonesian ? 'Daily AI Health Brief' : 'Daily AI Health Brief'}</span>
              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                {brief.isAiGenerated ? 'Gemini 3.7' : 'Smart Engine'}
              </span>
            </h3>
            <span className="text-[10px] text-slate-500 font-mono">
              {brief.generatedAt}
            </span>
          </div>
        </div>

        <button
          onClick={onRefresh}
          disabled={isLoading}
          className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer disabled:opacity-50"
          title={isIndonesian ? 'Perbarui Ringkasan AI' : 'Refresh AI Brief'}
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-emerald-400' : ''}`} />
        </button>
      </div>

      {/* Headline & Summary */}
      <div className="space-y-1">
        <div className="text-sm font-bold text-slate-100">{brief.headline}</div>
        <p className="text-xs text-slate-300 leading-relaxed">{brief.summary}</p>
      </div>

      {/* Actionable points */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
        {brief.positiveAreas && brief.positiveAreas.length > 0 && (
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-emerald-300 flex items-start gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
            <span>{brief.positiveAreas[0]}</span>
          </div>
        )}

        {brief.suggestions && brief.suggestions.length > 0 && (
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-teal-300 flex items-start gap-1.5">
            <Lightbulb className="w-3.5 h-3.5 text-teal-400 mt-0.5 shrink-0" />
            <span>{brief.suggestions[0]}</span>
          </div>
        )}
      </div>

      {/* Disclaimer */}
      <div className="flex items-center gap-1 text-[9px] text-slate-500 pt-1">
        <ShieldCheck className="w-3 h-3 text-emerald-400 shrink-0" />
        <span className="italic">
          {isIndonesian
            ? 'Ringkasan edukatif gaya hidup harian, bukan diagnosa medis.'
            : 'Informational daily wellness briefing, not clinical diagnosis.'}
        </span>
      </div>
    </div>
  );
};
