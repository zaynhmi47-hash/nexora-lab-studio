import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Flame,
  Globe,
  User as UserIcon,
  LogIn,
  ChevronDown,
  Sparkles,
  Activity,
  Utensils,
  Dumbbell,
  Trophy,
  Award,
  Database,
  CheckCircle2,
  Layers,
  HeartPulse,
  Search,
  Camera,
  SlidersHorizontal,
  Stethoscope,
  Grid,
  Mic,
  ShieldCheck,
  Smartphone,
  CreditCard,
  Building2,
} from 'lucide-react';
import { LanguageCode, UserProfile, HealthModuleId } from '../../types';
import { SUPPORTED_LANGUAGES, getTranslation } from '../../data/translations';
import { TabType } from './NavBar';
import { User } from '../../lib/firebase';
import { QuickCommandModal } from './QuickCommandModal';

interface HeaderProps {
  userProfile: UserProfile;
  activeTab?: TabType;
  setActiveTab: (tab: TabType) => void;
  onLanguageChange: (lang: LanguageCode) => void;
  currentUser: User | null;
  onOpenAuthModal: () => void;
  onOpenDrawer?: () => void;
  onSelectSpecificModule?: (moduleId: HealthModuleId) => void;
}

export const Header: React.FC<HeaderProps> = ({
  userProfile,
  activeTab = 'landing',
  setActiveTab,
  onLanguageChange,
  currentUser,
  onOpenAuthModal,
  onOpenDrawer,
  onSelectSpecificModule,
}) => {
  const isIndonesian = userProfile.language === 'id';
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const moreMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (moreMenuRef.current && !moreMenuRef.current.contains(event.target as Node)) {
        setIsMoreMenuOpen(false);
      }
    };
    if (isMoreMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isMoreMenuOpen]);

  // Google Play & Health Categories
  interface GooglePlayTabItem {
    id: TabType;
    label: string;
    icon: React.ElementType;
    highlight?: boolean;
    badge?: string;
  }

  const googlePlayTabs: GooglePlayTabItem[] = [
    {
      id: 'landing',
      label: isIndonesian ? 'Untuk Anda' : 'For You',
      icon: Sparkles,
    },
    {
      id: 'doctor_consultation',
      label: isIndonesian ? 'Dokter AI' : 'AI Doctor',
      icon: Stethoscope,
      highlight: true,
      badge: 'Baru',
    },
    {
      id: 'dashboard',
      label: isIndonesian ? 'Health Connect' : 'Health Connect',
      icon: Activity,
    },
    {
      id: 'nutrition',
      label: isIndonesian ? 'Gizi & Vision' : 'AI Nutrition',
      icon: Utensils,
    },
    {
      id: 'workout',
      label: isIndonesian ? 'Latihan AI' : 'Workouts',
      icon: Dumbbell,
    },
    {
      id: 'modules_hub',
      label: isIndonesian ? 'Peringkat Teratas (20)' : 'Top Charts (20)',
      icon: Layers,
    },
  ];

  // Secondary items in "Kategori Lain" popover
  const secondaryTabs = [
    {
      id: 'form_guard',
      label: 'FormGuard CV (Biomekanik)',
      desc: isIndonesian ? 'Pelacak pose & sudut sendi real-time' : 'Real-time joint pose tracking',
      icon: Camera,
    },
    {
      id: 'recovery',
      label: isIndonesian ? 'Recovery Lab & Peta Nyeri' : 'Recovery Lab',
      desc: isIndonesian ? 'Peta nyeri otot & hidroterapi' : 'Muscle pain heatmap & recovery',
      icon: HeartPulse,
    },
    {
      id: 'sport',
      label: isIndonesian ? 'Sport Tracker & PR' : 'Sport & PR Tracker',
      desc: isIndonesian ? 'GPS lari, sepeda & komunitas' : 'GPS run, cycling & matches',
      icon: Trophy,
    },
    {
      id: 'gamification',
      label: isIndonesian ? 'Play Points & XP' : 'Play Points & XP',
      desc: isIndonesian ? 'Streak reward, trophy & level up' : 'Streak badges & rewards',
      icon: Award,
    },
    {
      id: 'pricing',
      label: isIndonesian ? 'Paket Harga & Langganan' : 'Pricing & Subscription Plans',
      desc: isIndonesian ? 'Paket Standard, Pro & Bisnis' : 'Standard, Pro & Business tiers',
      icon: CreditCard,
    },
    {
      id: 'business_hub',
      label: isIndonesian ? 'Portal Bisnis & Klinik' : 'Business & Clinic Portal',
      desc: isIndonesian ? 'Rekam medis, resep & SIMRS' : 'EMR, e-prescriptions & SIMRS',
      icon: Building2,
    },
    {
      id: 'firestore',
      label: 'Cloud DB & Enkripsi',
      desc: isIndonesian ? 'Penyimpanan terenkripsi Firestore' : 'Encrypted cloud vault',
      icon: Database,
    },
  ] as const;

  const isCurrentInSecondary = secondaryTabs.some((t) => t.id === activeTab);
  const userInitial = currentUser?.displayName
    ? currentUser.displayName.charAt(0).toUpperCase()
    : userProfile.name
    ? userProfile.name.charAt(0).toUpperCase()
    : 'U';

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-xl border-b border-slate-200 shadow-2xs transition-all">
        {/* TOP ROW: Google Play Search Bar + App Logo + Profile */}
        <div className="max-w-7xl mx-auto px-3 sm:px-6 pt-2 pb-1.5 flex items-center justify-between gap-2 sm:gap-4 md:gap-6 w-full max-w-full overflow-hidden">
          {/* Brand Logo with Google Play & Google Health Vibe */}
          <div
            onClick={() => setActiveTab('landing')}
            className="flex items-center gap-2 cursor-pointer shrink-0 group select-none"
          >
            <div className="relative shrink-0">
              <motion.div
                whileHover={{ scale: 1.05, rotate: 6 }}
                whileTap={{ scale: 0.95 }}
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-sky-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/20"
              >
                <HeartPulse className="w-4 h-4 sm:w-5 sm:h-5" />
              </motion.div>
              <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-white border border-slate-200 flex items-center justify-center shadow-2xs">
                <span className="w-2 h-2 rounded-full bg-emerald-500 block" />
              </div>
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-black text-sm sm:text-base lg:text-lg tracking-tight text-slate-900 leading-none">
                  Google <span className="text-emerald-700 font-extrabold">Health</span>
                </span>
                <span className="hidden md:inline px-1.5 py-0.2 rounded-md bg-emerald-100 text-emerald-900 font-bold text-[9px] border border-emerald-300">
                  PLAY STORE
                </span>
              </div>
              <span className="hidden sm:flex text-[10px] text-slate-500 font-semibold leading-tight items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-600 inline" />
                {isIndonesian ? 'Terverifikasi Health Connect' : 'Verified Health Connect'}
              </span>
            </div>
          </div>

          {/* Center: Google Search Pill Bar + Live Biometrics Ticker */}
          <div className="hidden md:flex flex-1 max-w-md lg:max-w-2xl min-w-0 mx-2 items-center gap-2.5">
            <motion.div
              whileTap={{ scale: 0.99 }}
              onClick={() => setIsSearchOpen(true)}
              className="flex-1 bg-slate-100/90 hover:bg-slate-200/90 border border-slate-200 hover:border-emerald-300 rounded-full px-4 py-2 flex items-center justify-between gap-3 text-slate-500 text-xs font-medium cursor-pointer shadow-2xs transition-all"
            >
              <div className="flex items-center gap-2.5 flex-1 min-w-0">
                <Search className="w-4 h-4 text-emerald-700 shrink-0" />
                <span className="truncate text-slate-700 text-xs">
                  {isIndonesian
                    ? 'Telusuri dokter, kalori, EKG, atau 20 modul AI...'
                    : 'Search doctors, nutrition, ECG, or 20 AI modules...'}
                </span>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <kbd className="hidden lg:inline-block px-2 py-0.5 text-[10px] font-mono bg-white rounded-md border border-slate-200 text-slate-400 shadow-2xs font-semibold">
                  ⌘K
                </kbd>
                <div className="w-px h-4 bg-slate-300 hidden sm:block" />
                <Mic className="w-3.5 h-3.5 text-emerald-700 hidden sm:block hover:text-emerald-800" />
              </div>
            </motion.div>

            {/* Live Biometric Pulse Ticker Pill */}
            <div className="hidden xl:flex items-center gap-2 bg-emerald-50/90 border border-emerald-200/90 rounded-full px-3 py-1.5 shadow-2xs shrink-0 select-none">
              <div className="flex items-center gap-1.5">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="text-[11px] font-black text-emerald-950">76 bpm</span>
              </div>
              <div className="w-px h-3 bg-emerald-200" />
              <span className="text-[10px] font-extrabold text-emerald-800">92% Siap</span>
            </div>
          </div>

          {/* Right: Search button (mobile) + Streak + Language + Google Account Profile Avatar */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Mobile Quick Search Button */}
            <motion.button
              whileTap={{ scale: 0.92 }}
              onClick={() => setIsSearchOpen(true)}
              className="md:hidden p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200/80 transition-colors cursor-pointer"
              title={isIndonesian ? 'Cari Fitur / Modul' : 'Search Modules'}
            >
              <Search className="w-4 h-4 text-slate-700" />
            </motion.button>

            {/* Play Points / XP Streak Pill */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveTab('gamification')}
              className="flex items-center gap-1 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 text-[11px] sm:text-xs font-bold transition-all cursor-pointer shadow-2xs shrink-0"
              title="Google Play Health Points"
            >
              <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500 shrink-0" />
              <span>{userProfile.streakCount}d</span>
              <span className="hidden sm:inline">• {userProfile.xp} XP</span>
            </motion.button>

            {/* Language Selector Pill (Desktop) */}
            <div className="hidden lg:flex items-center gap-1 bg-slate-100 border border-slate-200 rounded-full px-2.5 py-1 text-xs shrink-0">
              <Globe className="w-3.5 h-3.5 text-emerald-700" />
              <select
                value={userProfile.language}
                onChange={(e) => onLanguageChange(e.target.value as LanguageCode)}
                className="bg-transparent text-slate-800 focus:outline-none cursor-pointer text-xs font-bold"
              >
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <option key={lang.code} value={lang.code} className="bg-white text-slate-900">
                    {lang.flag} {lang.code.toUpperCase()}
                  </option>
                ))}
              </select>
            </div>

            {/* Google Profile Avatar (Always permanently visible on the top right) */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.93 }}
              onClick={onOpenDrawer || onOpenAuthModal}
              className="relative p-0.5 rounded-full ring-2 ring-emerald-500 hover:ring-emerald-600 transition-all cursor-pointer shrink-0 ml-0.5"
              title={currentUser ? 'Pengaturan, Privasi, & Profil Google Health' : 'Menu Profil & Setelan'}
            >
              {currentUser?.photoURL ? (
                <img
                  src={currentUser.photoURL}
                  alt="Avatar"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-full object-cover shadow-2xs"
                />
              ) : (
                <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-gradient-to-br from-emerald-600 to-teal-700 text-white flex items-center justify-center font-black text-xs shadow-xs">
                  {userInitial}
                </div>
              )}
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-white rounded-full" />
            </motion.button>
          </div>
        </div>

        {/* BOTTOM ROW: Google Play Store Horizontal Category Tabs */}
        <div className="max-w-7xl mx-auto px-3 sm:px-6 overflow-x-auto no-scrollbar flex items-center justify-between gap-2 py-1.5 border-t border-slate-100 w-full max-w-full">
          <div className="flex items-center gap-1 sm:gap-1.5 min-w-max">
            {googlePlayTabs.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as TabType)}
                  className={`relative flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer select-none ${
                    isActive
                      ? 'text-emerald-950 font-black'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="active-googleplay-pill"
                      className="absolute inset-0 bg-emerald-100/90 border border-emerald-300 rounded-full shadow-2xs z-0"
                      transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                    />
                  )}

                  <Icon
                    className={`w-3.5 h-3.5 relative z-10 transition-colors ${
                      isActive ? 'text-emerald-700' : 'text-slate-500'
                    }`}
                  />
                  <span className="relative z-10">{item.label}</span>
                  {item.badge && !isActive && (
                    <span className="relative z-10 text-[9px] font-extrabold bg-emerald-600 text-white px-1.5 py-0.2 rounded-full shadow-2xs">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}

            {/* "Kategori Lain" Google Play Style Dropdown */}
            <div className="relative" ref={moreMenuRef}>
              <button
                onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)}
                className={`relative flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  isCurrentInSecondary
                    ? 'text-emerald-950 font-black bg-emerald-100/90 border border-emerald-300'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <span>{isIndonesian ? 'Kategori Lain' : 'Categories'}</span>
                <ChevronDown
                  className={`w-3 h-3 transition-transform duration-200 ${
                    isMoreMenuOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              <AnimatePresence>
                {isMoreMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 6, scale: 0.96 }}
                    transition={{ duration: 0.15, ease: 'easeOut' }}
                    className="absolute top-full left-0 mt-2 w-72 bg-white rounded-3xl border border-slate-200 shadow-xl p-2.5 z-50 space-y-1"
                  >
                    <div className="px-3 py-1.5 text-[10px] font-black text-slate-400 uppercase tracking-wider flex items-center justify-between">
                      <span>{isIndonesian ? 'Kategori & Alat Terintegrasi' : 'All Categories'}</span>
                      <Grid className="w-3.5 h-3.5 text-slate-400" />
                    </div>
                    {secondaryTabs.map((item) => {
                      const Icon = item.icon;
                      const isSelected = activeTab === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => {
                            setActiveTab(item.id as TabType);
                            setIsMoreMenuOpen(false);
                          }}
                          className={`w-full text-left p-2.5 rounded-2xl flex items-center justify-between gap-2.5 transition-colors cursor-pointer ${
                            isSelected
                              ? 'bg-emerald-50 border border-emerald-200 text-emerald-950 font-bold'
                              : 'hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <div
                              className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                                isSelected ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              <Icon className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="text-xs font-bold leading-tight">{item.label}</div>
                              <div className="text-[10px] text-slate-400 leading-tight mt-0.5">
                                {item.desc}
                              </div>
                            </div>
                          </div>
                          {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                        </button>
                      );
                    })}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </header>

      {/* Spotlight Command Modal */}
      <QuickCommandModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigateTab={setActiveTab}
        onSelectModule={(modId) => {
          if (onSelectSpecificModule) {
            onSelectSpecificModule(modId);
          } else {
            setActiveTab('modules_hub');
          }
        }}
        userProfile={userProfile}
      />
    </>
  );
};
