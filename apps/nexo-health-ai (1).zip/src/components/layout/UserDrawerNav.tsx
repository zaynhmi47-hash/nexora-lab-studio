import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Shield,
  CreditCard,
  Database,
  Globe,
  Settings as SettingsIcon,
  User,
  CheckCircle2,
  Lock,
  Download,
  Trash2,
  Plus,
  ArrowRight,
  Sparkles,
  Smartphone,
  ChevronRight,
  Flame,
  Award,
  LogOut,
  LogIn,
  Sliders,
  Check,
  RefreshCw,
  Bell,
  Heart,
  Volume2,
  FileText,
  KeyRound,
  Building2,
  Zap,
  TrendingUp,
  Tag
} from 'lucide-react';
import { UserProfile, DailyLog, LanguageCode, MealItem, ModularHealthDataEntry, SubscriptionPlanType } from '../../types';
import { SUPPORTED_LANGUAGES } from '../../data/translations';
import { TabType } from './NavBar';
import { User as FirebaseUser } from '../../lib/firebase';
import { FirestoreDataService } from '../../services/firestoreService';
import { SUBSCRIPTION_PLANS, getPlanDetails } from '../../data/subscriptionPlans';

interface UserDrawerNavProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  dailyLog: DailyLog;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
  onLanguageChange: (lang: LanguageCode) => void;
  currentUser: FirebaseUser | null;
  onOpenAuthModal: () => void;
  onSignOut: () => void;
  onNavigateTab: (tab: TabType) => void;
  loggedMeals?: MealItem[];
  modularLogs?: ModularHealthDataEntry[];
  onClearAllUserData: () => Promise<void>;
  onOpenUpgradeModal?: (plan?: SubscriptionPlanType) => void;
  onOpenBusinessHub?: () => void;
  onStartOnboarding?: () => void;
}

type DrawerSection = 'privacy' | 'payment' | 'data' | 'language' | 'settings';

export const UserDrawerNav: React.FC<UserDrawerNavProps> = ({
  isOpen,
  onClose,
  userProfile,
  dailyLog,
  onUpdateProfile,
  onLanguageChange,
  currentUser,
  onOpenAuthModal,
  onSignOut,
  onNavigateTab,
  loggedMeals = [],
  modularLogs = [],
  onClearAllUserData,
  onOpenUpgradeModal,
  onOpenBusinessHub,
  onStartOnboarding,
}) => {
  const isIndonesian = userProfile.language === 'id';
  const [activeSection, setActiveSection] = useState<DrawerSection>('privacy');
  const [isClearingData, setIsClearingData] = useState(false);
  const [showClearSuccess, setShowClearSuccess] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('gpay');
  const [isExporting, setIsExporting] = useState(false);

  const currentPlan = userProfile.subscriptionPlan || 'free';
  const planInfo = getPlanDetails(currentPlan);

  // Settings form state
  const [targetWater, setTargetWater] = useState(userProfile.dailyWaterTargetMl || 2500);
  const [targetCalories, setTargetCalories] = useState(userProfile.dailyCalorieTarget || 2000);
  const [targetSteps, setTargetSteps] = useState(userProfile.dailyStepsTarget || 8000);
  const [targetSleep, setTargetSleep] = useState(userProfile.dailySleepTargetHours || 8);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [savedSettingsMsg, setSavedSettingsMsg] = useState(false);

  const handleSaveSettings = () => {
    onUpdateProfile({
      dailyWaterTargetMl: Number(targetWater),
      dailyCalorieTarget: Number(targetCalories),
      dailyStepsTarget: Number(targetSteps),
      dailySleepTargetHours: Number(targetSleep),
    });
    setSavedSettingsMsg(true);
    setTimeout(() => setSavedSettingsMsg(false), 3000);
  };

  const handleExportData = () => {
    setIsExporting(true);
    const exportData = {
      userProfile,
      dailyLog,
      loggedMeals,
      modularLogs,
      exportedAt: new Date().toISOString(),
      platform: 'Google Health & Play AI Hub',
      encryptedChecksum: 'AES256-SHA256-VALIDATED',
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `GoogleHealth_Backup_${userProfile.name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setTimeout(() => setIsExporting(false), 800);
  };

  const handleClearDataConfirm = async () => {
    if (confirm(isIndonesian ? 'Hapus semua data kesehatan Anda secara permanen dari Cloud Firestore (Sesuai GDPR)?' : 'Permanently clear all your health data from Cloud Firestore (GDPR compliant)?')) {
      setIsClearingData(true);
      await onClearAllUserData();
      setIsClearingData(false);
      setShowClearSuccess(true);
      setTimeout(() => setShowClearSuccess(false), 4000);
    }
  };

  const menuItems: { id: DrawerSection; label: string; labelEn: string; icon: React.FC<{ className?: string }>; desc: string }[] = [
    {
      id: 'privacy',
      label: 'Privasi & Keamanan',
      labelEn: 'Privacy & Security',
      icon: Shield,
      desc: isIndonesian ? 'Enkripsi data medis, otorisasi & GDPR' : 'Medical encryption, RBAC & GDPR',
    },
    {
      id: 'payment',
      label: 'Metode Pembayaran & Paket',
      labelEn: 'Payment & Plans',
      icon: CreditCard,
      desc: isIndonesian ? 'Google Pay, QRIS, & paket bisnis' : 'Google Pay, QRIS, & business tiers',
    },
    {
      id: 'data',
      label: 'Manajemen Data',
      labelEn: 'Data Management',
      icon: Database,
      desc: isIndonesian ? 'Sinkronisasi cloud & ekspor riwayat' : 'Cloud sync & history export',
    },
    {
      id: 'language',
      label: 'Bahasa & Wilayah',
      labelEn: 'Language & Region',
      icon: Globe,
      desc: isIndonesian ? 'Pilihan bahasa antarmuka & satuan' : 'Interface language & units',
    },
    {
      id: 'settings',
      label: 'Setelan / Pengaturan',
      labelEn: 'Settings & Goals',
      icon: SettingsIcon,
      desc: isIndonesian ? 'Target harian, notifikasi & preferensi' : 'Daily goals, alerts & preferences',
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end" id="drawer-nav-bar-container">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity"
          />

          {/* Drawer Panel */}
          <motion.aside
            id="drawer-nav-bar"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 280 }}
            className="relative w-full max-w-md bg-white h-full shadow-2xl z-10 flex flex-col overflow-hidden border-l border-slate-200"
          >
            {/* Top Bar with User Profile Card */}
            <div className="p-5 sm:p-6 bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-white shrink-0 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex items-center justify-between relative z-10 mb-4">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    <Sparkles className="w-4 h-4" />
                  </span>
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                    Google Health Hub
                  </span>
                </div>
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Tutup"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* User Bio Header */}
              <div className="flex items-center gap-3.5 relative z-10">
                <div className="relative">
                  {currentUser?.photoURL ? (
                    <img
                      src={currentUser.photoURL}
                      alt="Avatar"
                      className="w-13 h-13 rounded-2xl object-cover ring-2 ring-emerald-400/80 shadow-md"
                    />
                  ) : (
                    <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white font-black text-lg ring-2 ring-emerald-400/80 shadow-md">
                      {userProfile.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                  <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-slate-900 rounded-full flex items-center justify-center" />
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="font-extrabold text-base text-white truncate flex items-center gap-1.5">
                    <span>{currentUser?.displayName || userProfile.name}</span>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  </h3>
                  <p className="text-xs text-slate-300 truncate">
                    {currentUser?.email || (isIndonesian ? 'Akun Tamu (Tersinkronisasi)' : 'Guest Mode (Synced)')}
                  </p>
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/20 text-[10px] font-black text-emerald-300 border border-emerald-500/30 uppercase tracking-wider">
                      {planInfo.badge}
                    </span>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/10 text-[11px] font-bold text-amber-300 border border-white/10">
                      <Flame className="w-3 h-3 text-amber-400 fill-amber-400" />
                      <span>{userProfile.streakCount} Hari</span>
                    </span>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/10 text-[11px] font-bold text-emerald-300 border border-white/10">
                      <Award className="w-3 h-3 text-emerald-400" />
                      <span>Lv. {userProfile.level}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Personal Health Profile Onboarding Button */}
              {onStartOnboarding && (
                <div className="mt-3.5 pt-3 border-t border-white/10">
                  <button
                    onClick={() => {
                      onClose();
                      onStartOnboarding();
                    }}
                    className="w-full py-2.5 px-3.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-white font-bold text-xs flex items-center justify-between cursor-pointer transition-all shadow-xs"
                  >
                    <div className="flex items-center gap-2">
                      <User className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{isIndonesian ? 'Personalisasi & Profil Onboarding AI' : 'Personalize & AI Health Profile'}</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>
                </div>
              )}

              {/* Fast Upgrade Banner inside Profile Header */}
              <div className="mt-2.5 pt-2.5 border-t border-white/10 flex items-center justify-between gap-2">
                <button
                  onClick={() => {
                    onClose();
                    if (onOpenUpgradeModal) onOpenUpgradeModal('business');
                  }}
                  className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isIndonesian ? 'Upgrade Paket Bisnis & Klinik' : 'Upgrade to Business Tier'}</span>
                </button>

                {currentUser ? (
                  <button
                    onClick={() => {
                      onSignOut();
                      onClose();
                    }}
                    className="p-2 text-rose-300 hover:text-rose-100 hover:bg-white/10 rounded-xl cursor-pointer transition-colors"
                    title={isIndonesian ? 'Keluar Akun' : 'Sign Out'}
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenAuthModal();
                    }}
                    className="p-2 text-emerald-300 hover:text-emerald-100 hover:bg-white/10 rounded-xl cursor-pointer transition-colors"
                    title={isIndonesian ? 'Masuk Akun Google' : 'Sign In'}
                  >
                    <LogIn className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Navigation Tabs Bar */}
            <div className="flex border-b border-slate-200 bg-slate-50/90 p-1.5 gap-1 overflow-x-auto no-scrollbar shrink-0">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveSection(item.id)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                      isActive
                        ? 'bg-white text-emerald-700 shadow-2xs border border-slate-200/80 font-black'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
                    <span>{isIndonesian ? item.label : item.labelEn}</span>
                  </button>
                );
              })}
            </div>

            {/* Main Content Area based on Selected Tab */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              {/* SECTION 1: PRIVASI & KEAMANAN */}
              {activeSection === 'privacy' && (
                <div className="space-y-4">
                  <div className="bg-emerald-50/80 border border-emerald-200/80 rounded-2xl p-4 space-y-2">
                    <div className="flex items-center gap-2 text-emerald-900 font-extrabold text-sm">
                      <Lock className="w-4 h-4 text-emerald-600" />
                      <span>{isIndonesian ? 'Enkripsi Medis AES-256 GCM' : 'AES-256 Medical Encryption'}</span>
                    </div>
                    <p className="text-xs text-emerald-800 leading-relaxed">
                      {isIndonesian
                        ? 'Semua data rekam medis elektronik, hasil laboratorium biomarker, dan log modul terlindungi dengan standar enkripsi end-to-end HIPAA & GDPR.'
                        : 'All electronic medical records, biomarker lab logs, and AI chats are protected under HIPAA & GDPR grade encryption.'}
                    </p>
                    <div className="flex items-center gap-2 pt-1 text-[11px] font-bold text-emerald-700">
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{isIndonesian ? 'Aturan Keamanan Firestore Aktif' : 'Firestore Security Rules Active'}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-xs font-black text-slate-500 uppercase tracking-wider">
                      {isIndonesian ? 'Kontrol Izin & Akses' : 'Permissions & Access'}
                    </h4>

                    <div className="bg-white border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Smartphone className="w-4 h-4 text-slate-500" />
                        <div>
                          <p className="text-xs font-bold text-slate-800">
                            {isIndonesian ? 'Akses Perangkat Wearable' : 'Wearable Sensor Access'}
                          </p>
                          <p className="text-[11px] text-slate-400">Detak jantung & jam tidur</p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-extrabold rounded-full">
                        {isIndonesian ? 'Diizinkan' : 'Granted'}
                      </span>
                    </div>

                    <div className="bg-white border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <KeyRound className="w-4 h-4 text-slate-500" />
                        <div>
                          <p className="text-xs font-bold text-slate-800">
                            {isIndonesian ? 'Isolasi Rekam Medis (RBAC)' : 'Medical Record Sandbox'}
                          </p>
                          <p className="text-[11px] text-slate-400">Hanya dapat diakses oleh UID Anda</p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-extrabold rounded-full">
                        {isIndonesian ? 'Terkunci' : 'Locked'}
                      </span>
                    </div>
                  </div>

                  {/* GDPR Right to Erasure */}
                  <div className="pt-3 border-t border-slate-200 space-y-2">
                    <h4 className="text-xs font-black text-rose-700 uppercase tracking-wider">
                      {isIndonesian ? 'Hak Privasi & Penghapusan Data (GDPR)' : 'GDPR Right to Erasure'}
                    </h4>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      {isIndonesian
                        ? 'Anda dapat menghapus seluruh riwayat aktivitas, jurnal gizi, dan catatan medis Anda dari server cloud tanpa sisa.'
                        : 'Permanently wipe your complete health footprint and logs from Cloud Firestore servers.'}
                    </p>
                    <button
                      onClick={handleClearDataConfirm}
                      disabled={isClearingData}
                      className="w-full py-2.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-800 text-xs font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                    >
                      <Trash2 className="w-4 h-4 text-rose-600" />
                      <span>{isClearingData ? (isIndonesian ? 'Menghapus...' : 'Clearing...') : (isIndonesian ? 'Bersihkan Semua Data Pribadi' : 'Erase All Personal Data')}</span>
                    </button>
                    {showClearSuccess && (
                      <p className="text-xs font-bold text-emerald-600 text-center">
                        ✓ {isIndonesian ? 'Semua data telah dibersihkan secara aman.' : 'All personal data cleared securely.'}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* SECTION 2: METODE PEMBAYARAN & PAKET BISNIS */}
              {activeSection === 'payment' && (
                <div className="space-y-4">
                  {/* Current Active Plan Card */}
                  <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-teal-950 text-white rounded-2xl p-4.5 space-y-3 shadow-md border border-slate-700">
                    <div className="flex items-center justify-between">
                      <span className="text-xs uppercase tracking-wider text-teal-300 font-bold flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                        <span>Google Health Tier</span>
                      </span>
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${planInfo.badgeColor}`}>
                        {planInfo.badge}
                      </span>
                    </div>

                    <div>
                      <p className="text-lg font-black tracking-tight text-white">{planInfo.name}</p>
                      <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                        {isIndonesian ? planInfo.description : planInfo.descriptionEn}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs text-slate-300">
                      <span>{isIndonesian ? 'Status Akses' : 'Access Status'}</span>
                      <span className="font-bold text-emerald-400">
                        {userProfile.subscriptionStatus === 'active' ? 'Aktif Penuh ✓' : 'Gratis'}
                      </span>
                    </div>

                    <div className="pt-1 flex items-center gap-2">
                      <button
                        onClick={() => {
                          onClose();
                          if (onOpenUpgradeModal) onOpenUpgradeModal();
                        }}
                        className="flex-1 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all"
                      >
                        <Tag className="w-3.5 h-3.5" />
                        <span>{isIndonesian ? 'Lihat Semua Paket & Fitur' : 'Explore All Tier Plans'}</span>
                      </button>

                      {(currentPlan === 'business' || currentPlan === 'enterprise') && (
                        <button
                          onClick={() => {
                            onClose();
                            if (onOpenBusinessHub) onOpenBusinessHub();
                          }}
                          className="py-2.5 px-3 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                        >
                          <Building2 className="w-3.5 h-3.5 text-teal-300" />
                          <span>Hub Klinik</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Pricing Overview Quick List */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-black text-slate-500 uppercase tracking-wider">
                        {isIndonesian ? 'Daftar Paket Langganan' : 'Subscription Packages'}
                      </h4>
                      <button
                        onClick={() => {
                          onClose();
                          if (onOpenUpgradeModal) onOpenUpgradeModal();
                        }}
                        className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
                      >
                        {isIndonesian ? 'Bandingkan Fitur →' : 'Compare Matrix →'}
                      </button>
                    </div>

                    <div className="grid grid-cols-1 gap-2">
                      {SUBSCRIPTION_PLANS.map((planItem) => {
                        const isCurrent = currentPlan === planItem.id;
                        return (
                          <div
                            key={planItem.id}
                            onClick={() => {
                              onClose();
                              if (onOpenUpgradeModal) onOpenUpgradeModal(planItem.id);
                            }}
                            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                              isCurrent
                                ? 'bg-emerald-50/50 border-emerald-500 ring-1 ring-emerald-500'
                                : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs'
                            }`}
                          >
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2">
                                <p className="text-xs font-black text-slate-900">{planItem.name}</p>
                                {planItem.isPopular && (
                                  <span className="px-1.5 py-0.2 rounded-md bg-emerald-500 text-white font-black text-[9px] uppercase">
                                    PRO
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-500 line-clamp-1">{planItem.tagline}</p>
                            </div>

                            <div className="text-right shrink-0">
                              <p className="text-xs font-black text-slate-900">
                                {planItem.priceMonthlyIdr === 0 ? 'Gratis' : `Rp ${planItem.priceMonthlyIdr.toLocaleString('id-ID')}`}
                              </p>
                              <span className="text-[10px] text-slate-400 font-medium">
                                {planItem.priceMonthlyIdr === 0 ? 'Selamanya' : '/ bulan'}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Payment Gateway Options */}
                  <div className="space-y-2 pt-2 border-t border-slate-200">
                    <h4 className="text-xs font-black text-slate-500 uppercase tracking-wider">
                      {isIndonesian ? 'Metode Pembayaran Tersimpan' : 'Saved Payment Options'}
                    </h4>

                    {/* Google Pay */}
                    <div
                      onClick={() => setSelectedPaymentMethod('gpay')}
                      className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                        selectedPaymentMethod === 'gpay'
                          ? 'border-emerald-500 bg-emerald-50/50 ring-1 ring-emerald-500'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-slate-900 text-white font-black text-xs flex items-center justify-center">
                          GPay
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-800">Google Pay / Play Balance</p>
                          <p className="text-[11px] text-slate-500">{currentUser?.email || 'zayn.hmi47@gmail.com'}</p>
                        </div>
                      </div>
                      {selectedPaymentMethod === 'gpay' && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      )}
                    </div>

                    {/* QRIS */}
                    <div
                      onClick={() => setSelectedPaymentMethod('qris')}
                      className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                        selectedPaymentMethod === 'qris'
                          ? 'border-emerald-500 bg-emerald-50/50 ring-1 ring-emerald-500'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-rose-600 text-white font-black text-[10px] flex items-center justify-center">
                          QRIS
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-800">QRIS Instan (BCA, Mandiri, GoPay, OVO)</p>
                          <p className="text-[11px] text-slate-500">Bebas biaya admin transfer</p>
                        </div>
                      </div>
                      {selectedPaymentMethod === 'qris' && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      )}
                    </div>

                    {/* Credit Card */}
                    <div
                      onClick={() => setSelectedPaymentMethod('card')}
                      className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                        selectedPaymentMethod === 'card'
                          ? 'border-emerald-500 bg-emerald-50/50 ring-1 ring-emerald-500'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-blue-600 text-white font-black text-[10px] flex items-center justify-center">
                          VISA
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-800">Mastercard / Visa Card</p>
                          <p className="text-[11px] text-slate-500">•••• •••• •••• 4421</p>
                        </div>
                      </div>
                      {selectedPaymentMethod === 'card' && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* SECTION 3: MANAJEMEN DATA */}
              {activeSection === 'data' && (
                <div className="space-y-4">
                  <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Database className="w-4 h-4 text-emerald-600" />
                        <h4 className="text-xs font-bold text-slate-900">
                          {isIndonesian ? 'Status Sinkronisasi Cloud Firestore' : 'Cloud Firestore Sync'}
                        </h4>
                      </div>
                      <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                        <span>Online</span>
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-center pt-1">
                      <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                        <p className="text-[10px] text-slate-500 font-bold uppercase">{isIndonesian ? 'Log 20 Modul' : 'Modular Logs'}</p>
                        <p className="text-base font-extrabold text-slate-900">{modularLogs.length}</p>
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                        <p className="text-[10px] text-slate-500 font-bold uppercase">{isIndonesian ? 'Menu Makanan' : 'Meals Logged'}</p>
                        <p className="text-base font-extrabold text-slate-900">{loggedMeals.length}</p>
                      </div>
                    </div>
                  </div>

                  {/* Export and Backup */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-black text-slate-500 uppercase tracking-wider">
                      {isIndonesian ? 'Cadangkan & Ekspor' : 'Backup & Export'}
                    </h4>

                    <button
                      onClick={handleExportData}
                      disabled={isExporting}
                      className="w-full p-3.5 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-left cursor-pointer transition-all shadow-2xs group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg group-hover:bg-emerald-100">
                          <Download className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-900">
                            {isIndonesian ? 'Unduh Format JSON Lengkap' : 'Download Complete JSON'}
                          </p>
                          <p className="text-[11px] text-slate-500">
                            {isIndonesian ? 'Cocok untuk cadangan dan analisis mandiri' : 'Full backup containing all modules & logs'}
                          </p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700" />
                    </button>
                  </div>
                </div>
              )}

              {/* SECTION 4: BAHASA & WILAYAH */}
              {activeSection === 'language' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="text-xs font-black text-slate-500 uppercase tracking-wider">
                      {isIndonesian ? 'Pilih Bahasa Tampilan' : 'Choose App Language'}
                    </h4>

                    <div className="grid grid-cols-1 gap-2">
                      {SUPPORTED_LANGUAGES.map((lang) => (
                        <div
                          key={lang.code}
                          onClick={() => onLanguageChange(lang.code)}
                          className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                            userProfile.language === lang.code
                              ? 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500 font-bold'
                              : 'border-slate-200 bg-white hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-xl">{lang.flag}</span>
                            <div>
                              <p className="text-xs text-slate-900 font-bold">{lang.name}</p>
                              <p className="text-[10px] text-slate-400 font-mono uppercase">{lang.code}</p>
                            </div>
                          </div>
                          {userProfile.language === lang.code && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* SECTION 5: SETELAN TARGET HARIAN */}
              {activeSection === 'settings' && (
                <div className="space-y-4">
                  <div className="space-y-3 bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
                    <h4 className="text-xs font-black text-slate-500 uppercase tracking-wider">
                      {isIndonesian ? 'Target Harian Utama' : 'Daily Core Targets'}
                    </h4>

                    <div className="space-y-2.5 text-xs">
                      <div>
                        <label className="text-slate-700 font-bold block mb-1">
                          {isIndonesian ? 'Target Air Minum (ml)' : 'Daily Water Target (ml)'}
                        </label>
                        <input
                          type="number"
                          value={targetWater}
                          onChange={(e) => setTargetWater(Number(e.target.value))}
                          className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        />
                      </div>

                      <div>
                        <label className="text-slate-700 font-bold block mb-1">
                          {isIndonesian ? 'Target Kalori Harian (kkal)' : 'Daily Calorie Target (kcal)'}
                        </label>
                        <input
                          type="number"
                          value={targetCalories}
                          onChange={(e) => setTargetCalories(Number(e.target.value))}
                          className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        />
                      </div>

                      <div>
                        <label className="text-slate-700 font-bold block mb-1">
                          {isIndonesian ? 'Target Langkah Kaki' : 'Daily Steps Goal'}
                        </label>
                        <input
                          type="number"
                          value={targetSteps}
                          onChange={(e) => setTargetSteps(Number(e.target.value))}
                          className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        />
                      </div>

                      <div>
                        <label className="text-slate-700 font-bold block mb-1">
                          {isIndonesian ? 'Target Jam Tidur (Jam)' : 'Sleep Goal (Hours)'}
                        </label>
                        <input
                          type="number"
                          value={targetSleep}
                          onChange={(e) => setTargetSleep(Number(e.target.value))}
                          className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                        />
                      </div>
                    </div>

                    <button
                      onClick={handleSaveSettings}
                      className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs transition-all"
                    >
                      <Check className="w-4 h-4" />
                      <span>{isIndonesian ? 'Simpan Target Harian' : 'Save Goals'}</span>
                    </button>

                    {savedSettingsMsg && (
                      <p className="text-xs font-bold text-emerald-600 text-center">
                        ✓ {isIndonesian ? 'Target berhasil disimpan ke profil cloud!' : 'Goals updated successfully!'}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Version Info */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-[10px] text-slate-400 font-medium shrink-0">
              Google Health & Play AI Hub v2.5.0 • Enkripsi Firestore Terverifikasi
            </div>
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
};
