import React from 'react';
import {
  HeartPulse,
  Sparkles,
  ShieldCheck,
  Zap,
  Activity,
  Layers,
  ArrowUpRight,
  Database,
  Moon,
  Wind,
  Brain,
  Award,
} from 'lucide-react';
import { TabType } from './NavBar';
import { UserProfile } from '../../types';

interface FooterProps {
  onNavigateTab: (tab: TabType) => void;
  onOpenDrawer?: () => void;
  userProfile: UserProfile;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigateTab,
  onOpenDrawer,
  userProfile,
}) => {
  const isIndonesian = userProfile.language === 'id';

  return (
    <footer className="mt-16 bg-white border-t border-slate-200/80 text-slate-600 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-100">
          {/* Brand & Mission */}
          <div className="md:col-span-1 space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 flex items-center justify-center text-white shadow-sm shadow-emerald-600/20">
                <HeartPulse className="w-4 h-4" />
              </div>
              <span className="font-extrabold text-slate-900 text-base tracking-tight">
                AI HealthMate
              </span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              {isIndonesian
                ? 'Platform kesehatan preventif dan performa atletik holistik yang mengintegrasikan 20 modul kecerdasan buatan dalam satu ekosistem otonom.'
                : 'Holistic preventive health & athletic performance platform integrating 20 AI modules in one autonomous ecosystem.'}
            </p>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-[11px] font-bold border border-emerald-200/70">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Gemini AI Engine: Aktif & Siap</span>
            </div>
          </div>

          {/* Quick Categories Navigation */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
              {isIndonesian ? 'Pilar Modul Utama' : 'Core Module Pillars'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigateTab('doctor_consultation')}
                  className="hover:text-emerald-700 transition-colors flex items-center gap-1.5 cursor-pointer font-bold text-emerald-800"
                >
                  <span>🩺 Konsultasi Dokter AI (Baru)</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('workout')}
                  className="hover:text-emerald-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <span>1. AI Adaptive Trainer & Sport</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('form_guard')}
                  className="hover:text-emerald-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <span>2. FormGuard Biomekanik CV</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('nutrition')}
                  className="hover:text-emerald-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <span>3. NutriGenius & Vision Scanner</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('recovery')}
                  className="hover:text-emerald-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <span>4. Active Recovery Lab & HRV</span>
                </button>
              </li>
            </ul>
          </div>

          {/* AI Tools & Features */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
              {isIndonesian ? 'Eksplorasi Fitur' : 'Features & Tools'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigateTab('modules_hub')}
                  className="hover:text-emerald-700 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Layers className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isIndonesian ? 'Katalog 20 Modul Lengkap' : 'All 20 Health Modules'}</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('dashboard')}
                  className="hover:text-emerald-700 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Activity className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isIndonesian ? 'Dasbor Pemantauan Real-time' : 'Real-time Daily Dashboard'}</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('gamification')}
                  className="hover:text-emerald-700 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Award className="w-3.5 h-3.5 text-amber-500" />
                  <span>{isIndonesian ? 'Sistem XP & Streak Harian' : 'Gamification & Daily Streaks'}</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateTab('firestore')}
                  className="hover:text-emerald-700 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Database className="w-3.5 h-3.5 text-indigo-500" />
                  <span>{isIndonesian ? 'Arsitektur Data & Keamanan' : 'Cloud DB & Privacy'}</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Privacy & Security Standard */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
              {isIndonesian ? 'Keamanan & Privasi' : 'Security & Privacy'}
            </h4>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 text-xs space-y-2">
              <div className="flex items-center gap-1.5 font-bold text-slate-900">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Privasi Data Medis</span>
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                {isIndonesian
                  ? 'Data kesehatan dan log makanan disimpan secara privat dengan enkripsi Firestore & otentikasi aman.'
                  : 'Health telemetry and dietary logs are privately stored with Firestore security rules.'}
              </p>
            </div>
          </div>
        </div>

        {/* Bottom copyright and drawer shortcut */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>© 2026 AI HealthMate. Ditenagai oleh Gemini AI & Cloud Firestore.</p>
          {onOpenDrawer && (
            <button
              onClick={onOpenDrawer}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
            >
              <span>{isIndonesian ? 'Buka Menu Lengkap 20 Modul' : 'Open 20 Modules Drawer'}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </footer>
  );
};
