import React from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  Activity,
  Utensils,
  Dumbbell,
  Award,
  Database,
  Layers,
  Stethoscope,
  Bot,
  User as UserIcon,
} from 'lucide-react';
import { UserProfile } from '../../types';
import { getTranslation } from '../../data/translations';

export type TabType =
  | 'landing'
  | 'coach'
  | 'health'
  | 'body_ai'
  | 'doctor_consultation'
  | 'modules_hub'
  | 'dashboard'
  | 'nutrition'
  | 'workout'
  | 'form_guard'
  | 'recovery'
  | 'sport'
  | 'posture'
  | 'smart_hydration'
  | 'supplement_manager'
  | 'mindful_eating'
  | 'cbt_therapy'
  | 'emotion_stress'
  | 'adaptive_meditation'
  | 'mental_resilience'
  | 'sleep_rituals'
  | 'ehr'
  | 'vitals_wearables'
  | 'longevity_bioage'
  | 'hormonal_health'
  | 'gamification'
  | 'business_hub'
  | 'pricing'
  | 'firestore';

interface NavBarProps {
  userProfile: UserProfile;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  onOpenDrawer?: () => void;
}

export const NavBar: React.FC<NavBarProps> = ({
  userProfile,
  activeTab,
  setActiveTab,
  onOpenDrawer,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const navItems = [
    {
      id: 'landing',
      label: isIndonesian ? 'Untuk Anda' : 'For You',
      icon: Sparkles,
      highlight: false,
    },
    {
      id: 'coach',
      label: isIndonesian ? 'AI Coach' : 'AI Coach',
      icon: Bot,
      highlight: true,
      badge: 'Gemini 3',
    },
    {
      id: 'health',
      label: isIndonesian ? 'Health Intelligence' : 'Health AI',
      icon: Sparkles,
      highlight: true,
      badge: 'Step 6',
    },
    {
      id: 'doctor_consultation',
      label: isIndonesian ? 'Dokter AI' : 'AI Doctor',
      icon: Stethoscope,
      highlight: false,
    },

    {
      id: 'dashboard',
      label: isIndonesian ? 'Health Connect' : 'Health Connect',
      icon: Activity,
      highlight: false,
    },
    {
      id: 'nutrition',
      label: isIndonesian ? 'Gizi & Vision' : 'AI Nutrition',
      icon: Utensils,
      highlight: false,
    },
    {
      id: 'workout',
      label: isIndonesian ? 'Latihan AI' : 'Workouts',
      icon: Dumbbell,
      highlight: false,
    },
    {
      id: 'modules_hub',
      label: isIndonesian ? 'Peringkat Teratas (20)' : 'Top Charts (20)',
      icon: Layers,
      highlight: false,
    },
    {
      id: 'gamification',
      label: isIndonesian ? 'Play Points & XP' : 'Play Points & XP',
      icon: Award,
      highlight: false,
    },
    {
      id: 'firestore',
      label: 'Cloud DB',
      icon: Database,
      highlight: false,
    },
  ] as const;

  return (
    <nav className="sticky top-[53px] z-30 bg-white/95 backdrop-blur-xl border-b border-slate-200 py-1.5 px-3 sm:px-4 shadow-2xs transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2.5">
        {onOpenDrawer && (
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onOpenDrawer}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 text-xs font-bold transition-colors shrink-0 cursor-pointer shadow-2xs"
            title={isIndonesian ? 'Buka Drawer Menu' : 'Open Drawer'}
          >
            <UserIcon className="w-3.5 h-3.5 text-emerald-700" />
            <span className="hidden sm:inline">{isIndonesian ? 'Koleksi Modul' : 'Modules'}</span>
          </motion.button>
        )}

        <div className="flex items-center overflow-x-auto no-scrollbar gap-1.5 scrollbar-none flex-1 relative">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <motion.button
                key={item.id}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveTab(item.id as TabType)}
                className={`relative flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap cursor-pointer transition-all ${
                  isActive
                    ? 'text-emerald-950 font-black'
                    : item.highlight
                    ? 'text-emerald-800 bg-emerald-50 border border-emerald-300 hover:bg-emerald-100'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 bg-slate-50 border border-slate-200'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="active-googleplay-tab-pill"
                    className="absolute inset-0 bg-emerald-100 border border-emerald-300 rounded-full shadow-2xs z-0"
                    transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                  />
                )}
                <Icon
                  className={`w-3.5 h-3.5 relative z-10 ${
                    isActive ? 'text-emerald-700' : item.highlight ? 'text-emerald-600 animate-pulse' : 'text-slate-500'
                  }`}
                />
                <span className="relative z-10">{item.label}</span>
                {item.highlight && !isActive && (
                  <span className="relative z-10 text-[9px] font-extrabold bg-emerald-600 text-white px-1.5 py-0.2 rounded-full">
                    Baru
                  </span>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
