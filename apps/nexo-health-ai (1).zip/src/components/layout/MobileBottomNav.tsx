import React from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  Layers,
  Activity,
  Utensils,
  Dumbbell,
  Stethoscope,
  Bot,
} from 'lucide-react';
import { UserProfile } from '../../types';
import { getTranslation } from '../../data/translations';
import { TabType } from './NavBar';

interface MobileBottomNavProps {
  userProfile: UserProfile;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  userProfile,
  activeTab,
  setActiveTab,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const leftNavItems = [
    {
      id: 'landing',
      label: isIndonesian ? 'Beranda' : 'Home',
      icon: Sparkles,
    },
    {
      id: 'coach',
      label: isIndonesian ? 'AI Coach' : 'AI Coach',
      icon: Bot,
    },
  ] as const;

  const rightNavItems = [
    {
      id: 'health',
      label: isIndonesian ? 'Health AI' : 'Health AI',
      icon: Sparkles,
    },
    {
      id: 'nutrition',
      label: isIndonesian ? 'Gizi AI' : 'Nutrition',
      icon: Utensils,
    },
  ] as const;


  const isHubActive = activeTab === 'modules_hub';

  return (
    <div className="lg:hidden fixed bottom-3 left-0 right-0 z-40 px-3 pointer-events-none flex justify-center">
      <motion.nav
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
        className="pointer-events-auto w-full max-w-md bg-white/95 backdrop-blur-2xl border border-slate-200/90 rounded-full px-2 py-1.5 shadow-2xl shadow-slate-900/15 flex items-center justify-between gap-1"
      >
        {/* Left Items */}
        {leftNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <motion.button
              key={item.id}
              whileTap={{ scale: 0.9 }}
              onClick={() => setActiveTab(item.id as TabType)}
              className={`relative flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-full cursor-pointer transition-colors ${
                isActive ? 'text-emerald-950 font-black' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="active-googleplay-mobilenav"
                  className="absolute inset-0 bg-emerald-100 border border-emerald-300 rounded-full z-0"
                  transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                />
              )}
              <Icon
                className={`w-4 h-4 relative z-10 transition-transform ${
                  isActive ? 'text-emerald-700 scale-110' : 'text-slate-400'
                }`}
              />
              <span className="text-[10px] tracking-tight leading-tight mt-0.5 whitespace-nowrap relative z-10 font-bold">
                {item.label}
              </span>
            </motion.button>
          );
        })}

        {/* Center Floating Action Button: Google Play Top Charts (20 Modules) */}
        <div className="relative -top-2 px-1">
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => setActiveTab('modules_hub')}
            className={`w-12 h-12 rounded-full flex flex-col items-center justify-center text-white shadow-lg transition-all cursor-pointer ${
              isHubActive
                ? 'bg-gradient-to-tr from-emerald-600 to-teal-500 ring-4 ring-emerald-500/25 shadow-emerald-600/40'
                : 'bg-gradient-to-tr from-slate-900 to-emerald-900 shadow-slate-900/30'
            }`}
            title="Pusat 20 Modul AI"
          >
            <Layers className="w-4 h-4" />
            <span className="text-[8px] font-black uppercase tracking-wider mt-0.5">
              20 Modul
            </span>
          </motion.button>
        </div>

        {/* Right Items */}
        {rightNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <motion.button
              key={item.id}
              whileTap={{ scale: 0.9 }}
              onClick={() => setActiveTab(item.id as TabType)}
              className={`relative flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-full cursor-pointer transition-colors ${
                isActive ? 'text-emerald-950 font-black' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="active-googleplay-mobilenav"
                  className="absolute inset-0 bg-emerald-100 border border-emerald-300 rounded-full z-0"
                  transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                />
              )}
              <Icon
                className={`w-4 h-4 relative z-10 transition-transform ${
                  isActive ? 'text-emerald-700 scale-110' : 'text-slate-400'
                }`}
              />
              <span className="text-[10px] tracking-tight leading-tight mt-0.5 whitespace-nowrap relative z-10 font-bold">
                {item.label}
              </span>
            </motion.button>
          );
        })}
      </motion.nav>
    </div>
  );
};
