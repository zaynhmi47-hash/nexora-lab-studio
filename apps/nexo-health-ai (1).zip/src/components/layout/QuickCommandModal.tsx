import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Sparkles,
  Layers,
  Activity,
  Utensils,
  Dumbbell,
  Camera,
  HeartPulse,
  Trophy,
  Award,
  Database,
  ArrowRight,
  X,
  Flame,
  Brain,
  Wind,
  Moon,
  Heart,
  Droplets,
  Clock,
  ShieldCheck,
  Stethoscope,
} from 'lucide-react';
import { TabType } from './NavBar';
import { HealthModuleId, UserProfile } from '../../types';
import { HEALTH_MODULES } from '../../data/healthModulesData';

interface QuickCommandModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab: (tab: TabType) => void;
  onSelectModule: (moduleId: HealthModuleId) => void;
  userProfile: UserProfile;
}

export const QuickCommandModal: React.FC<QuickCommandModalProps> = ({
  isOpen,
  onClose,
  onNavigateTab,
  onSelectModule,
  userProfile,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const isIndonesian = userProfile.language === 'id';

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const quickShortcuts = [
    {
      id: 'dashboard',
      title: isIndonesian ? 'Dasbor Harian' : 'Daily Dashboard',
      subtitle: isIndonesian ? 'Lihat ringkasan kalori, air & nutrisi' : 'View calories, hydration & logs',
      icon: Activity,
      action: () => {
        onNavigateTab('dashboard');
        onClose();
      },
      badge: 'Utama',
    },
    {
      id: 'nutrition',
      title: isIndonesian ? 'Scan Makanan AI Vision' : 'AI Food Scanner',
      subtitle: isIndonesian ? 'Analisis foto makanan & hitung makro otomatis' : 'Scan meal photo for instant macros',
      icon: Utensils,
      action: () => {
        onNavigateTab('nutrition');
        onClose();
      },
      badge: 'Vision AI',
    },
    {
      id: 'workout',
      title: isIndonesian ? 'Generator Latihan AI' : 'Adaptive Workout',
      subtitle: isIndonesian ? 'Program latihan sesuai kesiapan tubuh' : 'Personalized training routine',
      icon: Dumbbell,
      action: () => {
        onNavigateTab('workout');
        onClose();
      },
      badge: 'Trainer AI',
    },
    {
      id: 'form_guard',
      title: isIndonesian ? 'FormGuard CV (Analisis Gerakan)' : 'FormGuard CV Camera',
      subtitle: isIndonesian ? 'Deteksi sudut biomekanik & koreksi postur' : 'Real-time biomechanics analysis',
      icon: Camera,
      action: () => {
        onNavigateTab('form_guard');
        onClose();
      },
      badge: 'Camera CV',
    },
    {
      id: 'recovery',
      title: isIndonesian ? 'Recovery Lab & HRV' : 'Active Recovery Lab',
      subtitle: isIndonesian ? 'Protokol pemulihan otot & relaksasi' : 'Muscle recovery & nervous system protocols',
      icon: HeartPulse,
      action: () => {
        onNavigateTab('recovery');
        onClose();
      },
      badge: 'Recovery',
    },
  ];

  const filteredModules = HEALTH_MODULES.filter((m) => {
    const q = query.toLowerCase();
    return (
      m.title.toLowerCase().includes(q) ||
      m.titleEn.toLowerCase().includes(q) ||
      m.shortDesc.toLowerCase().includes(q) ||
      m.categoryName.toLowerCase().includes(q) ||
      m.tag.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-14 sm:pt-20 px-4 bg-slate-950/60 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Header */}
        <div className="p-4 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
          <div className="w-9 h-9 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <Search className="w-5 h-5" />
          </div>
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={
              isIndonesian
                ? 'Ketik fitur, modul (1-20), atau aksi cepat (misal: CBT, Sleep, Latihan)...'
                : 'Search any feature, 20 AI modules, or action...'
            }
            className="flex-1 bg-transparent text-sm font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2.5 py-1 rounded-xl bg-slate-200/70 text-slate-600 text-xs font-bold hover:bg-slate-300 transition-colors cursor-pointer"
          >
            ESC
          </button>
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {!query && (
            <div>
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2.5 px-1">
                {isIndonesian ? 'Akses Cepat Utama' : 'Quick Actions'}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {quickShortcuts.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={item.action}
                      className="text-left p-3 rounded-2xl border border-slate-200/80 hover:border-emerald-400 hover:bg-emerald-50/40 transition-all flex items-center justify-between group cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-950">
                            {item.title}
                          </div>
                          <div className="text-[10px] text-slate-500 line-clamp-1">
                            {item.subtitle}
                          </div>
                        </div>
                      </div>
                      <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200 shrink-0">
                        {item.badge}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div>
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2.5 px-1 flex items-center justify-between">
              <span>{isIndonesian ? '20 Modul Ekosistem AI' : '20 AI Health Modules'}</span>
              <span className="text-[10px] font-medium text-emerald-700">
                {filteredModules.length} {isIndonesian ? 'Tersedia' : 'Available'}
              </span>
            </div>

            <div className="space-y-1.5">
              {filteredModules.map((mod) => (
                <button
                  key={mod.id}
                  onClick={() => {
                    onSelectModule(mod.id);
                    onClose();
                  }}
                  className="w-full text-left p-2.5 sm:p-3 rounded-2xl border border-slate-200/70 hover:border-emerald-400 hover:bg-emerald-50/50 transition-all flex items-center justify-between gap-3 group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-lg bg-slate-100 text-slate-800 text-xs font-black flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                      {mod.moduleNumber}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-extrabold text-slate-900 group-hover:text-emerald-950">
                          {isIndonesian ? mod.title : mod.titleEn}
                        </span>
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                          {mod.categoryName}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                        {isIndonesian ? mod.shortDesc : mod.shortDescEn}
                      </p>
                    </div>
                  </div>

                  <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-emerald-600 group-hover:translate-x-1 transition-all shrink-0" />
                </button>
              ))}

              {filteredModules.length === 0 && (
                <div className="p-8 text-center text-slate-400 text-xs">
                  Tidak ada modul yang cocok dengan pencarian &quot;{query}&quot;.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 border-t border-slate-100 bg-slate-50 text-[11px] text-slate-500 flex items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>Ekosistem AI HealthMate Terintegrasi</span>
          </div>
          <span className="hidden sm:inline font-mono text-[10px] text-slate-400">
            Gunakan tombol ⌘K atau klik tombol Cari
          </span>
        </div>
      </div>
    </div>
  );
};
