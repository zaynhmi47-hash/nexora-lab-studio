import React, { useState, useEffect } from 'react';
import { Globe, Sparkles, X } from 'lucide-react';
import { LanguageCode } from '../../types';
import { SUPPORTED_LANGUAGES } from '../../data/translations';

interface AutoLocalizationBannerProps {
  currentLanguage: LanguageCode;
  onSelectLanguage: (lang: LanguageCode) => void;
}

export const AutoLocalizationBanner: React.FC<AutoLocalizationBannerProps> = ({
  currentLanguage,
  onSelectLanguage,
}) => {
  const [detectedLanguage, setDetectedLanguage] = useState<string>('English');
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    // Detect system browser language
    const navLang = navigator.language || 'en';
    if (navLang.startsWith('id')) setDetectedLanguage('Bahasa Indonesia (🇮🇩)');
    else if (navLang.startsWith('ja')) setDetectedLanguage('Japanese (🇯🇵)');
    else if (navLang.startsWith('pt')) setDetectedLanguage('Portuguese (🇧🇷)');
    else if (navLang.startsWith('es')) setDetectedLanguage('Spanish (🇪🇸)');
    else if (navLang.startsWith('de')) setDetectedLanguage('German (🇩🇪)');
    else if (navLang.startsWith('fr')) setDetectedLanguage('French (🇫🇷)');
    else if (navLang.startsWith('ar')) setDetectedLanguage('Arabic (🇸🇦)');
    else setDetectedLanguage('English (🇺🇸)');
  }, []);

  if (!visible) return null;

  return (
    <div className="bg-emerald-50/90 border-b border-emerald-100 text-xs px-3 sm:px-4 py-1.5 text-slate-700 w-full max-w-full overflow-hidden">
      <div className="max-w-7xl mx-auto w-full flex flex-col sm:flex-row items-center justify-between gap-1.5 sm:gap-2">
        <div className="flex items-center gap-2 min-w-0 max-w-full overflow-hidden">
          <span className="p-1 rounded-md bg-emerald-100 text-emerald-800 shrink-0">
            <Globe className="w-3.5 h-3.5" />
          </span>
          <span className="text-[11px] sm:text-xs truncate">
            <strong>Auto-Localization:</strong> Sistem mendeteksi:{' '}
            <span className="text-emerald-800 font-bold">{detectedLanguage}</span>
          </span>
          <span className="hidden md:inline text-emerald-200">|</span>
          <span className="hidden md:flex items-center gap-1 text-emerald-800 font-semibold text-[11px]">
            <Sparkles className="w-3 h-3 text-emerald-600" />
            <span>Gemini AI Dynamic Translation</span>
          </span>
        </div>

        <div className="flex items-center justify-between sm:justify-end gap-2 w-full sm:w-auto shrink-0">
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
            {SUPPORTED_LANGUAGES.slice(0, 4).map((lang) => (
              <button
                key={lang.code}
                onClick={() => onSelectLanguage(lang.code)}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer whitespace-nowrap ${
                  currentLanguage === lang.code
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-white text-slate-700 hover:bg-emerald-100/70 border border-slate-200/80'
                }`}
              >
                {lang.flag} {lang.code.toUpperCase()}
              </button>
            ))}
          </div>
          <button
            onClick={() => setVisible(false)}
            className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer shrink-0"
            title="Tutup Banner"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
