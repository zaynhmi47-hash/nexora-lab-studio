import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Search,
  Sparkles,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Star,
  Layers,
  Zap,
  Activity,
  Dumbbell,
  Camera,
  HeartPulse,
  Trophy,
  UserCheck,
  UtensilsCrossed,
  Scan,
  Droplets,
  Pill,
  Sparkle,
  MessageSquareHeart,
  Compass,
  Wind,
  Shield,
  Moon,
  Stethoscope,
  FileText,
  Heart,
  Sliders,
  CheckCircle2,
  Eye,
  X,
  Flame,
  Bookmark,
  Clock,
  Cpu,
  Check,
  Share2,
  TrendingUp,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { HealthModuleMetadata } from '../../types';
import { HEALTH_MODULES } from '../../data/healthModulesData';

interface GroupedModuleCarouselProps {
  onSelectModule: (module: HealthModuleMetadata) => void;
  isIndonesian?: boolean;
}

// Helper for Icon rendering
const getModuleIcon = (iconName: string) => {
  switch (iconName) {
    case 'Dumbbell': return Dumbbell;
    case 'Camera': return Camera;
    case 'HeartPulse': return HeartPulse;
    case 'Trophy': return Trophy;
    case 'UserCheck': return UserCheck;
    case 'UtensilsCrossed': return UtensilsCrossed;
    case 'Scan': return Scan;
    case 'Droplets': return Droplets;
    case 'Pill': return Pill;
    case 'Sparkle': return Sparkle;
    case 'MessageSquareHeart': return MessageSquareHeart;
    case 'Compass': return Compass;
    case 'Wind': return Wind;
    case 'Shield': return Shield;
    case 'Moon': return Moon;
    case 'Stethoscope': return Stethoscope;
    case 'FileText': return FileText;
    case 'Activity': return Activity;
    case 'Sparkles': return Sparkles;
    case 'Heart': return Heart;
    default: return Activity;
  }
};

// Category Color Scheme helper
const getCategoryStyles = (category: string) => {
  switch (category) {
    case 'sport_physical':
      return {
        pill: 'bg-emerald-100 text-emerald-900 border-emerald-300',
        iconBg: 'bg-emerald-600 text-white',
        borderHover: 'hover:border-emerald-400',
        gradientBg: 'from-emerald-500 to-teal-400',
        headerBg: 'bg-emerald-900 text-white',
        accentText: 'text-emerald-700',
        btnBg: 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20',
        cardBg: 'bg-emerald-50/30',
        dotActive: 'bg-emerald-600',
        statPill: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      };
    case 'nutrition_metabolism':
      return {
        pill: 'bg-teal-100 text-teal-900 border-teal-300',
        iconBg: 'bg-teal-600 text-white',
        borderHover: 'hover:border-teal-400',
        gradientBg: 'from-teal-500 to-cyan-400',
        headerBg: 'bg-teal-950 text-white',
        accentText: 'text-teal-700',
        btnBg: 'bg-teal-600 hover:bg-teal-700 text-white shadow-teal-600/20',
        cardBg: 'bg-teal-50/30',
        dotActive: 'bg-teal-600',
        statPill: 'bg-teal-50 text-teal-800 border-teal-200',
      };
    case 'mental_emotional':
      return {
        pill: 'bg-indigo-100 text-indigo-900 border-indigo-300',
        iconBg: 'bg-indigo-600 text-white',
        borderHover: 'hover:border-indigo-400',
        gradientBg: 'from-indigo-500 to-purple-400',
        headerBg: 'bg-indigo-950 text-white',
        accentText: 'text-indigo-700',
        btnBg: 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-600/20',
        cardBg: 'bg-indigo-50/30',
        dotActive: 'bg-indigo-600',
        statPill: 'bg-indigo-50 text-indigo-800 border-indigo-200',
      };
    case 'preventive_medical':
      return {
        pill: 'bg-rose-100 text-rose-900 border-rose-300',
        iconBg: 'bg-rose-600 text-white',
        borderHover: 'hover:border-rose-400',
        gradientBg: 'from-rose-500 to-amber-400',
        headerBg: 'bg-rose-950 text-white',
        accentText: 'text-rose-700',
        btnBg: 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-600/20',
        cardBg: 'bg-rose-50/30',
        dotActive: 'bg-rose-600',
        statPill: 'bg-rose-50 text-rose-800 border-rose-200',
      };
    default:
      return {
        pill: 'bg-slate-100 text-slate-900 border-slate-300',
        iconBg: 'bg-slate-800 text-white',
        borderHover: 'hover:border-slate-400',
        gradientBg: 'from-slate-700 to-slate-900',
        headerBg: 'bg-slate-900 text-white',
        accentText: 'text-slate-700',
        btnBg: 'bg-slate-900 hover:bg-slate-800 text-white shadow-slate-900/20',
        cardBg: 'bg-slate-50/50',
        dotActive: 'bg-slate-800',
        statPill: 'bg-slate-100 text-slate-800 border-slate-200',
      };
  }
};

/**
 * Reusable Horizontal Swipeable Module Carousel Card (5 Modules per card)
 */
interface CategorySwipeCardProps {
  category: {
    id: string;
    name: string;
    subtitle: string;
    icon: React.ComponentType<{ className?: string }>;
    count: number;
    colorTheme: string;
    badgeColor: string;
  };
  modules: HealthModuleMetadata[];
  onSelectModule: (module: HealthModuleMetadata) => void;
  onPreviewModule: (module: HealthModuleMetadata) => void;
  isIndonesian: boolean;
  cardIndexNumber?: number;
  highlightTag?: string;
  isHeroCard?: boolean;
  favorites: string[];
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
}

const CategorySwipeCard: React.FC<CategorySwipeCardProps> = ({
  category,
  modules,
  onSelectModule,
  onPreviewModule,
  isIndonesian,
  cardIndexNumber,
  highlightTag,
  isHeroCard = false,
  favorites,
  onToggleFavorite,
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeModuleIndex, setActiveModuleIndex] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeftState, setScrollLeftState] = useState(0);
  const [hasMoved, setHasMoved] = useState(false);

  const styles = getCategoryStyles(category.id);
  const CategoryIcon = category.icon;

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    const maxScroll = scrollWidth - clientWidth;
    if (maxScroll > 0) {
      const progress = Math.min(100, Math.max(0, (scrollLeft / maxScroll) * 100));
      setScrollProgress(progress);

      const cardWidth = 340;
      const index = Math.min(
        modules.length - 1,
        Math.max(0, Math.round(scrollLeft / cardWidth))
      );
      setActiveModuleIndex(index);
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!scrollRef.current) return;
    setIsDragging(true);
    setHasMoved(false);
    setStartX(e.pageX - scrollRef.current.offsetLeft);
    setScrollLeftState(scrollRef.current.scrollLeft);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !scrollRef.current) return;
    e.preventDefault();
    const x = e.pageX - scrollRef.current.offsetLeft;
    const walk = (x - startX) * 1.5;
    if (Math.abs(walk) > 5) {
      setHasMoved(true);
    }
    scrollRef.current.scrollLeft = scrollLeftState - walk;
  };

  const handleMouseUpOrLeave = () => {
    setIsDragging(false);
  };

  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -340, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: 340, behavior: 'smooth' });
    }
  };

  const scrollToIndex = (index: number) => {
    if (scrollRef.current) {
      const cardWidth = 340;
      scrollRef.current.scrollTo({
        left: index * cardWidth,
        behavior: 'smooth',
      });
      setActiveModuleIndex(index);
    }
  };

  return (
    <div
      className={`bg-white rounded-[32px] border ${
        isHeroCard
          ? 'border-emerald-300/80 shadow-md ring-1 ring-emerald-500/10'
          : 'border-slate-200/90 shadow-sm hover:shadow-md'
      } p-5 sm:p-6 transition-all duration-300 space-y-5 relative overflow-hidden`}
    >
      {/* Top Gradient Accent Bar */}
      <div className={`absolute top-0 left-0 right-0 h-2 bg-gradient-to-r ${styles.gradientBg}`} />

      {/* Header with Title, Badge, and Side-scroll arrow controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
        <div className="flex items-start sm:items-center gap-3.5">
          <div className={`w-12 h-12 rounded-2xl ${styles.iconBg} flex items-center justify-center font-black shadow-md shrink-0`}>
            <CategoryIcon className="w-6 h-6" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                {category.name}
              </h3>
              <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-black border ${category.badgeColor}`}>
                {modules.length} {isIndonesian ? 'Modul' : 'Modules'}
              </span>
              {cardIndexNumber && (
                <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-extrabold uppercase">
                  Card #{cardIndexNumber}
                </span>
              )}
              {highlightTag && (
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-extrabold flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-emerald-600" />
                  {highlightTag}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {category.subtitle}
            </p>
          </div>
        </div>

        {/* Scroll Nav Buttons & Indicator */}
        <div className="flex items-center gap-2 self-end sm:self-center">
          <span className="text-[11px] font-mono font-black text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200">
            {activeModuleIndex + 1} / {modules.length}
          </span>
          <button
            type="button"
            onClick={scrollLeft}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-all cursor-pointer active:scale-90"
            title={isIndonesian ? 'Geser ke Kiri' : 'Scroll Left'}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={scrollRight}
            className="w-9 h-9 rounded-full bg-slate-900 hover:bg-slate-800 text-white flex items-center justify-center transition-all cursor-pointer active:scale-90 shadow-xs"
            title={isIndonesian ? 'Geser ke Kanan' : 'Scroll Right'}
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Swipe Cue & Feature Summary Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-1 text-xs font-medium text-slate-500 bg-slate-50/80 p-2.5 rounded-2xl border border-slate-100">
        <div className="flex items-center gap-2 text-slate-700">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600"></span>
          </span>
          <span className="font-extrabold text-xs flex items-center gap-1 text-slate-800">
            👈 {isIndonesian ? 'Geser ke samping untuk melihat 5 modul' : 'Swipe sideways to view all 5 modules'}
          </span>
        </div>

        <div className="flex items-center gap-3 text-[11px] font-semibold text-slate-500">
          <span className="flex items-center gap-1">
            <Cpu className="w-3 h-3 text-emerald-600" />
            Gemini 2.5 AI
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-teal-600" />
            {isIndonesian ? 'Real-time Analitik' : 'Real-time Analytics'}
          </span>
        </div>
      </div>

      {/* Horizontal Swipeable Track */}
      <div className="relative group/carousel">
        <div
          ref={scrollRef}
          onScroll={handleScroll}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUpOrLeave}
          onMouseLeave={handleMouseUpOrLeave}
          className={`flex gap-4 overflow-x-auto no-scrollbar scroll-smooth snap-x snap-mandatory py-2 px-1 cursor-grab ${
            isDragging ? 'cursor-grabbing select-none' : ''
          }`}
          style={{
            scrollbarWidth: 'none',
            msOverflowStyle: 'none',
            WebkitOverflowScrolling: 'touch',
          }}
        >
          {modules.map((mod, idx) => {
            const ModIcon = getModuleIcon(mod.icon);
            const isFav = favorites.includes(mod.id);

            return (
              <div
                key={mod.id}
                onClick={() => {
                  if (!hasMoved) {
                    onSelectModule(mod);
                  }
                }}
                className={`shrink-0 w-[290px] sm:w-[330px] md:w-[350px] snap-start bg-white rounded-[26px] border border-slate-200/90 ${styles.borderHover} p-5 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between space-y-4 group cursor-pointer relative overflow-hidden`}
              >
                <div className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r ${styles.gradientBg}`} />

                <div className="space-y-3 pt-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div
                        className={`p-3 rounded-2xl ${styles.iconBg} shadow-md group-hover:scale-105 transition-transform shrink-0`}
                      >
                        <ModIcon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${styles.pill} inline-block`}
                        >
                          Modul #{mod.moduleNumber}
                        </span>
                        <span className="text-[11px] font-bold text-slate-500 block truncate mt-0.5">
                          {mod.tag}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* Favorite Button */}
                      <button
                        type="button"
                        onClick={(e) => onToggleFavorite(mod.id, e)}
                        className={`w-8 h-8 rounded-full flex items-center justify-center transition-all cursor-pointer active:scale-80 ${
                          isFav
                            ? 'bg-rose-50 text-rose-600 border border-rose-200 shadow-2xs'
                            : 'bg-slate-50 text-slate-400 hover:text-rose-500 hover:bg-rose-50 border border-slate-200/80'
                        }`}
                        title={isFav ? (isIndonesian ? 'Hapus dari Favorit' : 'Remove Favorite') : (isIndonesian ? 'Simpan ke Favorit' : 'Save Favorite')}
                      >
                        <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500' : ''}`} />
                      </button>

                      {/* Rating Badge */}
                      <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200 text-xs font-black text-slate-700">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        <span>4.9</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm sm:text-base font-black text-slate-900 group-hover:text-emerald-800 transition-colors leading-snug">
                      {isIndonesian ? mod.title : mod.titleEn}
                    </h4>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed line-clamp-3">
                    {isIndonesian ? mod.shortDesc : mod.shortDescEn}
                  </p>

                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                    <div className="flex items-center gap-1.5 text-[10px] font-black text-emerald-800 uppercase tracking-wide">
                      <Sparkles className="w-3 h-3 text-emerald-600" />
                      <span>{isIndonesian ? 'Keunggulan AI' : 'AI Advantage'}</span>
                    </div>
                    <p className="text-[11px] font-medium text-slate-600 line-clamp-2 leading-relaxed">
                      {isIndonesian ? mod.aiAdvantage : mod.aiAdvantageEn}
                    </p>
                  </div>
                </div>

                <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
                  {/* Quick Preview Info Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onPreviewModule(mod);
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
                    title={isIndonesian ? 'Pratinjau detail modul' : 'Preview module details'}
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{isIndonesian ? 'Detail' : 'Preview'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectModule(mod);
                    }}
                    className={`py-2 px-4 rounded-full ${styles.btnBg} font-black text-xs flex items-center gap-1.5 transition-all shadow-xs shrink-0 cursor-pointer active:scale-95`}
                  >
                    <span>{isIndonesian ? 'Buka Modul' : 'Open Module'}</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Interactive Pagination Dots (5 Dots for the 5 Modules) & Progress Bar */}
        <div className="flex items-center justify-between gap-4 mt-3 pt-1">
          <div className="flex items-center gap-1.5">
            {modules.map((m, dIdx) => (
              <button
                key={m.id}
                type="button"
                onClick={() => scrollToIndex(dIdx)}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  activeModuleIndex === dIdx
                    ? `w-6 ${styles.dotActive}`
                    : 'w-2 bg-slate-200 hover:bg-slate-300'
                }`}
                title={`Modul #${m.moduleNumber}: ${isIndonesian ? m.title : m.titleEn}`}
              />
            ))}
          </div>

          {/* Smooth Scroll Progress Bar */}
          <div className="flex-1 max-w-[200px] bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div
              style={{ width: `${Math.max(20, scrollProgress)}%` }}
              className={`bg-gradient-to-r ${styles.gradientBg} h-full rounded-full transition-all duration-150`}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export const GroupedModuleCarousel: React.FC<GroupedModuleCarouselProps> = ({
  onSelectModule,
  isIndonesian = true,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('sport_physical');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeFilterTab, setActiveFilterTab] = useState<'all' | 'favorites'>('all');
  const [previewingModule, setPreviewingModule] = useState<HealthModuleMetadata | null>(null);

  // Favorites saved in localStorage
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('nexo_favorite_modules');
      return saved ? JSON.parse(saved) : ['m1_adaptive_trainer', 'm6_nutrition_ai', 'm16_doctor_triage'];
    } catch {
      return ['m1_adaptive_trainer', 'm6_nutrition_ai', 'm16_doctor_triage'];
    }
  });

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFavorites((prev) => {
      const next = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      try {
        localStorage.setItem('nexo_favorite_modules', JSON.stringify(next));
      } catch {
        // ignore storage error
      }
      return next;
    });
  };

  // Category definitions with counts (5 modules each)
  const categories = useMemo(
    () => [
      {
        id: 'sport_physical',
        name: isIndonesian ? '1. Fisik & Olahraga' : '1. Physical & Sports',
        subtitle: isIndonesian ? 'Modul 1 s/d 5 • AI Coach, Form Vision & Biomekanika' : 'Modules 1 to 5 • AI Coach, Vision & Biomechanics',
        icon: Dumbbell,
        count: 5,
        colorTheme: 'emerald',
        badgeColor: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      },
      {
        id: 'nutrition_metabolism',
        name: isIndonesian ? '2. Nutrisi & Metabolisme' : '2. Nutrition & Metabolism',
        subtitle: isIndonesian ? 'Modul 6 s/d 10 • Smart Chef & Vision Food Scanner' : 'Modules 6 to 10 • Smart Chef & Vision Scanner',
        icon: UtensilsCrossed,
        count: 5,
        colorTheme: 'teal',
        badgeColor: 'bg-teal-100 text-teal-900 border-teal-300',
      },
      {
        id: 'mental_emotional',
        name: isIndonesian ? '3. Mental & Kualitas Tidur' : '3. Mental & Sleep Quality',
        subtitle: isIndonesian ? 'Modul 11 s/d 15 • Terapi CBT & Meditasi Napas HRV' : 'Modules 11 to 15 • CBT Therapy & Breathwork',
        icon: MessageSquareHeart,
        count: 5,
        colorTheme: 'indigo',
        badgeColor: 'bg-indigo-100 text-indigo-900 border-indigo-300',
      },
      {
        id: 'preventive_medical',
        name: isIndonesian ? '4. Medis Preventif & Longevity' : '4. Preventive & Longevity',
        subtitle: isIndonesian ? 'Modul 16 s/d 20 • Triage Dokter AI & Usia Biologis' : 'Modules 16 to 20 • Doctor Triage & Biological Age',
        icon: Stethoscope,
        count: 5,
        colorTheme: 'rose',
        badgeColor: 'bg-rose-100 text-rose-900 border-rose-300',
      },
    ],
    [isIndonesian]
  );

  // Active top category modules (filtered by search if active)
  const topCardCategory = categories.find((c) => c.id === selectedCategory) || categories[0];
  const topCardModules = useMemo(() => {
    let list = HEALTH_MODULES.filter((m) => m.category === selectedCategory);
    if (activeFilterTab === 'favorites') {
      list = list.filter((m) => favorites.includes(m.id));
    }
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      list = HEALTH_MODULES.filter(
        (mod) =>
          mod.title.toLowerCase().includes(q) ||
          mod.titleEn.toLowerCase().includes(q) ||
          mod.shortDesc.toLowerCase().includes(q) ||
          mod.tag.toLowerCase().includes(q) ||
          mod.aiAdvantage.toLowerCase().includes(q)
      );
    }
    return list.slice(0, 5);
  }, [selectedCategory, searchQuery, activeFilterTab, favorites]);

  // Remaining categories
  const otherCategories = useMemo(() => {
    return categories.filter((c) => c.id !== selectedCategory);
  }, [categories, selectedCategory]);

  return (
    <div className="w-full space-y-8" id="health-modules-carousel-container">
      {/* 1. FILTER CONTROLS & SEARCH BAR */}
      <div className="bg-white rounded-[28px] border border-slate-200 p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black shadow-md shadow-emerald-600/20 shrink-0">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
                  {isIndonesian ? 'Eksplorasi 20 Modul Kesehatan AI' : 'Explore 20 AI Health Modules'}
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black border border-emerald-200">
                  {HEALTH_MODULES.length} {isIndonesian ? 'Modul Klinis' : 'Clinical Modules'}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                {isIndonesian
                  ? 'Setiap card di bawah memuat 5 modul yang dapat digeser ke samping'
                  : 'Each card below contains 5 swipeable modules organized by category'}
              </p>
            </div>
          </div>

          {/* Search Input & Favorite Filter */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative flex-1 sm:w-60">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isIndonesian ? 'Cari modul, fitur, atau topik...' : 'Search module or topic...'}
                className="w-full bg-slate-50 border border-slate-200 rounded-full pl-9 pr-3.5 py-2 text-xs font-medium text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filter Toggle: All vs Favorites */}
            <div className="flex items-center p-1 rounded-2xl bg-slate-100 border border-slate-200">
              <button
                type="button"
                onClick={() => setActiveFilterTab('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  activeFilterTab === 'all'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {isIndonesian ? 'Semua' : 'All'}
              </button>
              <button
                type="button"
                onClick={() => setActiveFilterTab('favorites')}
                className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeFilterTab === 'favorites'
                    ? 'bg-white text-rose-600 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
                <span>{favorites.length}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Category Quick Navigation Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1 pb-0.5 border-t border-slate-100">
          <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider shrink-0 mr-1">
            {isIndonesian ? 'Pilih Kategori Utama:' : 'Select Primary Category:'}
          </span>
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 border ${
                  isSelected
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs font-black'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200/90'
                }`}
              >
                <cat.icon className="w-3.5 h-3.5" />
                <span>{cat.name}</span>
                <span
                  className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  5
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* CARD 1: KATEGORI UTAMA YANG DIPILIH (5 MODUL DENGAN KORSEL GESER)        */}
      {/* ========================================================================= */}
      <CategorySwipeCard
        category={topCardCategory}
        modules={topCardModules}
        onSelectModule={onSelectModule}
        onPreviewModule={(mod) => setPreviewingModule(mod)}
        isIndonesian={isIndonesian}
        cardIndexNumber={1}
        highlightTag={isIndonesian ? 'Kategori Terpilih' : 'Selected'}
        isHeroCard={true}
        favorites={favorites}
        onToggleFavorite={toggleFavorite}
      />

      {/* ========================================================================= */}
      {/* CARDS KATEGORI LAINNYA DI BAWAHNYA (MASING-MASING 5 MODUL GESER KE SAMPING)*/}
      {/* ========================================================================= */}
      <div className="space-y-6">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-sm shadow-xs">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-slate-900">
                {isIndonesian ? 'Kategori Modul Lengkap Lainnya (Geser ke Samping)' : 'Other Category Cards (Swipeable)'}
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                {isIndonesian
                  ? 'Setiap kategori di bawah memiliki 5 modul yang dapat digeser ke samping'
                  : 'Each category below holds 5 modules that can be swiped sideways'}
              </p>
            </div>
          </div>
        </div>

        {/* Render each remaining category card with identical sideways swipe carousel */}
        {otherCategories.map((cat, idx) => {
          const categoryModules = HEALTH_MODULES.filter((m) => m.category === cat.id).slice(0, 5);

          return (
            <CategorySwipeCard
              key={cat.id}
              category={cat}
              modules={categoryModules}
              onSelectModule={onSelectModule}
              onPreviewModule={(mod) => setPreviewingModule(mod)}
              isIndonesian={isIndonesian}
              cardIndexNumber={idx + 2}
              favorites={favorites}
              onToggleFavorite={toggleFavorite}
            />
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* MODAL QUICK PREVIEW DETAIL MODUL KLINIS                                   */}
      {/* ========================================================================= */}
      {previewingModule && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div
            className="bg-white rounded-[32px] border border-slate-200 max-w-lg w-full p-6 shadow-2xl space-y-5 relative overflow-hidden animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Accent Gradient */}
            <div
              className={`absolute top-0 left-0 right-0 h-2 bg-gradient-to-r ${
                getCategoryStyles(previewingModule.category).gradientBg
              }`}
            />

            {/* Modal Header */}
            <div className="flex items-start justify-between gap-3 pt-1">
              <div className="flex items-center gap-3">
                <div
                  className={`p-3.5 rounded-2xl ${
                    getCategoryStyles(previewingModule.category).iconBg
                  } shadow-md text-white`}
                >
                  {React.createElement(getModuleIcon(previewingModule.icon), {
                    className: 'w-6 h-6',
                  })}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase border ${
                        getCategoryStyles(previewingModule.category).pill
                      }`}
                    >
                      Modul #{previewingModule.moduleNumber}
                    </span>
                    <span className="text-xs font-bold text-slate-500">
                      {previewingModule.tag}
                    </span>
                  </div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900 mt-1">
                    {isIndonesian ? previewingModule.title : previewingModule.titleEn}
                  </h3>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setPreviewingModule(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-all cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Main Description */}
            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80">
                <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider block mb-1">
                  {isIndonesian ? 'Deskripsi Protokol' : 'Protocol Description'}
                </span>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {isIndonesian ? previewingModule.shortDesc : previewingModule.shortDescEn}
                </p>
              </div>

              {/* AI Advantages Details */}
              <div className="p-3.5 rounded-2xl bg-emerald-50/60 border border-emerald-200/80 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-black text-emerald-900 uppercase tracking-wide">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>{isIndonesian ? 'Keunggulan AI & Algoritma' : 'AI Capabilities & Clinical Edge'}</span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed font-medium">
                  {isIndonesian ? previewingModule.aiAdvantage : previewingModule.aiAdvantageEn}
                </p>
              </div>

              {/* Clinical Metrics Specs */}
              <div className="grid grid-cols-3 gap-2.5 text-center">
                <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 block">Rating</span>
                  <span className="text-xs font-black text-slate-900 flex items-center justify-center gap-0.5 mt-0.5">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" /> 4.9/5.0
                  </span>
                </div>
                <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 block">Durasi</span>
                  <span className="text-xs font-black text-slate-900 mt-0.5 block">5-15 Mins</span>
                </div>
                <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 block">Akurasi AI</span>
                  <span className="text-xs font-black text-emerald-700 mt-0.5 block">98.8%</span>
                </div>
              </div>
            </div>

            {/* Modal Bottom Actions */}
            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setPreviewingModule(null)}
                className="px-4 py-2.5 rounded-full border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-all cursor-pointer"
              >
                {isIndonesian ? 'Tutup' : 'Close'}
              </button>

              <button
                type="button"
                onClick={() => {
                  const mod = previewingModule;
                  setPreviewingModule(null);
                  onSelectModule(mod);
                }}
                className={`px-5 py-2.5 rounded-full ${
                  getCategoryStyles(previewingModule.category).btnBg
                } text-xs font-black flex items-center gap-2 transition-all shadow-md cursor-pointer active:scale-95`}
              >
                <span>{isIndonesian ? 'Luncurkan Modul Ini' : 'Launch Module Now'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
