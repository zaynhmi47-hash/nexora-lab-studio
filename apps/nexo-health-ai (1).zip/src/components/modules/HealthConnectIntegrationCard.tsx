import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  Moon,
  Activity,
  RefreshCw,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Smartphone,
  Sparkles,
  ChevronRight,
  TrendingUp,
  Layers,
  Zap,
  Info,
  Clock,
  Flame,
  Footprints,
} from 'lucide-react';
import { UserProfile, DailyLog } from '../../types';

interface HealthConnectIntegrationCardProps {
  userProfile: UserProfile;
  dailyLog: DailyLog;
  isIndonesian?: boolean;
  onOpenSleepStudio?: () => void;
  onOpenHeartDetails?: () => void;
}

export const HealthConnectIntegrationCard: React.FC<HealthConnectIntegrationCardProps> = ({
  userProfile,
  dailyLog,
  isIndonesian = true,
  onOpenSleepStudio,
  onOpenHeartDetails,
}) => {
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState(isIndonesian ? 'Baru saja' : 'Just now');
  const [heartRateValue, setHeartRateValue] = useState(76);
  const [syncStatus, setSyncStatus] = useState<'synced' | 'syncing' | 'offline'>('synced');
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  const handleManualSync = () => {
    setIsSyncing(true);
    setSyncStatus('syncing');

    setTimeout(() => {
      setIsSyncing(false);
      setSyncStatus('synced');
      setHeartRateValue(Math.floor(Math.random() * 6) + 72); // 72 - 77 bpm
      setLastSyncTime(isIndonesian ? 'Baru saja' : 'Just now');
    }, 1200);
  };

  // Supported permissions status
  const permissionStreamList = [
    {
      id: 'heart_rate',
      label: isIndonesian ? 'Denyut Jantung & EKG' : 'Heart Rate & ECG',
      icon: Heart,
      iconColor: 'text-rose-600',
      bgColor: 'bg-rose-50 border-rose-200',
      active: true,
      freq: '1 Hz Live',
    },
    {
      id: 'sleep_data',
      label: isIndonesian ? 'Arsitektur Tidur & REM' : 'Sleep Stages & REM',
      icon: Moon,
      iconColor: 'text-indigo-600',
      bgColor: 'bg-indigo-50 border-indigo-200',
      active: true,
      freq: 'Session Sync',
    },
    {
      id: 'steps_activity',
      label: isIndonesian ? 'Langkah & Kadensi' : 'Steps & Cadence',
      icon: Footprints,
      iconColor: 'text-emerald-600',
      bgColor: 'bg-emerald-50 border-emerald-200',
      active: true,
      freq: 'Real-Time',
    },
    {
      id: 'active_calories',
      label: isIndonesian ? 'Kalori Terbakar' : 'Active Burn',
      icon: Flame,
      iconColor: 'text-amber-600',
      bgColor: 'bg-amber-50 border-amber-200',
      active: true,
      freq: '5 Min Batch',
    },
  ];

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-[32px] p-6 sm:p-7 text-white shadow-xl relative overflow-hidden space-y-5">
      {/* Ambient background glows */}
      <div className="absolute top-0 right-1/4 w-72 h-72 bg-emerald-500/10 blur-3xl rounded-full pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-teal-400/10 blur-2xl rounded-full pointer-events-none" />

      {/* TOP HEADER: Google Health Connect Brand + Sync Status + Refresh Button */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-md shadow-emerald-500/20 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Activity className="w-5 h-5 text-emerald-400 animate-pulse" />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-1.5">
                <span>Google</span>
                <span className="text-emerald-400 font-extrabold">Health Connect</span>
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-black uppercase tracking-wider">
                Active Hub
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium">
              {isIndonesian
                ? 'Sinkronisasi biometrik terenkripsi di perangkat (On-Device Storage)'
                : 'Encrypted on-device biometric bridge & sensor federation'}
            </p>
          </div>
        </div>

        {/* Sync Status Badge & Action CTA */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-2xl px-3 py-1.5 backdrop-blur-md">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${
                syncStatus === 'synced' ? 'bg-emerald-400' : 'bg-amber-400'
              } opacity-75`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${
                syncStatus === 'synced' ? 'bg-emerald-500' : 'bg-amber-500'
              }`}></span>
            </span>
            <span className="text-[11px] font-bold text-slate-300">
              {syncStatus === 'syncing'
                ? (isIndonesian ? 'Mensinkronisasi...' : 'Syncing...')
                : `${isIndonesian ? 'Tersinkron' : 'Synced'} (${lastSyncTime})`}
            </span>
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleManualSync}
            disabled={isSyncing}
            className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-white transition-all cursor-pointer shadow-md disabled:opacity-50"
            title={isIndonesian ? 'Sinkronkan Ulang' : 'Sync Now'}
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin text-emerald-400' : 'text-slate-200'}`} />
          </motion.button>
        </div>
      </div>

      {/* REAL-TIME ICON-BASED SYNCHRONIZATION STATUS INDICATORS */}
      <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* ========================================================================= */}
        {/* 1. REAL-TIME HEART RATE SYNCHRONIZATION INDICATOR */}
        {/* ========================================================================= */}
        <div
          onClick={onOpenHeartDetails}
          className="bg-white/5 hover:bg-white/10 border border-white/10 hover:border-rose-500/40 rounded-3xl p-5 transition-all cursor-pointer group shadow-inner relative overflow-hidden"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              {/* Heart Rate Icon Indicator with live ping */}
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                  <Heart className="w-6 h-6 fill-rose-500 text-rose-500 animate-pulse" />
                </div>
                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center">
                  <span className="w-1.5 h-1.5 rounded-full bg-white block" />
                </span>
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-slate-300">
                    {isIndonesian ? 'Denyut Jantung Real-Time' : 'Live Heart Rate Stream'}
                  </span>
                  <span className="px-1.5 py-0.2 rounded-md bg-rose-500/20 text-rose-300 text-[9px] font-black uppercase">
                    1 Hz Live
                  </span>
                </div>
                <div className="flex items-baseline gap-2 mt-0.5">
                  <span className="text-3xl font-black text-white font-mono tracking-tight">
                    {heartRateValue}
                  </span>
                  <span className="text-xs font-bold text-slate-400">bpm</span>
                </div>
              </div>
            </div>

            <div className="text-right">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                <CheckCircle2 className="w-3 h-3" />
                <span>{isIndonesian ? 'Sinus Normal' : 'Normal Sinus'}</span>
              </span>
              <p className="text-[10px] text-slate-400 mt-1 font-mono">HRV: 68 ms</p>
            </div>
          </div>

          {/* Micro ECG waveform sparkline */}
          <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-[11px] text-slate-300 font-medium">
                {isIndonesian ? 'Sensor Wearable Terhubung' : 'Wearable Sensor Online'}
              </span>
            </div>
            <span className="text-[11px] text-emerald-400 font-bold group-hover:underline flex items-center gap-1">
              <span>{isIndonesian ? 'Buka Analitik' : 'View Stream'}</span>
              <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 2. REAL-TIME SLEEP DATA SYNCHRONIZATION INDICATOR */}
        {/* ========================================================================= */}
        <div
          onClick={onOpenSleepStudio}
          className="bg-white/5 hover:bg-white/10 border border-white/10 hover:border-indigo-500/40 rounded-3xl p-5 transition-all cursor-pointer group shadow-inner relative overflow-hidden"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              {/* Sleep Stage Icon Indicator with sleep moon glow */}
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-400 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                  <Moon className="w-6 h-6 text-indigo-300" />
                </div>
                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-indigo-400 border-2 border-slate-900 flex items-center justify-center">
                  <Sparkles className="w-2 h-2 text-slate-950" />
                </span>
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-slate-300">
                    {isIndonesian ? 'Sinkronisasi Tidur & REM' : 'Sleep Stages & Recovery'}
                  </span>
                  <span className="px-1.5 py-0.2 rounded-md bg-indigo-500/20 text-indigo-300 text-[9px] font-black uppercase">
                    Auto-Synced
                  </span>
                </div>
                <div className="flex items-baseline gap-2 mt-0.5">
                  <span className="text-3xl font-black text-white font-mono tracking-tight">
                    {dailyLog.sleepHours || 7.7}
                  </span>
                  <span className="text-xs font-bold text-slate-400">jam / {userProfile.dailySleepTargetHours || 8}h</span>
                </div>
              </div>
            </div>

            <div className="text-right">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-black border border-indigo-500/30">
                <ShieldCheck className="w-3 h-3" />
                <span>88 {isIndonesian ? 'Skor Prima' : 'Score'}</span>
              </span>
              <p className="text-[10px] text-slate-400 mt-1 font-mono">Deep: 1h 45m</p>
            </div>
          </div>

          {/* Micro sleep architecture bar */}
          <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-slate-300 font-medium">
                {isIndonesian ? 'Sinkron pukul 07:15 WIB' : 'Session synced at 07:15 AM'}
              </span>
            </div>
            <span className="text-[11px] text-indigo-300 font-bold group-hover:underline flex items-center gap-1">
              <span>{isIndonesian ? 'Studio Tidur' : 'Sleep Studio'}</span>
              <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>
      </div>

      {/* COMPACT ICON PERMISSION PILLS ROW */}
      <div className="relative z-10 pt-1 flex flex-wrap items-center justify-between gap-2 border-t border-white/10 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold text-slate-400">
            {isIndonesian ? 'Izin Sensor Terhubung:' : 'Connected Sensors:'}
          </span>
          {permissionStreamList.map((perm) => {
            const PIcon = perm.icon;
            return (
              <div
                key={perm.id}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-bold text-slate-300"
              >
                <PIcon className={`w-3 h-3 ${perm.iconColor}`} />
                <span>{perm.label}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              </div>
            );
          })}
        </div>

        <button
          onClick={() => setIsDetailsOpen(!isDetailsOpen)}
          className="text-[11px] font-black text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer flex items-center gap-1"
        >
          <span>{isDetailsOpen ? (isIndonesian ? 'Tutup Detail' : 'Hide Details') : (isIndonesian ? 'Kelola Izin' : 'Manage Permissions')}</span>
          <ChevronRight className={`w-3 h-3 transition-transform ${isDetailsOpen ? 'rotate-90' : ''}`} />
        </button>
      </div>

      {/* EXPANDED DETAILS ACCORDION */}
      <AnimatePresence>
        {isDetailsOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="pt-2 text-xs text-slate-300 space-y-2 border-t border-white/10"
          >
            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 grid grid-cols-1 sm:grid-cols-3 gap-3 text-[11px]">
              <div>
                <span className="text-slate-400 block font-medium">{isIndonesian ? 'Protokol Keamanan:' : 'Security Standard:'}</span>
                <strong className="text-white font-bold">Android Health Connect v1.4</strong>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">{isIndonesian ? 'Enkripsi Data:' : 'Encryption:'}</span>
                <strong className="text-emerald-400 font-bold">AES-256 GCM On-Device</strong>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">{isIndonesian ? 'Frekuensi Sinkronisasi:' : 'Sync Interval:'}</span>
                <strong className="text-teal-300 font-bold">{isIndonesian ? 'Otomatis Latar Belakang' : 'Background Continuous'}</strong>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
