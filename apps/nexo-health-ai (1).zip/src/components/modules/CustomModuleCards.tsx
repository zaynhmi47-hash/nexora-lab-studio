import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
  Activity,
  Dumbbell,
  Camera,
  HeartPulse,
  Trophy,
  Utensils,
  Brain,
  Star,
  Play,
  TrendingUp,
  CheckCircle2,
  Lock,
  Layers,
  ChevronRight,
  Flame,
  Award,
  Send,
  Loader2,
  Stethoscope,
  Sliders,
  Sparkle,
} from 'lucide-react';
import { HealthModuleMetadata, UserProfile, HealthModuleId } from '../../types';
import { HEALTH_MODULES } from '../../data/healthModulesData';

interface CustomModuleCardsProps {
  userProfile: UserProfile;
  activeModule: HealthModuleMetadata;
  onSelectModule: (module: HealthModuleMetadata) => void;
  onNavigateTab?: (tab: any) => void;
  isIndonesian?: boolean;
}

export const CustomModuleCards: React.FC<CustomModuleCardsProps> = ({
  userProfile,
  activeModule,
  onSelectModule,
  onNavigateTab,
  isIndonesian = true,
}) => {
  // Test Bench Interactive State
  const [testParam, setTestParam] = useState(85);
  const [testText, setTestText] = useState('Nyeri otot paha belakang pasca lari tempo 5K');
  const [isRunningAI, setIsRunningAI] = useState(false);
  const [aiSimulationOutput, setAiSimulationOutput] = useState<string | null>(null);

  const handleRunAiDemo = () => {
    setIsRunningAI(true);
    setAiSimulationOutput(null);

    setTimeout(() => {
      setIsRunningAI(false);
      if (activeModule.category === 'sport_physical') {
        setAiSimulationOutput(
          `✅ [AI ${activeModule.title}]: Koreksi Biomekanika Terdeteksi\n- Sudut Beban: ${testParam}° (Optimal: 90°)\n- Rekomendasi: Lakukan foam rolling hamstring 3x45 detik dan pendinginan aktif 5 menit untuk menurunkan asam laktat.`
        );
      } else if (activeModule.category === 'nutrition_metabolism') {
        setAiSimulationOutput(
          `✅ [AI ${activeModule.title}]: Rekomendasi Nutrisi Klinis\n- Kalori Terestimasi: 420 kkal (Protein: 32g, Karbo: 45g)\n- Saran: Tambahkan 250ml air kelapa elektrolit untuk mendukung hidrasi seluler.`
        );
      } else if (activeModule.category === 'mental_emotional') {
        setAiSimulationOutput(
          `✅ [AI ${activeModule.title}]: Modulasi Sistem Saraf Parasimpatis\n- Skor Stres: Terbimbing\n- Protokol: Jalankan latihan pernapasan 4-7-8 selama 3 siklus untuk meredakan ketegangan saraf vagus.`
        );
      } else {
        setAiSimulationOutput(
          `✅ [AI ${activeModule.title}]: Analisis Triase & Pencegahan\n- Status: Waspada Ringan (Hijau)\n- Tindakan: Pantau hidrasi, istirahat 7.5 jam, dan konsultasikan dokter bila gejala bertahan >48 jam.`
        );
      }
    }, 1100);
  };

  // Top 5 Ranked Modules for Google Play style Leaderboard
  const topRankedModules = [
    { rank: 1, mod: HEALTH_MODULES[15], metric: '99.4% Akurasi Triase', rating: '4.95', users: '1.2M+' },
    { rank: 2, mod: HEALTH_MODULES[0], metric: 'Autoregulasi HRV', rating: '4.92', users: '950K+' },
    { rank: 3, mod: HEALTH_MODULES[6], metric: 'Vision Scanner AI', rating: '4.90', users: '820K+' },
    { rank: 4, mod: HEALTH_MODULES[1], metric: '33 Landmark Pose', rating: '4.88', users: '640K+' },
    { rank: 5, mod: HEALTH_MODULES[10], metric: 'CBT Micro-Journaling', rating: '4.85', users: '510K+' },
  ];

  return (
    <div className="space-y-8 pt-4">
      {/* ========================================================================= */}
      {/* 1. CUSTOM CARD STYLE: HERO SPOTLIGHT (Pilihan Editor Google Health) */}
      {/* ========================================================================= */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <h4 className="text-sm sm:text-base font-black text-slate-900 tracking-tight">
              {isIndonesian ? '1. Sorotan Utama & Pilihan Dokter' : '1. Editor\'s Choice Spotlight'}
            </h4>
          </div>
          <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
            {isIndonesian ? 'Terverifikasi Medis' : 'Clinically Verified'}
          </span>
        </div>

        <motion.div
          whileHover={{ y: -2 }}
          className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-950 p-5 sm:p-7 text-white shadow-xl border border-emerald-700/50"
        >
          {/* Ambient Glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/20 blur-3xl rounded-full pointer-events-none" />
          <div className="absolute bottom-0 left-1/3 w-64 h-64 bg-teal-400/15 blur-2xl rounded-full pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-8 space-y-3.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 font-extrabold text-[11px] tracking-wide uppercase">
                  🏆 {isIndonesian ? 'Aplikasi Unggulan Minggu Ini' : 'Featured App of the Week'}
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-white/10 text-slate-300 font-semibold text-[10px]">
                  Modul #16 Triase Medis
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-white leading-tight">
                {isIndonesian
                  ? 'Dokter AI Klinis & Triase Gejala Cerdas'
                  : 'AI Doctor Consultation & Symptom Triage'}
              </h3>

              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed max-w-2xl font-medium">
                {isIndonesian
                  ? 'Sistem anamnesis digital berbasis protokol kedokteran untuk membedakan keluhan ringan dari red-flag gawat darurat dengan rekomendasi spesialis dan persiapan konsultasi.'
                  : 'Clinical digital anamnesis identifying emergency red-flags, differential assessments, and doctor specialist preparation.'}
              </p>

              {/* 3 Key Feature Badges */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5 border border-white/15 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-[11px] font-bold text-slate-100">Protokol Red-Flag</span>
                </div>
                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5 border border-white/15 flex items-center gap-2">
                  <Stethoscope className="w-4 h-4 text-teal-300 shrink-0" />
                  <span className="text-[11px] font-bold text-slate-100">Ringkasan Anamnesis</span>
                </div>
                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5 border border-white/15 flex items-center gap-2">
                  <Star className="w-4 h-4 text-amber-300 fill-amber-300 shrink-0" />
                  <span className="text-[11px] font-bold text-slate-100">4.95 (120k Ulasan)</span>
                </div>
              </div>
            </div>

            {/* Action Card Button */}
            <div className="lg:col-span-4 flex flex-col gap-3 justify-center">
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => onNavigateTab && onNavigateTab('doctor_consultation')}
                className="w-full py-3.5 px-5 rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 hover:from-emerald-300 hover:to-teal-200 transition-all cursor-pointer"
              >
                <span>{isIndonesian ? 'Mulai Konsultasi Dokter AI' : 'Start AI Doctor Session'}</span>
                <ArrowRight className="w-4 h-4" />
              </motion.button>

              <button
                type="button"
                onClick={() => onSelectModule(HEALTH_MODULES[15])}
                className="w-full py-2.5 px-4 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-white/10"
              >
                <span>{isIndonesian ? 'Lihat Spesifikasi Klinis' : 'View Module Specs'}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </motion.div>
      </section>

      {/* ========================================================================= */}
      {/* 2. CUSTOM CARD STYLE: BENTO GRID SINERGI LINTAS-MODUL (Cross-Module Synergies) */}
      {/* ========================================================================= */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-600" />
            <h4 className="text-sm sm:text-base font-black text-slate-900 tracking-tight">
              {isIndonesian ? '2. Sinergi Otomatis Lintas-Modul' : '2. Cross-Module Ecosystem Synergies'}
            </h4>
          </div>
          <span className="text-xs font-bold text-slate-500">
            {isIndonesian ? 'Terhubung Otomatis' : 'Auto-Sync'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
          {/* Bento Card 1: Biomekanik + Pemulihan */}
          <motion.div
            whileHover={{ y: -3 }}
            onClick={() => onSelectModule(HEALTH_MODULES[1])}
            className="rounded-3xl bg-gradient-to-br from-teal-500/10 via-white to-white p-4.5 border border-teal-200/80 shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between space-y-3"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="p-2.5 rounded-2xl bg-teal-600 text-white shadow-xs">
                  <Camera className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-black text-teal-800 bg-teal-100 px-2 py-0.5 rounded-full">
                  98% Sinergi
                </span>
              </div>
              <h5 className="text-xs sm:text-sm font-black text-slate-900">
                FormGuard CV ➔ Recovery Lab
              </h5>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {isIndonesian
                  ? 'Deviasi sudut lutut otomatis memicu protokol peregangan fascia & kompres es spesifik.'
                  : 'Joint form deviations trigger targeted foam rolling & contrast recovery routines.'}
              </p>
            </div>
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold text-teal-700">
              <span>Modul #2 + #3</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </motion.div>

          {/* Bento Card 2: Vision Nutrisi + Glukosa */}
          <motion.div
            whileHover={{ y: -3 }}
            onClick={() => onSelectModule(HEALTH_MODULES[6])}
            className="rounded-3xl bg-gradient-to-br from-emerald-500/10 via-white to-white p-4.5 border border-emerald-200/80 shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between space-y-3"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="p-2.5 rounded-2xl bg-emerald-600 text-white shadow-xs">
                  <Utensils className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-black text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                  96% Sinergi
                </span>
              </div>
              <h5 className="text-xs sm:text-sm font-black text-slate-900">
                Vision Scanner ➔ Indeks Glikemik
              </h5>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {isIndonesian
                  ? 'Foto piring makanan langsung menghitung beban glikemik dan jendela metabolik latihan.'
                  : 'Food photo instantly computes glycemic load & post-meal walk timing.'}
              </p>
            </div>
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold text-emerald-700">
              <span>Modul #7 + #8</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </motion.div>

          {/* Bento Card 3: CBT Journaling + Sirkadian Sleep */}
          <motion.div
            whileHover={{ y: -3 }}
            onClick={() => onSelectModule(HEALTH_MODULES[10])}
            className="rounded-3xl bg-gradient-to-br from-indigo-500/10 via-white to-white p-4.5 border border-indigo-200/80 shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between space-y-3"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="p-2.5 rounded-2xl bg-indigo-600 text-white shadow-xs">
                  <Brain className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-black text-indigo-800 bg-indigo-100 px-2 py-0.5 rounded-full">
                  95% Sinergi
                </span>
              </div>
              <h5 className="text-xs sm:text-sm font-black text-slate-900">
                CBT AI ➔ Ritme Tidur Sirkadian
              </h5>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {isIndonesian
                  ? 'Refleksi journaling malam mengurai kecemasan dan mengkalibrasi jadwal paparan melatonin.'
                  : 'Nightly thought de-escalation aligns with circadian melatonin and sleep hygiene.'}
              </p>
            </div>
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold text-indigo-700">
              <span>Modul #11 + #15</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </motion.div>

          {/* Bento Card 4: Longevity + VO2 Max */}
          <motion.div
            whileHover={{ y: -3 }}
            onClick={() => onSelectModule(HEALTH_MODULES[18])}
            className="rounded-3xl bg-gradient-to-br from-amber-500/10 via-white to-white p-4.5 border border-amber-200/80 shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between space-y-3"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="p-2.5 rounded-2xl bg-amber-600 text-white shadow-xs">
                  <Sparkles className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-black text-amber-900 bg-amber-100 px-2 py-0.5 rounded-full">
                  97% Sinergi
                </span>
              </div>
              <h5 className="text-xs sm:text-sm font-black text-slate-900">
                Longevity ➔ Periodisasi Olahraga
              </h5>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {isIndonesian
                  ? 'Kombinasi latihan Zona 2 kardio dan latihan beban untuk menekan usia biologis -4 tahun.'
                  : 'Zone 2 cardio and resistance balance reduces cellular biological age by -4 years.'}
              </p>
            </div>
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold text-amber-800">
              <span>Modul #19 + #1</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 3. CUSTOM CARD STYLE: GOOGLE PLAY TOP CHARTS (Leaderboard Peringkat 1-5) */}
      {/* ========================================================================= */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-500" />
            <h4 className="text-sm sm:text-base font-black text-slate-900 tracking-tight">
              {isIndonesian ? '3. Peringkat Terpopuler Google Health' : '3. Top Trending Health Charts'}
            </h4>
          </div>
          <span className="text-xs font-bold text-slate-500">
            {isIndonesian ? 'Diperbarui Real-time' : 'Live Updated'}
          </span>
        </div>

        <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-2xs divide-y divide-slate-100">
          {topRankedModules.map(({ rank, mod, metric, rating, users }) => (
            <motion.div
              key={mod.id}
              whileHover={{ backgroundColor: '#f8fafc' }}
              onClick={() => onSelectModule(mod)}
              className="py-3 px-2 sm:px-3 rounded-2xl flex items-center justify-between gap-3 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                {/* Rank Number Medal */}
                <span
                  className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs shrink-0 ${
                    rank === 1
                      ? 'bg-amber-400 text-amber-950 shadow-xs'
                      : rank === 2
                      ? 'bg-slate-300 text-slate-800'
                      : rank === 3
                      ? 'bg-amber-700/20 text-amber-900'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  #{rank}
                </span>

                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h5 className="text-xs sm:text-sm font-black text-slate-900 truncate">
                      {isIndonesian ? mod.title : mod.titleEn}
                    </h5>
                    <span className="hidden sm:inline-block text-[10px] font-bold px-2 py-0.2 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                      {mod.tag}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                    <span className="text-emerald-700 font-bold">{metric}</span>
                    <span>•</span>
                    <span className="flex items-center gap-0.5 text-slate-700 font-semibold">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      {rating}
                    </span>
                    <span>•</span>
                    <span>{users} pengguna</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectModule(mod);
                }}
                className="px-3.5 py-1.5 rounded-full bg-slate-100 hover:bg-emerald-600 hover:text-white text-slate-800 font-black text-xs transition-colors shrink-0 cursor-pointer shadow-2xs"
              >
                {isIndonesian ? 'Coba' : 'Try'}
              </button>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 4. CUSTOM CARD STYLE: KONSOL INTERAKTIF UJI COBA LIVE (Live Interactive Workbench) */}
      {/* ========================================================================= */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-600" />
            <h4 className="text-sm sm:text-base font-black text-slate-900 tracking-tight">
              {isIndonesian ? '4. Konsol Uji Coba Langsung AI' : '4. Live AI Sandbox & Simulation'}
            </h4>
          </div>
          <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
            Aktif: Modul #{activeModule.moduleNumber}
          </span>
        </div>

        <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-6 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <span className="text-[10px] font-black text-emerald-400 uppercase tracking-wider">
                {activeModule.categoryName} • Modul #{activeModule.moduleNumber}
              </span>
              <h4 className="text-base sm:text-lg font-black text-white">
                {isIndonesian ? activeModule.title : activeModule.titleEn}
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                {isIndonesian ? activeModule.shortDesc : activeModule.shortDescEn}
              </p>
            </div>
            <div className="p-3 rounded-2xl bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 shrink-0">
              <Zap className="w-5 h-5" />
            </div>
          </div>

          {/* Interactive Parameters Input */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2 bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700">
              <div className="flex justify-between text-xs font-bold text-slate-300">
                <span>{isIndonesian ? 'Parameter Uji / Intensitas' : 'Simulation Parameter'}</span>
                <span className="text-emerald-400 font-mono">{testParam}° / Skor {testParam}</span>
              </div>
              <input
                type="range"
                min="30"
                max="120"
                value={testParam}
                onChange={(e) => setTestParam(Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer"
              />
              <span className="text-[10px] text-slate-400 block">
                {isIndonesian ? 'Geser slider untuk mengubah simulasi biometrik' : 'Slide to modify test biometric input'}
              </span>
            </div>

            <div className="space-y-2 bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700">
              <label className="text-xs font-bold text-slate-300 block">
                {isIndonesian ? 'Catatan Gejala / Input Makanan' : 'Notes / Sample Prompt'}
              </label>
              <input
                type="text"
                value={testText}
                onChange={(e) => setTestText(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                placeholder="Tulis kondisi atau gejala..."
              />
            </div>
          </div>

          {/* Execute AI Button */}
          <div className="flex items-center justify-between pt-2">
            <span className="text-[11px] text-slate-400">
              {isIndonesian ? 'Didukung reasoning model Google Gemini' : 'Powered by Gemini AI Engine'}
            </span>

            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleRunAiDemo}
              disabled={isRunningAI}
              className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-950/40 disabled:opacity-50"
            >
              {isRunningAI ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{isIndonesian ? 'Menganalisis...' : 'Simulating...'}</span>
                </>
              ) : (
                <>
                  <Sparkle className="w-4 h-4" />
                  <span>{isIndonesian ? 'Jalankan Analisis AI' : 'Run AI Analysis'}</span>
                </>
              )}
            </motion.button>
          </div>

          {/* AI Result Output Box */}
          {aiSimulationOutput && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-950 border border-emerald-500/50 rounded-2xl p-4 text-xs font-mono text-emerald-300 whitespace-pre-line leading-relaxed shadow-inner"
            >
              {aiSimulationOutput}
            </motion.div>
          )}
        </div>
      </section>
    </div>
  );
};
