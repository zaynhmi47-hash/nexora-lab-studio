import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Stethoscope,
  Star,
  Phone,
  Video,
  MessageSquare,
  ShieldCheck,
  ChevronRight,
  Sparkles,
  BookOpen,
  Award,
} from 'lucide-react';
import { UserProfile } from '../../types';
import { DOCTOR_SPECIALISTS, DoctorSpecialistProfile } from '../../data/doctorSpecialists';

interface DoctorSpecialistDeckProps {
  userProfile: UserProfile;
  onSelectDoctorToConsult?: (doctorName: string, specialty: string, doctorId?: string) => void;
  onNavigateToFullDoctor?: () => void;
  onStartDirectCall?: (doctor: DoctorSpecialistProfile, type: 'voice' | 'video') => void;
}

export const DoctorSpecialistDeck: React.FC<DoctorSpecialistDeckProps> = ({
  userProfile,
  onSelectDoctorToConsult,
  onNavigateToFullDoctor,
  onStartDirectCall,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('all');

  const specialties = [
    { id: 'all', label: isIndonesian ? 'Semua Spesialis' : 'All Specialists' },
    { id: 'internal_medicine', label: 'Penyakit Dalam' },
    { id: 'cardiology', label: 'Jantung (Sp.JP)' },
    { id: 'psychology', label: 'Mental & CBT' },
    { id: 'clinical_nutrition', label: 'Gizi Klinis' },
    { id: 'physiotherapy', label: 'Fisioterapi (Sp.KFR)' },
    { id: 'pediatrics', label: 'Anak (Sp.A)' },
    { id: 'dermatology', label: 'Kulit (Sp.DVE)' },
    { id: 'neurology', label: 'Saraf (Sp.N)' },
  ];

  const filteredDoctors =
    selectedSpecialty === 'all'
      ? DOCTOR_SPECIALISTS
      : DOCTOR_SPECIALISTS.filter((d) => d.specialtyId === selectedSpecialty);

  return (
    <div className="bg-white border border-slate-200/90 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-emerald-50 text-emerald-700">
            <Stethoscope className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-2">
              <span>{isIndonesian ? 'Daftar Dokter Spesialis Medis AI' : 'AI Medical Specialists Roster'}</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                WhatsApp Live
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              {isIndonesian
                ? 'Konsultasi interaktif via WhatsApp Chat, Pesan Suara, & Panggilan Telepon AI 24/7'
                : 'Interactive WhatsApp chat, voice messages, and telephone consultation 24/7'}
            </p>
          </div>
        </div>

        {onNavigateToFullDoctor && (
          <button
            onClick={onNavigateToFullDoctor}
            className="flex items-center gap-1.5 text-xs font-black text-emerald-700 hover:text-emerald-800 transition-colors cursor-pointer w-fit"
          >
            <span>{isIndonesian ? 'Buka WhatsApp Dokter Penuh' : 'Open Full WhatsApp Room'}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Specialty Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        {specialties.map((spec) => (
          <button
            key={spec.id}
            onClick={() => setSelectedSpecialty(spec.id)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              selectedSpecialty === spec.id
                ? 'bg-slate-900 text-white shadow-xs font-black'
                : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200'
            }`}
          >
            {spec.label}
          </button>
        ))}
      </div>

      {/* Doctor Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredDoctors.map((doc) => (
          <div
            key={doc.id}
            className="bg-slate-50 border border-slate-200/90 rounded-2xl p-4 flex flex-col justify-between hover:border-emerald-300 hover:shadow-md transition-all group space-y-3.5"
          >
            <div className="flex items-start gap-3">
              <div className="relative shrink-0">
                <img
                  src={doc.avatar}
                  alt={doc.name}
                  referrerPolicy="no-referrer"
                  className="w-13 h-13 rounded-2xl object-cover border border-slate-200 shadow-2xs group-hover:scale-105 transition-transform"
                />
                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                    {doc.badge}
                  </span>
                  <div className="flex items-center gap-1 text-xs font-black text-amber-600">
                    <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                    <span>{doc.rating}</span>
                  </div>
                </div>

                <h3 className="text-xs font-black text-slate-900 truncate mt-1">
                  {doc.name}
                </h3>
                <p className="text-[11px] text-emerald-800 font-bold truncate">
                  {isIndonesian ? doc.specialtyTitle : doc.specialtyTitleEn}
                </p>
                <p className="text-[10px] text-slate-400 truncate">
                  {doc.hospital}
                </p>
              </div>
            </div>

            {/* Specialty Keywords */}
            <div className="flex flex-wrap gap-1">
              {doc.expertiseKeywords.slice(0, 3).map((kw, i) => (
                <span
                  key={i}
                  className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] font-medium text-slate-600"
                >
                  {kw}
                </span>
              ))}
            </div>

            {/* Actions: Chat WhatsApp & Call Buttons */}
            <div className="pt-2 border-t border-slate-200/80 flex items-center gap-2">
              <button
                onClick={() => {
                  if (onSelectDoctorToConsult) {
                    onSelectDoctorToConsult(doc.name, doc.specialtyTitle, doc.id);
                  }
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>{isIndonesian ? 'Chat WA' : 'WA Chat'}</span>
              </button>

              <button
                onClick={() => {
                  if (onStartDirectCall) {
                    onStartDirectCall(doc, 'voice');
                  } else if (onSelectDoctorToConsult) {
                    onSelectDoctorToConsult(doc.name, doc.specialtyTitle, doc.id);
                  }
                }}
                className="p-2 rounded-xl bg-slate-900 hover:bg-emerald-600 text-white transition-colors cursor-pointer"
                title={isIndonesian ? 'Panggilan Telepon Suara' : 'Voice Call'}
              >
                <Phone className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
