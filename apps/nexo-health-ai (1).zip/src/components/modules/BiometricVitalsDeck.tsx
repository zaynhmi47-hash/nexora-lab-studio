import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  Activity,
  Flame,
  Droplets,
  Scale,
  Moon,
  Footprints,
  TrendingUp,
  ChevronRight,
  Sparkles,
  Thermometer,
  Zap,
  Info,
  Calendar,
  Clock,
  ArrowUpRight,
  Plus,
} from 'lucide-react';
import { UserProfile, DailyLog } from '../../types';

interface BiometricVitalsDeckProps {
  userProfile: UserProfile;
  dailyLog: DailyLog;
  onNavigateTab?: (tab: string) => void;
  onOpenSleepStudio?: () => void;
  onOpenAiGuide?: () => void;
  onAddWater?: (amountMl: number) => void;
}

export const BiometricVitalsDeck: React.FC<BiometricVitalsDeckProps> = ({
  userProfile,
  dailyLog,
  onNavigateTab,
  onOpenSleepStudio,
  onOpenAiGuide,
  onAddWater,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // Selected Day in Week Strip (e.g. Wed 10)
  const [selectedDayIndex, setSelectedDayIndex] = useState(2); // Wednesday (today)
  const [activeFilterCategory, setActiveFilterCategory] = useState<'all' | 'heart' | 'sleep' | 'calories'>('all');

  const daysOfWeek = [
    { day: '08', name: 'Min', nameEn: 'Sun', dateStr: '2026-08-08' },
    { day: '09', name: 'Sen', nameEn: 'Mon', dateStr: '2026-08-09' },
    { day: '10', name: 'Sel', nameEn: 'Tue', dateStr: '2026-08-10' },
    { day: '11', name: 'Rab', nameEn: 'Wed', dateStr: '2026-08-11' },
    { day: '12', name: 'Kam', nameEn: 'Thu', dateStr: '2026-08-12' },
    { day: '13', name: 'Jum', nameEn: 'Fri', dateStr: '2026-08-13' },
    { day: '14', name: 'Sab', nameEn: 'Sat', dateStr: '2026-08-14' },
  ];

  // Weekly bar data for activity
  const weeklyStepsData = [
    { day: 'Min', steps: 4800, height: '48%' },
    { day: 'Sen', steps: 7200, height: '72%' },
    { day: 'Sel', steps: 9100, height: '91%' },
    { day: 'Rab', steps: 6420, height: '64%', isToday: true },
    { day: 'Kam', steps: 8300, height: '83%' },
    { day: 'Jum', steps: 9500, height: '95%' },
    { day: 'Sab', steps: 5900, height: '59%' },
  ];

  return (
    <div className="space-y-6 w-full max-w-full">
      {/* 1. DATE SELECTOR STRIP & HEALTH SCORE SUMMARY (Inspired by Screenshots 2, 4, 5, 7) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-slate-200/80 rounded-3xl p-4 sm:p-5 shadow-xs">
        {/* Date Selector Row */}
        <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar pb-1 sm:pb-0">
          {daysOfWeek.map((d, idx) => {
            const isSelected = selectedDayIndex === idx;
            return (
              <button
                key={d.day}
                onClick={() => setSelectedDayIndex(idx)}
                className={`flex flex-col items-center justify-center min-w-[48px] sm:min-w-[56px] py-2 px-2.5 rounded-2xl transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-600 text-white font-black shadow-md shadow-emerald-600/20 scale-105'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-100 font-semibold'
                }`}
              >
                <span className={`text-[10px] uppercase ${isSelected ? 'text-emerald-100 font-extrabold' : 'text-slate-400'}`}>
                  {isIndonesian ? d.name : d.nameEn}
                </span>
                <span className="text-base font-extrabold">{d.day}</span>
              </button>
            );
          })}
        </div>

        {/* AI Health Score Badge */}
        <div className="flex items-center gap-3 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-100 rounded-2xl p-2.5 sm:px-4">
          <div className="relative flex items-center justify-center w-11 h-11 rounded-full bg-emerald-600 text-white font-black text-xs shadow-xs">
            <span>92%</span>
            <div className="absolute inset-0 rounded-full border-2 border-emerald-300 animate-ping opacity-25" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black text-emerald-950">
                {isIndonesian ? 'Skor Kesehatan AI Prima' : 'AI Health Score: 92%'}
              </span>
              <span className="px-1.5 py-0.5 rounded-md bg-emerald-200/60 text-emerald-800 text-[10px] font-extrabold">
                {isIndonesian ? 'Optimal' : 'Optimal'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">
              {isIndonesian ? 'Biometrik ritme & pemulihan seimbang' : 'HRV & recovery vitals well-calibrated'}
            </p>
          </div>
        </div>
      </div>

      {/* 2. CATEGORY FILTER PILLS (Screenshot 2 & 5) */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        {[
          { id: 'all', label: isIndonesian ? 'Semua Metrik' : 'All Metrics', icon: Sparkles },
          { id: 'heart', label: isIndonesian ? 'Jantung & EKG' : 'Heart & ECG', icon: Heart },
          { id: 'sleep', label: isIndonesian ? 'Tidur & Pemulihan' : 'Sleep & Recovery', icon: Moon },
          { id: 'calories', label: isIndonesian ? 'Kalori & Gizi' : 'Calories & Nutrition', icon: Flame },
        ].map((cat) => {
          const Icon = cat.icon;
          const isActive = activeFilterCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveFilterCategory(cat.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer whitespace-nowrap shadow-2xs ${
                isActive
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* 3. MAIN BENTO GRID: 3D HEART RATE CARD + 4-IN-1 VITALS + SLEEP ARCHITECTURE (Screenshots 1, 2, 3, 5, 7) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* LEFT COLUMN: 3D HEART RATE & ECG CARD (Screenshots 2, 3, 5, 12) */}
        <div className="lg:col-span-7 bg-white border border-slate-200/90 rounded-[28px] p-6 shadow-xs flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-48 h-48 bg-rose-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between gap-2 pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-rose-50 border border-rose-100 text-rose-600 flex items-center justify-center shadow-2xs">
                  <Heart className="w-5 h-5 fill-rose-500 text-rose-500 animate-pulse" />
                </div>
                <div>
                  <h2 className="text-sm font-black text-slate-900">
                    {isIndonesian ? 'Denyut Jantung & R-R Interval' : 'Heart Rate & Rhythm Analysis'}
                  </h2>
                  <div className="flex items-center gap-1.5 text-[11px] text-emerald-600 font-bold">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                    <span>{isIndonesian ? 'Sensor Real-Time Aktif (Normal)' : 'Sensor Live Active (Normal)'}</span>
                  </div>
                </div>
              </div>

              <span className="text-xs font-black text-slate-400 bg-slate-100 px-2.5 py-1 rounded-full">
                24h Trend
              </span>
            </div>

            {/* Dynamic Metric Display & 3D Heart Illustration Placeholder */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 my-6 items-center">
              <div className="sm:col-span-6 space-y-1">
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl sm:text-5xl font-black tracking-tight text-slate-900">
                    86
                  </span>
                  <span className="text-sm font-bold text-slate-500">bpm</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-100 px-2.5 py-1 rounded-xl w-fit">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>{isIndonesian ? '-0.8 bpm dari rata-rata 7 hari' : '-0.8 bpm vs 7-day average'}</span>
                </div>
                <p className="text-xs text-slate-500 pt-2 leading-relaxed">
                  {isIndonesian
                    ? 'Variabilitas detak jantung (HRV) stabil di angka 62 ms dengan R-R interval 851 ms.'
                    : 'Heart rate variability (HRV) is steady at 62 ms with R-R interval 851 ms.'}
                </p>
              </div>

              {/* Animated ECG Waveform Canvas Visual */}
              <div className="sm:col-span-6 bg-slate-900 rounded-2xl p-4 text-white relative overflow-hidden shadow-inner">
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pb-2">
                  <span>EKG LEAD II • 25mm/s</span>
                  <span className="text-emerald-400 font-bold">851 ms</span>
                </div>
                {/* SVG ECG Waveform */}
                <svg className="w-full h-20 text-emerald-400 stroke-current" viewBox="0 0 300 80" fill="none">
                  <path
                    d="M 0,40 L 40,40 L 50,38 L 55,42 L 65,40 L 80,40 L 90,40 L 95,20 L 105,70 L 115,5 L 125,50 L 130,35 L 135,40 L 160,40 L 180,38 L 195,42 L 210,40 L 220,40 L 225,22 L 235,68 L 245,8 L 255,48 L 260,36 L 265,40 L 300,40"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="opacity-90"
                  />
                </svg>
                <div className="flex items-center justify-between text-[11px] font-bold text-slate-300 pt-1">
                  <span>Sinus Normal</span>
                  <span className="text-teal-300">SpO2: 98%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Action Link */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-slate-500 font-bold">
              <span>{isIndonesian ? 'Terakhir diperbarui 2 menit lalu' : 'Last synced 2 mins ago'}</span>
            </div>
            {onNavigateTab && (
              <button
                onClick={() => onNavigateTab('dashboard')}
                className="inline-flex items-center gap-1.5 text-xs font-black text-emerald-700 hover:text-emerald-800 transition-colors cursor-pointer"
              >
                <span>{isIndonesian ? 'Buka Analitik Jantung Lengkap' : 'View Full Heart Analytics'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: 4-IN-1 VITALS BENTO (Screenshots 1, 2, 5, 7) */}
        <div className="lg:col-span-5 grid grid-cols-2 gap-3.5 sm:gap-4">
          {/* Card 1: Blood Pressure */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-xl bg-cyan-50 text-cyan-600">
                <Activity className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                Optimal
              </span>
            </div>
            <div className="my-2">
              <span className="text-2xl font-black text-slate-900">117/73</span>
              <span className="text-[11px] text-slate-400 font-bold ml-1">mmHg</span>
              <p className="text-xs font-bold text-slate-700 mt-0.5">
                {isIndonesian ? 'Tekanan Darah' : 'Blood Pressure'}
              </p>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
              <div className="bg-cyan-500 h-1.5 rounded-full w-[78%]" />
            </div>
          </div>

          {/* Card 2: Sleep Score / Duration */}
          <div
            onClick={onOpenSleepStudio}
            className="bg-white border border-slate-200/90 hover:border-emerald-300 rounded-2xl p-4 shadow-xs flex flex-col justify-between cursor-pointer transition-all hover:shadow-md group"
          >
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600 group-hover:scale-110 transition-transform">
                <Moon className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full">
                85 Score
              </span>
            </div>
            <div className="my-2">
              <span className="text-2xl font-black text-slate-900">7h 45m</span>
              <p className="text-xs font-bold text-slate-700 mt-0.5">
                {isIndonesian ? 'Kualitas Tidur' : 'Sleep Quality'}
              </p>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
              <div className="bg-indigo-500 h-1.5 rounded-full w-[85%]" />
            </div>
          </div>

          {/* Card 3: Calorie Burn */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-xl bg-amber-50 text-amber-600">
                <Flame className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold text-slate-500">
                {dailyLog.caloriesConsumed} / {userProfile.dailyCalorieTarget}
              </span>
            </div>
            <div className="my-2">
              <span className="text-2xl font-black text-slate-900">{dailyLog.caloriesConsumed || 1290}</span>
              <span className="text-[11px] text-slate-400 font-bold ml-1">kcal</span>
              <p className="text-xs font-bold text-slate-700 mt-0.5">
                {isIndonesian ? 'Kalori Masuk' : 'Calorie Intake'}
              </p>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
              <div className="bg-amber-500 h-1.5 rounded-full w-[65%]" />
            </div>
          </div>

          {/* Card 4: Water Hydration Tracker with +250ml */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <div className="p-2 rounded-xl bg-sky-50 text-sky-600">
                <Droplets className="w-4 h-4" />
              </div>
              {onAddWater && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddWater(250);
                  }}
                  className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-sky-600 hover:bg-sky-700 text-white text-[10px] font-black transition-colors cursor-pointer shadow-2xs"
                >
                  <Plus className="w-2.5 h-2.5" />
                  <span>250ml</span>
                </button>
              )}
            </div>
            <div className="my-2">
              <span className="text-2xl font-black text-slate-900">
                {((dailyLog.waterIntakeMl || 1500) / 1000).toFixed(1)}
              </span>
              <span className="text-[11px] text-slate-400 font-bold ml-1">L</span>
              <p className="text-xs font-bold text-slate-700 mt-0.5">
                {isIndonesian ? 'Hidrasi Air' : 'Water Intake'}
              </p>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
              <div className="bg-sky-500 h-1.5 rounded-full w-[72%]" />
            </div>
          </div>
        </div>
      </div>

      {/* 4. WEEKLY STEPS & ACTIVITY SPARKLINE BAR (Screenshots 1, 3, 6) */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-50 text-emerald-700">
              <Footprints className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-slate-900">
                {isIndonesian ? 'Aktivitas Langkah & Target Gerak Harian' : 'Daily Steps & Activity Milestone'}
              </h2>
              <p className="text-xs text-slate-500">
                {isIndonesian ? 'Target harian: 10.000 langkah' : 'Target: 10,000 steps per day'}
              </p>
            </div>
          </div>

          <div className="text-right">
            <div className="text-xl sm:text-2xl font-black text-slate-900">6,420</div>
            <span className="text-[11px] font-bold text-emerald-600">+12% vs kemarin</span>
          </div>
        </div>

        {/* Weekly Bar Chart */}
        <div className="grid grid-cols-7 gap-2 sm:gap-4 items-end pt-4 h-32 border-t border-slate-100">
          {weeklyStepsData.map((bar, i) => (
            <div key={i} className="flex flex-col items-center gap-2 h-full justify-end group cursor-pointer">
              <span className="text-[10px] font-bold text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                {bar.steps}
              </span>
              <div className="w-full max-w-[36px] bg-slate-100 rounded-xl h-24 flex items-end p-1">
                <div
                  style={{ height: bar.height }}
                  className={`w-full rounded-lg transition-all duration-500 ${
                    bar.isToday
                      ? 'bg-gradient-to-t from-emerald-600 to-teal-400 shadow-sm shadow-emerald-500/30'
                      : 'bg-slate-300 group-hover:bg-emerald-400'
                  }`}
                />
              </div>
              <span
                className={`text-xs font-bold ${
                  bar.isToday ? 'text-emerald-700 font-black' : 'text-slate-500'
                }`}
              >
                {bar.day}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
