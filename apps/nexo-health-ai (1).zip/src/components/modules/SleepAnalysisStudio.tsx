import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Moon,
  Clock,
  Sparkles,
  Zap,
  Activity,
  Play,
  Pause,
  Volume2,
  X,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  RefreshCw,
  Bell,
  Sliders,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface SleepAnalysisStudioProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
}

export const SleepAnalysisStudio: React.FC<SleepAnalysisStudioProps> = ({
  isOpen,
  onClose,
  userProfile,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // Night Mode Live Session Tracking State (Screenshots 18, 19, 20)
  const [isLiveTracking, setIsLiveTracking] = useState(false);
  const [trackingSeconds, setTrackingSeconds] = useState(17220); // 4h 47m default
  const [isAudioRecording, setIsAudioRecording] = useState(true);

  // Tab: 'overview' | 'stages' | 'night_studio'
  const [activeTab, setActiveTab] = useState<'overview' | 'stages' | 'night_studio'>('overview');

  useEffect(() => {
    let timer: any;
    if (isLiveTracking) {
      timer = setInterval(() => {
        setTrackingSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isLiveTracking]);

  const formatTimer = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-[32px] border border-slate-200/90 shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden text-slate-800"
      >
        {/* HEADER */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 sm:p-6 relative overflow-hidden flex flex-col gap-3">
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex items-center justify-between z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md">
                <Moon className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-black text-white">
                    {isIndonesian ? 'Studio Analisis Kualitas Tidur' : 'Sleep Analysis Studio'}
                  </h2>
                  <span className="px-2 py-0.5 rounded-full bg-indigo-400/20 text-indigo-300 text-[10px] font-black border border-indigo-400/30">
                    85 Poin (Optimal)
                  </span>
                </div>
                <p className="text-xs text-slate-300">
                  {isIndonesian ? 'Arsitektur Tahap REM, Deep Sleep, & Pelacak Dengkuran' : 'REM, Deep Sleep Stages & Snore Tracking'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer border border-white/15"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Sub Navigation */}
          <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-md p-1 rounded-2xl border border-white/15 z-10">
            <button
              onClick={() => setActiveTab('overview')}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeTab === 'overview' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-200 hover:text-white'
              }`}
            >
              {isIndonesian ? 'Ringkasan & Skor' : 'Overview & Score'}
            </button>
            <button
              onClick={() => setActiveTab('stages')}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeTab === 'stages' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-200 hover:text-white'
              }`}
            >
              {isIndonesian ? 'Tahap Tidur (Stages)' : 'Sleep Stages'}
            </button>
            <button
              onClick={() => setActiveTab('night_studio')}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeTab === 'night_studio' ? 'bg-indigo-500 text-white shadow-sm' : 'text-slate-200 hover:text-white'
              }`}
            >
              {isIndonesian ? '🌙 Night Mode Tracker' : '🌙 Night Tracker'}
            </button>
          </div>
        </div>

        {/* BODY */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {/* ========================================================================= */}
          {/* TAB 1: OVERVIEW & SCORE (Screenshots 15, 17, 18) */}
          {/* ========================================================================= */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Score & Duration Bento */}
              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center">
                  <span className="text-xs font-black text-slate-400 block uppercase tracking-wider">
                    {isIndonesian ? 'Skor Kualitas' : 'Sleep Score'}
                  </span>
                  <span className="text-4xl font-black text-indigo-600 my-1 block">85</span>
                  <span className="text-xs font-bold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                    {isIndonesian ? 'Sangat Baik (+4%)' : 'Excellent (+4%)'}
                  </span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center">
                  <span className="text-xs font-black text-slate-400 block uppercase tracking-wider">
                    {isIndonesian ? 'Total Durasi' : 'Total Duration'}
                  </span>
                  <span className="text-4xl font-black text-slate-900 my-1 block">7h 45m</span>
                  <span className="text-xs font-bold text-slate-500">
                    {isIndonesian ? 'Target: 8h 00m' : 'Target: 8h 00m'}
                  </span>
                </div>
              </div>

              {/* Circular Sleep Stage Breakdown Visual (Screenshot 15 & 17) */}
              <div className="bg-gradient-to-br from-indigo-50/50 to-slate-50 border border-indigo-100 rounded-3xl p-5 sm:p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-slate-900">
                    {isIndonesian ? 'Komposisi Siklus & Arsitektur Tidur' : 'Sleep Cycle Architecture'}
                  </h3>
                  <span className="text-xs text-indigo-600 font-bold">4 Siklus Penuh</span>
                </div>

                {/* Horizontal Multi-color Stage Bar */}
                <div className="w-full h-5 rounded-full overflow-hidden flex shadow-inner">
                  <div style={{ width: '25%' }} className="bg-indigo-600 h-full" title="REM: 25%" />
                  <div style={{ width: '50%' }} className="bg-teal-400 h-full" title="Light: 50%" />
                  <div style={{ width: '20%' }} className="bg-purple-700 h-full" title="Deep: 20%" />
                  <div style={{ width: '5%' }} className="bg-rose-400 h-full" title="Awake: 5%" />
                </div>

                {/* Stage Legend */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-indigo-600" />
                    <div>
                      <div className="text-xs font-black text-slate-900">REM: 25%</div>
                      <div className="text-[10px] text-slate-500">1h 45m</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-teal-400" />
                    <div>
                      <div className="text-xs font-black text-slate-900">Light: 50%</div>
                      <div className="text-[10px] text-slate-500">3h 52m</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-purple-700" />
                    <div>
                      <div className="text-xs font-black text-slate-900">Deep: 20%</div>
                      <div className="text-[10px] text-slate-500">1h 33m</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-rose-400" />
                    <div>
                      <div className="text-xs font-black text-slate-900">Awake: 5%</div>
                      <div className="text-[10px] text-slate-500">23m</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* AI Sleep Hygiene Recommendations (Screenshot 15) */}
              <div className="space-y-2.5">
                <h3 className="text-xs font-black text-slate-900 uppercase tracking-wide">
                  {isIndonesian ? 'Saran Personalisasi AI untuk Tidur Nyenyak:' : 'AI Sleep Hygiene Suggestions:'}
                </h3>
                <div className="space-y-2">
                  <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200">
                    <Sparkles className="w-4 h-4 text-indigo-600 mt-0.5 shrink-0" />
                    <div>
                      <span className="text-xs font-black text-slate-900">
                        {isIndonesian ? 'Kurangi Paparan Layar 45 Menit Sebelum Tidur' : 'Limit Blue-Light Screen Exposure'}
                      </span>
                      <p className="text-xs text-slate-500">
                        {isIndonesian ? 'Meningkatkan pelepasan melatonin alami tubuh sebesar 32%.' : 'Boosts natural melatonin secretion by 32%.'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200">
                    <Sparkles className="w-4 h-4 text-teal-600 mt-0.5 shrink-0" />
                    <div>
                      <span className="text-xs font-black text-slate-900">
                        {isIndonesian ? 'Pertahankan Suhu Kamar Ideal (19-21°C)' : 'Room Temperature Calibration (19-21°C)'}
                      </span>
                      <p className="text-xs text-slate-500">
                        {isIndonesian ? 'Memaksimalkan durasi Deep Sleep untuk pemulihan otot.' : 'Maximizes restorative slow-wave deep sleep.'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 2: HYPNOGRAM STAGES GRAPH (Screenshots 17 & 18) */}
          {/* ========================================================================= */}
          {activeTab === 'stages' && (
            <div className="space-y-6">
              <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-6 space-y-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-mono text-slate-400">HYPNOGRAM GRAPH (22:30 - 06:15)</span>
                  <span className="text-indigo-400 font-bold">Kualitas 90%</span>
                </div>

                {/* SVG Hypnogram Wave */}
                <div className="h-44 w-full flex items-center justify-center">
                  <svg className="w-full h-full text-indigo-400 stroke-current" viewBox="0 0 400 120" fill="none">
                    {/* Background Stage Guides */}
                    <line x1="0" y1="20" x2="400" y2="20" stroke="#334155" strokeDasharray="3 3" />
                    <line x1="0" y1="50" x2="400" y2="50" stroke="#334155" strokeDasharray="3 3" />
                    <line x1="0" y1="80" x2="400" y2="80" stroke="#334155" strokeDasharray="3 3" />
                    <line x1="0" y1="110" x2="400" y2="110" stroke="#334155" strokeDasharray="3 3" />

                    {/* Sleep Wave Path */}
                    <path
                      d="M 0,20 L 30,20 L 50,80 L 80,110 L 110,110 L 130,50 L 160,50 L 180,110 L 220,110 L 250,50 L 280,20 L 310,80 L 350,110 L 380,50 L 400,20"
                      strokeWidth="3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-teal-400"
                    />
                  </svg>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-2 border-t border-slate-800">
                  <span>22:30 (Tidur)</span>
                  <span>01:00</span>
                  <span>03:30</span>
                  <span>06:15 (Bangun)</span>
                </div>
              </div>

              {/* Snore & Sound Detector Stats */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Volume2 className="w-4 h-4 text-slate-600" />
                    <span className="text-xs font-black text-slate-900">
                      {isIndonesian ? 'Deteksi Dengkuran & Kebisingan Suara' : 'Snoring & Sound Analysis'}
                    </span>
                  </div>
                  <span className="text-xs font-extrabold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                    Rendah (17m total)
                  </span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {isIndonesian
                    ? 'Mikrofon mendeteksi 2 episode dengkuran ringan pada pukul 02:12 dan 04:37 tanpa indikasi sleep apnea.'
                    : '2 mild snore episodes recorded at 02:12 and 04:37 with zero sleep apnea indicators.'}
                </p>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 3: NIGHT MODE TRACKER (Screenshots 18, 19, 20) */}
          {/* ========================================================================= */}
          {activeTab === 'night_studio' && (
            <div className="bg-slate-950 text-white rounded-3xl p-6 sm:p-8 flex flex-col items-center justify-center text-center space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl" />

              {/* Night Sky Visual & Moon */}
              <div className="relative">
                <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-amber-200 to-amber-100 shadow-2xl shadow-amber-200/30 flex items-center justify-center text-slate-950 text-4xl">
                  🌙
                </div>
                <div className="absolute -top-1 -right-1 text-xs text-amber-300 animate-pulse">✨</div>
                <div className="absolute -bottom-2 -left-2 text-xs text-indigo-300 animate-pulse">⭐</div>
              </div>

              <div className="space-y-1">
                <span className="text-xs font-mono text-indigo-400 tracking-widest uppercase">
                  {isLiveTracking ? 'SESI TIDUR AKTIF SEDANG BERJALAN' : 'SIAP MEMULAI PELACAKAN MALAM'}
                </span>
                <div className="text-4xl sm:text-5xl font-black font-mono tracking-tight text-white">
                  {formatTimer(trackingSeconds)}
                </div>
                <p className="text-xs text-slate-400">
                  {isIndonesian ? 'Waktu tidur: 22:55 • Alarm: 06:30' : 'Bedtime: 22:55 • Smart Alarm: 06:30'}
                </p>
              </div>

              {/* Interactive Start/Stop Controls */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsLiveTracking(!isLiveTracking)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full text-xs font-black transition-all cursor-pointer shadow-lg ${
                    isLiveTracking
                      ? 'bg-rose-600 text-white hover:bg-rose-700 shadow-rose-600/30'
                      : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-600/30'
                  }`}
                >
                  {isLiveTracking ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>
                    {isLiveTracking
                      ? isIndonesian ? 'Jeda Sesi Tidur' : 'Pause Session'
                      : isIndonesian ? 'Mulai Pelacakan Tidur' : 'Start Night Tracking'}
                  </span>
                </button>

                <button
                  onClick={() => setIsAudioRecording(!isAudioRecording)}
                  className={`p-3 rounded-full border transition-all cursor-pointer ${
                    isAudioRecording
                      ? 'bg-white/10 text-emerald-400 border-emerald-400/40'
                      : 'bg-white/5 text-slate-400 border-white/10'
                  }`}
                  title={isAudioRecording ? 'Audio detection ON' : 'Audio detection OFF'}
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
