import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  X,
  Send,
  Mic,
  MicOff,
  Stethoscope,
  ShieldCheck,
  Heart,
  Thermometer,
  AlertTriangle,
  FileText,
  Camera,
  Activity,
  UserCheck,
  Pill,
  ChevronRight,
  RefreshCw,
  Clock,
  ArrowRight,
  Smile,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface AiHealthCompanionModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onLaunchDoctorConsult?: () => void;
}

export const AiHealthCompanionModal: React.FC<AiHealthCompanionModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onLaunchDoctorConsult,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // Active Mode: 'guide' (Orb / Voice) | 'symptoms' (Interactive Checker) | 'chat' (Conversational) | 'photo' (Image Vision)
  const [activeMode, setActiveMode] = useState<'guide' | 'symptoms' | 'chat' | 'photo'>('guide');

  // Interactive Symptom State (Screenshots 10 & 14)
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [severityLevel, setSeverityLevel] = useState<'low' | 'mid' | 'moderate' | 'severe'>('mid');
  const [symptomDuration, setSymptomDuration] = useState<string>('2-3 days');
  const [isAnalyzingSymptoms, setIsAnalyzingSymptoms] = useState(false);
  const [symptomResult, setSymptomResult] = useState<any | null>(null);

  // Chat State (Screenshots 2, 4, 8, 9, 13)
  const [inputMessage, setInputMessage] = useState('');
  const [isAiTyping, setIsAiTyping] = useState(false);
  const [messages, setMessages] = useState<Array<{ id: string; sender: 'ai' | 'user'; text: string; time: string; card?: any }>>([
    {
      id: 'm1',
      sender: 'ai',
      text: isIndonesian
        ? `Halo ${userProfile.name}! Saya Clara, AI Health Guide Anda. Ada keluhan fisik, pertanyaan gizi, atau ingin mengecek ritme jantung hari ini?`
        : `Hi ${userProfile.name}! I am Clara, your AI Health Guide. How are you feeling today? Any symptoms, questions, or vitals you want to review?`,
      time: 'Just now',
    },
  ]);

  // Voice Listening Simulation
  const [isListening, setIsListening] = useState(false);

  // Quick symptom options
  const symptomList = [
    { id: 'fever', label: isIndonesian ? 'Demam' : 'Fever', icon: '🌡️' },
    { id: 'headache', label: isIndonesian ? 'Sakit Kepala' : 'Headache', icon: '🤕' },
    { id: 'stomach', label: isIndonesian ? 'Nyeri Perut' : 'Stomach Pain', icon: '🤢' },
    { id: 'breath', label: isIndonesian ? 'Sesak Napas' : 'Shortness of Breath', icon: '🫁' },
    { id: 'fatigue', label: isIndonesian ? 'Kelelahan Ekstrem' : 'Extreme Fatigue', icon: '😴' },
    { id: 'cough', label: isIndonesian ? 'Batuk & Radang' : 'Cough & Sore Throat', icon: '😷' },
    { id: 'chest', label: isIndonesian ? 'Dada Berdebar' : 'Chest Palpitations', icon: '💓' },
    { id: 'nausea', label: isIndonesian ? 'Mual & Pusing' : 'Nausea & Dizziness', icon: '😵' },
  ];

  const handleToggleSymptom = (label: string) => {
    if (selectedSymptoms.includes(label)) {
      setSelectedSymptoms(selectedSymptoms.filter((s) => s !== label));
    } else {
      setSelectedSymptoms([...selectedSymptoms, label]);
    }
  };

  const handleRunSymptomCheck = async () => {
    if (selectedSymptoms.length === 0) return;
    setIsAnalyzingSymptoms(true);
    setSymptomResult(null);

    try {
      const res = await fetch('/api/doctor/triage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          intake: {
            patientName: userProfile.name,
            patientAge: userProfile.age,
            patientGender: userProfile.gender,
            chiefComplaint: `Symptom Check: ${selectedSymptoms.join(', ')}`,
            symptomDuration: symptomDuration,
            painScaleVas: severityLevel === 'severe' ? 8 : severityLevel === 'moderate' ? 6 : severityLevel === 'mid' ? 4 : 2,
            painCharacter: 'dull_aching',
            associatedSymptoms: selectedSymptoms,
            existingConditions: [],
            currentMedications: 'None',
            drugOrFoodAllergies: 'None',
            lifestyleFactors: {
              sleepHoursLastNight: 7.5,
              stressLevel: 4,
              waterIntakeLiters: 2.0,
              recentUnusualDietOrActivity: 'Standard routine',
            },
            vitals: {
              heartRateBpm: 86,
              systolicBp: 118,
              diastolicBp: 76,
              bodyTempCelsius: selectedSymptoms.includes('Demam') || selectedSymptoms.includes('Fever') ? 38.4 : 36.6,
            },
          },
          language: userProfile.language,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setSymptomResult(data);
      } else {
        // Fallback result
        setSymptomResult({
          triageVerdict: isIndonesian ? 'Kategori Ringan - Disarankan Istirahat & Hidrasi' : 'Mild Category - Rest & Hydration Recommended',
          primaryDiagnosis: {
            conditionName: isIndonesian ? 'Sindrom Kelelahan & Gejala Flu Awal' : 'Fatigue Syndrome & Early Viral Onset',
            confidenceScorePercent: 88,
            clinicalReasoning: isIndonesian
              ? 'Gejala konsisten dengan kelelahan fisik atau infeksi virus ringan. Tidak ditemukan tanda bahaya darurat (red flag).'
              : 'Symptoms are consistent with physical fatigue or mild viral infection without emergency red-flags.',
          },
          prescriptionAndHomeCare: {
            otcMedicationGuidance: [
              {
                medicineName: 'Paracetamol 500mg',
                dosageAdvice: isIndonesian ? '1 tablet setiap 6-8 jam bila demam atau nyeri' : '1 tab every 6-8 hours if feverish',
              },
              {
                medicineName: isIndonesian ? 'Vitamin C + Zinc' : 'Vitamin C + Zinc',
                dosageAdvice: isIndonesian ? '1 kali sehari setelah makan' : 'Once daily post-meal',
              },
            ],
            nonPharmacologicalCare: [
              {
                category: isIndonesian ? 'Hidrasi' : 'Hydration',
                title: isIndonesian ? 'Minum Air Hangat 2.5L' : 'Warm Water 2.5L',
                actionGuidance: isIndonesian ? 'Cukupi cairan dan hindari minuman dingin/kafein' : 'Drink ample water and avoid caffeine',
              },
            ],
          },
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAnalyzingSymptoms(false);
    }
  };

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || inputMessage;
    if (!textToSend.trim()) return;

    const userMsg = {
      id: `msg_${Date.now()}`,
      sender: 'user' as const,
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsAiTyping(true);

    try {
      const res = await fetch('/api/doctor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          patientContext: {
            name: userProfile.name,
            age: userProfile.age,
            goal: userProfile.fitnessGoal,
            language: userProfile.language,
          },
          language: userProfile.language,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setMessages((prev) => [
          ...prev,
          {
            id: `msg_ai_${Date.now()}`,
            sender: 'ai',
            text: data.reply,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            id: `msg_ai_${Date.now()}`,
            sender: 'ai',
            text: isIndonesian
              ? `Berdasarkan data kesehatan Anda, detak jantung 86 bpm dan skor tidur 85 poin berada dalam rentang sangat baik. Apakah ada keluhan spesifik yang ingin diperiksa lebih lanjut?`
              : `Based on your vitals, your 86 bpm heart rate and 85 sleep score are in optimal shape. Is there any specific discomfort you would like us to analyze?`,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsAiTyping(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/60 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="bg-white rounded-[32px] border border-slate-200/90 shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden text-slate-800"
      >
        {/* HEADER BAR WITH MODES (Screenshots 2, 4, 9, 14) */}
        <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white p-5 sm:p-6 relative overflow-hidden flex flex-col gap-3">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-400/15 rounded-full blur-3xl pointer-events-none" />

          <div className="flex items-center justify-between z-10">
            <div className="flex items-center gap-3">
              {/* Cute Mascot Icon / Glowing Avatar */}
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-200 text-slate-950 flex items-center justify-center font-black shadow-md shadow-emerald-500/20">
                <Sparkles className="w-5 h-5 text-emerald-950" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-black text-white">
                    Clara AI Health Companion
                  </h2>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 text-[10px] font-extrabold border border-emerald-400/30">
                    Gemini 3.6
                  </span>
                </div>
                <p className="text-xs text-slate-300">
                  {isIndonesian ? 'Panduan Diagnostik & Konsultasi Pintar' : 'Autonomous Clinical & Wellness Assistant'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer border border-white/15"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* MODE TABS (Guide / Symptoms / Chat / Photo) */}
          <div className="flex items-center gap-1.5 bg-white/10 backdrop-blur-md p-1 rounded-2xl border border-white/15 z-10">
            <button
              onClick={() => setActiveMode('guide')}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeMode === 'guide' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-200 hover:text-white'
              }`}
            >
              {isIndonesian ? 'AI Voice & Guide' : 'AI Voice & Guide'}
            </button>
            <button
              onClick={() => setActiveMode('symptoms')}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeMode === 'symptoms' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-200 hover:text-white'
              }`}
            >
              {isIndonesian ? 'Cek Gejala' : 'Symptom Checker'}
            </button>
            <button
              onClick={() => setActiveMode('chat')}
              className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeMode === 'chat' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-200 hover:text-white'
              }`}
            >
              {isIndonesian ? 'Tanya AI' : 'Ask AI'}
            </button>
          </div>
        </div>

        {/* MODAL BODY CONTENT */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {/* ========================================================================= */}
          {/* MODE 1: AI VOICE & GUIDE ORB (Screenshots 4, 7, 9, 14) */}
          {/* ========================================================================= */}
          {activeMode === 'guide' && (
            <div className="flex flex-col items-center justify-center text-center space-y-6 py-4">
              {/* 3D Iridescent Glowing Sphere Orb */}
              <div className="relative flex items-center justify-center">
                <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-full bg-gradient-to-tr from-teal-400 via-emerald-300 to-amber-200 shadow-2xl shadow-emerald-400/40 animate-pulse flex items-center justify-center border-4 border-white">
                  <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-gradient-to-br from-emerald-500 via-teal-400 to-cyan-300 opacity-90 blur-xs flex items-center justify-center text-white">
                    <Sparkles className="w-12 h-12 text-white/90 animate-spin" style={{ animationDuration: '8s' }} />
                  </div>
                </div>
                {/* Orbital Rings */}
                <div className="absolute inset-0 -m-4 border border-emerald-300/40 rounded-full animate-ping opacity-30 pointer-events-none" />
              </div>

              <div className="space-y-1.5">
                <span className="text-xs font-extrabold text-emerald-700 uppercase tracking-widest bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full">
                  {isListening ? 'Mendengarkan suara...' : 'Clara AI Voice Active'}
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                  {isIndonesian ? `Hai ${userProfile.name}! Siap cek kesehatan hari ini?` : `Hi ${userProfile.name}! Ready to track your health?`}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
                  {isIndonesian
                    ? 'Pilih panduan instan di bawah atau ketuk mikrofon untuk mulai berdialog medis dengan dokter AI.'
                    : 'Select a quick action below or tap the microphone to start your AI diagnostic conversation.'}
                </p>
              </div>

              {/* Quick Action Prompt Chips (Screenshots 2, 4, 9, 14) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full max-w-md">
                <button
                  onClick={() => setActiveMode('symptoms')}
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 transition-all text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-rose-100 text-rose-600 group-hover:scale-110 transition-transform">
                      <Heart className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900">
                        {isIndonesian ? 'Cek Gejala & Nyeri' : 'Check Symptoms & Pain'}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {isIndonesian ? 'Triase klinis 2 detik' : '2-sec AI intake'}
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                </button>

                <button
                  onClick={() => {
                    setActiveMode('chat');
                    handleSendMessage(isIndonesian ? 'Bagaimana ringkasan skor kesehatan saya hari ini?' : 'How is my overall health score today?');
                  }}
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 transition-all text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-teal-100 text-teal-600 group-hover:scale-110 transition-transform">
                      <Activity className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900">
                        {isIndonesian ? 'Analisis Skor Tidur' : 'Sleep Score Analysis'}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {isIndonesian ? '85 Poin • 7h 45m' : '85 Pts • 7h 45m'}
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                </button>

                <button
                  onClick={() => {
                    if (onLaunchDoctorConsult) {
                      onClose();
                      onLaunchDoctorConsult();
                    }
                  }}
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 transition-all text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-emerald-100 text-emerald-700 group-hover:scale-110 transition-transform">
                      <Stethoscope className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900">
                        {isIndonesian ? 'Konsultasi Dokter AI' : 'Doctor AI Consultation'}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {isIndonesian ? 'Anamnesis SOAP Lengkap' : 'Full SOAP Diagnostic'}
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                </button>

                <button
                  onClick={() => {
                    setActiveMode('chat');
                    handleSendMessage(isIndonesian ? 'Rekomendasikan obat dan suplemen untuk menjaga daya tahan tubuh.' : 'Suggest essential supplements for recovery and immunity.');
                  }}
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 transition-all text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-amber-100 text-amber-700 group-hover:scale-110 transition-transform">
                      <Pill className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-900">
                        {isIndonesian ? 'Rekomendasi Suplemen' : 'Supplement Advisor'}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {isIndonesian ? 'Vitamin C, Zinc, Omega 3' : 'Immunity & Recovery'}
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                </button>
              </div>

              {/* Voice Interaction Mic Button */}
              <button
                onClick={() => setIsListening(!isListening)}
                className={`flex items-center gap-2 px-6 py-3 rounded-full text-xs font-black transition-all cursor-pointer shadow-lg ${
                  isListening
                    ? 'bg-rose-600 text-white animate-pulse shadow-rose-600/30'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/30'
                }`}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                <span>
                  {isListening
                    ? isIndonesian ? 'Hentikan Mendengarkan' : 'Stop Listening'
                    : isIndonesian ? 'Bicara Sekarang dengan Clara' : 'Speak with Clara'}
                </span>
              </button>
            </div>
          )}

          {/* ========================================================================= */}
          {/* MODE 2: INTERACTIVE SYMPTOM CHECKER (Screenshots 10 & 14) */}
          {/* ========================================================================= */}
          {activeMode === 'symptoms' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-black text-slate-900">
                  {isIndonesian ? 'Pilih Gejala yang Anda Rasakan' : 'Select Symptoms You Are Experiencing'}
                </h3>
                <p className="text-xs text-slate-500">
                  {isIndonesian ? 'Pilih satu atau lebih gejala dalam 12 jam terakhir:' : 'Choose one or more symptoms from the last 12 hours:'}
                </p>
              </div>

              {/* Visual Symptom Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {symptomList.map((sym) => {
                  const isSelected = selectedSymptoms.includes(sym.label);
                  return (
                    <button
                      key={sym.id}
                      onClick={() => handleToggleSymptom(sym.label)}
                      className={`flex flex-col items-center justify-center p-3 rounded-2xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-md scale-102 font-black'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200 font-bold'
                      }`}
                    >
                      <span className="text-2xl mb-1">{sym.icon}</span>
                      <span className="text-xs text-center leading-tight">{sym.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Severity Level Indicator (Screenshots 10 & 14) */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <label className="text-xs font-black text-slate-900 block">
                  {isIndonesian ? 'Tingkat Keparahan / Skala Nyeri (Severity):' : 'Severity Level:'}
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'low', label: isIndonesian ? 'Ringan' : 'Low', color: 'bg-emerald-100 text-emerald-800 border-emerald-300' },
                    { id: 'mid', label: isIndonesian ? 'Sedang' : 'Mid', color: 'bg-teal-100 text-teal-800 border-teal-300' },
                    { id: 'moderate', label: isIndonesian ? 'Kuat' : 'Moderate', color: 'bg-amber-100 text-amber-800 border-amber-300' },
                    { id: 'severe', label: isIndonesian ? 'Parah' : 'Severe', color: 'bg-rose-100 text-rose-800 border-rose-300' },
                  ].map((sev) => (
                    <button
                      key={sev.id}
                      onClick={() => setSeverityLevel(sev.id as any)}
                      className={`py-2 px-1 rounded-xl text-xs font-black border transition-all cursor-pointer text-center ${
                        severityLevel === sev.id
                          ? `${sev.color} ring-2 ring-emerald-500 font-black shadow-xs`
                          : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {sev.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Symptom Duration Selector */}
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-900 block">
                  {isIndonesian ? 'Berapa lama gejala ini berlangsung?' : 'How long have you had these symptoms?'}
                </label>
                <div className="flex flex-wrap gap-2">
                  {['< 1 hour', 'A few hours', '1-2 days', '3-7 days', '> 1 week'].map((dur) => (
                    <button
                      key={dur}
                      onClick={() => setSymptomDuration(dur)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                        symptomDuration === dur
                          ? 'bg-slate-900 text-white border-slate-900 font-black'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {dur}
                    </button>
                  ))}
                </div>
              </div>

              {/* Submit & Analyze Button */}
              <button
                onClick={handleRunSymptomCheck}
                disabled={selectedSymptoms.length === 0 || isAnalyzingSymptoms}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all cursor-pointer"
              >
                {isAnalyzingSymptoms ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{isIndonesian ? 'Clara sedang menganalisis gejala Anda (2 detik)...' : 'Clara is analyzing your symptoms...'}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>{isIndonesian ? 'Analisis Gejala dengan AI Gemini' : 'Analyze Symptoms with AI'}</span>
                  </>
                )}
              </button>

              {/* SYMPTOM DIAGNOSIS RESULT CARD */}
              {symptomResult && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-slate-50 border border-emerald-200 rounded-2xl p-4 sm:p-5 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black border border-emerald-300">
                      {symptomResult.triageVerdict || 'Hasil Triase'}
                    </span>
                    <span className="text-xs font-black text-slate-500">
                      Akurasi: {symptomResult.primaryDiagnosis?.confidenceScorePercent || 90}%
                    </span>
                  </div>

                  <h4 className="text-sm font-black text-slate-900">
                    {symptomResult.primaryDiagnosis?.conditionName}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {symptomResult.primaryDiagnosis?.clinicalReasoning}
                  </p>

                  {/* OTC Med Recommendations */}
                  {symptomResult.prescriptionAndHomeCare?.otcMedicationGuidance && (
                    <div className="pt-2 border-t border-slate-200/80 space-y-1.5">
                      <div className="text-[11px] font-black text-slate-800 flex items-center gap-1.5">
                        <Pill className="w-3.5 h-3.5 text-amber-600" />
                        <span>{isIndonesian ? 'Rekomendasi Perawatan / Obat Bebas (OTC):' : 'OTC Care Guidance:'}</span>
                      </div>
                      {symptomResult.prescriptionAndHomeCare.otcMedicationGuidance.map((med: any, i: number) => (
                        <div key={i} className="text-xs bg-white p-2.5 rounded-xl border border-slate-200">
                          <span className="font-black text-slate-900">{med.medicineName}: </span>
                          <span className="text-slate-600">{med.dosageAdvice}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {onLaunchDoctorConsult && (
                    <button
                      onClick={() => {
                        onClose();
                        onLaunchDoctorConsult();
                      }}
                      className="w-full mt-2 py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-black flex items-center justify-center gap-2 cursor-pointer transition-colors"
                    >
                      <Stethoscope className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{isIndonesian ? 'Konsultasi Lengkap dengan Dokter AI Spesialis' : 'Consult with Clinical AI Specialist'}</span>
                    </button>
                  )}
                </motion.div>
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* MODE 3: CONVERSATIONAL CHAT (Screenshots 2, 4, 8, 9, 13) */}
          {/* ========================================================================= */}
          {activeMode === 'chat' && (
            <div className="flex flex-col h-[380px]">
              {/* Chat Message List */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    {msg.sender === 'ai' && (
                      <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xs font-black shrink-0">
                        <Sparkles className="w-3.5 h-3.5" />
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                        msg.sender === 'user'
                          ? 'bg-emerald-600 text-white rounded-tr-xs shadow-xs font-medium'
                          : 'bg-slate-100 text-slate-800 rounded-tl-xs border border-slate-200/80 font-normal'
                      }`}
                    >
                      <p>{msg.text}</p>
                      <span
                        className={`text-[9px] block mt-1 font-mono ${
                          msg.sender === 'user' ? 'text-emerald-100' : 'text-slate-400'
                        }`}
                      >
                        {msg.time}
                      </span>
                    </div>
                  </div>
                ))}

                {isAiTyping && (
                  <div className="flex items-center gap-2 text-xs text-slate-400 font-bold p-2">
                    <Sparkles className="w-3.5 h-3.5 animate-spin text-emerald-600" />
                    <span>{isIndonesian ? 'Clara sedang mengetik rekomendasi...' : 'Clara is analyzing and typing...'}</span>
                  </div>
                )}
              </div>

              {/* Chat Input Bar */}
              <div className="pt-3 border-t border-slate-200 flex items-center gap-2">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder={isIndonesian ? 'Tanyakan keluhan, tidur, nutrisi, atau suplemen...' : 'Ask about vitals, sleep, diet, or medicine...'}
                  className="flex-1 bg-slate-100 border border-slate-200 rounded-full px-4 py-2.5 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />
                <button
                  onClick={() => handleSendMessage()}
                  disabled={!inputMessage.trim() || isAiTyping}
                  className="p-2.5 rounded-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white cursor-pointer shadow-md transition-colors"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
