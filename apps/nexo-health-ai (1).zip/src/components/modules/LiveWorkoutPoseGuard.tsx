import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Dumbbell,
  Play,
  Pause,
  Square,
  Clock,
  Flame,
  Heart,
  Activity,
  CheckCircle2,
  X,
  Camera,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface LiveWorkoutPoseGuardProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
}

export const LiveWorkoutPoseGuard: React.FC<LiveWorkoutPoseGuardProps> = ({
  isOpen,
  onClose,
  userProfile,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [isActive, setIsActive] = useState(true);
  const [seconds, setSeconds] = useState(272); // 4:32 default
  const [repsCount, setRepsCount] = useState(14);
  const [caloriesBurned, setCaloriesBurned] = useState(112);
  const [liveBpm, setLiveBpm] = useState(121);
  const [poseAccuracyPercent, setPoseAccuracyPercent] = useState(96);

  useEffect(() => {
    let interval: any;
    if (isActive) {
      interval = setInterval(() => {
        setSeconds((prev) => prev + 1);
        if (Math.random() > 0.6) {
          setRepsCount((r) => r + 1);
          setCaloriesBurned((c) => c + 1);
          setLiveBpm((b) => 118 + Math.floor(Math.random() * 8));
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isActive]);

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/75 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-slate-900 text-white rounded-[32px] border border-slate-700 shadow-2xl w-full max-w-lg overflow-hidden flex flex-col relative"
      >
        {/* Top Floating Controls */}
        <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between">
          <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-700">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-xs font-black text-white">
              {isIndonesian ? 'Pose Guard AI Live' : 'AI Landmark Tracking'}
            </span>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-900/80 text-white flex items-center justify-center border border-slate-700 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Camera Simulation Screen (Screenshot 3 Right) */}
        <div className="relative h-96 w-full bg-gradient-to-b from-slate-800 to-slate-950 flex items-center justify-center overflow-hidden">
          {/* Background Grid Lines */}
          <div className="absolute inset-0 bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:16px_16px] opacity-30" />

          {/* Athlete Visual Silhouette & Landmark Joint Dots */}
          <div className="relative z-10 flex flex-col items-center">
            {/* Pose Skeleton Joint Nodes */}
            <div className="relative w-48 h-72 flex items-center justify-center">
              {/* Head Dot */}
              <div className="absolute top-4 w-5 h-5 rounded-full bg-teal-400 border-2 border-white shadow-lg animate-pulse" />
              {/* Shoulder Nodes */}
              <div className="absolute top-16 left-8 w-4 h-4 rounded-full bg-emerald-400 border-2 border-white shadow-md" />
              <div className="absolute top-16 right-8 w-4 h-4 rounded-full bg-emerald-400 border-2 border-white shadow-md" />
              {/* Elbow Nodes */}
              <div className="absolute top-28 left-4 w-3.5 h-3.5 rounded-full bg-teal-300 border-2 border-white shadow-md" />
              <div className="absolute top-28 right-4 w-3.5 h-3.5 rounded-full bg-teal-300 border-2 border-white shadow-md" />
              {/* Hip Nodes */}
              <div className="absolute top-36 left-12 w-4 h-4 rounded-full bg-emerald-400 border-2 border-white shadow-md" />
              <div className="absolute top-36 right-12 w-4 h-4 rounded-full bg-emerald-400 border-2 border-white shadow-md" />
              {/* Knee Nodes */}
              <div className="absolute top-52 left-10 w-4 h-4 rounded-full bg-cyan-400 border-2 border-white shadow-md" />
              <div className="absolute top-48 right-14 w-4 h-4 rounded-full bg-cyan-400 border-2 border-white shadow-md animate-bounce" />
              {/* Ankle Nodes */}
              <div className="absolute bottom-2 left-8 w-3.5 h-3.5 rounded-full bg-teal-300 border-2 border-white" />
              <div className="absolute bottom-8 right-16 w-3.5 h-3.5 rounded-full bg-teal-300 border-2 border-white" />

              {/* Connecting Skeleton Lines SVG */}
              <svg className="absolute inset-0 w-full h-full text-emerald-400/60 stroke-current" strokeWidth="2">
                <line x1="96" y1="24" x2="96" y2="70" />
                <line x1="40" y1="70" x2="152" y2="70" />
                <line x1="40" y1="70" x2="20" y2="116" />
                <line x1="152" y1="70" x2="172" y2="116" />
                <line x1="56" y1="150" x2="136" y2="150" />
                <line x1="56" y1="150" x2="46" y2="214" />
                <line x1="136" y1="150" x2="146" y2="200" />
                <line x1="46" y1="214" x2="40" y2="276" />
                <line x1="146" y1="200" x2="136" y2="250" />
              </svg>
            </div>
          </div>

          {/* Floating Vitals Badges */}
          <div className="absolute top-16 right-4 flex flex-col gap-2 z-20">
            <div className="bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-slate-700 text-right">
              <span className="text-[10px] text-slate-400 block uppercase">Timer</span>
              <span className="text-sm font-black text-amber-400 font-mono">{formatTimer(seconds)}</span>
            </div>
            <div className="bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-slate-700 text-right">
              <span className="text-[10px] text-slate-400 block uppercase">SpO2 Oxygen</span>
              <span className="text-sm font-black text-teal-400 font-mono">97.5%</span>
            </div>
          </div>
        </div>

        {/* Bottom Metrics & Workout Controls (Screenshot 3 Right) */}
        <div className="p-5 bg-slate-900 border-t border-slate-800 space-y-4">
          <div className="grid grid-cols-3 gap-3 text-center">
            {/* Calories Burned */}
            <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700/80">
              <div className="flex items-center justify-center gap-1 text-amber-400 text-[10px] font-bold">
                <Flame className="w-3.5 h-3.5" />
                <span>KALORI</span>
              </div>
              <div className="text-xl font-black text-white mt-0.5">{caloriesBurned}</div>
              <span className="text-[10px] text-slate-400">kcal</span>
            </div>

            {/* Reps Count */}
            <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700/80">
              <div className="flex items-center justify-center gap-1 text-emerald-400 text-[10px] font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>REPETISI</span>
              </div>
              <div className="text-xl font-black text-white mt-0.5">{repsCount}</div>
              <span className="text-[10px] text-slate-400">reps (96% Form)</span>
            </div>

            {/* Live BPM */}
            <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700/80">
              <div className="flex items-center justify-center gap-1 text-rose-400 text-[10px] font-bold">
                <Heart className="w-3.5 h-3.5 fill-rose-500" />
                <span>HEART RATE</span>
              </div>
              <div className="text-xl font-black text-white mt-0.5">{liveBpm}</div>
              <span className="text-[10px] text-slate-400">bpm</span>
            </div>
          </div>

          {/* Action Button: Pause & Stop */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsActive(!isActive)}
              className="flex-1 py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-black text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-slate-700"
            >
              {isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isActive ? 'Jeda Latihan' : 'Lanjutkan'}</span>
            </button>

            <button
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-black text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg shadow-rose-600/30"
            >
              <Square className="w-4 h-4 fill-white" />
              <span>Selesai (STOP)</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
