import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Zap,
  Activity,
  Sliders,
  Cpu,
  ArrowRight,
  CheckCircle2,
  Layers,
  HeartPulse,
  Brain,
  ShieldCheck,
  Stethoscope,
  Utensils,
  Dumbbell,
  Play,
  RefreshCw,
} from 'lucide-react';
import { HealthModuleMetadata, UserProfile } from '../../types';
import { HEALTH_MODULES } from '../../data/healthModulesData';

interface ModuleSynergyWorkbenchProps {
  userProfile: UserProfile;
  activeModule: HealthModuleMetadata;
  onSelectModule: (mod: HealthModuleMetadata) => void;
  isIndonesian?: boolean;
}

export const ModuleSynergyWorkbench: React.FC<ModuleSynergyWorkbenchProps> = ({
  userProfile,
  activeModule,
  onSelectModule,
  isIndonesian = true,
}) => {
  const [activeTab, setActiveTab] = useState<'simulator' | 'synergy_map' | 'gemini_pipeline'>('simulator');
  const [userExertionLevel, setUserExertionLevel] = useState<number>(75);
  const [userFatigueLevel, setUserFatigueLevel] = useState<number>(40);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationResult, setSimulationResult] = useState<string | null>(null);

  const handleExecuteSimulation = () => {
    setIsSimulating(true);
    setSimulationResult(null);

    setTimeout(() => {
      setIsSimulating(false);
      if (activeModule.category === 'sport_physical') {
        setSimulationResult(
          isIndonesian
            ? `⚡ [Gemini Live Biomechanics]: Beban eksersi ${userExertionLevel}% dengan keletihan ${userFatigueLevel}% memicu modulasi volume -15%. Rekomendasi: Fokus latihan eksentrik terkontrol, repetisi RPE 7-8, dan pendinginan myofascial release 8 menit.`
            : `⚡ [Gemini Live Biomechanics]: Exertion ${userExertionLevel}% with fatigue ${userFatigueLevel}% triggered auto-deload -15%. Recommended: Eccentric controlled tempo, RPE 7-8 target, and 8-min myofascial release cooldown.`
        );
      } else if (activeModule.category === 'nutrition_metabolism') {
        setSimulationResult(
          isIndonesian
            ? `🥗 [Gemini Dietitian Hub]: Rekomendasi karbohidrat kompleks +45g pasca latihan intensif. Tambahkan 350ml air elektrolit kaya kalium dan 30g isolat protein untuk mempercepat sintesis glikogen otot.`
            : `🥗 [Gemini Dietitian Hub]: Post-exertion carbohydrate boost +45g prescribed. Add 350ml potassium-rich electrolyte fluids and 30g whey isolate to accelerate glycogen resynthesis.`
        );
      } else if (activeModule.category === 'mental_emotional') {
        setSimulationResult(
          isIndonesian
            ? `🧘 [Gemini Neural Regulator]: Deteksi kelelahan simpatis ${userFatigueLevel}%. Protokol aktivasi saraf vagus: Jalankan Box Breathing 4x4 detik dilanjutkan afirmasi mindfulness selama 5 menit sebelum tidur.`
            : `🧘 [Gemini Neural Regulator]: Sympathetic strain ${userFatigueLevel}% detected. Vagus nerve protocol: 4x4 Box Breathing followed by 5-min guided mindfulness prior to sleep.`
        );
      } else {
        setSimulationResult(
          isIndonesian
            ? `🩺 [Gemini Clinical Monitor]: Status hemodinamik stabil. HRV 68ms, estimasi usia biologis 24.2 tahun (-3.8 thn dari usia kronologis). Jadwalkan skrining profil lipid kuartal berikutnya.`
            : `🩺 [Gemini Clinical Monitor]: Hemodynamic stability confirmed. HRV 68ms, estimated biological age 24.2 yrs (-3.8 yrs vs chronological). Routine lipid panel check queued for Q3.`
        );
      }
    }, 900);
  };

  // Cross module synergy connections for the active module
  const synergyConnections = [
    {
      source: activeModule.title,
      target: isIndonesian ? 'Health Connect Biometrics' : 'Health Connect Vitals',
      flow: isIndonesian ? 'Sinkronisasi detak jantung & HRV real-time' : 'Real-time HRV & Resting HR sync',
      status: 'Active Live Stream',
    },
    {
      source: activeModule.title,
      target: isIndonesian ? 'EHR Vault & Rekam Medis' : 'EHR Vault & Clinical Record',
      flow: isIndonesian ? 'Penyimpanan terenkripsi Firestore AES-256' : 'AES-256 encrypted Firestore storage',
      status: 'Synced Encrypted',
    },
    {
      source: activeModule.title,
      target: isIndonesian ? 'Gemini 3.6 Autonomous Engine' : 'Gemini 3.6 Autonomous Engine',
      flow: isIndonesian ? 'Inferensi preskripsi klinis adaptif harian' : 'Daily adaptive prescription inference',
      status: 'High Precision',
    },
  ];

  return (
    <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 shadow-xs space-y-6">
      {/* Header with Switcher Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-emerald-600 text-white shadow-md shadow-emerald-600/20">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-black text-slate-900">
                {isIndonesian ? 'AI Workbench & Sinergi Ekosistem 20 Modul' : '20-Module AI Workbench & Synergy'}
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-extrabold text-[10px]">
                Live Lab
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              {isIndonesian
                ? 'Uji coba inferensi langsung dan pantau pertukaran data antar modul AI'
                : 'Test real-time Gemini inferences and monitor cross-module data exchange'}
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'simulator'
                ? 'bg-white text-slate-950 shadow-xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isIndonesian ? 'Simulator Uji AI' : 'Live AI Simulator'}
          </button>

          <button
            onClick={() => setActiveTab('synergy_map')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'synergy_map'
                ? 'bg-white text-slate-950 shadow-xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isIndonesian ? 'Peta Sinergi Modul' : 'Synergy Map'}
          </button>
        </div>
      </div>

      {/* Tab 1: Live Interactive Simulator */}
      {activeTab === 'simulator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Controls Form */}
          <div className="lg:col-span-5 bg-slate-50 rounded-3xl p-5 border border-slate-200/80 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200/80">
              <span className="text-xs font-black text-slate-900 uppercase tracking-wider">
                {isIndonesian ? 'Parameter Input Pengguna' : 'Biometric Input Test'}
              </span>
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                Modul #{activeModule.moduleNumber}
              </span>
            </div>

            {/* Slider 1: Exertion */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700">{isIndonesian ? 'Tingkat Intensitas / Eksersi' : 'Exertion / Intensity'}</span>
                <span className="text-emerald-700 font-mono font-black">{userExertionLevel}%</span>
              </div>
              <input
                type="range"
                min="20"
                max="100"
                value={userExertionLevel}
                onChange={(e) => setUserExertionLevel(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />
            </div>

            {/* Slider 2: Fatigue / Soreness */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-700">{isIndonesian ? 'Skor Kelelahan / DOMS' : 'Fatigue / Soreness'}</span>
                <span className="text-teal-700 font-mono font-black">{userFatigueLevel}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={userFatigueLevel}
                onChange={(e) => setUserFatigueLevel(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-teal-600"
              />
            </div>

            {/* Execute Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleExecuteSimulation}
              disabled={isSimulating}
              className="w-full py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-emerald-600/20 disabled:opacity-50"
            >
              {isSimulating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{isIndonesian ? 'Menjalankan Inferensi Gemini...' : 'Executing Inference...'}</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" />
                  <span>{isIndonesian ? 'Jalankan Inferensi Gemini AI' : 'Run Gemini AI Inference'}</span>
                </>
              )}
            </motion.button>
          </div>

          {/* Inference Output Screen */}
          <div className="lg:col-span-7 bg-slate-950 text-white rounded-3xl p-6 border border-slate-800 shadow-xl space-y-4 flex flex-col justify-between min-h-[240px]">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-mono text-emerald-400 font-bold uppercase tracking-wider">
                    {activeModule.title}
                  </span>
                </div>
                <span className="text-[10px] font-mono text-slate-400">Gemini 3.6 Flash</span>
              </div>

              <div className="pt-3">
                {simulationResult ? (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-200 text-xs sm:text-sm font-medium leading-relaxed font-sans"
                  >
                    {simulationResult}
                  </motion.div>
                ) : (
                  <div className="text-slate-400 text-xs sm:text-sm font-mono leading-relaxed py-4">
                    {isIndonesian
                      ? `Tekan tombol 'Jalankan Inferensi Gemini AI' untuk melihat respon preskripsi dinamis modul #${activeModule.moduleNumber}.`
                      : `Press 'Run Gemini AI Inference' to trigger adaptive clinical prescription for module #${activeModule.moduleNumber}.`}
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono border-t border-slate-900 pt-3">
              <span>Latency: ~120ms</span>
              <span>Model Confidence: 99.4%</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Synergy Map */}
      {activeTab === 'synergy_map' && (
        <div className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            {synergyConnections.map((item, idx) => (
              <div
                key={idx}
                className="bg-slate-50 border border-slate-200/90 rounded-2xl p-4 space-y-2.5 flex flex-col justify-between"
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                      {item.status}
                    </span>
                    <span className="text-xs font-mono text-slate-400">Stream #{idx + 1}</span>
                  </div>
                  <h4 className="text-xs font-black text-slate-900 pt-1">
                    {item.target}
                  </h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
                    {item.flow}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-200/60 flex items-center gap-1.5 text-[11px] font-bold text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{isIndonesian ? 'Terhubung Otomatis' : 'Auto Connected'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
