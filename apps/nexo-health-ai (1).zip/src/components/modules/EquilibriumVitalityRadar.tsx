import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  Activity,
  Moon,
  Utensils,
  Zap,
  ShieldCheck,
  Sparkles,
  ArrowUpRight,
  TrendingUp,
  Sliders,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { UserProfile, DailyLog } from '../../types';

interface EquilibriumVitalityRadarProps {
  userProfile: UserProfile;
  dailyLog: DailyLog;
  isIndonesian?: boolean;
  onNavigateTab?: (tab: any) => void;
}

export const EquilibriumVitalityRadar: React.FC<EquilibriumVitalityRadarProps> = ({
  userProfile,
  dailyLog,
  isIndonesian = true,
  onNavigateTab,
}) => {
  const [activePillarIndex, setActivePillarIndex] = useState<number>(0);

  // 6 Dynamic Health Pillars
  const pillars = [
    {
      id: 'readiness',
      title: isIndonesian ? 'Kesiapan Fisik (HRV)' : 'Physical Readiness (HRV)',
      score: 92,
      status: isIndonesian ? 'Sangat Prima' : 'Peak Optimal',
      desc: isIndonesian
        ? 'HRV 68ms menunjukkan sistem saraf parasimpatis terpulihkan sempurna untuk latihan intensif.'
        : 'HRV 68ms indicates optimal parasympathetic balance ready for high-intensity exertion.',
      icon: Activity,
      color: 'emerald',
      strokeColor: '#10b981',
      bgGlow: 'bg-emerald-500/15',
      route: 'dashboard',
    },
    {
      id: 'cardio',
      title: isIndonesian ? 'Ritme Kardiovaskular' : 'Cardiovascular Rhythm',
      score: 95,
      status: isIndonesian ? 'Sinus Normal' : 'Normal Sinus',
      desc: isIndonesian
        ? 'Detak jantung istirahat 62 bpm dengan tekanan darah 117/73 mmHg tanpa anomali aritmia.'
        : 'Resting HR 62 bpm with 117/73 mmHg blood pressure with zero arrhythmia detection.',
      icon: Heart,
      color: 'rose',
      strokeColor: '#f43f5e',
      bgGlow: 'bg-rose-500/15',
      route: 'doctor_consultation',
    },
    {
      id: 'sleep',
      title: isIndonesian ? 'Arsitektur Tidur' : 'Sleep Hygiene & REM',
      score: 88,
      status: isIndonesian ? 'Tidur Berkualitas' : 'Deep Restorative',
      desc: isIndonesian
        ? 'Total 7 jam 45 menit dengan 1 jam 40 menit deep sleep dan 2 jam REM sleep regeneratif.'
        : '7h 45m total duration with 1h 40m deep restorative sleep and 2h regenerative REM.',
      icon: Moon,
      color: 'indigo',
      strokeColor: '#6366f1',
      bgGlow: 'bg-indigo-500/15',
      route: 'recovery',
    },
    {
      id: 'nutrition',
      title: isIndonesian ? 'Beban Glikemik & Gizi' : 'Nutrition & Glycemic Balance',
      score: 86,
      status: isIndonesian ? 'Seimbang' : 'Well Balanced',
      desc: isIndonesian
        ? 'Asupan protein 92g memenuhi kebutuhan hipertrofi harian dengan defisit kalori terkontrol.'
        : 'Protein intake of 92g meets hypertrophy targets with steady glucose regulation.',
      icon: Utensils,
      color: 'teal',
      strokeColor: '#14b8a6',
      bgGlow: 'bg-teal-500/15',
      route: 'nutrition',
    },
    {
      id: 'cellular',
      title: isIndonesian ? 'Longevity Seluler' : 'Cellular Longevity',
      score: 94,
      status: isIndonesian ? 'Usia Biologis -3.8 Thn' : 'Bio-Age -3.8 Yrs',
      desc: isIndonesian
        ? 'Indeks elastisitas pembuluh darah dan regenerasi mitokondria melampaui usia kronologis.'
        : 'Vascular elasticity index and mitochondrial density surpass chronological expectations.',
      icon: Sparkles,
      color: 'amber',
      strokeColor: '#f59e0b',
      bgGlow: 'bg-amber-500/15',
      route: 'modules_hub',
    },
    {
      id: 'metabolic',
      title: isIndonesian ? 'Metabolisme & Hidrasi' : 'Hydration & Metabolism',
      score: 90,
      status: isIndonesian ? 'Hidrasi Terpenuhi' : 'Optimal Hydration',
      desc: isIndonesian
        ? 'Tingkat hidrasi cairan elektrolit 1.75L menjaga viskositas darah tetap encer dan optimal.'
        : '1.75L fluid volume maintains optimal blood viscosity and renal filtration rates.',
      icon: Zap,
      color: 'cyan',
      strokeColor: '#06b6d4',
      bgGlow: 'bg-cyan-500/15',
      route: 'dashboard',
    },
  ];

  const overallScore = Math.round(
    pillars.reduce((acc, p) => acc + p.score, 0) / pillars.length
  );

  const activePillar = pillars[activePillarIndex];
  const ActiveIcon = activePillar.icon;

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-white rounded-[32px] p-6 sm:p-8 border border-emerald-800/40 shadow-2xl relative overflow-hidden space-y-6">
      {/* Background Ambient Lights */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-emerald-500/15 blur-3xl rounded-full pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-teal-500/10 blur-3xl rounded-full pointer-events-none" />

      {/* Header Row */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[11px] font-black uppercase tracking-wider">
              ✨ {isIndonesian ? 'Equilibrium Biometrik Holistik' : 'Holistic Biometric Equilibrium'}
            </span>
            <span className="text-xs text-slate-400 font-medium">
              {isIndonesian ? '6 Pilar Kesehatan Terpadu' : '6 Integrated Pillars'}
            </span>
          </div>
          <h3 className="text-lg sm:text-xl font-black tracking-tight text-white">
            {isIndonesian ? 'Radar Vitalitas & Keseimbangan Tubuh' : 'Vitality Radar & Bodily Harmony'}
          </h3>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono">
              {overallScore}
              <span className="text-xs text-slate-400 font-bold"> / 100</span>
            </div>
            <span className="text-[10px] font-bold text-emerald-300">
              {isIndonesian ? 'Skor Vitalitas Sempurna' : 'Overall Vitality Rating'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Interactive Arc Dial + Detailed Pillar Card */}
      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Left: 6-Pillar Interactive Dial Wheel */}
        <div className="lg:col-span-6 flex flex-col items-center justify-center p-4">
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 flex items-center justify-center select-none">
            {/* Ambient Center Glow */}
            <div className="absolute inset-0 rounded-full bg-emerald-500/10 blur-xl animate-pulse" />

            {/* Central Score Node */}
            <motion.div
              key={activePillar.id}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.2 }}
              className="absolute w-32 h-32 sm:w-36 sm:h-36 rounded-full bg-slate-900/90 border-2 border-emerald-400/50 backdrop-blur-xl flex flex-col items-center justify-center shadow-xl shadow-emerald-950/50 z-20"
            >
              <ActiveIcon className="w-6 h-6 text-emerald-400 mb-1" />
              <span className="text-2xl sm:text-3xl font-black text-white font-mono leading-none">
                {activePillar.score}
              </span>
              <span className="text-[10px] font-extrabold text-emerald-300 mt-1 uppercase tracking-wider text-center px-2 truncate max-w-[110px]">
                {activePillar.status}
              </span>
            </motion.div>

            {/* Orbiting Pillar Nodes */}
            {pillars.map((p, idx) => {
              const angle = (idx / pillars.length) * 2 * Math.PI - Math.PI / 2;
              const radius = 108; // Orbit radius
              const x = Math.cos(angle) * radius;
              const y = Math.sin(angle) * radius;
              const isSelected = activePillarIndex === idx;
              const PIcon = p.icon;

              return (
                <motion.button
                  key={p.id}
                  whileHover={{ scale: 1.15 }}
                  whileTap={{ scale: 0.92 }}
                  onClick={() => setActivePillarIndex(idx)}
                  style={{
                    transform: `translate(${x}px, ${y}px)`,
                  }}
                  className={`absolute w-11 h-11 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center transition-all cursor-pointer z-30 shadow-md ${
                    isSelected
                      ? 'bg-emerald-500 text-slate-950 ring-4 ring-emerald-400/40 shadow-emerald-500/50 font-black'
                      : 'bg-slate-800/90 hover:bg-slate-700/90 text-slate-300 border border-white/10'
                  }`}
                  title={p.title}
                >
                  <PIcon className="w-5 h-5" />
                </motion.button>
              );
            })}

            {/* Connecting Orbit Ring SVG */}
            <svg className="w-full h-full transform -rotate-90 pointer-events-none" viewBox="0 0 200 200">
              <circle
                cx="100"
                cy="100"
                r="78"
                fill="none"
                stroke="rgba(255,255,255,0.08)"
                strokeWidth="2"
                strokeDasharray="4 4"
              />
              <circle
                cx="100"
                cy="100"
                r="78"
                fill="none"
                stroke="#10b981"
                strokeWidth="2.5"
                strokeDasharray="490"
                strokeDashoffset={490 - (490 * overallScore) / 100}
                className="transition-all duration-700 opacity-60"
              />
            </svg>
          </div>

          {/* Scrub Instruction Hint */}
          <p className="text-[11px] text-slate-400 text-center mt-3 font-medium">
            {isIndonesian
              ? 'Ketuk ikon di lingkaran untuk melihat analisis mendalam tiap pilar'
              : 'Tap any node on the orbital radar to inspect specific biometric analysis'}
          </p>
        </div>

        {/* Right: Active Pillar Deep Intelligence Card */}
        <div className="lg:col-span-6 space-y-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={activePillar.id}
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -12 }}
              transition={{ duration: 0.2 }}
              className="bg-white/5 backdrop-blur-md rounded-3xl p-5 sm:p-6 border border-white/10 space-y-4 shadow-xl"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-2xl ${activePillar.bgGlow} text-emerald-300 border border-emerald-400/30`}>
                    <ActiveIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-base sm:text-lg font-black text-white">
                      {activePillar.title}
                    </h4>
                    <span className="text-xs font-bold text-emerald-400">
                      {activePillar.status} • Skor {activePillar.score}/100
                    </span>
                  </div>
                </div>

                <span className="text-xs font-mono font-black text-emerald-300 bg-emerald-500/20 px-2.5 py-1 rounded-full border border-emerald-400/30 shrink-0">
                  #{activePillarIndex + 1}
                </span>
              </div>

              {/* Description & Clinical Context */}
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
                {activePillar.desc}
              </p>

              {/* Metric Progress Bar */}
              <div className="space-y-1.5 pt-1">
                <div className="flex justify-between text-[11px] font-bold text-slate-300">
                  <span>{isIndonesian ? 'Tingkat Kalibrasi Optimal' : 'Calibration Accuracy'}</span>
                  <span className="font-mono text-emerald-400">{activePillar.score}%</span>
                </div>
                <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${activePillar.score}%` }}
                    className="bg-gradient-to-r from-emerald-500 to-teal-300 h-full rounded-full transition-all duration-500"
                  />
                </div>
              </div>

              {/* Action Button to launch specific module */}
              <div className="pt-2 flex items-center justify-between border-t border-white/10">
                <span className="text-[11px] text-slate-400">
                  {isIndonesian ? 'Terhubung ke Google Health Connect' : 'Synced with Health Connect'}
                </span>

                {onNavigateTab && (
                  <button
                    type="button"
                    onClick={() => onNavigateTab(activePillar.route)}
                    className="px-4 py-2 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
                  >
                    <span>{isIndonesian ? 'Buka Analitik' : 'Launch Deep View'}</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Quick Pillar Selector Strip */}
          <div className="grid grid-cols-6 gap-2 pt-1">
            {pillars.map((p, i) => (
              <button
                key={p.id}
                onClick={() => setActivePillarIndex(i)}
                className={`py-2 rounded-xl text-[10px] font-black transition-all cursor-pointer text-center truncate px-1 border ${
                  activePillarIndex === i
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md font-extrabold'
                    : 'bg-white/5 hover:bg-white/10 text-slate-300 border-white/10'
                }`}
              >
                {p.score}%
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
