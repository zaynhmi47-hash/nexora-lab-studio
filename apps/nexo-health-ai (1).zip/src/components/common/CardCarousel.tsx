import React, { useRef, useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export interface CardCarouselProps {
  title?: string;
  subtitle?: string;
  badge?: string;
  children: React.ReactNode[];
  cardWidthClass?: string; // e.g. "w-[280px] sm:w-[320px]"
  gapClass?: string; // e.g. "gap-4"
  showIndicators?: boolean;
  actionButton?: React.ReactNode;
  id?: string;
}

export const CardCarousel: React.FC<CardCarouselProps> = ({
  title,
  subtitle,
  badge,
  children,
  cardWidthClass = 'w-[280px] sm:w-[320px] md:w-[360px]',
  gapClass = 'gap-4',
  showIndicators = true,
  actionButton,
  id,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);

  // Mouse Drag-to-scroll state
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeftState, setScrollLeftState] = useState(0);

  const checkScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const { scrollLeft, scrollWidth, clientWidth } = el;
    setCanScrollLeft(scrollLeft > 10);
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);

    // Calculate approximate active card index
    const childCount = children.length;
    if (childCount > 0 && scrollWidth > clientWidth) {
      const scrollFraction = scrollLeft / (scrollWidth - clientWidth);
      const newIndex = Math.min(childCount - 1, Math.round(scrollFraction * (childCount - 1)));
      setActiveIndex(newIndex);
    }
  };

  useEffect(() => {
    checkScroll();
    window.addEventListener('resize', checkScroll);
    return () => window.removeEventListener('resize', checkScroll);
  }, [children.length]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!scrollContainerRef.current) return;
    setIsDragging(true);
    setStartX(e.pageX - scrollContainerRef.current.offsetLeft);
    setScrollLeftState(scrollContainerRef.current.scrollLeft);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !scrollContainerRef.current) return;
    e.preventDefault();
    const x = e.pageX - scrollContainerRef.current.offsetLeft;
    const walk = (x - startX) * 1.5;
    scrollContainerRef.current.scrollLeft = scrollLeftState - walk;
  };

  const handleMouseUpOrLeave = () => {
    setIsDragging(false);
  };

  const scroll = (direction: 'left' | 'right') => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const scrollAmount = el.clientWidth * 0.75;
    el.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    });
  };

  const scrollToIndex = (index: number) => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const items = el.children;
    if (items[index]) {
      (items[index] as HTMLElement).scrollIntoView({
        behavior: 'smooth',
        inline: 'center',
        block: 'nearest',
      });
    }
  };

  return (
    <div className="w-full space-y-3" id={id}>
      {/* Header section with title and next/prev controls */}
      {(title || subtitle || badge || actionButton) && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-1">
          <div>
            <div className="flex items-center gap-2">
              {badge && (
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 uppercase tracking-wider">
                  {badge}
                </span>
              )}
              {title && (
                <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                  {title}
                </h3>
              )}
            </div>
            {subtitle && (
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {subtitle}
              </p>
            )}
          </div>

          {/* Controls Cluster */}
          <div className="flex items-center gap-2 self-end sm:self-auto">
            {actionButton}

            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200/80 shadow-xs">
              <button
                onClick={() => scroll('left')}
                disabled={!canScrollLeft}
                aria-label="Scroll left"
                className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                  canScrollLeft
                    ? 'bg-white text-slate-700 shadow-xs hover:bg-emerald-50 hover:text-emerald-700 active:scale-95'
                    : 'text-slate-300 cursor-not-allowed opacity-50'
                }`}
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <span className="text-[11px] font-semibold text-slate-500 px-1 font-mono">
                {activeIndex + 1}/{children.length}
              </span>

              <button
                onClick={() => scroll('right')}
                disabled={!canScrollRight}
                aria-label="Scroll right"
                className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                  canScrollRight
                    ? 'bg-white text-slate-700 shadow-xs hover:bg-emerald-50 hover:text-emerald-700 active:scale-95'
                    : 'text-slate-300 cursor-not-allowed opacity-50'
                }`}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Horizontal Carousel Track with drag-to-scroll support */}
      <div
        ref={scrollContainerRef}
        onScroll={checkScroll}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUpOrLeave}
        onMouseLeave={handleMouseUpOrLeave}
        className={`flex overflow-x-auto no-scrollbar scroll-smooth snap-x snap-mandatory py-2 px-1 cursor-grab ${
          isDragging ? 'cursor-grabbing select-none' : ''
        } ${gapClass}`}
        style={{
          scrollbarWidth: 'none',
          msOverflowStyle: 'none',
          WebkitOverflowScrolling: 'touch',
        }}
      >
        {children.map((child, index) => (
          <div
            key={index}
            className={`shrink-0 snap-start transition-all duration-300 ${cardWidthClass}`}
          >
            {child}
          </div>
        ))}
      </div>

      {/* Dot Indicators */}
      {showIndicators && children.length > 1 && (
        <div className="flex items-center justify-center gap-1.5 pt-1">
          {children.map((_, idx) => (
            <button
              key={idx}
              onClick={() => scrollToIndex(idx)}
              aria-label={`Go to slide ${idx + 1}`}
              className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                idx === activeIndex
                  ? 'w-6 bg-emerald-600 shadow-xs'
                  : 'w-1.5 bg-slate-200 hover:bg-emerald-300'
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
};
