import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Phone,
  Video,
  Search,
  MoreVertical,
  Paperclip,
  Mic,
  Send,
  Check,
  CheckCheck,
  ShieldCheck,
  Sparkles,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Clock,
  User,
  Star,
  Award,
  BookOpen,
  FileText,
  Stethoscope,
  X,
  PhoneOff,
  MicOff,
  Image as ImageIcon,
  FileSpreadsheet,
  ChevronLeft,
  ChevronRight,
  Info,
  Calendar,
  HeartPulse,
  Pill,
  Share2,
  Download,
  Activity,
  Smile,
  VideoOff,
  Camera,
  MessageCircle,
  HelpCircle,
  CornerDownLeft,
  Maximize2,
  Minimize2,
  Radio,
  Zap,
} from 'lucide-react';
import { UserProfile, DoctorChatMessage, ClinicalIntakeForm, ClinicalExaminationResult } from '../../types';
import { DOCTOR_SPECIALISTS, DoctorSpecialistProfile, SpecialistKnowledgeCard } from '../../data/doctorSpecialists';

interface WhatsAppDoctorChatProps {
  userProfile: UserProfile;
  onOpenAnamnesisForm?: () => void;
  onBackToHome?: () => void;
  intakeData?: ClinicalIntakeForm;
  examinationResult?: ClinicalExaminationResult | null;
  initialDoctorId?: string;
  autoStartCallType?: 'voice' | 'video' | null;
}

interface WhatsAppMessageItem {
  id: string;
  sender: 'doctor' | 'patient';
  text: string;
  timestamp: string;
  doctorName?: string;
  specialistTitle?: string;
  isVoiceNote?: boolean;
  voiceDurationSec?: number;
  knowledgeCard?: SpecialistKnowledgeCard;
  isCallResume?: boolean;
  callDurationFormatted?: string;
  callActions?: string[];
}

export const WhatsAppDoctorChat: React.FC<WhatsAppDoctorChatProps> = ({
  userProfile,
  onOpenAnamnesisForm,
  onBackToHome,
  intakeData,
  examinationResult,
  initialDoctorId,
  autoStartCallType,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // Active Specialist Selection
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>(
    initialDoctorId || DOCTOR_SPECIALISTS[0].id
  );
  const activeDoctor = DOCTOR_SPECIALISTS.find((d) => d.id === selectedDoctorId) || DOCTOR_SPECIALISTS[0];

  // Mobile View state ('list' | 'chat') & Fullscreen Maximized state
  const [mobileActiveView, setMobileActiveView] = useState<'list' | 'chat'>('chat');
  const [isMaximized, setIsMaximized] = useState(false);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSpecialtyTab, setActiveSpecialtyTab] = useState<string>('all');
  const [sidebarTab, setSidebarTab] = useState<'chats' | 'calls' | 'knowledge'>('chats');

  // Chat message histories per doctor
  const [chatHistories, setChatHistories] = useState<Record<string, WhatsAppMessageItem[]>>(() => {
    const initial: Record<string, WhatsAppMessageItem[]> = {};
    DOCTOR_SPECIALISTS.forEach((doc) => {
      initial[doc.id] = [
        {
          id: `init-${doc.id}`,
          sender: 'doctor',
          text: isIndonesian ? doc.initialGreeting.id : doc.initialGreeting.en,
          timestamp: '09:00',
          doctorName: doc.name,
          specialistTitle: isIndonesian ? doc.specialtyTitle : doc.specialtyTitleEn,
        },
      ];
    });
    return initial;
  });

  const currentMessages = chatHistories[activeDoctor.id] || [];

  // Input state
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [voiceSpeechTranscript, setVoiceSpeechTranscript] = useState('');
  const [audioLevel, setAudioLevel] = useState<number>(0);

  // Audio Voice Note Playback state
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);
  const [playbackRate, setPlaybackRate] = useState<number>(1);

  // Profile / Knowledge Slide-Out Drawer
  const [isProfileDrawerOpen, setIsProfileDrawerOpen] = useState(false);
  const [selectedKnowledgeDetail, setSelectedKnowledgeDetail] = useState<SpecialistKnowledgeCard | null>(null);

  // Attachment Menu
  const [isAttachmentMenuOpen, setIsAttachmentMenuOpen] = useState(false);

  // Phone Call Modal & Simulation State
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);
  const [callType, setCallType] = useState<'voice' | 'video'>('voice');
  const [callState, setCallState] = useState<'calling' | 'ringing' | 'connected' | 'ended'>('calling');
  const [callSeconds, setCallSeconds] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [doctorSpeechText, setDoctorSpeechText] = useState('');
  const [isDoctorSpeaking, setIsDoctorSpeaking] = useState(false);
  const [callTranscriptHistory, setCallTranscriptHistory] = useState<string[]>([]);
  const [inCallInputText, setInCallInputText] = useState('');
  const [isPatientInCallSpeaking, setIsPatientInCallSpeaking] = useState(false);
  const [inCallLiveTranscript, setInCallLiveTranscript] = useState('');

  // Call logs history
  const [callLogs, setCallLogs] = useState<
    {
      id: string;
      doctorName: string;
      doctorAvatar: string;
      specialtyTitle: string;
      timestamp: string;
      durationFormatted: string;
      type: 'voice' | 'video';
      outcome: 'completed' | 'missed';
    }[]
  >([
    {
      id: 'call-1',
      doctorName: 'Dr. Elena Al-Hafiz, Sp.PD',
      doctorAvatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=240&auto=format&fit=crop&q=80',
      specialtyTitle: 'Spesialis Penyakit Dalam',
      timestamp: isIndonesian ? 'Kemarin, 14:20' : 'Yesterday, 2:20 PM',
      durationFormatted: '03:45',
      type: 'voice',
      outcome: 'completed',
    },
    {
      id: 'call-2',
      doctorName: 'Dr. Ethan Brooks, Sp.JP',
      doctorAvatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=240&auto=format&fit=crop&q=80',
      specialtyTitle: 'Spesialis Jantung',
      timestamp: isIndonesian ? '3 hari lalu' : '3 days ago',
      durationFormatted: '02:10',
      type: 'video',
      outcome: 'completed',
    },
  ]);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const recordingTimerRef = useRef<any>(null);
  const callTimerRef = useRef<any>(null);
  const ringtoneIntervalRef = useRef<any>(null);
  const userVideoRef = useRef<HTMLVideoElement>(null);
  const recognitionRef = useRef<any>(null);
  const inCallRecognitionRef = useRef<any>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const micAudioCtxRef = useRef<AudioContext | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Audio Tone generator for ring, connect, send, receive, end
  const playAudioTone = (type: 'ring' | 'connect' | 'send' | 'receive' | 'end') => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      if (type === 'ring') {
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();
        osc1.frequency.setValueAtTime(440, now);
        osc2.frequency.setValueAtTime(480, now);
        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);
        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);
        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + 1.2);
        osc2.stop(now + 1.2);
      } else if (type === 'connect') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(523.25, now);
        osc.frequency.setValueAtTime(659.25, now + 0.1);
        osc.frequency.setValueAtTime(783.99, now + 0.2);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (type === 'send') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(600, now);
        osc.frequency.exponentialRampToValueAtTime(900, now + 0.1);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.12);
      } else if (type === 'receive') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.setValueAtTime(1174.66, now + 0.08);
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.2);
      } else if (type === 'end') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(400, now);
        osc.frequency.exponentialRampToValueAtTime(180, now + 0.3);
        gain.gain.setValueAtTime(0.07, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.3);
      }
    } catch (e) {
      // Audio autoplay policy fallback
    }
  };

  // Start Real Microphone Capture & Live Audio Level Analyser
  const startMicAnalyser = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        micStreamRef.current = stream;
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          micAudioCtxRef.current = ctx;
          const analyser = ctx.createAnalyser();
          analyser.fftSize = 64;
          const source = ctx.createMediaStreamSource(stream);
          source.connect(analyser);

          const bufferLength = analyser.frequencyBinCount;
          const dataArray = new Uint8Array(bufferLength);

          const checkLevel = () => {
            if (!micStreamRef.current) return;
            analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < bufferLength; i++) {
              sum += dataArray[i];
            }
            const avg = sum / bufferLength;
            // Scale level to percentage 0-100
            const scaled = Math.min(100, Math.round((avg / 128) * 100));
            setAudioLevel(scaled);
            animFrameRef.current = requestAnimationFrame(checkLevel);
          };
          checkLevel();
        }
      }
    } catch (err) {
      console.warn('Microphone stream permission error:', err);
    }
  };

  // Stop Microphone Capture & Analyser
  const stopMicAnalyser = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((track) => track.stop());
      micStreamRef.current = null;
    }
    if (micAudioCtxRef.current) {
      try {
        micAudioCtxRef.current.close();
      } catch (e) {}
      micAudioCtxRef.current = null;
    }
    setAudioLevel(0);
  };

  // Sync initial doctor
  useEffect(() => {
    if (initialDoctorId) {
      setSelectedDoctorId(initialDoctorId);
    }
  }, [initialDoctorId]);

  // Trigger call if autoStartCallType is passed
  useEffect(() => {
    if (autoStartCallType) {
      handleStartCall(autoStartCallType);
    }
  }, [autoStartCallType]);

  // Auto scroll to bottom of chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentMessages, isTyping]);

  // Handle Voice Recording lifecycle in Chat input
  useEffect(() => {
    if (isRecordingVoice) {
      setRecordingSeconds(0);
      setVoiceSpeechTranscript('');
      startMicAnalyser();

      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);

      // Start Web Speech Recognition
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        try {
          const rec = new SpeechRecognition();
          rec.lang = isIndonesian ? 'id-ID' : 'en-US';
          rec.continuous = true;
          rec.interimResults = true;
          rec.onresult = (event: any) => {
            let current = '';
            for (let i = 0; i < event.results.length; i++) {
              current += event.results[i][0].transcript;
            }
            if (current) setVoiceSpeechTranscript(current);
          };
          rec.onerror = (e: any) => {
            console.log('Speech rec error:', e);
          };
          rec.start();
          recognitionRef.current = rec;
        } catch (e) {
          console.log('Speech recognition init error:', e);
        }
      }
    } else {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      stopMicAnalyser();
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
        recognitionRef.current = null;
      }
    }
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      stopMicAnalyser();
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, [isRecordingVoice, isIndonesian]);

  // Call timer simulation & webcam handler
  useEffect(() => {
    if (isCallModalOpen && callState === 'connected') {
      callTimerRef.current = setInterval(() => {
        setCallSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    }
    return () => {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    };
  }, [isCallModalOpen, callState]);

  // Webcam stream handling for Video call
  useEffect(() => {
    let stream: MediaStream | null = null;
    if (isCallModalOpen && callType === 'video' && isCameraOn && callState === 'connected') {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices
          .getUserMedia({ video: true, audio: false })
          .then((mediaStream) => {
            stream = mediaStream;
            if (userVideoRef.current) {
              userVideoRef.current.srcObject = mediaStream;
            }
          })
          .catch((err) => {
            console.log('Webcam permission not granted or unavailable:', err);
          });
      }
    }
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isCallModalOpen, callType, isCameraOn, callState]);

  // Format seconds to mm:ss
  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60)
      .toString()
      .padStart(2, '0');
    const s = (sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  // Text-To-Speech function using Web Speech API with Natural Indonesian Voice selection
  const speakText = (rawText: string, onEnd?: () => void) => {
    if (!isSpeakerOn) {
      if (onEnd) onEnd();
      return;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      // Strip markdown symbols for natural human speech flow
      const cleanText = rawText
        .replace(/[*#_`~]/g, '')
        .replace(/https?:\/\/\S+/g, '')
        .trim();

      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = isIndonesian ? 'id-ID' : 'en-US';
      utterance.rate = playbackRate === 1 ? 0.96 : playbackRate;
      utterance.pitch = 1.02;

      // Select Indonesian voice if available
      const voices = window.speechSynthesis.getVoices();
      const idVoice = voices.find(
        (v) =>
          v.lang.toLowerCase().includes('id') ||
          v.name.toLowerCase().includes('indonesia') ||
          v.name.toLowerCase().includes('gadis') ||
          v.name.toLowerCase().includes('ardi')
      );
      if (idVoice) utterance.voice = idVoice;

      utterance.onstart = () => setIsDoctorSpeaking(true);
      utterance.onend = () => {
        setIsDoctorSpeaking(false);
        if (onEnd) onEnd();
      };
      utterance.onerror = () => {
        setIsDoctorSpeaking(false);
        if (onEnd) onEnd();
      };
      window.speechSynthesis.speak(utterance);
    } else {
      if (onEnd) onEnd();
    }
  };

  // Send message to Doctor AI
  const handleSendMessage = async (textToSend?: string, knowledgeAttach?: SpecialistKnowledgeCard) => {
    const query = textToSend || inputText;
    if (!query.trim() && !knowledgeAttach) return;

    playAudioTone('send');

    const newPatientMsg: WhatsAppMessageItem = {
      id: 'patient-' + Date.now(),
      sender: 'patient',
      text: query,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      knowledgeCard: knowledgeAttach,
    };

    // Update state immediately
    setChatHistories((prev) => ({
      ...prev,
      [activeDoctor.id]: [...(prev[activeDoctor.id] || []), newPatientMsg],
    }));

    setInputText('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/doctor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...(chatHistories[activeDoctor.id] || []), newPatientMsg],
          intakeData: intakeData || {},
          clinicalResult: examinationResult || {},
          userMessage: query,
          language: userProfile.language || 'id',
          specialistId: activeDoctor.id,
          specialistName: activeDoctor.name,
          specialistField: isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn,
          specialistExpertise: isIndonesian ? activeDoctor.bioSummary : activeDoctor.bioSummaryEn,
        }),
      });

      const json = await response.json();
      const replyText =
        json.reply ||
        (isIndonesian
          ? 'Terima kasih atas informasinya. Saya merekomendasikan untuk beristirahat cukup dan menjaga hidrasi optimal.'
          : 'Thank you for the update. I recommend optimal rest and proper hydration.');

      const newDoctorMsg: WhatsAppMessageItem = {
        id: 'doc-' + Date.now(),
        sender: 'doctor',
        text: replyText,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        doctorName: activeDoctor.name,
        specialistTitle: isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn,
      };

      playAudioTone('receive');

      setChatHistories((prev) => ({
        ...prev,
        [activeDoctor.id]: [...(prev[activeDoctor.id] || []), newDoctorMsg],
      }));
    } catch (err) {
      console.error('Error sending doctor chat:', err);
    } finally {
      setIsTyping(false);
    }
  };

  // Voice Note send simulation
  const handleFinishVoiceRecord = () => {
    setIsRecordingVoice(false);
    const duration = Math.max(3, recordingSeconds);
    const recordedText =
      voiceSpeechTranscript.trim() ||
      (isIndonesian
        ? 'Dokter, saya ingin konsultasi mengenai gejala yang sedang saya rasakan hari ini.'
        : 'Doctor, I want to consult regarding the symptoms I am feeling today.');

    playAudioTone('send');

    const voicePatientMsg: WhatsAppMessageItem = {
      id: 'voice-' + Date.now(),
      sender: 'patient',
      text: recordedText,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      isVoiceNote: true,
      voiceDurationSec: duration,
    };

    setChatHistories((prev) => ({
      ...prev,
      [activeDoctor.id]: [...(prev[activeDoctor.id] || []), voicePatientMsg],
    }));

    // Trigger fast AI response to voice note
    setIsTyping(true);
    setTimeout(async () => {
      try {
        const response = await fetch('/api/doctor/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: [...(chatHistories[activeDoctor.id] || []), voicePatientMsg],
            intakeData: intakeData || {},
            clinicalResult: examinationResult || {},
            userMessage: recordedText,
            language: userProfile.language || 'id',
            specialistId: activeDoctor.id,
            specialistName: activeDoctor.name,
            specialistField: isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn,
            specialistExpertise: isIndonesian ? activeDoctor.bioSummary : activeDoctor.bioSummaryEn,
          }),
        });
        const json = await response.json();
        const docMsg: WhatsAppMessageItem = {
          id: 'doc-voice-reply-' + Date.now(),
          sender: 'doctor',
          text:
            json.reply ||
            (isIndonesian
              ? 'Saya telah mendengarkan pesan suara Anda. Rekomendasi klinis saya adalah menjaga hidrasi dan istirahat optimal.'
              : 'I listened to your voice message. My clinical advice is to maintain proper rest and hydration.'),
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
          doctorName: activeDoctor.name,
          specialistTitle: isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn,
          isVoiceNote: true,
          voiceDurationSec: 16,
        };

        playAudioTone('receive');

        setChatHistories((prev) => ({
          ...prev,
          [activeDoctor.id]: [...(prev[activeDoctor.id] || []), docMsg],
        }));
      } catch (e) {
        console.error(e);
      } finally {
        setIsTyping(false);
      }
    }, 600);
  };

  // Launch WhatsApp Voice / Video Call
  const handleStartCall = (type: 'voice' | 'video') => {
    setCallType(type);
    setCallState('calling');
    setCallSeconds(0);
    setIsCallModalOpen(true);
    setCallTranscriptHistory([]);
    setInCallLiveTranscript('');
    const introText = isIndonesian ? activeDoctor.phoneCallIntroVoice.id : activeDoctor.phoneCallIntroVoice.en;
    setDoctorSpeechText(introText);

    playAudioTone('ring');

    // Ringing interval sound
    ringtoneIntervalRef.current = setInterval(() => {
      playAudioTone('ring');
    }, 2400);

    // Call Progression: Calling -> Ringing -> Connected
    setTimeout(() => {
      setCallState('ringing');
    }, 1200);

    setTimeout(() => {
      if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);
      setCallState('connected');
      playAudioTone('connect');
      // Speak the doctor greeting via TTS
      speakText(introText);
      setCallTranscriptHistory([`Dokter (${activeDoctor.name}): ${introText}`]);
      // Start microphone analyser in call
      startMicAnalyser();
    }, 2800);
  };

  // Speak / Send Question During Active Call
  const handleInCallSpeak = async (customPatientText?: string) => {
    const text = customPatientText || inCallInputText || inCallLiveTranscript;
    if (!text.trim()) return;

    setInCallInputText('');
    setInCallLiveTranscript('');
    setIsDoctorSpeaking(true);
    const updatedHistory = [...callTranscriptHistory, `Pasien: ${text}`];
    setCallTranscriptHistory(updatedHistory);

    try {
      const response = await fetch('/api/doctor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ sender: 'patient', text }],
          intakeData: intakeData || {},
          clinicalResult: examinationResult || {},
          userMessage: `[Telekonsultasi Suara Langsung / In-Call] Pasien berbicara secara langsung: "${text}". Berikan respon dokter spesialis ${activeDoctor.name} yang ramah, ringkas, menenangkan, dan langsung ke instruksi medis praktis dalam 2-3 kalimat santun.`,
          language: userProfile.language || 'id',
          specialistId: activeDoctor.id,
          specialistName: activeDoctor.name,
          specialistField: isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn,
          specialistExpertise: isIndonesian ? activeDoctor.bioSummary : activeDoctor.bioSummaryEn,
        }),
      });

      const json = await response.json();
      const reply =
        json.reply ||
        (isIndonesian
          ? 'Saya mendengar keluhan Anda. Prioritaskan relaksasi, minum air putih hangat, dan hindari pemicu stres saat ini.'
          : 'I hear your concern. Please prioritize hydration, rest, and avoid acute physical stress.');

      setDoctorSpeechText(reply);
      setCallTranscriptHistory((prev) => [...prev, `Dokter (${activeDoctor.name}): ${reply}`]);
      speakText(reply);
    } catch (err) {
      console.error('In-call chat error:', err);
      setIsDoctorSpeaking(false);
    }
  };

  // Toggle in-call patient microphone speech recognition
  const toggleInCallMicSpeech = async () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (isPatientInCallSpeaking) {
      if (inCallRecognitionRef.current) {
        try {
          inCallRecognitionRef.current.stop();
        } catch (e) {}
        inCallRecognitionRef.current = null;
      }
      setIsPatientInCallSpeaking(false);
      // Auto-submit recognized speech if available
      if (inCallLiveTranscript.trim()) {
        handleInCallSpeak(inCallLiveTranscript);
      }
    } else {
      // Request mic explicitly
      await startMicAnalyser();
      setIsPatientInCallSpeaking(true);
      setInCallLiveTranscript('');

      if (SpeechRecognition) {
        try {
          const rec = new SpeechRecognition();
          rec.lang = isIndonesian ? 'id-ID' : 'en-US';
          rec.continuous = true;
          rec.interimResults = true;
          rec.onstart = () => setIsPatientInCallSpeaking(true);
          rec.onresult = (event: any) => {
            let current = '';
            for (let i = 0; i < event.results.length; i++) {
              current += event.results[i][0].transcript;
            }
            if (current) {
              setInCallLiveTranscript(current);
            }
          };
          rec.onend = () => {
            // If still speaking state, restart or submit
            if (isPatientInCallSpeaking && inCallLiveTranscript.trim()) {
              handleInCallSpeak(inCallLiveTranscript);
              setIsPatientInCallSpeaking(false);
            }
          };
          rec.onerror = (err: any) => {
            console.warn('In call recognition error:', err);
          };
          rec.start();
          inCallRecognitionRef.current = rec;
        } catch (e) {
          console.warn('Speech recognition start failed:', e);
        }
      }
    }
  };

  // End WhatsApp Call & Generate Medical Call Resume
  const handleEndCall = async () => {
    if (ringtoneIntervalRef.current) clearInterval(ringtoneIntervalRef.current);
    stopMicAnalyser();
    if (inCallRecognitionRef.current) {
      try {
        inCallRecognitionRef.current.stop();
      } catch (e) {}
      inCallRecognitionRef.current = null;
    }
    setIsPatientInCallSpeaking(false);

    playAudioTone('end');
    setCallState('ended');
    const finalSec = callSeconds;
    const durationFormatted = formatTimer(finalSec);

    // Add to call logs
    const newLog = {
      id: 'call-' + Date.now(),
      doctorName: activeDoctor.name,
      doctorAvatar: activeDoctor.avatar,
      specialtyTitle: isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn,
      timestamp: isIndonesian ? 'Baru saja' : 'Just now',
      durationFormatted: durationFormatted,
      type: callType,
      outcome: 'completed' as const,
    };
    setCallLogs((prev) => [newLog, ...prev]);

    // Close modal
    setTimeout(() => {
      setIsCallModalOpen(false);
      window.speechSynthesis?.cancel();
    }, 600);

    // Generate Call Resume in Chat History
    try {
      const response = await fetch('/api/doctor/call-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          specialistName: activeDoctor.name,
          specialistField: isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn,
          callDurationSec: finalSec,
          patientTopic: currentMessages[currentMessages.length - 1]?.text || 'Konsultasi keluhan umum',
          callTranscript: callTranscriptHistory.join('\n'),
          language: userProfile.language || 'id',
        }),
      });

      const json = await response.json();
      const resumeData = json.data || {};

      const callResumeMsg: WhatsAppMessageItem = {
        id: 'call-resume-' + Date.now(),
        sender: 'doctor',
        text: `📞 ${isIndonesian ? 'Resume Panggilan Telemedisin AI' : 'AI Telemedicine Call Resume'}\n\n**${resumeData.callTitle || 'Konsultasi Suara Selesai'}** (${durationFormatted})\n\n${(resumeData.clinicalKeypoints || []).map((k: string) => `• ${k}`).join('\n')}\n\n${resumeData.doctorClosingNote || 'Terima kasih atas diskusinya!'}`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        doctorName: activeDoctor.name,
        specialistTitle: isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn,
        isCallResume: true,
        callDurationFormatted: durationFormatted,
        callActions: resumeData.prescribedActions,
      };

      setChatHistories((prev) => ({
        ...prev,
        [activeDoctor.id]: [...(prev[activeDoctor.id] || []), callResumeMsg],
      }));
    } catch (e) {
      console.error(e);
    }
  };

  // Filtered Doctors list
  const filteredDoctors = DOCTOR_SPECIALISTS.filter((doc) => {
    const matchesSearch =
      doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.specialtyTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.expertiseKeywords.some((k) => k.toLowerCase().includes(searchQuery.toLowerCase()));

    if (activeSpecialtyTab === 'all') return matchesSearch;
    return matchesSearch && doc.specialtyId === activeSpecialtyTab;
  });

  return (
    <div
      className={`w-full bg-slate-900/5 rounded-3xl border border-slate-200 overflow-hidden shadow-xl flex flex-col md:flex-row relative transition-all duration-300 ${
        isMaximized
          ? 'fixed inset-0 z-50 rounded-none h-screen max-h-screen bg-slate-950 p-0 sm:p-2'
          : 'h-[780px] max-h-[88vh]'
      }`}
    >
      {/* 1. LEFT SIDEBAR: WHATSAPP SPECIALIST DIRECTORY & CALLS */}
      <div
        className={`w-full md:w-80 lg:w-96 bg-white border-r border-slate-200 flex flex-col shrink-0 ${
          mobileActiveView === 'chat' ? 'hidden md:flex' : 'flex'
        }`}
      >
        {/* Top Profile Header */}
        <div className="p-3 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white font-bold text-sm shadow-md">
                <Stethoscope className="w-5 h-5" />
              </div>
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-slate-900 rounded-full" />
            </div>
            <div>
              <div className="text-xs font-black text-white flex items-center gap-1">
                <span>WhatsApp Telemedisin AI</span>
              </div>
              <div className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                <Zap className="w-3 h-3" />
                <span>8 Dokter Spesialis Aktif</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {onOpenAnamnesisForm && (
              <button
                onClick={onOpenAnamnesisForm}
                className="p-1.5 rounded-lg bg-emerald-800/80 hover:bg-emerald-700 text-emerald-200 text-[11px] font-bold flex items-center gap-1 px-2.5 transition-all cursor-pointer"
                title="Buka Form Anamnesis Medis Lengkap"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Anamnesis</span>
              </button>
            )}
          </div>
        </div>

        {/* Navigation Tabs in Sidebar: Chats vs Call Logs vs Knowledge Base */}
        <div className="flex border-b border-slate-200 bg-slate-50 text-xs font-bold">
          <button
            onClick={() => setSidebarTab('chats')}
            className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              sidebarTab === 'chats'
                ? 'border-b-2 border-emerald-600 text-emerald-800 bg-white font-black'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Chat Dokter' : 'Doctors'}</span>
          </button>

          <button
            onClick={() => setSidebarTab('calls')}
            className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              sidebarTab === 'calls'
                ? 'border-b-2 border-emerald-600 text-emerald-800 bg-white font-black'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Panggilan' : 'Calls'}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 text-[9px] font-black">
              {callLogs.length}
            </span>
          </button>

          <button
            onClick={() => setSidebarTab('knowledge')}
            className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              sidebarTab === 'knowledge'
                ? 'border-b-2 border-emerald-600 text-emerald-800 bg-white font-black'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Protokol' : 'Protocols'}</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-2.5 bg-slate-50 border-b border-slate-200">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isIndonesian ? 'Cari dokter spesialis atau keluhan...' : 'Search specialists...'}
              className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* TAB 1: CHATS LIST (Specialist Doctors List) */}
        {sidebarTab === 'chats' && (
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {filteredDoctors.map((doc) => {
              const isSelected = doc.id === activeDoctor.id;
              const lastMsg = (chatHistories[doc.id] || []).slice(-1)[0];

              return (
                <div
                  key={doc.id}
                  onClick={() => {
                    setSelectedDoctorId(doc.id);
                    setMobileActiveView('chat');
                  }}
                  className={`p-3 flex items-start gap-3 cursor-pointer transition-colors relative ${
                    isSelected ? 'bg-emerald-50/80 border-l-4 border-emerald-600' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="relative shrink-0">
                    <img
                      src={doc.avatar}
                      alt={doc.name}
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 rounded-full object-cover border border-slate-200 shadow-xs"
                    />
                    <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-white rounded-full" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <div className="font-black text-xs text-slate-900 truncate">{doc.name}</div>
                      <span className="text-[10px] text-slate-400 font-semibold shrink-0">
                        {lastMsg ? lastMsg.timestamp : '09:00'}
                      </span>
                    </div>

                    <div className="text-[11px] font-bold text-emerald-700 truncate mt-0.5">
                      {isIndonesian ? doc.specialtyTitle : doc.specialtyTitleEn}
                    </div>

                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                      {lastMsg ? (
                        lastMsg.isVoiceNote ? (
                          <span className="flex items-center gap-1 text-emerald-800 font-semibold">
                            <Mic className="w-3 h-3" />
                            <span>{isIndonesian ? 'Pesan Suara' : 'Voice Note'}</span>
                          </span>
                        ) : (
                          lastMsg.text
                        )
                      ) : (
                        doc.subSpecialty
                      )}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 2: CALL LOGS */}
        {sidebarTab === 'calls' && (
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 p-2 space-y-1">
            <div className="text-[11px] font-black text-slate-400 uppercase tracking-wider px-2 py-1">
              {isIndonesian ? 'Riwayat Telekonsultasi AI' : 'Call History'}
            </div>
            {callLogs.map((log) => (
              <div key={log.id} className="p-2.5 flex items-center justify-between hover:bg-slate-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <img
                    src={log.doctorAvatar}
                    alt={log.doctorName}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover border border-slate-200"
                  />
                  <div>
                    <div className="text-xs font-bold text-slate-900">{log.doctorName}</div>
                    <div className="text-[10px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                      {log.type === 'video' ? (
                        <Video className="w-3 h-3 text-emerald-600" />
                      ) : (
                        <Phone className="w-3 h-3 text-emerald-600" />
                      )}
                      <span>{log.timestamp}</span>
                      <span>•</span>
                      <span className="font-mono text-emerald-700 font-bold">{log.durationFormatted}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    const matched = DOCTOR_SPECIALISTS.find((d) => d.name === log.doctorName);
                    if (matched) setSelectedDoctorId(matched.id);
                    handleStartCall(log.type);
                  }}
                  className="p-2 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white transition-colors cursor-pointer"
                  title="Panggil Kembali"
                >
                  <Phone className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* TAB 3: KNOWLEDGE BASE QUICK BROWSER */}
        {sidebarTab === 'knowledge' && (
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
            <div className="text-[11px] font-black text-slate-400 uppercase tracking-wider">
              {isIndonesian ? 'Katalog Protokol Klinis Dokter' : 'Clinical Protocols'}
            </div>
            {DOCTOR_SPECIALISTS.flatMap((d) =>
              d.knowledgeCards.map((k) => ({
                ...k,
                doctorOwner: d,
              }))
            ).map((card) => (
              <div
                key={card.id}
                onClick={() => {
                  setSelectedDoctorId(card.doctorOwner.id);
                  setSelectedKnowledgeDetail(card);
                  setIsProfileDrawerOpen(true);
                }}
                className="p-3 bg-slate-50 hover:bg-emerald-50/80 border border-slate-200 hover:border-emerald-300 rounded-2xl transition-all cursor-pointer space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-black rounded-full">
                    {card.badge}
                  </span>
                  <span className="text-[10px] text-slate-400 font-bold">
                    {card.doctorOwner.name.split(',')[0]}
                  </span>
                </div>
                <div className="text-xs font-black text-slate-900 leading-snug">
                  {isIndonesian ? card.topicTitle : card.topicTitleEn}
                </div>
                <p className="text-[11px] text-slate-600 line-clamp-2">
                  {isIndonesian ? card.summary : card.summaryEn}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 2. MAIN WHATSAPP CHAT CANVAS */}
      <div
        className={`flex-1 flex flex-col bg-[#efeae2] relative overflow-hidden ${
          mobileActiveView === 'list' ? 'hidden md:flex' : 'flex'
        }`}
      >
        {/* WhatsApp Chat Header */}
        <div className="p-3 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 z-10">
          <div className="flex items-center gap-3">
            {/* Mobile Back to List button */}
            <button
              onClick={() => setMobileActiveView('list')}
              className="md:hidden p-1.5 rounded-lg bg-slate-800 text-slate-200 hover:text-white"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <div
              onClick={() => setIsProfileDrawerOpen(true)}
              className="flex items-center gap-3 cursor-pointer group"
            >
              <div className="relative">
                <img
                  src={activeDoctor.avatar}
                  alt={activeDoctor.name}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover border border-slate-700 group-hover:scale-105 transition-transform"
                />
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-slate-900 rounded-full" />
              </div>

              <div>
                <div className="text-xs sm:text-sm font-extrabold text-white flex items-center gap-1.5">
                  <span>{activeDoctor.name}</span>
                  <Award className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                  <span>
                    {isTyping
                      ? isIndonesian ? 'Sedang mengetik...' : 'Typing...'
                      : isIndonesian ? 'Online • Balas instan < 1 dtk' : 'Online • Instant AI response'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Action Icons: Voice Call, Video Call, Fullscreen, Profile Info */}
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => handleStartCall('voice')}
              className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
              title={isIndonesian ? 'Panggilan Telepon Suara AI' : 'AI Voice Call'}
            >
              <Phone className="w-4 h-4" />
              <span className="hidden sm:inline">{isIndonesian ? 'Telepon' : 'Call'}</span>
            </button>

            <button
              onClick={() => handleStartCall('video')}
              className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
              title={isIndonesian ? 'Panggilan Video AI' : 'AI Video Call'}
            >
              <Video className="w-4 h-4" />
              <span className="hidden sm:inline">{isIndonesian ? 'Video' : 'Video'}</span>
            </button>

            {/* Maximize / Fullscreen Toggle */}
            <button
              onClick={() => setIsMaximized(!isMaximized)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title={isMaximized ? 'Perkecil' : 'Layar Penuh (Full Screen)'}
            >
              {isMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              onClick={() => setIsProfileDrawerOpen(true)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Kredensial Dokter"
            >
              <Info className="w-4 h-4" />
            </button>

            {isMaximized && (
              <button
                onClick={() => setIsMaximized(false)}
                className="p-2 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white transition-colors cursor-pointer"
                title="Tutup Layar Penuh"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* WhatsApp Background Chat Area with subtle pattern */}
        <div
          className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 relative"
          style={{
            backgroundImage: `radial-gradient(#cbd5e1 1px, transparent 1px)`,
            backgroundSize: '20px 20px',
          }}
        >
          {/* Encryption & Medical Notice Banner */}
          <div className="flex justify-center">
            <span className="px-3 py-1 bg-amber-50/90 text-amber-900 border border-amber-200/80 text-[10px] sm:text-[11px] font-semibold rounded-full shadow-2xs flex items-center gap-1.5 text-center max-w-md">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-700 shrink-0" />
              <span>
                {isIndonesian
                  ? '🔒 Konsultasi terenkripsi & didukung 8 Dokter Spesialis Gemini 2.5 Flash.'
                  : '🔒 Encrypted consultation powered by Gemini 2.5 Flash Specialists.'}
              </span>
            </span>
          </div>

          {/* Date separator */}
          <div className="flex justify-center">
            <span className="px-3 py-1 bg-white/80 backdrop-blur-xs text-slate-600 text-[10px] font-black rounded-full border border-slate-200/80 shadow-2xs uppercase tracking-wider">
              {isIndonesian ? 'Hari Ini' : 'Today'}
            </span>
          </div>

          {/* Message Bubbles */}
          {currentMessages.map((msg) => {
            const isDoctor = msg.sender === 'doctor';

            return (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex flex-col ${isDoctor ? 'items-start' : 'items-end'}`}
              >
                <div
                  className={`max-w-[85%] sm:max-w-xl rounded-2xl p-3 sm:p-3.5 shadow-xs relative ${
                    isDoctor
                      ? 'bg-white text-slate-900 rounded-tl-xs border border-slate-200'
                      : 'bg-[#dcf8c6] text-slate-900 rounded-tr-xs border border-emerald-300'
                  }`}
                >
                  {/* Doctor badge inside bubble */}
                  {isDoctor && (
                    <div className="flex items-center justify-between gap-2 pb-1.5 mb-1.5 border-b border-slate-100 text-[11px] font-black text-emerald-800">
                      <span className="flex items-center gap-1">
                        <Stethoscope className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{msg.doctorName || activeDoctor.name}</span>
                      </span>
                      <span className="text-[10px] text-slate-500 font-semibold">
                        {msg.specialistTitle || activeDoctor.specialtyTitle}
                      </span>
                    </div>
                  )}

                  {/* Voice Note Player UI */}
                  {msg.isVoiceNote ? (
                    <div className="space-y-2 py-1">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => {
                            if (playingVoiceId === msg.id) {
                              setPlayingVoiceId(null);
                              window.speechSynthesis?.cancel();
                            } else {
                              setPlayingVoiceId(msg.id);
                              speakText(msg.text, () => setPlayingVoiceId(null));
                            }
                          }}
                          className="w-10 h-10 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center shadow-xs transition-transform active:scale-95 cursor-pointer shrink-0"
                        >
                          {playingVoiceId === msg.id ? (
                            <Pause className="w-4 h-4 fill-white" />
                          ) : (
                            <Play className="w-4 h-4 fill-white ml-0.5" />
                          )}
                        </button>

                        <div className="flex-1 space-y-1">
                          {/* Animated Voice waveform bars */}
                          <div className="flex items-center gap-0.5 h-6">
                            {[12, 24, 18, 28, 14, 22, 32, 16, 26, 12, 30, 20, 15, 24, 18, 10].map(
                              (h, i) => (
                                <div
                                  key={i}
                                  className={`w-1 rounded-full transition-all ${
                                    playingVoiceId === msg.id
                                      ? 'bg-emerald-600 animate-pulse'
                                      : 'bg-slate-400'
                                  }`}
                                  style={{ height: `${h}px` }}
                                />
                              )
                            )}
                          </div>
                          <div className="flex justify-between text-[10px] text-slate-500 font-bold">
                            <span>0:00</span>
                            <span>{formatTimer(msg.voiceDurationSec || 15)}</span>
                          </div>
                        </div>

                        <button
                          onClick={() => setPlaybackRate((r) => (r === 1 ? 1.5 : r === 1.5 ? 2 : 1))}
                          className="px-2 py-1 rounded-lg bg-white border border-slate-300 text-[10px] font-black text-slate-700 hover:bg-slate-100"
                        >
                          {playbackRate}x
                        </button>
                      </div>
                      <p className="text-xs text-slate-700 font-medium italic border-t border-slate-100 pt-1.5">
                        "{msg.text}"
                      </p>
                    </div>
                  ) : (
                    /* Standard Message Text */
                    <div className="text-xs sm:text-sm text-slate-800 whitespace-pre-wrap leading-relaxed">
                      {msg.text}
                    </div>
                  )}

                  {/* Attached Knowledge Card Widget */}
                  {msg.knowledgeCard && (
                    <div className="mt-2 p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-1">
                      <div className="text-[10px] font-black text-emerald-800 uppercase">
                        📘 {isIndonesian ? 'Rujukan Medis Klinis' : 'Clinical Medical Reference'}
                      </div>
                      <div className="text-xs font-black text-slate-900">
                        {isIndonesian ? msg.knowledgeCard.topicTitle : msg.knowledgeCard.topicTitleEn}
                      </div>
                      <div className="text-[11px] text-slate-600">
                        {isIndonesian ? msg.knowledgeCard.summary : msg.knowledgeCard.summaryEn}
                      </div>
                    </div>
                  )}

                  {/* Call Resume Actions List */}
                  {msg.isCallResume && msg.callActions && (
                    <div className="mt-2.5 pt-2 border-t border-slate-200 space-y-1.5">
                      <div className="text-[11px] font-black text-emerald-800">
                        💊 {isIndonesian ? 'Instruksi Tindak Lanjut Pasca Panggilan:' : 'Post-Call Action Directives:'}
                      </div>
                      <ul className="text-xs space-y-1 text-slate-700">
                        {msg.callActions.map((act, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-emerald-600 font-bold">•</span>
                            <span>{act}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Bubble Footer: Timestamp, TTS Read Aloud & Blue Checkmarks */}
                  <div className="flex items-center justify-end gap-1.5 mt-1.5 text-[10px] text-slate-500 font-medium">
                    {isDoctor && (
                      <button
                        onClick={() => speakText(msg.text)}
                        className="text-slate-400 hover:text-emerald-700 transition-colors p-0.5 cursor-pointer"
                        title={isIndonesian ? 'Dengarkan Suara Dokter' : 'Listen with Doctor Voice'}
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <span>{msg.timestamp}</span>
                    {!isDoctor && <CheckCheck className="w-3.5 h-3.5 text-blue-500" />}
                  </div>
                </div>
              </motion.div>
            );
          })}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-start">
              <div className="bg-white rounded-2xl rounded-tl-xs p-3 shadow-xs border border-slate-200 flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600 animate-spin" />
                <span>{activeDoctor.name.split(',')[0]} {isIndonesian ? 'sedang menyusun rekomendasi klinis...' : 'is responding...'}</span>
              </div>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* WhatsApp Quick Prompts Row */}
        <div className="bg-white/80 border-t border-slate-200 px-3 py-1.5 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {[
            { id: '1', label: isIndonesian ? '💊 Dosis Obat Aman' : '💊 Safe Medicine' },
            { id: '2', label: isIndonesian ? '🥗 Pola Makan & Pantangan' : '🥗 Diet Guidance' },
            { id: '3', label: isIndonesian ? '🚨 Tanda Bahaya (Red Flags)' : '🚨 Red Flags' },
            { id: '4', label: isIndonesian ? '📋 Periksa Lab Darah' : '📋 Lab Tests' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => handleSendMessage(`Dokter, saya ingin konsultasi mengenai ${item.label}. Bagaimana anjuran spesialis?`)}
              className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300 border border-slate-200 rounded-full text-[11px] font-semibold text-slate-700 whitespace-nowrap transition-all cursor-pointer"
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* WhatsApp Bottom Input Bar */}
        <div className="p-2.5 sm:p-3 bg-slate-100 border-t border-slate-300 flex items-center gap-2 relative">
          {/* Attachment Menu Popup */}
          <div className="relative">
            <button
              onClick={() => setIsAttachmentMenuOpen(!isAttachmentMenuOpen)}
              className="p-2 rounded-full text-slate-500 hover:text-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
              title="Lampirkan Dokumen Medis"
            >
              <Paperclip className="w-5 h-5" />
            </button>

            <AnimatePresence>
              {isAttachmentMenuOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute bottom-12 left-0 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 w-56 space-y-1 z-30"
                >
                  <button
                    onClick={() => {
                      setIsAttachmentMenuOpen(false);
                      if (onOpenAnamnesisForm) onOpenAnamnesisForm();
                    }}
                    className="w-full text-left px-3 py-2 text-xs font-bold text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 rounded-xl flex items-center gap-2.5 transition-colors cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-teal-600" />
                    <span>{isIndonesian ? 'Buka Form Anamnesis' : 'Open Anamnesis Form'}</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsAttachmentMenuOpen(false);
                      handleSendMessage(
                        isIndonesian
                          ? 'Lampiran Tanda Vital Pasien: Tekanan Darah 120/80 mmHg, Denyut Nadi 76 bpm, Suhu 36.6°C, SpO2 98%.'
                          : 'Patient Vitals Attachment: BP 120/80 mmHg, HR 76 bpm, Temp 36.6°C, SpO2 98%.'
                      );
                    }}
                    className="w-full text-left px-3 py-2 text-xs font-bold text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 rounded-xl flex items-center gap-2.5 transition-colors cursor-pointer"
                  >
                    <Activity className="w-4 h-4 text-emerald-600" />
                    <span>{isIndonesian ? 'Kirim Tanda Vital Terkini' : 'Send Vitals Attachment'}</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsAttachmentMenuOpen(false);
                      handleSendMessage(
                        isIndonesian
                          ? 'Lampiran Hasil Laboratorium: Hemoglobin 14.2 g/dL, Leukosit 6.800 /uL, Trombosit 240.000 /uL, Gula Darah Puasa 92 mg/dL.'
                          : 'Lab Results Attachment: Hemoglobin 14.2 g/dL, WBC 6,800 /uL, Platelets 240,000 /uL, Fasting Blood Glucose 92 mg/dL.'
                      );
                    }}
                    className="w-full text-left px-3 py-2 text-xs font-bold text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 rounded-xl flex items-center gap-2.5 transition-colors cursor-pointer"
                  >
                    <HeartPulse className="w-4 h-4 text-rose-600" />
                    <span>{isIndonesian ? 'Kirim Rekam Hasil Lab' : 'Send Lab Report'}</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Voice recording live bar with dynamic equalizer or standard text input */}
          {isRecordingVoice ? (
            <div className="flex-1 bg-rose-50 border border-rose-200 rounded-2xl px-4 py-2 flex items-center justify-between text-rose-700 text-xs font-black">
              <div className="flex items-center gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping" />
                <span className="font-mono text-rose-800">{formatTimer(recordingSeconds)}</span>

                {/* Dynamic live audio level meter equalizer */}
                <div className="flex items-center gap-0.5 h-5 px-2 bg-rose-100 rounded-lg">
                  {[20, 45, 75, 50, 30, 60, 90, 40].map((h, i) => {
                    const dynamicHeight = Math.max(4, Math.min(20, Math.round((audioLevel / 100) * h)));
                    return (
                      <div
                        key={i}
                        className="w-1 bg-rose-600 rounded-full transition-all duration-75"
                        style={{ height: `${dynamicHeight}px` }}
                      />
                    );
                  })}
                </div>

                <div className="truncate max-w-[120px] sm:max-w-[200px] text-[11px] font-normal text-slate-700 italic">
                  {voiceSpeechTranscript ? `"${voiceSpeechTranscript}"` : (isIndonesian ? 'Mendengarkan suara Anda...' : 'Listening to your voice...')}
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsRecordingVoice(false)}
                  className="px-2.5 py-1 bg-slate-200 text-slate-700 rounded-lg text-xs font-bold hover:bg-slate-300 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  onClick={handleFinishVoiceRecord}
                  className="px-3 py-1 bg-emerald-600 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 cursor-pointer shadow-xs flex items-center gap-1"
                >
                  <Send className="w-3 h-3" />
                  <span>{isIndonesian ? 'Kirim Suara' : 'Send'}</span>
                </button>
              </div>
            </div>
          ) : (
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={
                isIndonesian
                  ? `Ketik pesan atau keluhan untuk ${activeDoctor.name.split(',')[0]}...`
                  : `Type message for ${activeDoctor.name}...`
              }
              className="flex-1 bg-white border border-slate-300 rounded-2xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          )}

          {/* Send or Voice Record Button */}
          {inputText.trim() ? (
            <button
              onClick={() => handleSendMessage()}
              className="w-10 h-10 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center shadow-md active:scale-95 transition-transform cursor-pointer shrink-0"
              title="Kirim Pesan"
            >
              <Send className="w-4 h-4 ml-0.5" />
            </button>
          ) : (
            <button
              onClick={() => {
                if (isRecordingVoice) {
                  handleFinishVoiceRecord();
                } else {
                  setIsRecordingVoice(true);
                }
              }}
              className={`w-10 h-10 rounded-full flex items-center justify-center shadow-md active:scale-95 transition-all cursor-pointer shrink-0 ${
                isRecordingVoice
                  ? 'bg-rose-600 text-white animate-bounce'
                  : 'bg-slate-800 hover:bg-emerald-600 text-white'
              }`}
              title={isIndonesian ? 'Rekam Pesan Suara / Bicara Langsung' : 'Record Voice Note'}
            >
              <Mic className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* 3. DOCTOR PROFILE & KNOWLEDGE SLIDE-OUT DRAWER */}
      <AnimatePresence>
        {isProfileDrawerOpen && (
          <motion.div
            initial={{ opacity: 0, x: 80 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 80 }}
            className="absolute top-0 right-0 bottom-0 w-full sm:w-96 bg-white border-l border-slate-200 shadow-2xl z-40 flex flex-col overflow-y-auto"
          >
            {/* Drawer Header */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <div className="font-extrabold text-sm flex items-center gap-2">
                <User className="w-4 h-4 text-emerald-400" />
                <span>{isIndonesian ? 'Profil & Kredensial Dokter' : 'Doctor Credentials'}</span>
              </div>
              <button
                onClick={() => setIsProfileDrawerOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Profile Hero */}
            <div className="p-6 text-center bg-slate-50 border-b border-slate-200 space-y-3">
              <img
                src={activeDoctor.avatar}
                alt={activeDoctor.name}
                referrerPolicy="no-referrer"
                className="w-24 h-24 rounded-full object-cover mx-auto border-4 border-white shadow-md"
              />
              <div>
                <h3 className="text-base font-black text-slate-900">{activeDoctor.name}</h3>
                <div className="text-xs font-bold text-emerald-700 mt-0.5">
                  {isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn}
                </div>
                <div className="text-[11px] text-slate-500 font-medium">{activeDoctor.subSpecialty}</div>
              </div>

              {/* Verified SIP & Hospital Badge */}
              <div className="p-3 bg-white rounded-2xl border border-slate-200 space-y-1 text-left">
                <div className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>{activeDoctor.sipNumber}</span>
                </div>
                <div className="text-[10px] text-slate-500">{activeDoctor.hospital}</div>
              </div>

              {/* Rating and Experience stats */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <div className="p-2.5 bg-white rounded-xl border border-slate-200 text-center">
                  <div className="flex items-center justify-center gap-1 text-amber-500 font-black text-xs">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    <span>{activeDoctor.rating}</span>
                  </div>
                  <div className="text-[10px] text-slate-400">{activeDoctor.reviewsCount} {isIndonesian ? 'Ulasan' : 'Reviews'}</div>
                </div>

                <div className="p-2.5 bg-white rounded-xl border border-slate-200 text-center">
                  <div className="text-xs font-black text-slate-900">{activeDoctor.experienceYears} {isIndonesian ? 'Tahun' : 'Years'}</div>
                  <div className="text-[10px] text-slate-400">{isIndonesian ? 'Pengalaman' : 'Experience'}</div>
                </div>
              </div>
            </div>

            {/* Knowledge Cards List for this doctor */}
            <div className="p-4 space-y-3 flex-1 overflow-y-auto">
              <div className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <BookOpen className="w-4 h-4 text-emerald-600" />
                <span>{isIndonesian ? 'Protokol Klinis Spesialis' : 'Specialist Clinical Protocols'}</span>
              </div>

              {activeDoctor.knowledgeCards.map((card) => (
                <div
                  key={card.id}
                  className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                      {card.badge}
                    </span>
                  </div>
                  <div className="font-black text-slate-900">
                    {isIndonesian ? card.topicTitle : card.topicTitleEn}
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {isIndonesian ? card.summary : card.summaryEn}
                  </p>
                  <div className="p-2 bg-white rounded-xl border border-slate-100 text-[11px] text-emerald-900 font-bold">
                    💡 {card.clinicalKeyMetrics}
                  </div>
                  <div className="text-[10px] text-slate-500 italic">
                    Protocol: {card.actionProtocol}
                  </div>
                  <button
                    onClick={() => {
                      setIsProfileDrawerOpen(false);
                      handleSendMessage(
                        isIndonesian
                          ? `Mohon penjelasan lebih lanjut mengenai protokol "${card.topicTitle}".`
                          : `Please explain more regarding the protocol "${card.topicTitleEn}".`,
                        card
                      );
                    }}
                    className="w-full py-1.5 bg-slate-900 hover:bg-emerald-600 text-white rounded-xl font-bold text-[11px] transition-colors cursor-pointer"
                  >
                    {isIndonesian ? 'Tanyakan Topik Ini' : 'Ask This Topic'}
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 4. WHATSAPP PHONE & VIDEO CALLING OVERLAY MODAL */}
      <AnimatePresence>
        {isCallModalOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
          >
            <div className="w-full max-w-lg bg-gradient-to-b from-slate-900 via-teal-950 to-slate-950 border border-emerald-500/40 rounded-3xl p-4 sm:p-6 text-white text-center shadow-2xl flex flex-col items-center justify-between min-h-[580px] relative overflow-hidden my-auto">
              {/* Background Soundwave Glow */}
              <div className="absolute top-1/4 w-80 h-80 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />

              {/* Call Top Header */}
              <div className="w-full flex items-center justify-between text-xs text-emerald-400 font-bold border-b border-emerald-900/50 pb-3">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>{isIndonesian ? 'Panggilan Medis AI Terenkripsi' : 'Encrypted Medical Call'}</span>
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-900/60 border border-emerald-500/30 text-[10px] font-black uppercase">
                  {callType === 'voice' ? 'Voice Call' : 'Video Call'}
                </span>
              </div>

              {/* VIDEO CALL DUAL VIEW OR VOICE CALL AVATAR VIEW */}
              {callType === 'video' && callState === 'connected' ? (
                <div className="w-full my-auto space-y-3">
                  <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-slate-950 border-2 border-emerald-500/40 shadow-xl flex items-center justify-center">
                    {/* Doctor Video / Animated Feed */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-slate-900 to-teal-950 p-4">
                      <img
                        src={activeDoctor.avatar}
                        alt={activeDoctor.name}
                        referrerPolicy="no-referrer"
                        className="w-24 h-24 rounded-full object-cover border-2 border-emerald-400 shadow-lg"
                      />
                      <div className="mt-2 text-sm font-black text-white">{activeDoctor.name}</div>
                      <div className="text-[11px] text-emerald-300 font-semibold">{isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn}</div>
                      
                      {/* Doctor speaking indicator */}
                      <div className="mt-2 flex items-center gap-1">
                        <span className={`w-2 h-2 rounded-full ${isDoctorSpeaking ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
                        <span className="text-[10px] text-emerald-400">{isDoctorSpeaking ? 'Dokter sedang berbicara...' : 'Mendengarkan pasien...'}</span>
                      </div>
                    </div>

                    {/* Patient PiP (Picture in Picture) Video */}
                    <div className="absolute bottom-3 right-3 w-28 h-36 bg-slate-900 rounded-xl border border-emerald-400 overflow-hidden shadow-2xl z-20 flex items-center justify-center">
                      {isCameraOn ? (
                        <video
                          ref={userVideoRef}
                          autoPlay
                          playsInline
                          muted
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-slate-400 text-[10px] p-2">
                          <VideoOff className="w-5 h-5 mb-1 text-slate-500" />
                          <span>Kamera Mati</span>
                        </div>
                      )}
                      <span className="absolute top-1 left-1.5 px-1 py-0.2 rounded bg-slate-950/80 text-[8px] font-bold text-white">
                        Anda
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                /* VOICE CALL AVATAR VIEW */
                <div className="space-y-3 my-auto w-full">
                  <div className="relative mx-auto w-32 h-32 flex items-center justify-center">
                    {callState === 'connected' && isDoctorSpeaking ? (
                      <div className="absolute inset-0 bg-emerald-400/30 rounded-full animate-ping" />
                    ) : callState === 'connected' ? (
                      <div className="absolute inset-0 bg-emerald-500/20 rounded-full animate-pulse" />
                    ) : (
                      <div className="absolute inset-0 bg-teal-500/30 rounded-full animate-pulse" />
                    )}
                    <img
                      src={activeDoctor.avatar}
                      alt={activeDoctor.name}
                      referrerPolicy="no-referrer"
                      className="w-28 h-28 rounded-full object-cover border-4 border-emerald-400 shadow-xl relative z-10"
                    />
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-xl font-black text-white">{activeDoctor.name}</h3>
                    <p className="text-xs text-emerald-300 font-semibold">
                      {isIndonesian ? activeDoctor.specialtyTitle : activeDoctor.specialtyTitleEn}
                    </p>

                    <div className="pt-1 text-sm font-black tracking-wider">
                      {callState === 'calling' && (
                        <span className="text-slate-300 animate-pulse">{isIndonesian ? 'Memanggil...' : 'Calling...'}</span>
                      )}
                      {callState === 'ringing' && (
                        <span className="text-emerald-300 animate-pulse">{isIndonesian ? 'Berdering...' : 'Ringing...'}</span>
                      )}
                      {callState === 'connected' && (
                        <span className="text-emerald-400 font-mono text-base">{formatTimer(callSeconds)}</span>
                      )}
                      {callState === 'ended' && (
                        <span className="text-rose-400">{isIndonesian ? 'Panggilan Berakhir' : 'Call Ended'}</span>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* LIVE INTERACTIVE IN-CALL SUBTITLES & INTERACTION PANEL */}
              {callState === 'connected' && (
                <div className="w-full space-y-2.5 my-2">
                  {/* Doctor Speech Subtitle Box */}
                  <div className="p-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/15 text-xs text-slate-100 max-w-md mx-auto leading-relaxed shadow-lg text-left">
                    <div className="flex items-center justify-between text-emerald-400 font-bold text-[11px] mb-1">
                      <span className="flex items-center gap-1.5">
                        <Volume2 className={`w-4 h-4 ${isDoctorSpeaking ? 'animate-bounce text-emerald-300' : 'text-slate-400'}`} />
                        <span>{activeDoctor.name.split(',')[0]} (Dokter):</span>
                      </span>
                      {isDoctorSpeaking && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded-md bg-emerald-500/30 text-emerald-200 animate-pulse">
                          Suara Dokter Aktif
                        </span>
                      )}
                    </div>
                    <p className="italic text-slate-200">"{doctorSpeechText}"</p>
                  </div>

                  {/* Patient Live Voice Transcription Bubble (if speaking) */}
                  {isPatientInCallSpeaking && (
                    <div className="p-2.5 bg-emerald-950/80 border border-emerald-400/50 rounded-xl text-left max-w-md mx-auto flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
                        <span className="text-[11px] text-emerald-200 truncate italic">
                          {inCallLiveTranscript ? `Mendengarkan: "${inCallLiveTranscript}"` : 'Silakan berbicara langsung ke mikrofon...'}
                        </span>
                      </div>
                      {inCallLiveTranscript && (
                        <button
                          onClick={() => {
                            handleInCallSpeak(inCallLiveTranscript);
                            setIsPatientInCallSpeaking(false);
                          }}
                          className="px-2 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-[10px] font-black rounded-lg cursor-pointer shrink-0"
                        >
                          Kirim
                        </button>
                      )}
                    </div>
                  )}

                  {/* Quick In-Call Speech Questions */}
                  <div className="flex items-center justify-center gap-1.5 overflow-x-auto no-scrollbar py-1">
                    {[
                      { id: '1', text: isIndonesian ? 'Dokter, saya merasa pusing & lemas' : 'I feel dizzy & fatigued' },
                      { id: '2', text: isIndonesian ? 'Dada terasa berdebar kencang' : 'Heart is racing fast' },
                      { id: '3', text: isIndonesian ? 'Bagaimana anjuran obat amannya?' : 'What is safe OTC medicine?' },
                      { id: '4', text: isIndonesian ? 'Kapan saya harus ke IGD?' : 'When to visit Emergency Room?' },
                    ].map((q) => (
                      <button
                        key={q.id}
                        onClick={() => handleInCallSpeak(q.text)}
                        className="px-2.5 py-1 bg-emerald-950/80 hover:bg-emerald-700 border border-emerald-500/40 rounded-full text-[10px] font-bold text-emerald-200 whitespace-nowrap transition-all cursor-pointer active:scale-95"
                      >
                        {q.text}
                      </button>
                    ))}
                  </div>

                  {/* Patient In-Call Input Box */}
                  <div className="flex items-center gap-2 max-w-md mx-auto">
                    <input
                      type="text"
                      value={inCallInputText}
                      onChange={(e) => setInCallInputText(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleInCallSpeak();
                        }
                      }}
                      placeholder={isIndonesian ? 'Ketik atau klik mic untuk bicara langsung...' : 'Type message to doctor in call...'}
                      className="flex-1 bg-slate-900/80 border border-emerald-500/40 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-400"
                    />
                    <button
                      onClick={() => handleInCallSpeak()}
                      disabled={!inCallInputText.trim()}
                      className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white cursor-pointer"
                      title="Kirim"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              {/* CALL CONTROLS BAR */}
              <div className="w-full flex items-center justify-center gap-3 sm:gap-5 pt-3 border-t border-emerald-900/50">
                {/* Mute Mic / Push to Talk */}
                <button
                  onClick={toggleInCallMicSpeech}
                  className={`p-3 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                    isPatientInCallSpeaking
                      ? 'bg-emerald-500 text-white animate-bounce ring-4 ring-emerald-400/50'
                      : isMuted
                      ? 'bg-rose-500/30 text-rose-300 border border-rose-500'
                      : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                  title={isIndonesian ? 'Klik untuk Bicara Langsung ke Dokter' : 'Mic / Push to Talk'}
                >
                  {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>

                {/* Camera Toggle for Video Call */}
                {callType === 'video' && (
                  <button
                    onClick={() => setIsCameraOn(!isCameraOn)}
                    className={`p-3 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                      !isCameraOn ? 'bg-rose-500/30 text-rose-300' : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                    title="Kamera"
                  >
                    {isCameraOn ? <Camera className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                  </button>
                )}

                {/* Hang Up (Red WhatsApp Button) */}
                <button
                  onClick={handleEndCall}
                  className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-700 text-white flex items-center justify-center shadow-lg shadow-rose-600/50 active:scale-95 transition-transform cursor-pointer"
                  title="Akhiri Panggilan & Buat Resume"
                >
                  <PhoneOff className="w-6 h-6" />
                </button>

                {/* Speaker Toggle */}
                <button
                  onClick={() => setIsSpeakerOn(!isSpeakerOn)}
                  className={`p-3 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                    !isSpeakerOn ? 'bg-rose-500/30 text-rose-300' : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                  title="Speaker Suara Dokter"
                >
                  {isSpeakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

