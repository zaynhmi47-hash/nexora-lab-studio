import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Check,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  Building2,
  Zap,
  HelpCircle,
  Clock,
  ArrowRight,
  Shield,
  CreditCard,
  QrCode,
  Smartphone,
  ChevronDown,
  ChevronUp,
  Stethoscope,
  Users,
  Activity,
  Award,
  Layers,
  FileText,
  Lock,
  Star,
  CheckCheck
} from 'lucide-react';
import { SubscriptionPlanType, UserProfile } from '../../types';
import {
  SUBSCRIPTION_PLANS,
  ALL_FEATURES_MATRIX,
  SubscriptionPlanInfo,
  getPlanDetails,
  isFeatureAccessible
} from '../../data/subscriptionPlans';
import { FirestoreDataService } from '../../services/firestoreService';

export interface PricingPlansViewProps {
  userProfile: UserProfile;
  onUpdateProfile?: (updated: Partial<UserProfile>) => void;
  onNavigateTab?: (tab: string) => void;
  onSelectPlan?: (planId: SubscriptionPlanType) => void;
  isEmbedded?: boolean;
}

export const PricingPlansView: React.FC<PricingPlansViewProps> = ({
  userProfile,
  onUpdateProfile,
  onNavigateTab,
  onSelectPlan,
  isEmbedded = false,
}) => {
  const isIndonesian = userProfile.language === 'id';
  const currentPlan = userProfile.subscriptionPlan || 'free';

  // State
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('yearly');
  const [currency, setCurrency] = useState<'IDR' | 'USD'>(isIndonesian ? 'IDR' : 'USD');
  const [selectedPlanId, setSelectedPlanId] = useState<SubscriptionPlanType>('pro');
  const [showComparisonTable, setShowComparisonTable] = useState(false);
  const [activeFaqIndex, setActiveFaqIndex] = useState<number | null>(null);

  // Direct upgrade modal / confirmation state
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [checkoutModalPlan, setCheckoutModalPlan] = useState<SubscriptionPlanInfo | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'gpay' | 'qris' | 'card' | 'va'>('gpay');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [upgradeSuccess, setUpgradeSuccess] = useState(false);

  // Standard (Free), Pro, and Business plans from data
  const standardPlan = SUBSCRIPTION_PLANS.find((p) => p.id === 'free') || SUBSCRIPTION_PLANS[0];
  const proPlan = SUBSCRIPTION_PLANS.find((p) => p.id === 'pro') || SUBSCRIPTION_PLANS[1];
  const businessPlan = SUBSCRIPTION_PLANS.find((p) => p.id === 'business') || SUBSCRIPTION_PLANS[2];
  const enterprisePlan = SUBSCRIPTION_PLANS.find((p) => p.id === 'enterprise') || SUBSCRIPTION_PLANS[3];

  const mainPlans = [standardPlan, proPlan, businessPlan];

  const formatPrice = (plan: SubscriptionPlanInfo) => {
    if (plan.id === 'free') {
      return isIndonesian ? 'Rp 0' : '$0';
    }

    if (currency === 'IDR') {
      const price = billingCycle === 'yearly' ? plan.priceYearlyIdr : plan.priceMonthlyIdr;
      return `Rp ${price.toLocaleString('id-ID')}`;
    } else {
      const price = billingCycle === 'yearly' ? plan.priceYearlyUsd : plan.priceMonthlyUsd;
      return `$${price.toFixed(2)}`;
    }
  };

  const getPricePerMonthEquivalent = (plan: SubscriptionPlanInfo) => {
    if (plan.id === 'free') return '';
    if (billingCycle === 'yearly') {
      if (currency === 'IDR') {
        const perMonth = Math.round(plan.priceYearlyIdr / 12);
        return isIndonesian ? `(Setara Rp ${perMonth.toLocaleString('id-ID')}/bln)` : `(Equivalent to Rp ${perMonth.toLocaleString('id-ID')}/mo)`;
      } else {
        const perMonth = (plan.priceYearlyUsd / 12).toFixed(2);
        return `(Equivalent to $${perMonth}/mo)`;
      }
    }
    return '';
  };

  const handlePlanAction = (plan: SubscriptionPlanInfo) => {
    if (plan.id === currentPlan) {
      return;
    }
    if (onSelectPlan) {
      onSelectPlan(plan.id);
    }
    setCheckoutModalPlan(plan);
  };

  const handleConfirmUpgrade = async () => {
    if (!checkoutModalPlan) return;
    setIsProcessingPayment(true);

    // Simulate network processing
    await new Promise((resolve) => setTimeout(resolve, 1200));

    const expiryDate = new Date();
    if (billingCycle === 'yearly') {
      expiryDate.setFullYear(expiryDate.getFullYear() + 1);
    } else {
      expiryDate.setMonth(expiryDate.getMonth() + 1);
    }

    const updatedProfile: Partial<UserProfile> = {
      subscriptionPlan: checkoutModalPlan.id,
      subscriptionStatus: 'active',
      planActiveUntil: expiryDate.toISOString().split('T')[0],
      clinicName:
        checkoutModalPlan.id === 'business' || checkoutModalPlan.id === 'enterprise'
          ? userProfile.clinicName || 'Klinik Sehat AI'
          : undefined,
    };

    if (onUpdateProfile) {
      onUpdateProfile(updatedProfile);
    }
    await FirestoreDataService.saveUserProfile({ ...userProfile, ...updatedProfile });

    setIsProcessingPayment(false);
    setUpgradeSuccess(true);

    setTimeout(() => {
      setUpgradeSuccess(false);
      setCheckoutModalPlan(null);
      if (checkoutModalPlan.id === 'business' && onNavigateTab) {
        onNavigateTab('business_hub');
      }
    }, 1800);
  };

  const faqs = [
    {
      qId: 'Bisakah saya berganti paket atau membatalkan langganan kapan saja?',
      qEn: 'Can I switch plans or cancel my subscription anytime?',
      aId: 'Ya, Anda bebas melakukan upgrade, downgrade, atau membatalkan perpanjangan otomatis kapan saja tanpa biaya tersembunyi. Fitur Anda akan tetap aktif hingga akhir periode penagihan.',
      aEn: 'Yes, you can upgrade, downgrade, or cancel auto-renewal anytime with zero cancellation fees. Your features stay active until the end of your billing term.',
    },
    {
      qId: 'Apa perbedaan utama paket Pro dan Bisnis Klinik?',
      qEn: 'What is the main difference between Pro and Business Clinic?',
      aId: 'Paket Pro diperuntukkan bagi pengguna personal untuk membuka 20 modul, pemindai makanan tak terbatas, dan konsultasi AI pribadi. Paket Bisnis dirancang untuk klinik, dokter, dan konsultan gizi dengan fitur manajemen 50 pasien, generator e-Resep ber-QR resmi, 5 akun tim, dan integrasi API SIMRS.',
      aEn: 'Pro is tailored for personal users unlocking all 20 modules, unlimited food scans, and 24/7 AI doctor consults. Business is engineered for clinics, doctors, and coaches with 50 patient slots, clinical e-prescriptions, 5 doctor seats, and SIMRS API integration.',
    },
    {
      qId: 'Bagaimana keamanan data rekam medis pasien dijamin?',
      qEn: 'How is patient medical record security and privacy guaranteed?',
      aId: 'Semua rekam medis elektronik (EHR) dan biomarker dienkripsi dengan standar AES-256 GCM sesuai regulasi HIPAA dan GDPR. Isolasi database berbasis User ID (RBAC) memastikan hanya pihak berwenang yang dapat mengakses data.',
      aEn: 'All electronic health records and biomarkers are encrypted with AES-256 GCM adhering strictly to HIPAA and GDPR standards with RBAC tenant isolation.',
    },
    {
      qId: 'Metode pembayaran apa saja yang didukung?',
      qEn: 'What payment methods are supported?',
      aId: 'Kami mendukung QRIS Instan (BCA, Mandiri, GoPay, OVO, ShopeePay), Google Pay, Kartu Debit/Kredit Visa & Mastercard, serta Virtual Account Bank.',
      aEn: 'We support Instant QRIS (BCA, Mandiri, GoPay, OVO), Google Pay, Visa & Mastercard Credit/Debit cards, and Bank Virtual Accounts.',
    },
  ];

  return (
    <div className={`w-full ${isEmbedded ? '' : 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12'}`} id="pricing-plans-view">
      {/* Top Header & Title */}
      <div className="text-center max-w-3xl mx-auto space-y-4 mb-8 sm:mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-extrabold tracking-wide uppercase shadow-2xs">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          <span>{isIndonesian ? 'Paket Fleksibel & Transparan' : 'Flexible & Transparent Pricing'}</span>
        </div>

        <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-tight">
          {isIndonesian ? (
            <>
              Pilih Paket Kesehatan & <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-700">
                Kecerdasan Buatan Medis
              </span>
            </>
          ) : (
            <>
              Choose Your Health & <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-700">
                Medical AI Intelligence Plan
              </span>
            </>
          )}
        </h1>

        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          {isIndonesian
            ? 'Tersedia paket untuk individu mandiri, pengguna profesional, hingga praktisi medis dan klinik. Buka kekuatan penuh Google Health AI.'
            : 'Tailored for independent individuals, power health enthusiasts, and clinical practitioners. Unlock the full power of Google Health AI.'}
        </p>

        {/* Currency & Billing Cycle Segmented Controls */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          {/* Monthly / Yearly Billing Toggle */}
          <div className="inline-flex p-1 bg-slate-100/90 border border-slate-200/80 rounded-2xl shadow-inner">
            <button
              id="billing-monthly-btn"
              onClick={() => setBillingCycle('monthly')}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                billingCycle === 'monthly'
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200/60'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {isIndonesian ? 'Bulanan' : 'Monthly'}
            </button>

            <button
              id="billing-yearly-btn"
              onClick={() => setBillingCycle('yearly')}
              className={`relative px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                billingCycle === 'yearly'
                  ? 'bg-emerald-600 text-white shadow-xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>{isIndonesian ? 'Tahunan' : 'Yearly'}</span>
              <span
                className={`text-[10px] uppercase font-black px-2 py-0.5 rounded-full ${
                  billingCycle === 'yearly'
                    ? 'bg-white/20 text-white border border-white/30'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                {isIndonesian ? 'Hemat 17%' : 'Save 17%'}
              </span>
            </button>
          </div>

          {/* Currency Toggle */}
          <div className="inline-flex p-1 bg-slate-100/80 border border-slate-200/80 rounded-xl text-xs">
            <button
              onClick={() => setCurrency('IDR')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                currency === 'IDR'
                  ? 'bg-white text-slate-900 shadow-2xs font-extrabold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              IDR (Rp)
            </button>
            <button
              onClick={() => setCurrency('USD')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                currency === 'USD'
                  ? 'bg-white text-slate-900 shadow-2xs font-extrabold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              USD ($)
            </button>
          </div>
        </div>
      </div>

      {/* Visual Pricing Cards Grid: Standard, Pro, and Business */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8 items-stretch mb-12">
        {/* CARD 1: STANDARD (FREE STARTER) */}
        <motion.div
          id="pricing-card-standard"
          whileHover={{ y: -4 }}
          transition={{ duration: 0.2 }}
          className={`flex flex-col rounded-3xl bg-white border transition-all p-6 sm:p-7 relative ${
            currentPlan === 'free'
              ? 'border-emerald-400/80 ring-2 ring-emerald-500/20 shadow-lg'
              : 'border-slate-200/90 shadow-sm hover:shadow-md hover:border-slate-300'
          }`}
        >
          {/* Active Status Badge */}
          {currentPlan === 'free' && (
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-slate-800 text-white text-[11px] font-black uppercase tracking-wider shadow-sm flex items-center gap-1">
              <Check className="w-3 h-3 text-emerald-400" />
              <span>{isIndonesian ? 'Paket Aktif Anda' : 'Your Current Plan'}</span>
            </div>
          )}

          <div className="mb-5">
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="px-3 py-1 rounded-xl bg-slate-100 text-slate-700 text-xs font-extrabold uppercase tracking-wide border border-slate-200">
                {isIndonesian ? 'Standard (Starter)' : 'Standard (Starter)'}
              </span>
              <span className="text-xs text-slate-400 font-medium">{isIndonesian ? 'Pengguna Baru' : 'New Users'}</span>
            </div>

            <h3 className="text-xl sm:text-2xl font-black text-slate-900">
              {isIndonesian ? 'Standard Gratis' : 'Standard Free'}
            </h3>
            <p className="text-xs text-slate-500 mt-1.5 line-clamp-2">
              {isIndonesian ? standardPlan.description : standardPlan.descriptionEn}
            </p>
          </div>

          {/* Pricing Display */}
          <div className="pb-6 border-b border-slate-100 mb-6">
            <div className="flex items-baseline gap-1">
              <span className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
                {formatPrice(standardPlan)}
              </span>
              <span className="text-xs text-slate-400 font-medium">
                {isIndonesian ? '/selamanya' : '/forever'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {isIndonesian ? 'Tanpa biaya berlangganan atau kartu kredit' : 'No credit card or recurring charge required'}
            </p>
          </div>

          {/* Key Features List */}
          <div className="flex-1 space-y-3 mb-6">
            <p className="text-xs font-black uppercase tracking-wider text-slate-400">
              {isIndonesian ? 'Fitur yang Termasuk:' : 'Included Features:'}
            </p>
            <ul className="space-y-2.5">
              {(isIndonesian ? standardPlan.keyBenefits : standardPlan.keyBenefitsEn).map((benefit, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-[13px] text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Action Button */}
          <div className="pt-2">
            {currentPlan === 'free' ? (
              <button
                disabled
                className="w-full py-3 rounded-2xl bg-slate-100 text-slate-500 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-default border border-slate-200"
              >
                <Check className="w-4 h-4 text-emerald-600" />
                <span>{isIndonesian ? 'Aktif Saat Ini' : 'Currently Active'}</span>
              </button>
            ) : (
              <button
                onClick={() => handlePlanAction(standardPlan)}
                className="w-full py-3 rounded-2xl bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs hover:border-slate-400"
              >
                <span>{isIndonesian ? 'Pilih Paket Standar' : 'Choose Standard'}</span>
              </button>
            )}
          </div>
        </motion.div>

        {/* CARD 2: PRO (AI HEALTH PRO) - POPULAR & FEATURED */}
        <motion.div
          id="pricing-card-pro"
          whileHover={{ y: -6 }}
          transition={{ duration: 0.2 }}
          className="flex flex-col rounded-3xl bg-gradient-to-b from-emerald-950 via-slate-900 to-slate-900 text-white border-2 border-emerald-400 shadow-2xl relative p-6 sm:p-7 overflow-hidden"
        >
          {/* Top highlight glow */}
          <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

          {/* Popular Tag Header */}
          <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 text-xs font-black uppercase tracking-wider shadow-lg flex items-center gap-1.5">
            <Star className="w-3.5 h-3.5 fill-slate-950" />
            <span>{isIndonesian ? 'Paling Populer Personal' : 'Most Popular Pro'}</span>
          </div>

          <div className="mb-5 mt-2">
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-extrabold uppercase tracking-wide border border-emerald-500/30">
                {isIndonesian ? proPlan.name : proPlan.nameEn}
              </span>
              <span className="text-xs text-emerald-300/80 font-bold flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                <span>AI 2.5 Ultra</span>
              </span>
            </div>

            <h3 className="text-xl sm:text-2xl font-black text-white">
              {isIndonesian ? 'AI Health Pro' : 'AI Health Pro'}
            </h3>
            <p className="text-xs text-slate-300 mt-1.5 line-clamp-2">
              {isIndonesian ? proPlan.description : proPlan.descriptionEn}
            </p>
          </div>

          {/* Pricing Display */}
          <div className="pb-6 border-b border-white/10 mb-6">
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                {formatPrice(proPlan)}
              </span>
              <span className="text-xs text-slate-300 font-medium">
                {billingCycle === 'yearly'
                  ? isIndonesian
                    ? '/tahun'
                    : '/year'
                  : isIndonesian
                  ? '/bulan'
                  : '/month'}
              </span>
            </div>
            {billingCycle === 'yearly' && (
              <p className="text-[11px] text-emerald-400 font-bold mt-1">
                {getPricePerMonthEquivalent(proPlan)} • {isIndonesian ? 'Hemat 2 Bulan' : '2 Months Free'}
              </p>
            )}
          </div>

          {/* Key Features List */}
          <div className="flex-1 space-y-3 mb-6">
            <p className="text-xs font-black uppercase tracking-wider text-emerald-300/90">
              {isIndonesian ? 'Semua Fitur Pro & Medis AI:' : 'All Pro & Medical AI Features:'}
            </p>
            <ul className="space-y-2.5">
              {(isIndonesian ? proPlan.keyBenefits : proPlan.keyBenefitsEn).map((benefit, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-[13px] text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="leading-snug">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Action Button */}
          <div className="pt-2">
            {currentPlan === 'pro' ? (
              <button
                disabled
                className="w-full py-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 text-emerald-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-default"
              >
                <CheckCheck className="w-4 h-4 text-emerald-400" />
                <span>{isIndonesian ? 'Paket Aktif Saat Ini' : 'Current Active Plan'}</span>
              </button>
            ) : (
              <button
                id="upgrade-to-pro-btn"
                onClick={() => handlePlanAction(proPlan)}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-500/25 active:scale-[0.99]"
              >
                <Sparkles className="w-4 h-4 fill-slate-950" />
                <span>{isIndonesian ? 'Upgrade ke Pro Sekarang' : 'Upgrade to Pro Now'}</span>
              </button>
            )}
          </div>
        </motion.div>

        {/* CARD 3: BUSINESS (BUSINESS / CLINIC HUB) */}
        <motion.div
          id="pricing-card-business"
          whileHover={{ y: -4 }}
          transition={{ duration: 0.2 }}
          className={`flex flex-col rounded-3xl bg-white border transition-all p-6 sm:p-7 relative ${
            currentPlan === 'business'
              ? 'border-teal-500 ring-2 ring-teal-500/20 shadow-xl'
              : 'border-slate-200/90 shadow-sm hover:shadow-md hover:border-slate-300'
          }`}
        >
          {/* Active Status Badge */}
          {currentPlan === 'business' && (
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-teal-800 text-white text-[11px] font-black uppercase tracking-wider shadow-sm flex items-center gap-1">
              <Check className="w-3 h-3 text-teal-300" />
              <span>{isIndonesian ? 'Paket Bisnis Aktif' : 'Business Active'}</span>
            </div>
          )}

          <div className="mb-5">
            <div className="flex items-center justify-between gap-2 mb-2">
              <span className="px-3 py-1 rounded-xl bg-teal-50 text-teal-800 text-xs font-extrabold uppercase tracking-wide border border-teal-200">
                {isIndonesian ? 'Bisnis / Klinik Hub' : 'Business / Clinic Hub'}
              </span>
              <span className="text-xs text-teal-700 font-bold flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5 text-teal-600" />
                <span>Klinik & Dokter</span>
              </span>
            </div>

            <h3 className="text-xl sm:text-2xl font-black text-slate-900">
              {isIndonesian ? 'Bisnis & Klinik Hub' : 'Business & Clinic Hub'}
            </h3>
            <p className="text-xs text-slate-500 mt-1.5 line-clamp-2">
              {isIndonesian ? businessPlan.description : businessPlan.descriptionEn}
            </p>
          </div>

          {/* Pricing Display */}
          <div className="pb-6 border-b border-slate-100 mb-6">
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
                {formatPrice(businessPlan)}
              </span>
              <span className="text-xs text-slate-400 font-medium">
                {billingCycle === 'yearly'
                  ? isIndonesian
                    ? '/tahun'
                    : '/year'
                  : isIndonesian
                  ? '/bulan'
                  : '/month'}
              </span>
            </div>
            {billingCycle === 'yearly' && (
              <p className="text-[11px] text-teal-700 font-bold mt-1">
                {getPricePerMonthEquivalent(businessPlan)} • {isIndonesian ? 'Hemat 2 Bulan' : '2 Months Free'}
              </p>
            )}
          </div>

          {/* Key Features List */}
          <div className="flex-1 space-y-3 mb-6">
            <p className="text-xs font-black uppercase tracking-wider text-slate-400">
              {isIndonesian ? 'Fitur Manajemen Pasien & Tim:' : 'Patient & Team Features:'}
            </p>
            <ul className="space-y-2.5">
              {(isIndonesian ? businessPlan.keyBenefits : businessPlan.keyBenefitsEn).map((benefit, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-[13px] text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Action Button */}
          <div className="pt-2">
            {currentPlan === 'business' ? (
              <button
                disabled
                className="w-full py-3 rounded-2xl bg-teal-50 text-teal-800 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-default border border-teal-200"
              >
                <Check className="w-4 h-4 text-teal-600" />
                <span>{isIndonesian ? 'Paket Bisnis Aktif' : 'Business Active'}</span>
              </button>
            ) : (
              <button
                id="upgrade-to-business-btn"
                onClick={() => handlePlanAction(businessPlan)}
                className="w-full py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md hover:shadow-lg active:scale-[0.99]"
              >
                <Building2 className="w-4 h-4 text-teal-400" />
                <span>{isIndonesian ? 'Upgrade ke Bisnis Hub' : 'Upgrade to Business Hub'}</span>
              </button>
            )}
          </div>
        </motion.div>
      </div>

      {/* Enterprise Custom Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-950 text-white rounded-3xl p-6 sm:p-8 mb-12 border border-slate-700 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl text-center md:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold uppercase tracking-wider">
            <Building2 className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Jaringan Rumah Sakit & Korporasi' : 'Hospital Networks & Enterprise'}</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white">
            {isIndonesian ? 'Butuh Pasien Tanpa Batas & Integrasi Server Khusus?' : 'Need Unlimited Seats & Custom Server Integration?'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {isIndonesian
              ? 'Paket Enterprise menyediakan penempatan server on-premise, fine-tuning model LLM lokal rumah sakit, SLA 99.99%, dan manajer akun dokter khusus.'
              : 'Enterprise tier provides on-premise deployment, private local LLM fine-tuning, 99.99% critical SLA, and dedicated medical success managers.'}
          </p>
        </div>

        <div className="shrink-0 w-full md:w-auto">
          <button
            onClick={() => handlePlanAction(enterprisePlan)}
            className="w-full md:w-auto px-6 py-3.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md"
          >
            <span>{isIndonesian ? 'Hubungi Tim Enterprise' : 'Contact Enterprise Team'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Expandable Full Feature Comparison Table */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 mb-12 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <h3 className="text-lg sm:text-xl font-black text-slate-900">
              {isIndonesian ? 'Perbandingan Detail Antar Paket' : 'Detailed Feature Comparison Matrix'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {isIndonesian
                ? 'Bandingkan batasan teknis, kuota pemindaian, dan hak akses antar tier.'
                : 'Compare technical limits, scan quotas, and access permissions across all tiers.'}
            </p>
          </div>

          <button
            onClick={() => setShowComparisonTable(!showComparisonTable)}
            className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer"
          >
            <span>{showComparisonTable ? (isIndonesian ? 'Sembunyikan Matriks' : 'Hide Matrix') : (isIndonesian ? 'Buka Matriks Lengkap' : 'Show Full Matrix')}</span>
            {showComparisonTable ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

        <AnimatePresence>
          {showComparisonTable && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-x-auto pt-6"
            >
              <table className="w-full text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-bold text-xs uppercase tracking-wider">
                    <th className="pb-3 pr-4">{isIndonesian ? 'Fitur / Kemampuan' : 'Feature / Capability'}</th>
                    <th className="pb-3 px-3 text-center text-slate-700">{isIndonesian ? 'Standard' : 'Standard'}</th>
                    <th className="pb-3 px-3 text-center text-emerald-700 font-black">{isIndonesian ? 'Pro Personal' : 'Pro Personal'}</th>
                    <th className="pb-3 px-3 text-center text-teal-800 font-black">{isIndonesian ? 'Bisnis Klinik' : 'Business Clinic'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ALL_FEATURES_MATRIX.slice(0, 10).map((feat) => (
                    <tr key={feat.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 pr-4">
                        <p className="font-bold text-slate-900">{isIndonesian ? feat.name : feat.nameEn}</p>
                        <p className="text-[11px] text-slate-500">{isIndonesian ? feat.description : feat.descriptionEn}</p>
                      </td>
                      <td className="py-3.5 px-3 text-center font-medium text-slate-600">
                        {typeof feat.tiers.free === 'boolean' ? (
                          feat.tiers.free ? <Check className="w-4 h-4 text-emerald-600 mx-auto" /> : <span className="text-slate-300">—</span>
                        ) : (
                          feat.tiers.free
                        )}
                      </td>
                      <td className="py-3.5 px-3 text-center font-bold text-emerald-700 bg-emerald-50/40 rounded-lg">
                        {typeof feat.tiers.pro === 'boolean' ? (
                          feat.tiers.pro ? <Check className="w-4 h-4 text-emerald-600 mx-auto" /> : <span className="text-slate-300">—</span>
                        ) : (
                          feat.tiers.pro
                        )}
                      </td>
                      <td className="py-3.5 px-3 text-center font-bold text-teal-800 bg-teal-50/40 rounded-lg">
                        {typeof feat.tiers.business === 'boolean' ? (
                          feat.tiers.business ? <Check className="w-4 h-4 text-teal-600 mx-auto" /> : <span className="text-slate-300">—</span>
                        ) : (
                          feat.tiers.business
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Trust & Guarantee Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 flex items-center gap-3.5 shadow-2xs">
          <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900">{isIndonesian ? 'Enkripsi Medis AES-256' : 'AES-256 Medical Security'}</h4>
            <p className="text-[11px] text-slate-500">{isIndonesian ? 'Kepatuhan HIPAA & GDPR' : 'HIPAA & GDPR Compliant'}</p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 flex items-center gap-3.5 shadow-2xs">
          <div className="p-2.5 rounded-xl bg-blue-50 text-blue-700">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900">{isIndonesian ? 'Aktivasi Instan Real-time' : 'Instant Real-time Unlock'}</h4>
            <p className="text-[11px] text-slate-500">{isIndonesian ? 'Sinkronisasi Cloud Firestore' : 'Synced across all devices'}</p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 flex items-center gap-3.5 shadow-2xs">
          <div className="p-2.5 rounded-xl bg-amber-50 text-amber-700">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900">{isIndonesian ? 'Garansi 30 Hari Pengembalian' : '30-Day Money Back'}</h4>
            <p className="text-[11px] text-slate-500">{isIndonesian ? '100% kepuasan dijamin' : 'No questions asked policy'}</p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 flex items-center gap-3.5 shadow-2xs">
          <div className="p-2.5 rounded-xl bg-teal-50 text-teal-700">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900">{isIndonesian ? 'Dukungan Dokter & CS 24/7' : '24/7 Support & Onboarding'}</h4>
            <p className="text-[11px] text-slate-500">{isIndonesian ? 'Respon cepat via live chat' : 'Direct live chat assistance'}</p>
          </div>
        </div>
      </div>

      {/* Frequently Asked Questions (FAQ) */}
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="text-center space-y-1 mb-6">
          <h3 className="text-xl sm:text-2xl font-black text-slate-900">
            {isIndonesian ? 'Pertanyaan yang Sering Diajukan' : 'Frequently Asked Questions'}
          </h3>
          <p className="text-xs text-slate-500">
            {isIndonesian ? 'Informasi penting seputar penagihan, lisensi, dan keamanan data.' : 'Clear answers regarding subscriptions, licenses, and privacy.'}
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = activeFaqIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xs transition-all"
              >
                <button
                  onClick={() => setActiveFaqIndex(isOpen ? null : idx)}
                  className="w-full p-4.5 text-left flex items-center justify-between gap-4 font-bold text-xs sm:text-sm text-slate-900 hover:bg-slate-50/80 transition-colors cursor-pointer"
                >
                  <span>{isIndonesian ? faq.qId : faq.qEn}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                </button>

                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="px-4.5 pb-4 text-xs sm:text-[13px] text-slate-600 leading-relaxed border-t border-slate-100 pt-3"
                    >
                      {isIndonesian ? faq.aId : faq.aEn}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>

      {/* Checkout / Upgrade Confirmation Modal */}
      <AnimatePresence>
        {checkoutModalPlan && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !isProcessingPayment && setCheckoutModalPlan(null)}
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl z-10 overflow-hidden border border-slate-200"
            >
              {upgradeSuccess ? (
                <div className="p-8 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <h3 className="text-xl font-black text-slate-900">
                    {isIndonesian ? 'Upgrade Berhasil Diaktifkan!' : 'Upgrade Activated Successfully!'}
                  </h3>
                  <p className="text-xs text-slate-600">
                    {isIndonesian
                      ? `Selamat! Akun Anda kini aktif pada paket ${checkoutModalPlan.name}. Semua modul dan kuota telah diperbarui.`
                      : `Congratulations! Your account is now active on ${checkoutModalPlan.nameEn}. All features unlocked.`}
                  </p>
                </div>
              ) : (
                <div className="p-6 sm:p-7 space-y-5">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div>
                      <span className="text-[10px] uppercase font-black tracking-wider text-emerald-600">
                        {isIndonesian ? 'Konfirmasi Berlangganan' : 'Subscription Checkout'}
                      </span>
                      <h3 className="text-lg font-black text-slate-900">
                        {isIndonesian ? checkoutModalPlan.name : checkoutModalPlan.nameEn}
                      </h3>
                    </div>
                    <button
                      disabled={isProcessingPayment}
                      onClick={() => setCheckoutModalPlan(null)}
                      className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      <Lock className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Summary Box */}
                  <div className="bg-slate-50 rounded-2xl p-4 space-y-2 border border-slate-200/80">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-500">{isIndonesian ? 'Periode Penagihan' : 'Billing Cycle'}</span>
                      <span className="font-bold text-slate-800 capitalize">
                        {billingCycle === 'yearly' ? (isIndonesian ? 'Tahunan (Hemat 17%)' : 'Yearly (Save 17%)') : (isIndonesian ? 'Bulanan' : 'Monthly')}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm pt-1 border-t border-slate-200">
                      <span className="font-bold text-slate-800">{isIndonesian ? 'Total Pembayaran' : 'Total Amount'}</span>
                      <span className="font-black text-emerald-700 text-base">{formatPrice(checkoutModalPlan)}</span>
                    </div>
                  </div>

                  {/* Payment Method Selector */}
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase tracking-wider text-slate-500">
                      {isIndonesian ? 'Pilih Metode Pembayaran' : 'Payment Method'}
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('gpay')}
                        className={`p-3 rounded-xl border flex items-center gap-2.5 text-left transition-all cursor-pointer ${
                          paymentMethod === 'gpay'
                            ? 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500 font-bold'
                            : 'border-slate-200 bg-white hover:border-slate-300'
                        }`}
                      >
                        <Smartphone className="w-4 h-4 text-slate-700 shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-slate-900">Google Pay</p>
                          <p className="text-[10px] text-slate-400">Play Store One-Tap</p>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentMethod('qris')}
                        className={`p-3 rounded-xl border flex items-center gap-2.5 text-left transition-all cursor-pointer ${
                          paymentMethod === 'qris'
                            ? 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500 font-bold'
                            : 'border-slate-200 bg-white hover:border-slate-300'
                        }`}
                      >
                        <QrCode className="w-4 h-4 text-rose-600 shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-slate-900">QRIS Instan</p>
                          <p className="text-[10px] text-slate-400">BCA, GoPay, OVO</p>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentMethod('card')}
                        className={`p-3 rounded-xl border flex items-center gap-2.5 text-left transition-all cursor-pointer ${
                          paymentMethod === 'card'
                            ? 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500 font-bold'
                            : 'border-slate-200 bg-white hover:border-slate-300'
                        }`}
                      >
                        <CreditCard className="w-4 h-4 text-blue-600 shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-slate-900">Kartu Kredit/Debit</p>
                          <p className="text-[10px] text-slate-400">Visa / Mastercard</p>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentMethod('va')}
                        className={`p-3 rounded-xl border flex items-center gap-2.5 text-left transition-all cursor-pointer ${
                          paymentMethod === 'va'
                            ? 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500 font-bold'
                            : 'border-slate-200 bg-white hover:border-slate-300'
                        }`}
                      >
                        <Building2 className="w-4 h-4 text-teal-600 shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-slate-900">Virtual Account</p>
                          <p className="text-[10px] text-slate-400">BCA, Mandiri, BRI</p>
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-2 flex items-center gap-3">
                    <button
                      type="button"
                      disabled={isProcessingPayment}
                      onClick={() => setCheckoutModalPlan(null)}
                      className="flex-1 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer transition-colors"
                    >
                      {isIndonesian ? 'Batal' : 'Cancel'}
                    </button>
                    <button
                      type="button"
                      disabled={isProcessingPayment}
                      onClick={handleConfirmUpgrade}
                      className="flex-1 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md disabled:opacity-50"
                    >
                      {isProcessingPayment ? (
                        <span>{isIndonesian ? 'Memproses Transaksi...' : 'Processing...'}</span>
                      ) : (
                        <>
                          <Check className="w-4 h-4" />
                          <span>{isIndonesian ? 'Konfirmasi Pembayaran' : 'Confirm Payment'}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
