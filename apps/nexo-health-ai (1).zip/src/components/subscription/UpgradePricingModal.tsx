import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Check,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  Building2,
  User,
  Zap,
  CreditCard,
  QrCode,
  Smartphone,
  ChevronRight,
  Lock,
  Search,
  HelpCircle,
  Clock,
  Download,
  Flame,
  Award,
  ArrowRight,
  Shield
} from 'lucide-react';
import { SubscriptionPlanType, UserProfile } from '../../types';
import {
  SUBSCRIPTION_PLANS,
  ALL_FEATURES_MATRIX,
  SubscriptionPlanInfo,
  PlanFeatureItem,
  getPlanDetails
} from '../../data/subscriptionPlans';
import { FirestoreDataService } from '../../services/firestoreService';

interface UpgradePricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
  preSelectedPlan?: SubscriptionPlanType;
  onOpenBusinessHub?: () => void;
}

export const UpgradePricingModal: React.FC<UpgradePricingModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onUpdateProfile,
  preSelectedPlan = 'business',
  onOpenBusinessHub,
}) => {
  const isIndonesian = userProfile.language === 'id';
  const currentPlan = userProfile.subscriptionPlan || 'free';

  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('yearly');
  const [activeTab, setActiveTab] = useState<'plans' | 'features'>('plans');
  const [featureCategoryFilter, setFeatureCategoryFilter] = useState<'all' | 'ai_modules' | 'clinical_business' | 'security_support'>('all');
  const [featureSearchQuery, setFeatureSearchQuery] = useState('');

  // Checkout State
  const [checkoutPlan, setCheckoutPlan] = useState<SubscriptionPlanInfo | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'gpay' | 'qris' | 'card' | 'va'>('gpay');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [activatedPlan, setActivatedPlan] = useState<SubscriptionPlanInfo | null>(null);

  const handleStartCheckout = (plan: SubscriptionPlanInfo) => {
    if (plan.id === currentPlan) {
      alert(isIndonesian ? 'Anda saat ini sudah aktif pada paket ini.' : 'You are currently active on this plan.');
      return;
    }
    setCheckoutPlan(plan);
  };

  const handleConfirmPayment = async () => {
    if (!checkoutPlan) return;
    setIsProcessingPayment(true);

    // Simulate real gateway latency & token confirmation
    await new Promise((resolve) => setTimeout(resolve, 1400));

    const expiryDate = new Date();
    if (billingCycle === 'yearly') {
      expiryDate.setFullYear(expiryDate.getFullYear() + 1);
    } else {
      expiryDate.setMonth(expiryDate.getMonth() + 1);
    }

    const updatedProfile: Partial<UserProfile> = {
      subscriptionPlan: checkoutPlan.id,
      subscriptionStatus: 'active',
      planActiveUntil: expiryDate.toISOString().split('T')[0],
      clinicName: checkoutPlan.id === 'business' || checkoutPlan.id === 'enterprise' ? (userProfile.clinicName || 'Klinik Sehat AI') : undefined,
    };

    onUpdateProfile(updatedProfile);
    await FirestoreDataService.saveUserProfile({ ...userProfile, ...updatedProfile });

    setIsProcessingPayment(false);
    setPaymentSuccess(true);
    setActivatedPlan(checkoutPlan);
  };

  const filteredFeatures = ALL_FEATURES_MATRIX.filter((feat) => {
    const matchCat = featureCategoryFilter === 'all' || feat.category === featureCategoryFilter;
    const matchSearch =
      feat.name.toLowerCase().includes(featureSearchQuery.toLowerCase()) ||
      feat.nameEn.toLowerCase().includes(featureSearchQuery.toLowerCase()) ||
      feat.description.toLowerCase().includes(featureSearchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto" id="upgrade-pricing-modal">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={() => {
          if (!isProcessingPayment) onClose();
        }}
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm transition-opacity"
      />

      {/* Main Container Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl overflow-hidden z-10 flex flex-col max-h-[92vh] border border-slate-200 my-auto"
      >
        {/* Header Hero Section */}
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950 text-white p-6 sm:p-8 shrink-0 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer z-10"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="max-w-2xl relative z-10 space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Google Health & Play AI Hub Tier Plans</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {isIndonesian ? 'Tingkatkan ke Fitur Bisnis & AI Klinis' : 'Upgrade to Business & Clinical AI'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {isIndonesian
                ? 'Dapatkan akses bebas ke 20 modul kesehatan terpadu, generator resep klinis, pemindai gizi tanpa batas, dan dasbor manajemen multi-pasien.'
                : 'Unlock all 20 integrated health modules, clinical EHR prescriptions, unlimited AI food scans, and multi-patient management.'}
            </p>
          </div>

          {/* Sub Navigation Bar inside Modal */}
          <div className="mt-6 pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 relative z-10">
            {/* View Switcher */}
            <div className="flex bg-white/10 p-1 rounded-xl border border-white/10">
              <button
                onClick={() => setActiveTab('plans')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'plans'
                    ? 'bg-emerald-500 text-slate-950 shadow-sm font-black'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {isIndonesian ? 'Pilihan Paket & Harga' : 'Plans & Pricing'}
              </button>
              <button
                onClick={() => setActiveTab('features')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'features'
                    ? 'bg-emerald-500 text-slate-950 shadow-sm font-black'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {isIndonesian ? 'Tabel Perbandingan Fitur' : 'Compare Features Matrix'}
              </button>
            </div>

            {/* Billing Cycle Toggle */}
            <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10">
              <span className={`text-xs font-bold ${billingCycle === 'monthly' ? 'text-white' : 'text-slate-400'}`}>
                {isIndonesian ? 'Bulanan' : 'Monthly'}
              </span>
              <button
                onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
                className="w-11 h-6 bg-emerald-600 rounded-full p-0.5 transition-colors relative cursor-pointer"
              >
                <motion.div
                  animate={{ x: billingCycle === 'yearly' ? 20 : 0 }}
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  className="w-5 h-5 bg-white rounded-full shadow-md"
                />
              </button>
              <span className={`text-xs font-bold flex items-center gap-1 ${billingCycle === 'yearly' ? 'text-emerald-300' : 'text-slate-400'}`}>
                <span>{isIndonesian ? 'Tahunan' : 'Yearly'}</span>
                <span className="px-1.5 py-0.5 rounded-md bg-amber-400 text-slate-950 font-black text-[10px]">
                  {isIndonesian ? 'Hemat 20%' : 'Save 20%'}
                </span>
              </span>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 bg-slate-50">
          {/* TAB 1: PRICING CARDS */}
          {activeTab === 'plans' && (
            <div className="space-y-6">
              {/* Active Plan Status Banner */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-black">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 font-medium">
                      {isIndonesian ? 'Paket Aktif Akun Anda Saat Ini' : 'Your Current Active Tier'}
                    </p>
                    <p className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                      <span>{getPlanDetails(currentPlan).name}</span>
                      <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        {userProfile.subscriptionStatus === 'active' ? 'Aktif' : 'Gratis'}
                      </span>
                    </p>
                  </div>
                </div>

                {currentPlan === 'business' || currentPlan === 'enterprise' ? (
                  <button
                    onClick={() => {
                      onClose();
                      if (onOpenBusinessHub) onOpenBusinessHub();
                    }}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-sm"
                  >
                    <Building2 className="w-4 h-4 text-emerald-400" />
                    <span>{isIndonesian ? 'Buka Dasbor Bisnis & Klinik' : 'Open Clinic & Business Hub'}</span>
                  </button>
                ) : (
                  <p className="text-xs text-slate-500 font-medium">
                    {isIndonesian ? 'Pilih paket bisnis di bawah untuk membuka seluruh akses klinis & multi-pasien.' : 'Select a business plan below to unlock clinical tools.'}
                  </p>
                )}
              </div>

              {/* 4 Pricing Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
                {SUBSCRIPTION_PLANS.map((plan) => {
                  const isCurrent = currentPlan === plan.id;
                  const price =
                    billingCycle === 'yearly'
                      ? plan.priceYearlyIdr
                      : plan.priceMonthlyIdr;
                  const priceFormatted =
                    price === 0
                      ? isIndonesian ? 'Gratis' : 'Free'
                      : `Rp ${price.toLocaleString('id-ID')}`;
                  const periodSuffix =
                    price === 0
                      ? ''
                      : billingCycle === 'yearly'
                      ? '/ tahun'
                      : '/ bulan';

                  return (
                    <motion.div
                      key={plan.id}
                      whileHover={{ y: -4 }}
                      className={`relative bg-white rounded-3xl p-5 sm:p-6 flex flex-col justify-between border transition-all shadow-xs ${
                        plan.isPopular
                          ? 'border-emerald-500 ring-2 ring-emerald-500/30'
                          : plan.id === 'business'
                          ? 'border-teal-500 ring-2 ring-teal-500/20 bg-gradient-to-b from-teal-50/20 to-white'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {/* Popular / Highlight Ribbons */}
                      {plan.highlightText && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-extrabold text-[10px] uppercase tracking-wider shadow-sm whitespace-nowrap">
                          {isIndonesian ? plan.highlightText : plan.highlightTextEn}
                        </div>
                      )}

                      <div>
                        {/* Top Badge & Title */}
                        <div className="flex items-center justify-between mb-3">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black tracking-wider uppercase border ${plan.badgeColor}`}>
                            {plan.badge}
                          </span>
                          {isCurrent && (
                            <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full">
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span>{isIndonesian ? 'Paket Anda' : 'Current'}</span>
                            </span>
                          )}
                        </div>

                        <h3 className="text-lg font-black text-slate-900 tracking-tight">
                          {isIndonesian ? plan.name : plan.nameEn}
                        </h3>
                        <p className="text-xs text-slate-500 min-h-[32px] mt-1 line-clamp-2">
                          {isIndonesian ? plan.tagline : plan.taglineEn}
                        </p>

                        {/* Pricing */}
                        <div className="mt-4 mb-4 pb-4 border-b border-slate-100">
                          <div className="flex items-baseline gap-1">
                            <span className="text-2xl font-black text-slate-900 tracking-tight">
                              {priceFormatted}
                            </span>
                            <span className="text-xs font-bold text-slate-400">
                              {periodSuffix}
                            </span>
                          </div>
                          {billingCycle === 'yearly' && price > 0 && (
                            <p className="text-[11px] text-emerald-700 font-bold mt-1">
                              ~Rp {Math.round(price / 12).toLocaleString('id-ID')} / bulan (Hemat 20%)
                            </p>
                          )}
                        </div>

                        {/* Key Benefits Checklist */}
                        <div className="space-y-2.5 mb-6">
                          <p className="text-[11px] font-black uppercase text-slate-400 tracking-wider">
                            {isIndonesian ? 'Fitur yang Termasuk:' : 'Included Features:'}
                          </p>
                          {(isIndonesian ? plan.keyBenefits : plan.keyBenefitsEn).map((benefit, idx) => (
                            <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                              <span className="leading-snug">{benefit}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Action Button */}
                      <div>
                        {isCurrent ? (
                          <button
                            disabled
                            className="w-full py-3 rounded-2xl bg-slate-100 text-slate-400 font-bold text-xs cursor-default flex items-center justify-center gap-1.5"
                          >
                            <Check className="w-4 h-4" />
                            <span>{isIndonesian ? 'Paket Sedang Aktif' : 'Active Plan'}</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleStartCheckout(plan)}
                            className={`w-full py-3 rounded-2xl font-extrabold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm ${
                              plan.id === 'business'
                                ? 'bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white shadow-teal-500/20'
                                : plan.id === 'pro'
                                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-500/20'
                                : plan.id === 'enterprise'
                                ? 'bg-slate-900 hover:bg-slate-800 text-white'
                                : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                            }`}
                          >
                            <span>{isIndonesian ? `Pilih ${plan.name}` : `Select ${plan.nameEn}`}</span>
                            <ArrowRight className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: INTERACTIVE FEATURE MATRIX */}
          {activeTab === 'features' && (
            <div className="space-y-6">
              {/* Filter & Search Bar */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
                {/* Search */}
                <div className="relative flex-1 min-w-[220px]">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={featureSearchQuery}
                    onChange={(e) => setFeatureSearchQuery(e.target.value)}
                    placeholder={isIndonesian ? 'Cari nama fitur atau kata kunci klinis...' : 'Search features or clinical terms...'}
                    className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
                  />
                </div>

                {/* Category Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                  {[
                    { id: 'all', label: isIndonesian ? 'Semua Fitur' : 'All Features' },
                    { id: 'ai_modules', label: isIndonesian ? 'AI & Modul' : 'AI & Modules' },
                    { id: 'clinical_business', label: isIndonesian ? 'Klinis & Bisnis' : 'Clinical & Business' },
                    { id: 'security_support', label: isIndonesian ? 'Keamanan & Integrasi' : 'Security & Sync' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setFeatureCategoryFilter(cat.id as any)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                        featureCategoryFilter === cat.id
                          ? 'bg-emerald-600 text-white font-black shadow-2xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Comparison Table */}
              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    {/* Header Row */}
                    <thead>
                      <tr className="bg-slate-900 text-white border-b border-slate-800">
                        <th className="p-4 sm:p-5 font-black text-sm w-2/5">
                          {isIndonesian ? 'Fitur & Kemampuan Sistem' : 'Feature & Capability'}
                        </th>
                        <th className="p-4 text-center font-extrabold w-[15%]">
                          Gratis
                        </th>
                        <th className="p-4 text-center font-extrabold w-[15%] text-emerald-300">
                          AI Pro
                        </th>
                        <th className="p-4 text-center font-extrabold w-[15%] text-teal-300 bg-slate-800/80">
                          Bisnis / Klinik ⭐
                        </th>
                        <th className="p-4 text-center font-extrabold w-[15%] text-amber-300">
                          Enterprise
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredFeatures.map((feat) => (
                        <tr key={feat.id} className="hover:bg-slate-50/80 transition-colors">
                          {/* Feature Name & Desc */}
                          <td className="p-4 sm:p-5">
                            <p className="font-extrabold text-slate-900 text-xs sm:text-sm">
                              {isIndonesian ? feat.name : feat.nameEn}
                            </p>
                            <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                              {isIndonesian ? feat.description : feat.descriptionEn}
                            </p>
                          </td>

                          {/* Free */}
                          <td className="p-4 text-center">
                            {typeof feat.tiers.free === 'boolean' ? (
                              feat.tiers.free ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                              ) : (
                                <Lock className="w-3.5 h-3.5 text-slate-300 mx-auto" />
                              )
                            ) : (
                              <span className="font-bold text-slate-600 text-[11px]">{feat.tiers.free}</span>
                            )}
                          </td>

                          {/* Pro */}
                          <td className="p-4 text-center bg-emerald-50/20">
                            {typeof feat.tiers.pro === 'boolean' ? (
                              feat.tiers.pro ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 mx-auto" />
                              ) : (
                                <Lock className="w-3.5 h-3.5 text-slate-300 mx-auto" />
                              )
                            ) : (
                              <span className="font-bold text-emerald-800 text-[11px]">{feat.tiers.pro}</span>
                            )}
                          </td>

                          {/* Business */}
                          <td className="p-4 text-center bg-teal-50/40 font-bold">
                            {typeof feat.tiers.business === 'boolean' ? (
                              feat.tiers.business ? (
                                <CheckCircle2 className="w-4 h-4 text-teal-600 mx-auto" />
                              ) : (
                                <Lock className="w-3.5 h-3.5 text-slate-300 mx-auto" />
                              )
                            ) : (
                              <span className="font-extrabold text-teal-900 text-[11px]">{feat.tiers.business}</span>
                            )}
                          </td>

                          {/* Enterprise */}
                          <td className="p-4 text-center">
                            {typeof feat.tiers.enterprise === 'boolean' ? (
                              feat.tiers.enterprise ? (
                                <CheckCircle2 className="w-4 h-4 text-amber-600 mx-auto" />
                              ) : (
                                <Lock className="w-3.5 h-3.5 text-slate-300 mx-auto" />
                              )
                            ) : (
                              <span className="font-bold text-slate-800 text-[11px]">{feat.tiers.enterprise}</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer */}
        <div className="p-4 sm:p-5 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <Shield className="w-4 h-4 text-emerald-600" />
            <span>{isIndonesian ? 'Enkripsi Medis Terstandarisasi HIPAA & Cloud Firestore' : 'HIPAA Compliant & Cloud Firestore Security'}</span>
          </div>
          <button
            onClick={() => setActiveTab(activeTab === 'plans' ? 'features' : 'plans')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
          >
            <span>{activeTab === 'plans' ? (isIndonesian ? 'Lihat Matriks Fitur Lengkap →' : 'View Full Feature Matrix →') : (isIndonesian ? '← Kembali ke Pilihan Paket' : '← Back to Plans')}</span>
          </button>
        </div>
      </motion.div>

      {/* CHECKOUT / PAYMENT DIALOG */}
      <AnimatePresence>
        {checkoutPlan && !paymentSuccess && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !isProcessingPayment && setCheckoutPlan(null)}
              className="fixed inset-0 bg-slate-950/80 backdrop-blur-md"
            />

            <motion.div
              initial={{ scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.94, opacity: 0 }}
              className="relative w-full max-w-lg bg-white rounded-3xl p-6 sm:p-8 shadow-2xl z-10 space-y-5 border border-slate-200"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div>
                  <span className="text-[10px] font-black uppercase text-emerald-600 tracking-wider">
                    {isIndonesian ? 'Konfirmasi Pembelian Langganan' : 'Subscription Checkout'}
                  </span>
                  <h3 className="text-lg font-black text-slate-900">
                    {isIndonesian ? checkoutPlan.name : checkoutPlan.nameEn}
                  </h3>
                </div>
                <button
                  onClick={() => !isProcessingPayment && setCheckoutPlan(null)}
                  className="p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Price Summary */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-600">
                  <span>{isIndonesian ? 'Paket Layanan' : 'Plan Type'}</span>
                  <span className="font-bold text-slate-900">{checkoutPlan.name} ({billingCycle === 'yearly' ? 'Tahunan' : 'Bulanan'})</span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-600">
                  <span>{isIndonesian ? 'Periode Aktif' : 'Validity'}</span>
                  <span className="font-bold text-slate-900">{billingCycle === 'yearly' ? '12 Bulan (Hemat 20%)' : '1 Bulan'}</span>
                </div>
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-sm">
                  <span className="font-extrabold text-slate-900">{isIndonesian ? 'Total Pembayaran' : 'Total Amount'}</span>
                  <span className="font-black text-emerald-700 text-base">
                    Rp {(billingCycle === 'yearly' ? checkoutPlan.priceYearlyIdr : checkoutPlan.priceMonthlyIdr).toLocaleString('id-ID')}
                  </span>
                </div>
              </div>

              {/* Payment Methods Choice */}
              <div className="space-y-2">
                <p className="text-xs font-black text-slate-500 uppercase tracking-wider">
                  {isIndonesian ? 'Pilih Metode Pembayaran' : 'Select Payment Method'}
                </p>

                <div className="grid grid-cols-2 gap-2">
                  {/* Google Pay */}
                  <div
                    onClick={() => setPaymentMethod('gpay')}
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                      paymentMethod === 'gpay'
                        ? 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="w-6 h-6 rounded-md bg-slate-900 text-white font-black text-[10px] flex items-center justify-center">
                      GPay
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-800">Google Pay</p>
                      <p className="text-[10px] text-slate-400">Instan 1-Klik</p>
                    </div>
                  </div>

                  {/* QRIS */}
                  <div
                    onClick={() => setPaymentMethod('qris')}
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                      paymentMethod === 'qris'
                        ? 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="w-6 h-6 rounded-md bg-rose-600 text-white font-black text-[9px] flex items-center justify-center">
                      QRIS
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-800">QRIS Instan</p>
                      <p className="text-[10px] text-slate-400">BCA, Gopay, OVO</p>
                    </div>
                  </div>

                  {/* Kartu Kredit */}
                  <div
                    onClick={() => setPaymentMethod('card')}
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                      paymentMethod === 'card'
                        ? 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <CreditCard className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="text-xs font-bold text-slate-800">Kartu Kredit/Debit</p>
                      <p className="text-[10px] text-slate-400">Visa / Mastercard</p>
                    </div>
                  </div>

                  {/* Virtual Account */}
                  <div
                    onClick={() => setPaymentMethod('va')}
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                      paymentMethod === 'va'
                        ? 'border-emerald-500 bg-emerald-50/60 ring-1 ring-emerald-500'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <Smartphone className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="text-xs font-bold text-slate-800">Virtual Account</p>
                      <p className="text-[10px] text-slate-400">BCA, Mandiri, BRI</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Confirm Pay Button */}
              <button
                onClick={handleConfirmPayment}
                disabled={isProcessingPayment}
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md disabled:opacity-50"
              >
                {isProcessingPayment ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>{isIndonesian ? 'Memproses Transaksi...' : 'Processing Payment...'}</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>
                      {isIndonesian
                        ? `Bayar & Aktifkan Paket ${checkoutPlan.name}`
                        : `Pay & Activate ${checkoutPlan.nameEn}`}
                    </span>
                  </>
                )}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* PAYMENT SUCCESS CONFIRMATION MODAL */}
      <AnimatePresence>
        {paymentSuccess && activatedPlan && (
          <div className="fixed inset-0 z-70 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-950/85 backdrop-blur-md"
            />

            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-md bg-white rounded-3xl p-6 sm:p-8 shadow-2xl z-10 text-center space-y-5 border border-emerald-200"
            >
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto ring-8 ring-emerald-50 shadow-inner">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div className="space-y-1">
                <span className="px-3 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase tracking-wider">
                  {isIndonesian ? 'Pembayaran Berhasil & Terverifikasi' : 'Payment Success & Verified'}
                </span>
                <h3 className="text-xl font-black text-slate-900">
                  {isIndonesian ? 'Selamat! Paket Anda Kini Aktif' : 'Congratulations! Plan Activated'}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {isIndonesian
                    ? `Anda sekarang memiliki akses bebas ke seluruh fitur ${activatedPlan.name}. Data profil dan batasan sistem telah diperbarui secara otomatis.`
                    : `You now have full access to ${activatedPlan.nameEn} capabilities across all devices.`}
                </p>
              </div>

              <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 text-left space-y-1.5 text-xs text-emerald-900">
                <p className="font-bold flex items-center justify-between">
                  <span>{isIndonesian ? 'Nomor Bukti Transaksi:' : 'Transaction ID:'}</span>
                  <span className="font-mono text-[11px]">GH-{Math.random().toString(36).substring(2, 9).toUpperCase()}</span>
                </p>
                <p className="font-bold flex items-center justify-between">
                  <span>{isIndonesian ? 'Status Sinkronisasi:' : 'Sync Status:'}</span>
                  <span className="text-emerald-700">Cloud Firestore Persistent ✓</span>
                </p>
              </div>

              <div className="space-y-2">
                {activatedPlan.id === 'business' || activatedPlan.id === 'enterprise' ? (
                  <button
                    onClick={() => {
                      setPaymentSuccess(false);
                      setCheckoutPlan(null);
                      onClose();
                      if (onOpenBusinessHub) onOpenBusinessHub();
                    }}
                    className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-2xl flex items-center justify-center gap-2 cursor-pointer shadow-md"
                  >
                    <Building2 className="w-4 h-4 text-emerald-400" />
                    <span>{isIndonesian ? 'Buka Dasbor Bisnis & Klinik Sekarang' : 'Open Clinic & Business Hub'}</span>
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setPaymentSuccess(false);
                      setCheckoutPlan(null);
                      onClose();
                    }}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-2xl flex items-center justify-center gap-2 cursor-pointer shadow-md"
                  >
                    <span>{isIndonesian ? 'Mulai Eksplorasi Fitur Pro' : 'Start Exploring Pro Features'}</span>
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
