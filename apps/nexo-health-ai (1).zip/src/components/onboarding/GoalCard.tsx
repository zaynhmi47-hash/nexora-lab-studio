import React, { ReactNode } from 'react';
import { Check } from 'lucide-react';

interface GoalCardProps {
  id?: string;
  isSelected: boolean;
  onSelect: () => void;
  title: string;
  subtitle?: string;
  icon: ReactNode;
  categoryTag?: string;
  recommendedFor?: string;
  isMulti?: boolean;
}

export const GoalCard: React.FC<GoalCardProps> = ({
  id,
  isSelected,
  onSelect,
  title,
  subtitle,
  icon,
  categoryTag,
  recommendedFor,
  isMulti = false,
}) => {
  return (
    <button
      id={id}
      type="button"
      onClick={onSelect}
      className={`w-full text-left p-4 rounded-2xl border transition-all duration-200 cursor-pointer flex flex-col justify-between relative select-none ${
        isSelected
          ? 'bg-gradient-to-br from-emerald-50 to-teal-50/50 border-emerald-500 shadow-sm ring-2 ring-emerald-400/30'
          : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/40 shadow-2xs'
      }`}
    >
      <div className="flex items-start justify-between gap-3 w-full mb-3">
        <div className="flex items-center gap-3">
          <div
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all ${
              isSelected ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-100 text-slate-700'
            }`}
          >
            {icon}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className={`text-sm font-black ${isSelected ? 'text-emerald-950' : 'text-slate-900'}`}>
                {title}
              </span>
            </div>
            {categoryTag && (
              <span className="text-3xs font-bold uppercase tracking-wider text-emerald-600 block mt-0.5">
                {categoryTag}
              </span>
            )}
          </div>
        </div>

        {/* Check Indicator */}
        <div
          className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 transition-all ${
            isSelected
              ? 'bg-emerald-600 border-emerald-600 text-white'
              : 'border-slate-300 bg-white'
          }`}
        >
          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
        </div>
      </div>

      {subtitle && (
        <p className={`text-xs leading-relaxed ${isSelected ? 'text-emerald-900/80' : 'text-slate-500'}`}>
          {subtitle}
        </p>
      )}

      {recommendedFor && (
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-3xs text-slate-400 font-medium">
          <span>Target:</span>
          <span className="text-slate-700 font-bold">{recommendedFor}</span>
        </div>
      )}
    </button>
  );
};
