import React from 'react';
import { Minus, Plus } from 'lucide-react';

interface SliderInputProps {
  id?: string;
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  description?: string;
  onChange: (value: number) => void;
  quickLabels?: { value: number; label: string }[];
}

export const SliderInput: React.FC<SliderInputProps> = ({
  id,
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  description,
  onChange,
  quickLabels,
}) => {
  const handleDecrement = () => {
    const nextVal = Math.max(min, Math.round((value - step) * 10) / 10);
    onChange(nextVal);
  };

  const handleIncrement = () => {
    const nextVal = Math.min(max, Math.round((value + step) * 10) / 10);
    onChange(nextVal);
  };

  return (
    <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
      {/* Label and Value Header */}
      <div className="flex items-center justify-between">
        <div>
          <label htmlFor={id} className="text-sm font-bold text-slate-900 block">
            {label}
          </label>
          {description && <p className="text-xs text-slate-500 mt-0.5">{description}</p>}
        </div>

        {/* Current Value Display Badge */}
        <div className="flex items-baseline gap-1 bg-emerald-50 px-3.5 py-1.5 rounded-xl border border-emerald-200/60 text-emerald-900 shadow-2xs">
          <span className="text-xl font-black">{value}</span>
          {unit && <span className="text-xs font-bold text-emerald-700">{unit}</span>}
        </div>
      </div>

      {/* Interactive Range Slider */}
      <div className="space-y-2 pt-1">
        <input
          id={id}
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600 focus:outline-hidden"
        />

        {/* Min & Max Legend */}
        <div className="flex justify-between text-3xs font-bold text-slate-400">
          <span>
            {min} {unit}
          </span>
          <span>
            {max} {unit}
          </span>
        </div>
      </div>

      {/* Quick Fine-Tuning Control Buttons */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleDecrement}
            disabled={value <= min}
            className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center text-slate-700 font-bold transition-all cursor-pointer"
          >
            <Minus className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleIncrement}
            disabled={value >= max}
            className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-slate-200 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center text-slate-700 font-bold transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Quick presets if provided */}
        {quickLabels && (
          <div className="flex items-center gap-1">
            {quickLabels.map((q) => (
              <button
                key={q.value}
                type="button"
                onClick={() => onChange(q.value)}
                className={`px-2.5 py-1 rounded-lg text-3xs font-bold transition-all cursor-pointer ${
                  value === q.value
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                {q.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
