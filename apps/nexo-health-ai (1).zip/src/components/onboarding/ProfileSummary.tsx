import React from 'react';
import { User, Target, Activity, Moon, Sparkles, Bell, ShieldCheck, Check, Edit2 } from 'lucide-react';
import { UserProfile, PrimaryGoalType, SecondaryGoalType, ActivityLevelType, EquipmentType, AiToneType } from '../../types';

interface ProfileSummaryProps {
  formData: Partial<UserProfile>;
  onEditStep?: (stepIndex: number) => void;
}

export const ProfileSummary: React.FC<ProfileSummaryProps> = ({ formData, onEditStep }) => {
  const heightM = (formData.heightCm || 170) / 100;
  const weight = formData.weightKg || 65;
  const bmi = Math.round((weight / (heightM * heightM)) * 10) / 10;

  const getBmiCategory = (val: number) => {
    if (val < 18.5) return { label: 'Di Bawah Normal', color: 'text-amber-600 bg-amber-50' };
    if (val < 25) return { label: 'Normal / Ideal', color: 'text-emerald-700 bg-emerald-50' };
    if (val < 30) return { label: 'Kelebihan Berat', color: 'text-amber-700 bg-amber-50' };
    return { label: 'Kategori Obesitas', color: 'text-rose-700 bg-rose-50' };
  };

  const bmiCat = getBmiCategory(bmi);

  const goalTitles: Record<PrimaryGoalType, string> = {
    fitness: 'Kebugaran Umum & Stamina',
    weight_loss: 'Penurunan Berat & Fat Loss',
    muscle_gain: 'Pembentukan Otot & Hipertrofi',
    endurance: 'Daya Tahan Kardio & Atletik',
    stress_relief: 'Relaksasi & Reduksi Stres',
    healthy_aging: 'Kesehatan Jangka Panjang (Longevity)',
  };

  const secondaryGoalTitles: Record<SecondaryGoalType, string> = {
    better_sleep: 'Kualitas Tidur Nyenyak',
    posture_correction: 'Koreksi Postur & Ergonomi',
    flexibility: 'Kelenturan & Mobilitas Sendi',
    habit_consistency: 'Konsistensi Rutinitas Harian',
    nutrition_balance: 'Keseimbangan Makronutrisi',
    injury_prevention: 'Pencegahan Cedera & Recovery',
    cardiovascular_health: 'Kesehatan Jantung & Pembuluh',
    energy_boost: 'Vitalitas & Energi Harian',
  };

  const activityLevelTitles: Record<ActivityLevelType, string> = {
    sedentary: 'Sedentary (Banyak Duduk)',
    light: 'Ringan (1-2x / minggu)',
    moderate: 'Moderat (3-4x / minggu)',
    active: 'Aktif (5-6x / minggu)',
    very_active: 'Sangat Aktif / Atlet',
  };

  const equipmentTitles: Record<EquipmentType, string> = {
    none: 'Tanpa Alat (Bodyweight)',
    dumbbells: 'Dumbbell / Barbell Ringan',
    resistance_bands: 'Resistance Bands',
    full_gym: 'Akses Gym Lengkap',
    kettlebells: 'Kettlebell',
    pullup_bar: 'Pull-up Bar',
    cardio_machines: 'Mesin Kardio (Treadmill/Sepeda)',
    yoga_mat: 'Matras Yoga / Stretching',
  };

  const toneTitles: Record<AiToneType, { title: string; desc: string }> = {
    friendly: { title: 'Ramah & Mendukung', desc: 'Hangat, suportif dan memotivasi langkah kecil' },
    clinical: { title: 'Klinis & Berbasis Bukti', desc: 'Fokus data fisiologis dan acuan biomekanik' },
    motivational: { title: 'Pelatih Bersemangat', desc: 'Disiplin, energik dan fokus pencapaian target' },
    calm: { title: 'Tenang & Mindful', desc: 'Santai, holistik dan ramah pemulihan mental' },
  };

  return (
    <div className="space-y-4">
      {/* Overview Card */}
      <div className="bg-gradient-to-br from-emerald-900 to-slate-900 text-white p-6 rounded-3xl shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-emerald-600/30 border border-emerald-400/40 flex items-center justify-center text-white">
              <User className="w-7 h-7" />
            </div>
            <div>
              <span className="text-3xs uppercase font-bold text-emerald-300 tracking-wider block">
                PROFIL KESEHATAN PERSONAL
              </span>
              <h3 className="text-2xl font-black">{formData.name || 'Alex'}</h3>
              <p className="text-xs text-slate-300">
                {formData.age} Tahun • {formData.gender === 'male' ? 'Pria' : formData.gender === 'female' ? 'Wanita' : 'Lainnya'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/10">
            <div>
              <span className="text-3xs text-slate-300 block font-medium">Indeks Massa Tubuh (BMI)</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl font-black text-emerald-300">{bmi}</span>
                <span className={`px-2 py-0.5 rounded text-3xs font-bold ${bmiCat.color}`}>
                  {bmiCat.label}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {/* Basic Physical Data */}
        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
              <User className="w-4 h-4 text-emerald-600" />
              <span>Biometrik Fisik</span>
            </div>
            {onEditStep && (
              <button
                type="button"
                onClick={() => onEditStep(1)}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
              >
                <Edit2 className="w-3 h-3" />
                <span>Ubah</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
              <span className="text-slate-400 text-3xs block">Tinggi Badan</span>
              <span className="font-black text-slate-800 text-sm">{formData.heightCm} cm</span>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
              <span className="text-slate-400 text-3xs block">Berat Badan</span>
              <span className="font-black text-slate-800 text-sm">{formData.weightKg} kg</span>
            </div>
          </div>
        </div>

        {/* Goals */}
        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
              <Target className="w-4 h-4 text-emerald-600" />
              <span>Target & Fokus</span>
            </div>
            {onEditStep && (
              <button
                type="button"
                onClick={() => onEditStep(2)}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
              >
                <Edit2 className="w-3 h-3" />
                <span>Ubah</span>
              </button>
            )}
          </div>

          <div className="space-y-2 text-xs">
            <div className="bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-200/50">
              <span className="text-emerald-800 font-bold text-3xs uppercase tracking-wider block">Target Utama</span>
              <span className="font-bold text-emerald-950 text-sm">
                {formData.primaryGoal ? goalTitles[formData.primaryGoal] : 'Kebugaran Umum'}
              </span>
            </div>

            {formData.secondaryGoals && formData.secondaryGoals.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {formData.secondaryGoals.map((sg) => (
                  <span key={sg} className="px-2 py-0.5 bg-slate-100 text-slate-700 text-3xs font-bold rounded-md">
                    {secondaryGoalTitles[sg] || sg}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Lifestyle & Activity */}
        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
              <Activity className="w-4 h-4 text-emerald-600" />
              <span>Gaya Hidup & Latihan</span>
            </div>
            {onEditStep && (
              <button
                type="button"
                onClick={() => onEditStep(4)}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
              >
                <Edit2 className="w-3 h-3" />
                <span>Ubah</span>
              </button>
            )}
          </div>

          <div className="space-y-1.5 text-xs text-slate-700">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Aktivitas:</span>
              <span className="font-bold">{formData.activityLevel ? activityLevelTitles[formData.activityLevel] : 'Moderat'}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Frekuensi Latihan:</span>
              <span className="font-bold">{formData.exerciseFrequency ?? 3} hari / minggu</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-500">Peralatan:</span>
              <span className="font-bold text-right truncate max-w-[160px]">
                {formData.equipment?.map((e) => equipmentTitles[e] || e).join(', ') || 'Tanpa Alat'}
              </span>
            </div>
          </div>
        </div>

        {/* Sleep & AI Tone */}
        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>Tidur & Preferensi AI</span>
            </div>
            {onEditStep && (
              <button
                type="button"
                onClick={() => onEditStep(7)}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
              >
                <Edit2 className="w-3 h-3" />
                <span>Ubah</span>
              </button>
            )}
          </div>

          <div className="space-y-1.5 text-xs text-slate-700">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Target Tidur:</span>
              <span className="font-bold">{formData.sleepTargetHours ?? 7.5} Jam ({formData.bedtime || '23:00'} - {formData.wakeTime || '06:30'})</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Gaya Coach AI:</span>
              <span className="font-bold">{formData.aiTone ? toneTitles[formData.aiTone].title : 'Ramah'}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-500">Bahasa & Satuan:</span>
              <span className="font-bold uppercase">{formData.language || 'id'} • {formData.units || 'metric'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Privacy Guarantee Card */}
      <div className="bg-slate-100 p-4 rounded-2xl border border-slate-200 flex items-start gap-3 text-xs text-slate-600">
        <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
        <div>
          <strong className="text-slate-800 block">Jaminan Privasi & Batasan Klinis:</strong>
          Data profil Anda disimpan secara lokal dan aman. Profil ini digunakan eksklusif untuk personalisasi panduan latihan, nutrisi, dan kebiasaan sehat — bukan untuk diagnosis medis pengganti dokter.
        </div>
      </div>
    </div>
  );
};
