import React from 'react';

interface StepIndicatorProps {
  currentStep: number;
  totalSteps: number;
  stepTitle: string;
  stepCategory?: string;
}

export const StepIndicator: React.FC<StepIndicatorProps> = ({
  currentStep,
  totalSteps,
  stepTitle,
  stepCategory,
}) => {
  const progressPercent = Math.round(((currentStep + 1) / totalSteps) * 100);

  return (
    <div className="w-full space-y-2.5">
      {/* Top Header info */}
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          {stepCategory && (
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold uppercase tracking-wider text-3xs">
              {stepCategory}
            </span>
          )}
          <span className="text-slate-500 font-medium">
            Langkah <strong className="text-slate-900 font-bold">{currentStep + 1}</strong> dari {totalSteps}
          </span>
        </div>
        <span className="font-mono font-bold text-emerald-600">{progressPercent}%</span>
      </div>

      {/* Modern Progress Bar */}
      <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
        <div
          className="h-full bg-linear-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300 ease-out"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Step Title */}
      <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight pt-1">
        {stepTitle}
      </h2>
    </div>
  );
};
