import React, { ReactNode } from 'react';
import { Check } from 'lucide-react';

interface SelectionCardProps {
  id?: string;
  isSelected: boolean;
  onSelect: () => void;
  title: string;
  description?: string;
  icon?: ReactNode;
  badge?: string;
  disabled?: boolean;
}

export const SelectionCard: React.FC<SelectionCardProps> = ({
  id,
  isSelected,
  onSelect,
  title,
  description,
  icon,
  badge,
  disabled = false,
}) => {
  return (
    <button
      id={id}
      type="button"
      onClick={onSelect}
      disabled={disabled}
      className={`w-full text-left p-4 rounded-2xl border transition-all duration-200 cursor-pointer min-h-[56px] flex items-start gap-3.5 relative select-none ${
        isSelected
          ? 'bg-emerald-50/70 border-emerald-500 shadow-sm shadow-emerald-500/10 ring-2 ring-emerald-400/30'
          : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      {/* Icon Wrapper */}
      {icon && (
        <div
          className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
            isSelected
              ? 'bg-emerald-600 text-white'
              : 'bg-slate-100 text-slate-600 group-hover:bg-slate-200'
          }`}
        >
          {icon}
        </div>
      )}

      {/* Text Info */}
      <div className="flex-1 min-w-0 pr-6">
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`text-sm font-bold leading-snug ${isSelected ? 'text-emerald-950' : 'text-slate-900'}`}>
            {title}
          </span>
          {badge && (
            <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-3xs font-extrabold uppercase tracking-wide">
              {badge}
            </span>
          )}
        </div>
        {description && (
          <p className={`text-xs mt-0.5 leading-relaxed ${isSelected ? 'text-emerald-800/80' : 'text-slate-500'}`}>
            {description}
          </p>
        )}
      </div>

      {/* Selected Radio / Check Indicator */}
      <div
        className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 transition-all ${
          isSelected
            ? 'bg-emerald-600 border-emerald-600 text-white'
            : 'border-slate-300 bg-white'
        }`}
      >
        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
      </div>
    </button>
  );
};
