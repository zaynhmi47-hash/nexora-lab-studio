import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Check,
  User,
  Target,
  Activity,
  Calendar,
  Dumbbell,
  Moon,
  Bot,
  Globe,
  Ruler,
  Bell,
  FileText,
  ShieldCheck,
  CheckCircle2,
  Zap,
  RotateCcw,
} from 'lucide-react';

import {
  UserProfile,
  PrimaryGoalType,
  SecondaryGoalType,
  ActivityLevelType,
  EquipmentType,
  GenderType,
  UnitSystemType,
  AiToneType,
  LanguageCode,
} from '../../types';
import { StepIndicator } from './StepIndicator';
import { SelectionCard } from './SelectionCard';
import { GoalCard } from './GoalCard';
import { SliderInput } from './SliderInput';
import { ProfileSummary } from './ProfileSummary';
import { MOCK_PROFILE } from '../../data/mockProfile';

interface OnboardingFlowProps {
  initialProfile?: UserProfile;
  onComplete: (profile: Partial<UserProfile>) => void;
  onCancel?: () => void;
}

const TOTAL_STEPS = 14;

export const OnboardingFlow: React.FC<OnboardingFlowProps> = ({
  initialProfile,
  onComplete,
  onCancel,
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isFinishing, setIsFinishing] = useState(false);
  const [isReady, setIsReady] = useState(false);

  // Consolidated form state initialized with initialProfile or defaults
  const [formData, setFormData] = useState<Partial<UserProfile>>(() => ({
    name: initialProfile?.name || 'Alex',
    age: initialProfile?.age || 26,
    gender: initialProfile?.gender || 'other',
    heightCm: initialProfile?.heightCm || 167,
    weightKg: initialProfile?.weightKg || 58,
    primaryGoal: initialProfile?.primaryGoal || 'fitness',
    secondaryGoals: initialProfile?.secondaryGoals || ['better_sleep', 'posture_correction', 'habit_consistency'],
    activityLevel: initialProfile?.activityLevel || 'moderate',
    exerciseFrequency: initialProfile?.exerciseFrequency ?? 3,
    equipment: initialProfile?.equipment || ['none'],
    sleepTargetHours: initialProfile?.sleepTargetHours ?? 7.5,
    bedtime: initialProfile?.bedtime || '23:00',
    wakeTime: initialProfile?.wakeTime || '06:30',
    aiTone: initialProfile?.aiTone || 'friendly',
    language: initialProfile?.language || 'id',
    units: initialProfile?.units || 'metric',
    notifications: initialProfile?.notifications || {
      dailyReminders: true,
      workoutAlerts: true,
      hydrationNudges: true,
      weeklyProgress: true,
    },
  }));

  // Clear validation error whenever step or inputs change
  useEffect(() => {
    setValidationError(null);
  }, [currentStep]);

  // Validation function per step
  const validateCurrentStep = (step: number): boolean => {
    setValidationError(null);

    switch (step) {
      case 1: {
        // Basic Information
        if (!formData.name || formData.name.trim().length === 0) {
          setValidationError('Nama lengkap wajib diisi.');
          return false;
        }
        if (!formData.age || formData.age < 10 || formData.age > 120) {
          setValidationError('Usia harus berupa angka yang wajar (10 - 120 tahun).');
          return false;
        }
        if (!formData.heightCm || formData.heightCm < 50 || formData.heightCm > 260) {
          setValidationError('Tinggi badan harus diisi dengan benar (50 - 260 cm).');
          return false;
        }
        if (!formData.weightKg || formData.weightKg < 20 || formData.weightKg > 350) {
          setValidationError('Berat badan harus diisi dengan benar (20 - 350 kg).');
          return false;
        }
        return true;
      }
      case 2: {
        // Primary Goal
        if (!formData.primaryGoal) {
          setValidationError('Pilih 1 target utama Anda untuk melanjutkan.');
          return false;
        }
        return true;
      }
      case 3: {
        // Secondary Goals (optional but must be array)
        return true;
      }
      case 4: {
        // Activity Level
        if (!formData.activityLevel) {
          setValidationError('Pilih tingkat aktivitas harian Anda.');
          return false;
        }
        return true;
      }
      case 5: {
        // Exercise Frequency
        if (formData.exerciseFrequency === undefined || formData.exerciseFrequency < 0 || formData.exerciseFrequency > 7) {
          setValidationError('Frekuensi latihan harus antara 0 dan 7 hari per minggu.');
          return false;
        }
        return true;
      }
      case 6: {
        // Equipment
        if (!formData.equipment || formData.equipment.length === 0) {
          setValidationError('Pilih minimal 1 peralatan atau pilih "Tanpa Alat".');
          return false;
        }
        return true;
      }
      case 7: {
        // Sleep
        if (!formData.sleepTargetHours || formData.sleepTargetHours < 4 || formData.sleepTargetHours > 14) {
          setValidationError('Target tidur harian harus antara 4 hingga 14 jam.');
          return false;
        }
        return true;
      }
      case 8: {
        // AI Preferences
        if (!formData.aiTone) {
          setValidationError('Pilih gaya komunikasi Coach AI yang Anda sukai.');
          return false;
        }
        return true;
      }
      case 9: {
        // Language
        if (!formData.language) {
          setValidationError('Pilih bahasa antarmuka.');
          return false;
        }
        return true;
      }
      case 10: {
        // Units
        if (!formData.units) {
          setValidationError('Pilih sistem satuan (Metrik / Imperial).');
          return false;
        }
        return true;
      }
      case 11: {
        // Notifications
        return true;
      }
      case 12: {
        // Profile Summary
        return true;
      }
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (!validateCurrentStep(currentStep)) {
      return;
    }

    if (currentStep === 12) {
      // Transition to Step 13 (Completion / Loading & Ready)
      setCurrentStep(13);
      setIsFinishing(true);

      // Simulate AI personalization build flow
      setTimeout(() => {
        setIsFinishing(false);
        setIsReady(true);
      }, 1600);
      return;
    }

    setCurrentStep((prev) => Math.min(TOTAL_STEPS - 1, prev + 1));
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleApplyMockProfile = () => {
    setFormData({
      ...formData,
      name: MOCK_PROFILE.name,
      age: MOCK_PROFILE.age,
      gender: MOCK_PROFILE.gender,
      heightCm: MOCK_PROFILE.heightCm,
      weightKg: MOCK_PROFILE.weightKg,
      primaryGoal: MOCK_PROFILE.primaryGoal,
      secondaryGoals: MOCK_PROFILE.secondaryGoals,
      activityLevel: MOCK_PROFILE.activityLevel,
      exerciseFrequency: MOCK_PROFILE.exerciseFrequency,
      sleepTargetHours: MOCK_PROFILE.sleepTargetHours,
      equipment: MOCK_PROFILE.equipment,
      language: MOCK_PROFILE.language,
      units: MOCK_PROFILE.units,
      aiTone: MOCK_PROFILE.aiTone,
    });
  };

  const handleFinishAndEnterApp = () => {
    onComplete(formData);
  };

  // Toggle helpers for multi-select
  const toggleSecondaryGoal = (goal: SecondaryGoalType) => {
    const current = formData.secondaryGoals || [];
    if (current.includes(goal)) {
      setFormData({ ...formData, secondaryGoals: current.filter((g) => g !== goal) });
    } else {
      setFormData({ ...formData, secondaryGoals: [...current, goal] });
    }
  };

  const toggleEquipment = (equip: EquipmentType) => {
    let current = formData.equipment || [];
    if (equip === 'none') {
      setFormData({ ...formData, equipment: ['none'] });
      return;
    }
    current = current.filter((e) => e !== 'none');
    if (current.includes(equip)) {
      const filtered = current.filter((e) => e !== equip);
      setFormData({ ...formData, equipment: filtered.length > 0 ? filtered : ['none'] });
    } else {
      setFormData({ ...formData, equipment: [...current, equip] });
    }
  };

  // Step Titles Configuration
  const stepTitles = [
    'Selamat Datang di Health AI',
    'Informasi Dasar Fisik',
    'Tentukan Target Utama Anda',
    'Pilih Fokus & Target Tambahan',
    'Tingkat Aktivitas Harian',
    'Frekuensi Latihan Mingguan',
    'Peralatan Latihan yang Tersedia',
    'Pola Tidur & Jam Istirahat',
    'Gaya Komunikasi Coach AI',
    'Pilihan Bahasa',
    'Sistem Satuan',
    'Pengaturan Notifikasi',
    'Tinjau Rangkuman Profil Anda',
    'Konfirmasi & Personalisasi AI',
  ];

  const stepCategories = [
    'Pengantar',
    'Biometrik',
    'Goals',
    'Goals',
    'Lifestyle',
    'Lifestyle',
    'Lifestyle',
    'Lifestyle',
    'Preferensi AI',
    'Pengaturan',
    'Pengaturan',
    'Pengaturan',
    'Verifikasi',
    'Selesai',
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 flex flex-col max-h-[92vh] overflow-hidden my-auto"
      >
        {/* Top Header Bar */}
        <div className="px-6 pt-6 pb-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-xs">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="font-black text-slate-900 text-sm tracking-tight">
                Health AI Setup
              </span>
            </div>

            {/* Quick Fill Mock Button for testing/development */}
            <button
              type="button"
              onClick={handleApplyMockProfile}
              className="text-3xs font-bold text-slate-500 hover:text-emerald-700 bg-slate-100 hover:bg-emerald-50 px-2.5 py-1 rounded-lg border border-slate-200 transition-all flex items-center gap-1 cursor-pointer"
              title="Isi dengan profil Alex (Mock Development Profile)"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Isi Profil Alex</span>
            </button>
          </div>

          {currentStep < 13 && (
            <StepIndicator
              currentStep={currentStep}
              totalSteps={TOTAL_STEPS - 1}
              stepTitle={stepTitles[currentStep]}
              stepCategory={stepCategories[currentStep]}
            />
          )}
        </div>

        {/* Scrollable Step Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -12 }}
              transition={{ duration: 0.2 }}
              className="space-y-4"
            >
              {/* STEP 0: Welcome Screen */}
              {currentStep === 0 && (
                <div className="text-center py-4 space-y-6">
                  <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-xl shadow-emerald-500/20 flex items-center justify-center">
                    <div className="w-full h-full bg-emerald-600 rounded-[22px] flex items-center justify-center text-white">
                      <Sparkles className="w-10 h-10 animate-pulse" />
                    </div>
                  </div>

                  <div className="space-y-2 max-w-lg mx-auto">
                    <h3 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                      Personalisasi Kesehatan & Kebugaran Berbasis AI
                    </h3>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      Lengkapi beberapa informasi singkat untuk menyesuaikan pelatih AI, panduan nutrisi, dan program latihan yang tepat untuk tubuh dan tujuan Anda.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-left max-w-lg mx-auto pt-2">
                    <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                      <Zap className="w-5 h-5 text-emerald-600 mb-1.5" />
                      <h4 className="text-xs font-bold text-slate-800">Adaptive AI</h4>
                      <p className="text-3xs text-slate-500 mt-0.5">Program latihan yang menyesuaikan kapasitas tubuh Anda.</p>
                    </div>
                    <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                      <ShieldCheck className="w-5 h-5 text-emerald-600 mb-1.5" />
                      <h4 className="text-xs font-bold text-slate-800">Privasi Terjaga</h4>
                      <p className="text-3xs text-slate-500 mt-0.5">Data aman, lokal, dan tidak digunakan untuk diagnosa sembarangan.</p>
                    </div>
                    <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100">
                      <Bot className="w-5 h-5 text-emerald-600 mb-1.5" />
                      <h4 className="text-xs font-bold text-slate-800">Coach Personal</h4>
                      <p className="text-3xs text-slate-500 mt-0.5">Pendampingan 24/7 dengan gaya komunikasi pilihan Anda.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 1: Basic Information */}
              {currentStep === 1 && (
                <div className="space-y-4">
                  <p className="text-xs text-slate-500">
                    Informasi ini membantu algoritma menghitung kebutuhan kalori, laju metabolik basal (BMR), serta estimasi beban latihan ideal.
                  </p>

                  <div className="space-y-3.5">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">
                        Nama Lengkap / Panggilan <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={formData.name || ''}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Contoh: Alex"
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-hidden text-sm font-medium transition-all"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-bold text-slate-700 block mb-1">
                          Usia (Tahun) <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="number"
                          min={10}
                          max={120}
                          value={formData.age || ''}
                          onChange={(e) => setFormData({ ...formData, age: Number(e.target.value) })}
                          placeholder="26"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-hidden text-sm font-medium transition-all"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-bold text-slate-700 block mb-1">
                          Jenis Kelamin
                        </label>
                        <select
                          value={formData.gender || 'other'}
                          onChange={(e) => setFormData({ ...formData, gender: e.target.value as GenderType })}
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-hidden text-sm font-medium transition-all bg-white"
                        >
                          <option value="male">Pria</option>
                          <option value="female">Wanita</option>
                          <option value="other">Lainnya / Tidak Disebutkan</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-bold text-slate-700 block mb-1">
                          Tinggi Badan (cm) <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="number"
                          min={50}
                          max={250}
                          value={formData.heightCm || ''}
                          onChange={(e) => setFormData({ ...formData, heightCm: Number(e.target.value) })}
                          placeholder="167"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-hidden text-sm font-medium transition-all"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-bold text-slate-700 block mb-1">
                          Berat Badan (kg) <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="number"
                          min={20}
                          max={300}
                          value={formData.weightKg || ''}
                          onChange={(e) => setFormData({ ...formData, weightKg: Number(e.target.value) })}
                          placeholder="58"
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-hidden text-sm font-medium transition-all"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 2: Primary Goal */}
              {currentStep === 2 && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-500">
                    Pilih 1 prioritas utama yang paling ingin Anda capai dalam 3-6 bulan ke depan.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <GoalCard
                      isSelected={formData.primaryGoal === 'fitness'}
                      onSelect={() => setFormData({ ...formData, primaryGoal: 'fitness' })}
                      title="Kebugaran & Stamina Umum"
                      subtitle="Tingkatkan energi, daya tahan tubuh, dan mobilitas sehari-hari."
                      categoryTag="Vitalitas"
                      recommendedFor="Semua Tingkatan"
                      icon={<Activity className="w-5 h-5" />}
                    />
                    <GoalCard
                      isSelected={formData.primaryGoal === 'weight_loss'}
                      onSelect={() => setFormData({ ...formData, primaryGoal: 'weight_loss' })}
                      title="Penurunan Berat Badan"
                      subtitle="Bakar lemak efektif dengan defisit kalori terukur dan latihan terarah."
                      categoryTag="Fat Loss"
                      recommendedFor="Defisit Kalori"
                      icon={<Target className="w-5 h-5" />}
                    />
                    <GoalCard
                      isSelected={formData.primaryGoal === 'muscle_gain'}
                      onSelect={() => setFormData({ ...formData, primaryGoal: 'muscle_gain' })}
                      title="Pembentukan Massa Otot"
                      subtitle="Hipertrofi otot, kekuatan fungsional, dan target protein optimal."
                      categoryTag="Hipertrofi"
                      recommendedFor="Surplus Terkontrol"
                      icon={<Dumbbell className="w-5 h-5" />}
                    />
                    <GoalCard
                      isSelected={formData.primaryGoal === 'endurance'}
                      onSelect={() => setFormData({ ...formData, primaryGoal: 'endurance' })}
                      title="Daya Tahan Kardio & Atletik"
                      subtitle="Tingkatkan VO2 Max, performa lari, bersepeda, dan kapasitas aerobik."
                      categoryTag="Aerobik"
                      recommendedFor="Zona 2 & Laktat"
                      icon={<Zap className="w-5 h-5" />}
                    />
                    <GoalCard
                      isSelected={formData.primaryGoal === 'stress_relief'}
                      onSelect={() => setFormData({ ...formData, primaryGoal: 'stress_relief' })}
                      title="Relaksasi & Reduksi Stres"
                      subtitle="Pola napas, meditasi adaptif, dan regulasi sistem saraf otonom."
                      categoryTag="Mental Health"
                      recommendedFor="De-stress"
                      icon={<Moon className="w-5 h-5" />}
                    />
                    <GoalCard
                      isSelected={formData.primaryGoal === 'healthy_aging'}
                      onSelect={() => setFormData({ ...formData, primaryGoal: 'healthy_aging' })}
                      title="Longevity & Healthy Aging"
                      subtitle="Pertahankan densitas tulang, kesehatan sendi, dan metabolisme prima."
                      categoryTag="Panjang Umur"
                      recommendedFor="Kesehatan Jangka Panjang"
                      icon={<ShieldCheck className="w-5 h-5" />}
                    />
                  </div>
                </div>
              )}

              {/* STEP 3: Secondary Goals */}
              {currentStep === 3 && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-500">
                    Pilih target tambahan yang ingin didukung oleh Health AI (Boleh memilih lebih dari satu):
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {[
                      { id: 'better_sleep', title: 'Kualitas Tidur Lebih Nyenyak', desc: 'Ritual tidur dan optimasi ritme sirkadian.' },
                      { id: 'posture_correction', title: 'Koreksi Postur & Ergonomi', desc: 'Atasi leher bungkuk dan pegal punggung.' },
                      { id: 'flexibility', title: 'Kelenturan & Mobilitas Sendi', desc: 'Peregangan dinamis dan pemulihan fasia.' },
                      { id: 'habit_consistency', title: 'Konsistensi Rutinitas Harian', desc: 'Streak tracker dan pengingat kebiasaan kecil.' },
                      { id: 'nutrition_balance', title: 'Keseimbangan Makronutrisi', desc: 'Kebutuhan protein, serat, dan hidrasi harian.' },
                      { id: 'injury_prevention', title: 'Pencegahan Cedera & Recovery', desc: 'Protokol pemanasan dan FormGuard bio-feedback.' },
                      { id: 'cardiovascular_health', title: 'Kesehatan Jantung & Pembuluh', desc: 'Monitoring detak jantung dan latihan aerobik.' },
                      { id: 'energy_boost', title: 'Vitalitas Energi Pagi & Siang', desc: 'Atasi penurunan fokus di jam kerja.' },
                    ].map((item) => {
                      const isSelected = formData.secondaryGoals?.includes(item.id as SecondaryGoalType) || false;
                      return (
                        <SelectionCard
                          key={item.id}
                          isSelected={isSelected}
                          onSelect={() => toggleSecondaryGoal(item.id as SecondaryGoalType)}
                          title={item.title}
                          description={item.desc}
                        />
                      );
                    })}
                  </div>
                </div>
              )}

              {/* STEP 4: Activity Level */}
              {currentStep === 4 && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-500">
                    Berapa banyak aktivitas fisik non-olahraga yang biasa Anda lakukan dalam keseharian?
                  </p>

                  <div className="space-y-2.5">
                    {[
                      {
                        id: 'sedentary',
                        title: 'Sedentary (Banyak Duduk)',
                        desc: 'Pekerjaan meja di kantor atau di rumah, minim jalan kaki (< 3.000 langkah/hari).',
                      },
                      {
                        id: 'light',
                        title: 'Aktivitas Ringan',
                        desc: 'Pekerjaan santai, beberapa kali berjalan kaki atau berdiri (3.000 - 6.000 langkah/hari).',
                      },
                      {
                        id: 'moderate',
                        title: 'Aktivitas Moderat (Rekomendasi)',
                        desc: 'Banyak bergerak, jalan kaki aktif, naik tangga (6.000 - 10.000 langkah/hari).',
                      },
                      {
                        id: 'active',
                        title: 'Sangat Aktif',
                        desc: 'Pekerjaan fisik aktif, sering berdiri atau bergerak seharian (> 10.000 langkah/hari).',
                      },
                      {
                        id: 'very_active',
                        title: 'Tingkat Atlet / Pekerja Fisik Berat',
                        desc: 'Latihan intensif harian atau pekerjaan lapangan berat.',
                      },
                    ].map((lvl) => (
                      <SelectionCard
                        key={lvl.id}
                        isSelected={formData.activityLevel === lvl.id}
                        onSelect={() => setFormData({ ...formData, activityLevel: lvl.id as ActivityLevelType })}
                        title={lvl.title}
                        description={lvl.desc}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* STEP 5: Exercise Frequency */}
              {currentStep === 5 && (
                <div className="space-y-4">
                  <p className="text-xs text-slate-500">
                    Tentukan target hari latihan per minggu yang realistis untuk Anda jalani:
                  </p>

                  <SliderInput
                    label="Frekuensi Latihan"
                    description="Jumlah hari per minggu untuk berolahraga atau latihan terstruktur."
                    value={formData.exerciseFrequency ?? 3}
                    min={0}
                    max={7}
                    step={1}
                    unit="hari / minggu"
                    onChange={(val) => setFormData({ ...formData, exerciseFrequency: val })}
                    quickLabels={[
                      { value: 0, label: '0 Hari (Baru Mulai)' },
                      { value: 3, label: '3 Hari (Ideal Pemula)' },
                      { value: 4, label: '4 Hari (Optimal)' },
                      { value: 5, label: '5 Hari (Lanjutan)' },
                    ]}
                  />

                  <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200/60 text-xs text-emerald-900">
                    <strong>Saran AI Coach:</strong>{' '}
                    {(formData.exerciseFrequency ?? 3) <= 2
                      ? 'Target 1-2 hari sangat baik untuk membangun kebiasaan tanpa membebani tubuh.'
                      : (formData.exerciseFrequency ?? 3) <= 4
                      ? 'Target 3-4 hari merupakan titik emas antara stimulasi otot dan waktu pemulihan (recovery).'
                      : 'Target 5-7 hari membutuhkan manajemen tidur dan nutrisi anti-inflamasi yang ketat.'}
                  </div>
                </div>
              )}

              {/* STEP 6: Equipment */}
              {currentStep === 6 && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-500">
                    Pilih peralatan yang Anda miliki saat ini untuk merancang variasi gerakan yang sesuai:
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {[
                      { id: 'none', title: 'Tanpa Alat (Bodyweight)', desc: 'Latihan fleksibel di rumah/kamar.' },
                      { id: 'dumbbells', title: 'Dumbbell / Barbell', desc: 'Beban bebas untuk resistensi otot.' },
                      { id: 'resistance_bands', title: 'Resistance Bands', desc: 'Karet resistensi untuk aktivasi sendi.' },
                      { id: 'full_gym', title: 'Akses Gym Lengkap', desc: 'Mesin beban, cable, barbell, rack.' },
                      { id: 'kettlebells', title: 'Kettlebell', desc: 'Latihan balistik dan fungsional core.' },
                      { id: 'pullup_bar', title: 'Pull-up Bar', desc: 'Latihan pull vertical tubuh atas.' },
                      { id: 'cardio_machines', title: 'Mesin Kardio', desc: 'Treadmill, sepeda statis, atau rowing.' },
                      { id: 'yoga_mat', title: 'Matras Yoga', desc: 'Alas empuk untuk mobilitas dan core.' },
                    ].map((eq) => {
                      const isSelected = formData.equipment?.includes(eq.id as EquipmentType) || false;
                      return (
                        <SelectionCard
                          key={eq.id}
                          isSelected={isSelected}
                          onSelect={() => toggleEquipment(eq.id as EquipmentType)}
                          title={eq.title}
                          description={eq.desc}
                        />
                      );
                    })}
                  </div>
                </div>
              )}

              {/* STEP 7: Sleep */}
              {currentStep === 7 && (
                <div className="space-y-4">
                  <p className="text-xs text-slate-500">
                    Pemulihan dan sintesis otot berlangsung saat tidur. Atur target jam istirahat harian Anda:
                  </p>

                  <SliderInput
                    label="Target Durasi Tidur"
                    description="Rekomendasi medis umum untuk dewasa adalah 7 hingga 9 jam."
                    value={formData.sleepTargetHours ?? 7.5}
                    min={4}
                    max={12}
                    step={0.5}
                    unit="Jam"
                    onChange={(val) => setFormData({ ...formData, sleepTargetHours: val })}
                    quickLabels={[
                      { value: 6, label: '6 Jam' },
                      { value: 7, label: '7 Jam' },
                      { value: 7.5, label: '7.5 Jam' },
                      { value: 8, label: '8 Jam' },
                    ]}
                  />

                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">
                        Perkiraan Jam Tidur (Bedtime)
                      </label>
                      <input
                        type="time"
                        value={formData.bedtime || '23:00'}
                        onChange={(e) => setFormData({ ...formData, bedtime: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:border-emerald-500 outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-700 block mb-1">
                        Perkiraan Jam Bangun (Wake Time)
                      </label>
                      <input
                        type="time"
                        value={formData.wakeTime || '06:30'}
                        onChange={(e) => setFormData({ ...formData, wakeTime: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:border-emerald-500 outline-hidden"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 8: AI Preferences */}
              {currentStep === 8 && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-500">
                    Pilih gaya penyampaian saran dan dorongan dari asisten AI Health Coach Anda:
                  </p>

                  <div className="space-y-2.5">
                    {[
                      {
                        id: 'friendly',
                        title: 'Ramah & Suportif (Direkomendasikan)',
                        desc: 'Hangat, penuh empati, merayakan pencapaian kecil, dan mendampingi langkah demi langkah.',
                      },
                      {
                        id: 'clinical',
                        title: 'Klinis & Objektif Berbasis Bukti',
                        desc: 'Fokus pada metrik fisiologis, biomekanik, data riset, dan penjelasan ilmiah terstruktur.',
                      },
                      {
                        id: 'motivational',
                        title: 'Pelatih Bersemangat & Disiplin',
                        desc: 'Energetik, fokus pada target tantangan, menjaga akuntabilitas, dan mendorong performa terbaik.',
                      },
                      {
                        id: 'calm',
                        title: 'Tenang & Mindful (Holistik)',
                        desc: 'Menekankan kesadaran tubuh, pernapasan, relaksasi stres, dan gaya hidup seimbang.',
                      },
                    ].map((tone) => (
                      <SelectionCard
                        key={tone.id}
                        isSelected={formData.aiTone === tone.id}
                        onSelect={() => setFormData({ ...formData, aiTone: tone.id as AiToneType })}
                        title={tone.title}
                        description={tone.desc}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* STEP 9: Language */}
              {currentStep === 9 && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-500">
                    Pilih bahasa utama untuk antarmuka aplikasi dan komunikasi AI Coach:
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {[
                      { code: 'id', name: 'Bahasa Indonesia', flag: '🇮🇩' },
                      { code: 'en', name: 'English (US)', flag: '🇺🇸' },
                      { code: 'ja', name: '日本語 (Japanese)', flag: '🇯🇵' },
                      { code: 'es', name: 'Español', flag: '🇪🇸' },
                      { code: 'pt', name: 'Português', flag: '🇧🇷' },
                      { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
                      { code: 'fr', name: 'Français', flag: '🇫🇷' },
                      { code: 'ar', name: 'العربية (Arabic)', flag: '🇸🇦' },
                    ].map((l) => (
                      <button
                        key={l.code}
                        type="button"
                        onClick={() => setFormData({ ...formData, language: l.code as LanguageCode })}
                        className={`p-4 rounded-2xl border flex items-center justify-between transition-all cursor-pointer ${
                          formData.language === l.code
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold ring-2 ring-emerald-400/30'
                            : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-xl">{l.flag}</span>
                          <span className="text-sm font-bold">{l.name}</span>
                        </div>
                        {formData.language === l.code && <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* STEP 10: Units */}
              {currentStep === 10 && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-500">
                    Pilih format satuan pengukuran untuk tinggi, berat badan, dan jarak:
                  </p>

                  <div className="space-y-3">
                    <SelectionCard
                      isSelected={formData.units === 'metric' || !formData.units}
                      onSelect={() => setFormData({ ...formData, units: 'metric' })}
                      title="Metrik (kg, cm, km, ml)"
                      description="Standar internasional yang umum digunakan di Indonesia, Asia, dan Eropa."
                    />
                    <SelectionCard
                      isSelected={formData.units === 'imperial'}
                      onSelect={() => setFormData({ ...formData, units: 'imperial' })}
                      title="Imperial (lbs, ft/in, miles, oz)"
                      description="Standar yang umum digunakan di Amerika Serikat dan Inggris."
                    />
                  </div>
                </div>
              )}

              {/* STEP 11: Notifications */}
              {currentStep === 11 && (
                <div className="space-y-3">
                  <p className="text-xs text-slate-500">
                    Atur preferensi pengingat otomatis untuk menjaga rutinitas harian Anda:
                  </p>

                  <div className="space-y-2.5">
                    {[
                      {
                        key: 'dailyReminders',
                        title: 'Pengingat Rutinitas Harian',
                        desc: 'Nudge cerdas di pagi dan sore hari untuk cek target harian.',
                      },
                      {
                        key: 'workoutAlerts',
                        title: 'Jadwal Olahraga & Sesi Latihan',
                        desc: 'Pengingat sesi workout terjadwal dan saran pemanasan 5 menit.',
                      },
                      {
                        key: 'hydrationNudges',
                        title: 'Pengingat Minum Air (Smart Hydration)',
                        desc: 'Nudge berkala setiap 2 jam untuk menjaga asupan cairan tubuh.',
                      },
                      {
                        key: 'weeklyProgress',
                        title: 'Rangkuman Kemajuan Mingguan',
                        desc: 'Laporan evaluasi AI mingguan, streak badge, dan pencapaian target.',
                      },
                    ].map((notif) => {
                      const notifObj = formData.notifications || {
                        dailyReminders: true,
                        workoutAlerts: true,
                        hydrationNudges: true,
                        weeklyProgress: true,
                      };
                      const isChecked = notifObj[notif.key as keyof typeof notifObj];
                      return (
                        <div
                          key={notif.key}
                          onClick={() => {
                            setFormData({
                              ...formData,
                              notifications: {
                                ...notifObj,
                                [notif.key]: !isChecked,
                              },
                            });
                          }}
                          className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                            isChecked
                              ? 'bg-emerald-50/70 border-emerald-300 ring-1 ring-emerald-300/40'
                              : 'bg-white border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <div className="pr-4">
                            <h4 className="text-xs font-bold text-slate-900">{notif.title}</h4>
                            <p className="text-3xs text-slate-500 mt-0.5">{notif.desc}</p>
                          </div>
                          <div
                            className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-all ${
                              isChecked ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-300 bg-white'
                            }`}
                          >
                            {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* STEP 12: Profile Summary */}
              {currentStep === 12 && (
                <div className="space-y-4">
                  <ProfileSummary
                    formData={formData}
                    onEditStep={(stepIndex) => setCurrentStep(stepIndex)}
                  />
                </div>
              )}

              {/* STEP 13: Completion & Loading State */}
              {currentStep === 13 && (
                <div className="text-center py-10 space-y-6">
                  {isFinishing ? (
                    <div className="space-y-4">
                      <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-100 flex items-center justify-center text-emerald-600 animate-spin">
                        <Sparkles className="w-8 h-8" />
                      </div>
                      <h3 className="text-xl font-black text-slate-900">
                        Menyiapkan Pengalaman Health AI Anda...
                      </h3>
                      <p className="text-xs text-slate-500 max-w-sm mx-auto">
                        Mengalkulasi target makronutrisi, BMR, dan merancang modul personalisasi adaptif berdasarkan profil Anda.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="w-20 h-20 mx-auto rounded-3xl bg-emerald-600 text-white flex items-center justify-center shadow-xl shadow-emerald-600/30">
                        <CheckCircle2 className="w-10 h-10" />
                      </div>

                      <div className="space-y-2">
                        <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider">
                          Setup Berhasil
                        </span>
                        <h3 className="text-3xl font-black text-slate-900">
                          Profil Anda Siap! 🎉
                        </h3>
                        <p className="text-sm text-slate-600 max-w-md mx-auto">
                          Selamat bergabung, <strong>{formData.name || 'Alex'}</strong>! Pelatih AI dan seluruh modul kesehatan pintar kini siap mendampingi perjalanan sehat Anda.
                        </p>
                      </div>

                      <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 max-w-md mx-auto text-left flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center shrink-0">
                          <Zap className="w-5 h-5" />
                        </div>
                        <div>
                          <span className="text-xs font-bold text-slate-900 block">+150 XP Bonus Awal Diterima!</span>
                          <span className="text-3xs text-slate-500">Tingkat Level 1 (Starter Health Explorer)</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={handleFinishAndEnterApp}
                        className="w-full max-w-md mx-auto py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <span>Mulai Sekarang ke Beranda</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Inline Validation Feedback */}
          {validationError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-bold flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
              <span>{validationError}</span>
            </div>
          )}
        </div>

        {/* Bottom Navigation Toolbar */}
        {currentStep < 13 && (
          <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleBack}
              disabled={currentStep === 0}
              className={`px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 transition-all flex items-center gap-1.5 cursor-pointer ${
                currentStep === 0 ? 'opacity-0 pointer-events-none' : ''
              }`}
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Kembali</span>
            </button>

            <div className="flex items-center gap-2">
              {onCancel && (
                <button
                  type="button"
                  onClick={onCancel}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-700 cursor-pointer"
                >
                  Batal
                </button>
              )}

              <button
                type="button"
                onClick={handleNext}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>{currentStep === 12 ? 'Konfirmasi & Selesai' : 'Lanjutkan'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
