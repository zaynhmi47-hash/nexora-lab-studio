import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, Sparkles, CornerDownLeft } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  placeholder?: string;
  onVoiceClickPlaceholder?: () => void;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading,
  placeholder = 'Tanyakan latihan, nutrisi, atau panduan tidur...',
  onVoiceClickPlaceholder,
}) => {
  const [inputText, setInputText] = useState('');
  const [showMicTooltip, setShowMicTooltip] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [inputText]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;
    onSendMessage(inputText.trim());
    setInputText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleMicClick = () => {
    setShowMicTooltip(true);
    setTimeout(() => setShowMicTooltip(false), 3000);
    if (onVoiceClickPlaceholder) onVoiceClickPlaceholder();
  };

  return (
    <div className="w-full relative">
      {/* Mic Tooltip */}
      {showMicTooltip && (
        <div className="absolute -top-10 left-3 bg-slate-900 text-white text-[11px] px-3 py-1.5 rounded-lg shadow-lg z-30 animate-fade-in flex items-center gap-1.5">
          <Mic size={12} className="text-emerald-400" />
          <span>Fitur Suara Real-time (LiveKit) akan aktif di langkah berikutnya.</span>
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        className="relative flex items-end gap-2 bg-white border border-slate-200/90 focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-100 rounded-2xl p-2 sm:p-2.5 shadow-sm transition-all"
      >
        {/* Voice Button Placeholder */}
        <button
          type="button"
          onClick={handleMicClick}
          title="Voice Chat (Segera Hadir)"
          className="p-2.5 rounded-xl text-slate-400 hover:text-emerald-600 hover:bg-emerald-50/80 transition-colors shrink-0 cursor-pointer"
        >
          <Mic size={18} />
        </button>

        {/* Text Input */}
        <textarea
          ref={textareaRef}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={isLoading}
          rows={1}
          className="flex-1 max-h-28 py-2 px-1 text-sm sm:text-base text-slate-800 placeholder-slate-400 bg-transparent resize-none focus:outline-none leading-relaxed"
        />

        {/* Send Button */}
        <button
          type="submit"
          disabled={!inputText.trim() || isLoading}
          className={`p-2.5 rounded-xl font-bold flex items-center justify-center shrink-0 transition-all cursor-pointer ${
            inputText.trim() && !isLoading
              ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-md shadow-emerald-600/20 active:scale-95'
              : 'bg-slate-100 text-slate-400 cursor-not-allowed'
          }`}
        >
          <Send size={16} />
        </button>
      </form>

      <div className="flex items-center justify-between px-2 pt-1.5 text-[11px] text-slate-600">
        <span className="hidden sm:inline">Tekan Enter untuk mengirim • Shift+Enter baris baru</span>
        <span className="flex items-center gap-1 ml-auto">
          <Sparkles size={11} className="text-emerald-500" />
          Didukung oleh Google Gemini 3
        </span>
      </div>
    </div>
  );
};
