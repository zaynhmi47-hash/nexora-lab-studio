import React from 'react';
import { Bot, User, Sparkles, AlertTriangle, Flame, Moon, Apple } from 'lucide-react';
import { AIResponseType } from '../../types/ai';

interface AIAvatarProps {
  role: 'user' | 'assistant' | 'system';
  responseType?: AIResponseType;
  size?: 'sm' | 'md' | 'lg';
  isThinking?: boolean;
}

export const AIAvatar: React.FC<AIAvatarProps> = ({
  role,
  responseType = 'text',
  size = 'md',
  isThinking = false,
}) => {
  const sizeClasses = {
    sm: 'w-7 h-7 text-xs',
    md: 'w-9 h-9 text-sm',
    lg: 'w-11 h-11 text-base',
  }[size];

  const iconSizes = {
    sm: 14,
    md: 18,
    lg: 22,
  }[size];

  if (role === 'user') {
    return (
      <div
        id="user-avatar-badge"
        className={`${sizeClasses} rounded-full bg-slate-900 text-white flex items-center justify-center shadow-sm shrink-0 border border-slate-700`}
      >
        <User size={iconSizes} />
      </div>
    );
  }

  // Choose icon & background based on response type
  let bgClasses = 'bg-emerald-600 text-white shadow-emerald-500/20';
  let IconComponent = Bot;

  if (responseType === 'emergency_guidance' || responseType === 'warning') {
    bgClasses = 'bg-rose-600 text-white shadow-rose-500/30 ring-2 ring-rose-300';
    IconComponent = AlertTriangle;
  } else if (responseType === 'workout_recommendation') {
    bgClasses = 'bg-indigo-600 text-white shadow-indigo-500/20';
    IconComponent = Flame;
  } else if (responseType === 'nutrition_advice') {
    bgClasses = 'bg-amber-600 text-white shadow-amber-500/20';
    IconComponent = Apple;
  } else if (responseType === 'health_advice') {
    bgClasses = 'bg-teal-600 text-white shadow-teal-500/20';
    IconComponent = Sparkles;
  }

  return (
    <div className="relative shrink-0">
      <div
        id="ai-avatar-badge"
        className={`${sizeClasses} rounded-full ${bgClasses} flex items-center justify-center shadow-md transition-all ${
          isThinking ? 'animate-pulse ring-2 ring-emerald-400/50' : ''
        }`}
      >
        <IconComponent size={iconSizes} />
      </div>
      {isThinking && (
        <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 border-2 border-white rounded-full animate-ping" />
      )}
    </div>
  );
};
