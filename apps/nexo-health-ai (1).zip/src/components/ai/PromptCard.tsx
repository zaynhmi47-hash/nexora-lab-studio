import React from 'react';
import { motion } from 'motion/react';
import { Dumbbell, Utensils, Moon, Droplets, TrendingUp, Sparkles, AlertCircle } from 'lucide-react';

interface PromptCardProps {
  prompt: string;
  onClick: (prompt: string) => void;
  category?: 'fitness' | 'nutrition' | 'sleep' | 'hydration' | 'progress' | 'general';
  disabled?: boolean;
}

export const PromptCard: React.FC<PromptCardProps> = ({
  prompt,
  onClick,
  category = 'general',
  disabled = false,
}) => {
  const getIcon = () => {
    const pLower = prompt.toLowerCase();
    if (pLower.includes('latihan') || pLower.includes('workout') || category === 'fitness') return Dumbbell;
    if (pLower.includes('makan') || pLower.includes('eat') || category === 'nutrition') return Utensils;
    if (pLower.includes('tidur') || pLower.includes('sleep') || category === 'sleep') return Moon;
    if (pLower.includes('hidrasi') || pLower.includes('air') || category === 'hydration') return Droplets;
    if (pLower.includes('perkembangan') || pLower.includes('progress') || category === 'progress') return TrendingUp;
    return Sparkles;
  };

  const IconComponent = getIcon();

  return (
    <motion.button
      whileHover={{ scale: 1.02, y: -1 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onClick(prompt)}
      disabled={disabled}
      className={`group text-left px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white/90 hover:bg-emerald-50/80 hover:border-emerald-300 transition-all shadow-xs flex items-center gap-2.5 cursor-pointer ${
        disabled ? 'opacity-50 pointer-events-none' : ''
      }`}
    >
      <div className="w-6 h-6 rounded-lg bg-slate-100 group-hover:bg-emerald-100 text-slate-600 group-hover:text-emerald-700 flex items-center justify-center shrink-0 transition-colors">
        <IconComponent size={13} />
      </div>
      <span className="text-xs sm:text-sm font-medium text-slate-800 group-hover:text-emerald-950 line-clamp-1 leading-snug">
        {prompt}
      </span>
    </motion.button>
  );
};
