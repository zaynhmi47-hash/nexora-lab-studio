import React from 'react';
import { motion } from 'motion/react';
import { AIAvatar } from './AIAvatar';

interface TypingIndicatorProps {
  label?: string;
}

export const TypingIndicator: React.FC<TypingIndicatorProps> = ({
  label = 'AI is thinking...',
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -6 }}
      className="flex items-start gap-3 w-full max-w-2xl"
    >
      <AIAvatar role="assistant" isThinking size="md" />

      <div
        id="ai-typing-container"
        className="bg-white border border-slate-200/90 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm flex items-center gap-3"
      >
        <span className="text-xs font-semibold text-slate-700 tracking-tight">{label}</span>
        
        <div className="flex items-center gap-1">
          <motion.span
            animate={{ scale: [1, 1.4, 1], opacity: [0.4, 1, 0.4] }}
            transition={{ repeat: Infinity, duration: 1, ease: 'easeInOut', delay: 0 }}
            className="w-1.5 h-1.5 rounded-full bg-emerald-600 inline-block"
          />
          <motion.span
            animate={{ scale: [1, 1.4, 1], opacity: [0.4, 1, 0.4] }}
            transition={{ repeat: Infinity, duration: 1, ease: 'easeInOut', delay: 0.2 }}
            className="w-1.5 h-1.5 rounded-full bg-emerald-600 inline-block"
          />
          <motion.span
            animate={{ scale: [1, 1.4, 1], opacity: [0.4, 1, 0.4] }}
            transition={{ repeat: Infinity, duration: 1, ease: 'easeInOut', delay: 0.4 }}
            className="w-1.5 h-1.5 rounded-full bg-emerald-600 inline-block"
          />
        </div>
      </div>
    </motion.div>
  );
};
