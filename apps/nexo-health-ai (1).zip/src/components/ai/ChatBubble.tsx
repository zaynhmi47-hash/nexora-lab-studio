import React from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
  ListOrdered,
  Activity,
  Flame,
  Apple,
  ShieldAlert,
  HelpCircle,
  Clock,
} from 'lucide-react';
import { AIMessage } from '../../types/ai';
import { AIAvatar } from './AIAvatar';
import { PromptCard } from './PromptCard';

interface ChatBubbleProps {
  message: AIMessage;
  onRetry?: () => void;
  onSelectPrompt?: (prompt: string) => void;
  isLast?: boolean;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({
  message,
  onRetry,
  onSelectPrompt,
  isLast = false,
}) => {
  const isUser = message.role === 'user';
  const { responseType = 'text', structuredData, isError, suggestedPrompts } = message;

  // Format content with basic bold markdown rendering
  const renderFormattedText = (text: string) => {
    // Basic bold parsing: **text**
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-semibold text-slate-900">
            {part.slice(2, -2)}
          </strong>
        );
      }
      return <span key={i}>{part}</span>;
    });
  };

  if (isUser) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-start justify-end gap-2.5 w-full max-w-3xl ml-auto"
      >
        <div className="flex flex-col items-end max-w-[85%] sm:max-w-[75%]">
          <div
            id={`user-msg-${message.id}`}
            className="bg-slate-900 text-white px-4 py-3 rounded-2xl rounded-tr-xs shadow-sm text-sm sm:text-base leading-relaxed break-words"
          >
            {message.content}
          </div>
          <span className="text-[10px] text-slate-400 mt-1 mr-1 flex items-center gap-1 font-mono">
            <Clock size={10} /> {message.timestamp}
          </span>
        </div>
        <AIAvatar role="user" size="sm" />
      </motion.div>
    );
  }

  // Assistant Bubble styling based on responseType
  const getCardHeaderStyle = () => {
    switch (responseType) {
      case 'emergency_guidance':
        return {
          badgeBg: 'bg-rose-100 text-rose-800 border-rose-200',
          containerBorder: 'border-rose-300 bg-rose-50/40',
          titleColor: 'text-rose-900',
          icon: ShieldAlert,
          label: 'Panduan Darurat Medis',
        };
      case 'warning':
        return {
          badgeBg: 'bg-amber-100 text-amber-800 border-amber-200',
          containerBorder: 'border-amber-300 bg-amber-50/30',
          titleColor: 'text-amber-900',
          icon: AlertTriangle,
          label: 'Perhatian Klinis',
        };
      case 'workout_recommendation':
        return {
          badgeBg: 'bg-indigo-100 text-indigo-800 border-indigo-200',
          containerBorder: 'border-indigo-200 bg-indigo-50/20',
          titleColor: 'text-indigo-950',
          icon: Flame,
          label: 'Rekomendasi Latihan',
        };
      case 'nutrition_advice':
        return {
          badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          containerBorder: 'border-emerald-200 bg-emerald-50/20',
          titleColor: 'text-emerald-950',
          icon: Apple,
          label: 'Panduan Gizi & Nutrisi',
        };
      case 'health_advice':
        return {
          badgeBg: 'bg-teal-100 text-teal-800 border-teal-200',
          containerBorder: 'border-teal-200 bg-teal-50/20',
          titleColor: 'text-teal-950',
          icon: Sparkles,
          label: 'Saran Kebugaran & Pemulihan',
        };
      case 'clarification':
        return {
          badgeBg: 'bg-slate-100 text-slate-800 border-slate-200',
          containerBorder: 'border-slate-200 bg-slate-50/50',
          titleColor: 'text-slate-900',
          icon: HelpCircle,
          label: 'Klarifikasi Informasi',
        };
      default:
        return null;
    }
  };

  const headerStyle = getCardHeaderStyle();
  const HeaderIcon = headerStyle?.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-start gap-3 w-full max-w-3xl"
    >
      <AIAvatar role="assistant" responseType={responseType} size="md" />

      <div className="flex flex-col items-start w-full max-w-[90%] sm:max-w-[85%]">
        {/* Main Content Bubble */}
        <div
          id={`assistant-msg-${message.id}`}
          className={`w-full rounded-2xl rounded-tl-xs px-4 sm:px-5 py-4 shadow-sm border transition-all ${
            headerStyle ? `${headerStyle.containerBorder} bg-white` : 'border-slate-200 bg-white'
          }`}
        >
          {/* Structured Category Badge */}
          {headerStyle && HeaderIcon && (
            <div className="flex items-center gap-1.5 mb-2.5">
              <span
                className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full border ${headerStyle.badgeBg}`}
              >
                <HeaderIcon size={12} />
                {headerStyle.label}
              </span>
              {structuredData?.urgencyLevel === 'critical_emergency' && (
                <span className="text-[10px] font-bold bg-rose-600 text-white px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                  Darurat
                </span>
              )}
            </div>
          )}

          {/* Structured Title if available */}
          {structuredData?.title && (
            <h4 className={`text-base font-bold mb-2 ${headerStyle?.titleColor || 'text-slate-900'}`}>
              {structuredData.title}
            </h4>
          )}

          {/* Narrative Text */}
          <div className="text-sm sm:text-base text-slate-700 leading-relaxed space-y-2 break-words">
            {renderFormattedText(message.content)}
          </div>

          {/* Key Points */}
          {structuredData?.keyPoints && structuredData.keyPoints.length > 0 && (
            <div className="mt-3.5 pt-3 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1 mb-1.5">
                <Activity size={13} className="text-emerald-600" /> Poin Penting:
              </span>
              <ul className="space-y-1 text-xs sm:text-sm text-slate-700">
                {structuredData.keyPoints.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Action Items */}
          {structuredData?.actionItems && structuredData.actionItems.length > 0 && (
            <div className="mt-3 pt-3 border-t border-slate-100 bg-slate-50/80 -mx-4 -mb-4 sm:-mx-5 px-4 sm:px-5 py-3 rounded-b-2xl">
              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1 mb-2">
                <CheckCircle2 size={13} className="text-emerald-600" /> Langkah Tindakan:
              </span>
              <div className="space-y-1.5">
                {structuredData.actionItems.map((act, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-800">
                    <span className="w-4 h-4 rounded-full bg-emerald-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span>{act}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Medical Safety Disclaimer */}
          {structuredData?.disclaimer && (
            <p className="mt-3 text-[11px] text-slate-500 italic border-t border-slate-100 pt-2 flex items-center gap-1">
              <AlertTriangle size={11} className="text-amber-500 shrink-0" />
              {structuredData.disclaimer}
            </p>
          )}

          {/* Error & Retry Button */}
          {isError && onRetry && (
            <div className="mt-3 pt-3 border-t border-rose-100 flex items-center justify-between gap-2">
              <span className="text-xs text-rose-600 font-medium">Gagal memproses pesan.</span>
              <button
                onClick={onRetry}
                className="inline-flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-lg bg-rose-600 text-white hover:bg-rose-700 transition cursor-pointer"
              >
                <RotateCcw size={12} /> Coba Lagi
              </button>
            </div>
          )}
        </div>

        {/* Timestamp */}
        <span className="text-[10px] text-slate-400 mt-1 ml-1 flex items-center gap-1 font-mono">
          <Clock size={10} /> {message.timestamp}
          {message.modelUsed && <span className="text-slate-300">• {message.modelUsed}</span>}
        </span>

        {/* Suggested Prompts on latest message */}
        {isLast && suggestedPrompts && suggestedPrompts.length > 0 && onSelectPrompt && (
          <motion.div
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-3 w-full"
          >
            <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2 block flex items-center gap-1">
              <Sparkles size={11} className="text-emerald-600" /> Saran Pertanyaan Lanjutan:
            </span>
            <div className="flex flex-wrap gap-2">
              {suggestedPrompts.map((prompt, pIdx) => (
                <PromptCard
                  key={pIdx}
                  prompt={prompt}
                  onClick={onSelectPrompt}
                />
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};
