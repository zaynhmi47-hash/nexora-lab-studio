import React from 'react';
import { Sunrise, Sun, Moon, Apple, Plus, Utensils } from 'lucide-react';
import { MealSummary, MealType, FoodEntry } from '../../types/nutrition';
import { FoodEntryCard } from './FoodEntryCard';

interface MealCardProps {
  mealSummary: MealSummary;
  isIndonesian: boolean;
  onAddFoodClick: (mealType: MealType) => void;
  onDeleteEntry: (id: string) => void;
  onEditEntry?: (entry: FoodEntry) => void;
}

export const MealCard: React.FC<MealCardProps> = ({
  mealSummary,
  isIndonesian,
  onAddFoodClick,
  onDeleteEntry,
  onEditEntry,
}) => {
  const mealConfig: Record<
    MealType,
    { title: string; desc: string; icon: any; color: string; bgColor: string }
  > = {
    breakfast: {
      title: isIndonesian ? 'Sarapan Pagi' : 'Breakfast',
      desc: isIndonesian ? 'Energi memulai hari' : 'Kickstart your morning',
      icon: Sunrise,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/10 border-amber-500/30',
    },
    lunch: {
      title: isIndonesian ? 'Makan Siang' : 'Lunch',
      desc: isIndonesian ? 'Nutrisi tengah hari' : 'Midday refuel & stamina',
      icon: Sun,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10 border-emerald-500/30',
    },
    dinner: {
      title: isIndonesian ? 'Makan Malam' : 'Dinner',
      desc: isIndonesian ? 'Pemulihan & relaksasi' : 'Evening recovery & wind-down',
      icon: Moon,
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-500/10 border-indigo-500/30',
    },
    snack: {
      title: isIndonesian ? 'Cemilan & Minuman' : 'Snacks & Extras',
      desc: isIndonesian ? 'Gizi pelengkap' : 'Healthy bites & hydration',
      icon: Apple,
      color: 'text-teal-400',
      bgColor: 'bg-teal-500/10 border-teal-500/30',
    },
  };

  const config = mealConfig[mealSummary.mealType] || mealConfig.breakfast;
  const Icon = config.icon;

  return (
    <div
      id={`meal-card-${mealSummary.mealType}`}
      className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl"
    >
      {/* Card Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-2xl flex items-center justify-center border ${config.bgColor} ${config.color}`}
          >
            <Icon className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <span>{config.title}</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                {mealSummary.totalCalories} kcal
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">{config.desc}</p>
          </div>
        </div>

        {/* Add Food Button */}
        <button
          onClick={() => onAddFoodClick(mealSummary.mealType)}
          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-emerald-600/30 hover:text-emerald-300 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border border-slate-700 hover:border-emerald-500/40"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{isIndonesian ? 'Tambah' : 'Add'}</span>
        </button>
      </div>

      {/* Logged Food Entries List */}
      {mealSummary.items.length > 0 ? (
        <div className="space-y-2 pt-1">
          {mealSummary.items.map((entry) => (
            <FoodEntryCard
              key={entry.id}
              entry={entry}
              isIndonesian={isIndonesian}
              onDelete={onDeleteEntry}
              onEdit={onEditEntry}
            />
          ))}
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-slate-800/40 border border-dashed border-slate-800 text-center space-y-1.5">
          <Utensils className="w-5 h-5 text-slate-400 mx-auto" />
          <p className="text-xs text-slate-400">
            {isIndonesian
              ? 'Belum ada makanan dicatat untuk sesi ini.'
              : 'No meals logged yet for this time slot.'}
          </p>
          <button
            onClick={() => onAddFoodClick(mealSummary.mealType)}
            className="text-[11px] text-emerald-400 hover:underline font-semibold cursor-pointer inline-block"
          >
            {isIndonesian ? '+ Catat Makanan Sekarang' : '+ Log Meal Now'}
          </button>
        </div>
      )}
    </div>
  );
};
