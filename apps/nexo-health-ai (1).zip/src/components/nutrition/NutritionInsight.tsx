import React from 'react';
import {
  Sparkles,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Lightbulb,
  Clock,
  Flame,
  Drumstick,
  Droplets,
} from 'lucide-react';
import { NutritionInsight as NutritionInsightType } from '../../types/nutrition';

interface NutritionInsightProps {
  insights: NutritionInsightType[];
  isIndonesian: boolean;
}

export const NutritionInsight: React.FC<NutritionInsightProps> = ({ insights, isIndonesian }) => {
  const typeStyles = {
    positive: {
      border: 'border-emerald-500/30',
      bg: 'bg-emerald-950/20',
      icon: CheckCircle2,
      iconColor: 'text-emerald-400',
      tag: 'bg-emerald-500/20 text-emerald-300',
    },
    suggestion: {
      border: 'border-teal-500/30',
      bg: 'bg-teal-950/20',
      icon: Lightbulb,
      iconColor: 'text-teal-400',
      tag: 'bg-teal-500/20 text-teal-300',
    },
    warning: {
      border: 'border-amber-500/30',
      bg: 'bg-amber-950/20',
      icon: AlertCircle,
      iconColor: 'text-amber-400',
      tag: 'bg-amber-500/20 text-amber-300',
    },
    neutral: {
      border: 'border-slate-700/60',
      bg: 'bg-slate-800/40',
      icon: Sparkles,
      iconColor: 'text-slate-400',
      tag: 'bg-slate-800 text-slate-300',
    },
  };

  const categoryIcons = {
    protein: Drumstick,
    calories: Flame,
    hydration: Droplets,
    variety: Sparkles,
    timing: Clock,
    balance: TrendingUp,
  };

  return (
    <div
      id="nutrition-insights-panel"
      className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/30">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              {isIndonesian ? 'Wawasan Gizi & Pola Makan' : 'Nutrition Insights & Pacing'}
            </h3>
            <p className="text-xs text-slate-400">
              {isIndonesian
                ? 'Analisis perilaku makan harian untuk mendukung konsistensi kebugaran Anda.'
                : 'Pacing feedback to support your health & fitness consistency.'}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
        {insights.map((ins) => {
          const style = typeStyles[ins.type] || typeStyles.neutral;
          const Icon = style.icon;
          const CatIcon = categoryIcons[ins.category] || Sparkles;

          return (
            <div
              key={ins.id}
              className={`p-4 rounded-2xl border ${style.border} ${style.bg} space-y-2.5 shadow-sm`}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Icon className={`w-4 h-4 ${style.iconColor} flex-shrink-0`} />
                  <h4 className="text-xs sm:text-sm font-bold text-white">{ins.title}</h4>
                </div>

                <span
                  className={`text-[9px] font-mono px-2 py-0.5 rounded-full capitalize flex items-center gap-1 ${style.tag}`}
                >
                  <CatIcon className="w-2.5 h-2.5" />
                  <span>{ins.category}</span>
                </span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">{ins.message}</p>

              {ins.actionableTip && (
                <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] text-teal-300 flex items-start gap-1.5">
                  <span className="font-bold flex-shrink-0">Tip:</span>
                  <span>{ins.actionableTip}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
