import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  ShoppingCart,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Utensils,
  BookOpen,
} from 'lucide-react';
import { MealPlan, Meal } from '../../types/nutrition';

interface MealPlanCardProps {
  plan: MealPlan;
  isIndonesian: boolean;
  onAddToGroceries: (plan: MealPlan) => void;
  onLogMealItem?: (meal: Meal) => void;
}

export const MealPlanCard: React.FC<MealPlanCardProps> = ({
  plan,
  isIndonesian,
  onAddToGroceries,
  onLogMealItem,
}) => {
  const [expandedMealId, setExpandedMealId] = useState<string | null>(null);
  const [addedGroceries, setAddedGroceries] = useState<boolean>(false);

  const toggleExpand = (id: string) => {
    setExpandedMealId((prev) => (prev === id ? null : id));
  };

  const handleAddGroceriesClick = () => {
    onAddToGroceries(plan);
    setAddedGroceries(true);
    setTimeout(() => setAddedGroceries(false), 3000);
  };

  return (
    <div
      id={`meal-plan-${plan.id}`}
      className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 capitalize">
              {plan.planType === 'daily'
                ? (isIndonesian ? 'Rencana Harian' : 'Daily Plan')
                : (isIndonesian ? 'Rencana Mingguan' : 'Weekly Plan')}
            </span>
            <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {plan.date}
            </span>
          </div>

          <h3 className="text-lg font-black text-white mt-1">{plan.title}</h3>
          <p className="text-xs text-slate-400">{plan.disclaimer}</p>
        </div>

        {/* Target Macros Badge */}
        <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/60 flex items-center gap-3 text-xs font-mono">
          <div>
            <span className="text-[10px] text-slate-400 block">{isIndonesian ? 'Target Energi' : 'Energy Target'}</span>
            <strong className="text-white text-sm">~{plan.targetCalories} kcal</strong>
          </div>
          <div className="h-6 w-px bg-slate-700" />
          <div className="text-[11px] text-slate-300">
            <div>P: <strong className="text-emerald-400">{plan.targetProtein}g</strong></div>
            <div>C: <strong className="text-teal-400">{plan.targetCarbs}g</strong></div>
          </div>
        </div>
      </div>

      {/* Meals Accordion List */}
      <div className="space-y-3">
        {plan.meals.map((meal) => {
          const isExpanded = expandedMealId === meal.id;

          const typeLabels: Record<string, string> = {
            breakfast: isIndonesian ? 'Sarapan' : 'Breakfast',
            lunch: isIndonesian ? 'Makan Siang' : 'Lunch',
            dinner: isIndonesian ? 'Makan Malam' : 'Dinner',
            snack: isIndonesian ? 'Snack Sehat' : 'Snack',
          };

          return (
            <div
              key={meal.id}
              className="rounded-2xl bg-slate-800/70 border border-slate-700/70 overflow-hidden transition-all"
            >
              {/* Row Header */}
              <div
                onClick={() => toggleExpand(meal.id)}
                className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-800/90 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-slate-900 flex items-center justify-center text-teal-400 font-bold text-xs border border-slate-700">
                    <Utensils className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono text-slate-400 uppercase">
                        {typeLabels[meal.type] || meal.type}
                      </span>
                      {meal.cookingTimeMinutes && (
                        <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
                          <Clock className="w-3 h-3" /> {meal.cookingTimeMinutes}m
                        </span>
                      )}
                    </div>
                    <h4 className="text-sm font-bold text-white">{meal.name}</h4>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right font-mono">
                    <span className="text-xs font-bold text-white">{meal.estimatedCalories}</span>
                    <span className="text-[10px] text-slate-400 ml-0.5">kcal</span>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Expanded Details */}
              {isExpanded && (
                <div className="p-4 pt-0 border-t border-slate-700/50 bg-slate-900/40 space-y-3 text-xs">
                  {/* Macros Strip */}
                  <div className="flex items-center gap-3 pt-3 font-mono text-[11px]">
                    <span className="px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-500/20">
                      Protein: <strong>{meal.estimatedProtein}g</strong>
                    </span>
                    <span className="px-2 py-0.5 rounded bg-teal-950/60 text-teal-300 border border-teal-500/20">
                      Karbo: <strong>{meal.estimatedCarbs}g</strong>
                    </span>
                    <span className="px-2 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-500/20">
                      Lemak: <strong>{meal.estimatedFat}g</strong>
                    </span>
                  </div>

                  {/* Ingredients */}
                  <div>
                    <span className="text-[11px] font-bold text-slate-300 block mb-1">
                      {isIndonesian ? 'Bahan Utama:' : 'Ingredients:'}
                    </span>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pl-2 text-slate-300">
                      {meal.ingredients.map((ing, idx) => (
                        <li key={idx} className="flex items-center gap-1.5 text-[11px]">
                          <div className="w-1.5 h-1.5 rounded-full bg-teal-400" />
                          <span>{ing}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {meal.healthBenefits && (
                    <p className="text-[11px] text-teal-200/90 italic bg-teal-950/30 p-2.5 rounded-xl border border-teal-500/20">
                      💡 {meal.healthBenefits}
                    </p>
                  )}

                  {onLogMealItem && (
                    <button
                      onClick={() => onLogMealItem(meal)}
                      className="w-full py-2 rounded-xl bg-slate-800 hover:bg-emerald-600/30 text-emerald-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer border border-emerald-500/30"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{isIndonesian ? 'Catat Menu Ini ke Buku Makanan' : 'Log This to Food Diary'}</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Nutrition Tips & Grocery Action */}
      <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-300">
          <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0" />
          <span>
            {plan.nutritionTips?.[0] ||
              (isIndonesian
                ? 'Utamakan makanan utuh bergizi seimbang.'
                : 'Prioritize whole, nutrient-dense ingredients.')}
          </span>
        </div>

        <button
          onClick={handleAddGroceriesClick}
          className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-2 transition-all cursor-pointer flex-shrink-0 ${
            addedGroceries
              ? 'bg-emerald-600 text-white'
              : 'bg-teal-600 hover:bg-teal-500 text-white shadow-lg'
          }`}
        >
          {addedGroceries ? (
            <>
              <CheckCircle2 className="w-4 h-4" />
              <span>{isIndonesian ? 'Tersimpan ke Belanja!' : 'Added to List!'}</span>
            </>
          ) : (
            <>
              <ShoppingCart className="w-4 h-4" />
              <span>{isIndonesian ? 'Simpan Bahan ke Daftar Belanja' : 'Export to Grocery List'}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
