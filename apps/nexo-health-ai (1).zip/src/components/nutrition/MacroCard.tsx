import React from 'react';
import { motion } from 'motion/react';
import { Drumstick, Wheat, Droplets, Sparkles } from 'lucide-react';
import { NutritionSummary } from '../../types/nutrition';

interface MacroCardProps {
  summary: NutritionSummary;
  isIndonesian: boolean;
}

export const MacroCard: React.FC<MacroCardProps> = ({ summary, isIndonesian }) => {
  const macros = [
    {
      id: 'protein',
      label: 'Protein',
      current: summary.protein,
      target: summary.targetProtein,
      unit: 'g',
      color: 'bg-emerald-500',
      textColor: 'text-emerald-400',
      borderColor: 'border-emerald-500/30',
      bgColor: 'bg-emerald-950/20',
      icon: Drumstick,
      desc: isIndonesian ? 'Pemulihan & otot' : 'Muscle & recovery',
    },
    {
      id: 'carbs',
      label: isIndonesian ? 'Karbohidrat' : 'Carbs',
      current: summary.carbs,
      target: summary.targetCarbs,
      unit: 'g',
      color: 'bg-teal-500',
      textColor: 'text-teal-400',
      borderColor: 'border-teal-500/30',
      bgColor: 'bg-teal-950/20',
      icon: Wheat,
      desc: isIndonesian ? 'Sumber energi harian' : 'Daily energy source',
    },
    {
      id: 'fat',
      label: isIndonesian ? 'Lemak Sehat' : 'Healthy Fat',
      current: summary.fat,
      target: summary.targetFat,
      unit: 'g',
      color: 'bg-amber-500',
      textColor: 'text-amber-400',
      borderColor: 'border-amber-500/30',
      bgColor: 'bg-amber-950/20',
      icon: Droplets,
      desc: isIndonesian ? 'Hormon & penyerapan' : 'Hormones & absorption',
    },
  ];

  return (
    <div id="macro-cards-grid" className="grid grid-cols-1 sm:grid-cols-3 gap-3">
      {macros.map((m) => {
        const percent = Math.min(150, Math.round((m.current / Math.max(1, m.target)) * 100));
        const Icon = m.icon;

        return (
          <div
            key={m.id}
            className={`p-4 rounded-2xl border ${m.borderColor} ${m.bgColor} bg-slate-900/90 space-y-3 shadow-lg`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center ${m.textColor}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white">{m.label}</h3>
                  <span className="text-[10px] text-slate-400 block">{m.desc}</span>
                </div>
              </div>

              <span className={`text-xs font-mono font-bold ${m.textColor}`}>
                {percent}%
              </span>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-baseline justify-between">
                <span className="text-lg font-black text-white font-mono">
                  {m.current}{' '}
                  <span className="text-xs font-normal text-slate-400">/ {m.target}g</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {Math.max(0, m.target - m.current)}g {isIndonesian ? 'tersisa' : 'left'}
                </span>
              </div>

              {/* Progress Bar */}
              <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                <motion.div
                  className={`h-full ${m.color} rounded-full`}
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(100, percent)}%` }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
