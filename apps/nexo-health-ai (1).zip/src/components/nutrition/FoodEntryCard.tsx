import React from 'react';
import { Trash2, Edit3, Camera, QrCode, PenTool, CheckCircle2, AlertCircle } from 'lucide-react';
import { FoodEntry } from '../../types/nutrition';

interface FoodEntryCardProps {
  entry: FoodEntry;
  isIndonesian: boolean;
  onDelete: (id: string) => void;
  onEdit?: (entry: FoodEntry) => void;
}

export const FoodEntryCard: React.FC<FoodEntryCardProps> = ({
  entry,
  isIndonesian,
  onDelete,
  onEdit,
}) => {
  const sourceIcons = {
    manual: PenTool,
    ai_photo: Camera,
    barcode: QrCode,
  };

  const sourceLabels = {
    manual: isIndonesian ? 'Manual' : 'Manual',
    ai_photo: isIndonesian ? 'AI Foto' : 'AI Vision',
    barcode: isIndonesian ? 'Barcode' : 'Barcode',
  };

  const SourceIcon = sourceIcons[entry.source] || PenTool;

  const timeFormatted = new Date(entry.createdAt).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div
      id={`food-entry-${entry.id}`}
      className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800/80 hover:border-slate-700 transition-all space-y-2.5 shadow-sm group"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="space-y-0.5 flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h4 className="text-xs sm:text-sm font-bold text-white truncate">
              {entry.name}
            </h4>

            {/* Source Tag */}
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700/60 flex items-center gap-1">
              <SourceIcon className="w-3 h-3 text-emerald-400" />
              <span>{sourceLabels[entry.source]}</span>
            </span>

            {/* Estimate Notice Pill */}
            {!entry.isVerified && (
              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-800/60 text-slate-400">
                {isIndonesian ? 'Estimasi' : 'Estimate'}
              </span>
            )}
          </div>

          <span className="text-[11px] text-slate-400 block">
            {entry.servingAmount} {entry.servingUnit} • {timeFormatted}
            {entry.notes ? ` • ${entry.notes}` : ''}
          </span>
        </div>

        {/* Total Calories Display */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="text-right">
            <span className="text-sm sm:text-base font-black text-white font-mono">
              {entry.estimatedCalories}
            </span>
            <span className="text-[10px] text-slate-400 ml-1">kcal</span>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
            {onEdit && (
              <button
                onClick={() => onEdit(entry)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
                title={isIndonesian ? 'Edit Porsi' : 'Edit Serving'}
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              onClick={() => onDelete(entry.id)}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/40 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
              title={isIndonesian ? 'Hapus' : 'Delete'}
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Macro Breakdown Chips */}
      <div className="flex items-center gap-2 pt-1 border-t border-slate-800/60 text-[11px] font-mono">
        <span className="px-2 py-0.5 rounded bg-emerald-950/40 text-emerald-300 border border-emerald-500/20">
          P: <strong>{entry.estimatedProtein}g</strong>
        </span>
        <span className="px-2 py-0.5 rounded bg-teal-950/40 text-teal-300 border border-teal-500/20">
          C: <strong>{entry.estimatedCarbs}g</strong>
        </span>
        <span className="px-2 py-0.5 rounded bg-amber-950/40 text-amber-300 border border-amber-500/20">
          F: <strong>{entry.estimatedFat}g</strong>
        </span>
        {entry.estimatedFiber !== undefined && entry.estimatedFiber > 0 && (
          <span className="px-2 py-0.5 rounded bg-indigo-950/40 text-indigo-300 border border-indigo-500/20 hidden sm:inline-block">
            Serat: <strong>{entry.estimatedFiber}g</strong>
          </span>
        )}
      </div>
    </div>
  );
};
