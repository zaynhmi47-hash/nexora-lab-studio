import React from 'react';
import { motion } from 'motion/react';
import { Flame, ShieldAlert, CheckCircle2, Sparkles } from 'lucide-react';
import { NutritionSummary } from '../../types/nutrition';

interface NutritionRingProps {
  summary: NutritionSummary;
  isIndonesian: boolean;
}

export const NutritionRing: React.FC<NutritionRingProps> = ({ summary, isIndonesian }) => {
  const calories = summary.calories;
  const target = summary.targetCalories;
  const remaining = Math.max(0, target - calories);
  const isOver = calories > target;
  const progressPercent = Math.min(100, Math.round((calories / Math.max(1, target)) * 100));

  // Circular calculations
  const size = 180;
  const strokeWidth = 14;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div
      id="nutrition-ring-card"
      className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6"
    >
      {/* Circular Progress Gauge */}
      <div className="relative flex items-center justify-center flex-shrink-0">
        <svg width={size} height={size} className="transform -rotate-90">
          {/* Background Track */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="currentColor"
            strokeWidth={strokeWidth}
            fill="transparent"
            className="text-slate-800"
          />
          {/* Animated Progress Ring */}
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="currentColor"
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1.2, ease: 'easeOut' }}
            strokeLinecap="round"
            fill="transparent"
            className={isOver ? 'text-amber-400' : 'text-emerald-500'}
          />
        </svg>

        {/* Center Content */}
        <div className="absolute flex flex-col items-center justify-center text-center p-2">
          <Flame className={`w-5 h-5 mb-0.5 ${isOver ? 'text-amber-400' : 'text-emerald-400'}`} />
          <span className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight">
            {calories}
          </span>
          <span className="text-[11px] text-slate-400 font-medium">
            {isIndonesian ? 'dari' : 'of'} {target} kcal
          </span>
        </div>
      </div>

      {/* Numerical Stats & Pacing Analysis */}
      <div className="flex-1 space-y-4 w-full text-center sm:text-left">
        <div>
          <div className="flex items-center justify-center sm:justify-start gap-2">
            <h2 className="text-lg font-bold text-white">
              {isIndonesian ? 'Estimasi Kalori Harian' : 'Daily Estimated Calories'}
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              {progressPercent}%
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {isIndonesian
              ? 'Dihitung secara lokal berdasarkan makanan yang Anda catat hari ini.'
              : 'Computed locally based on your logged meals today.'}
          </p>
        </div>

        {/* Remaining vs Consumed Quick Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60">
            <span className="text-[11px] text-slate-400 font-medium block">
              {isIndonesian ? 'Sisa Kalori' : 'Remaining'}
            </span>
            <span className={`text-xl font-bold font-mono ${isOver ? 'text-amber-400' : 'text-emerald-400'}`}>
              {isOver ? `+${calories - target}` : remaining}{' '}
              <span className="text-xs font-normal text-slate-400">kcal</span>
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60">
            <span className="text-[11px] text-slate-400 font-medium block">
              {isIndonesian ? 'Status Kebutuhan' : 'Energy Zone'}
            </span>
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5 mt-1">
              {isOver ? (
                <>
                  <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  <span className="text-amber-300">{isIndonesian ? 'Sedikit di Atas' : 'Over Target'}</span>
                </>
              ) : progressPercent >= 80 ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span className="text-emerald-300">{isIndonesian ? 'Zona Optimal' : 'Optimal Zone'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-teal-400 flex-shrink-0" />
                  <span className="text-teal-300">{isIndonesian ? 'Sesuai Rencana' : 'On Track'}</span>
                </>
              )}
            </span>
          </div>
        </div>

        <p className="text-[11px] text-slate-400 italic">
          {isIndonesian
            ? '*Semua nilai kalori dan porsi merupakan estimasi gizi referensi.'
            : '*All calorie and serving values are reference nutritional estimates.'}
        </p>
      </div>
    </div>
  );
};
