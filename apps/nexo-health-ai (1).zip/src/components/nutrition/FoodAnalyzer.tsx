import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Camera,
  Upload,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  X,
  Edit2,
  Trash2,
  Plus,
  ShieldCheck,
  RotateCcw,
  Info,
} from 'lucide-react';
import { FoodVisionAnalyzer } from '../../services/nutrition/foodVisionAnalyzer';
import {
  AiFoodAnalysisResult,
  CandidateFoodItem,
  FoodEntry,
  MealType,
} from '../../types/nutrition';
import { UserProfile } from '../../types';

interface FoodAnalyzerProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmLog: (entries: Omit<FoodEntry, 'id' | 'createdAt'>[]) => void;
  userProfile: UserProfile;
  initialMealType?: MealType;
}

export const FoodAnalyzer: React.FC<FoodAnalyzerProps> = ({
  isOpen,
  onClose,
  onConfirmLog,
  userProfile,
  initialMealType = 'lunch',
}) => {
  const isIndonesian = userProfile.language !== 'en';
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [mealType, setMealType] = useState<MealType>(initialMealType);
  const [customNote, setCustomNote] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisResult, setAnalysisResult] = useState<AiFoodAnalysisResult | null>(null);
  const [editableCandidates, setEditableCandidates] = useState<CandidateFoodItem[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Preset sample dishes for instant testing without camera
  const sampleTestingDishes = [
    {
      name: isIndonesian ? 'Nasi Piring Dada Ayam & Brokoli' : 'Healthy Chicken Rice Plate',
      img: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80',
    },
    {
      name: isIndonesian ? 'Salmon Panggang & Salad Quinoa' : 'Grilled Salmon & Quinoa Salad',
      img: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&auto=format&fit=crop&q=80',
    },
    {
      name: isIndonesian ? 'Greek Yogurt & Buah Beri' : 'Greek Yogurt & Berries',
      img: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=600&auto=format&fit=crop&q=80',
    },
  ];

  if (!isOpen) return null;

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setAnalysisResult(null);
        setErrorMessage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectSampleDish = (imgUrl: string) => {
    setSelectedImage(imgUrl);
    setAnalysisResult(null);
    setErrorMessage(null);
  };

  // Perform Gemini Multimodal Analysis
  const handleAnalyzePhoto = async () => {
    if (!selectedImage) return;

    try {
      setIsAnalyzing(true);
      setErrorMessage(null);
      const result = await FoodVisionAnalyzer.analyzeFoodPhoto(
        selectedImage,
        userProfile,
        customNote
      );
      setAnalysisResult(result);
      setEditableCandidates([...result.candidateFoods]);
    } catch (err: any) {
      setErrorMessage(
        err.message ||
          (isIndonesian ? 'Gagal menganalisis foto makanan.' : 'Failed to analyze food photo.')
      );
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Candidate modifications
  const handleUpdateCandidate = (
    id: string,
    field: keyof CandidateFoodItem,
    value: string | number
  ) => {
    setEditableCandidates((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const updated = { ...item, [field]: value };
          // If portion changed, proportionally scale calories
          if (field === 'servingAmount' && typeof value === 'number' && item.servingAmount > 0) {
            const scale = value / item.servingAmount;
            updated.estimatedCalories = Math.round(item.estimatedCalories * scale);
            updated.estimatedProtein = Math.round(item.estimatedProtein * scale);
            updated.estimatedCarbs = Math.round(item.estimatedCarbs * scale);
            updated.estimatedFat = Math.round(item.estimatedFat * scale);
          }
          return updated;
        }
        return item;
      })
    );
  };

  const handleRemoveCandidate = (id: string) => {
    setEditableCandidates((prev) => prev.filter((item) => item.id !== id));
  };

  const handleAddCandidate = () => {
    const newItem: CandidateFoodItem = {
      id: `cand_new_${Date.now()}`,
      name: isIndonesian ? 'Komponen Makanan Tambahan' : 'Additional Food Item',
      confidence: 1.0,
      servingAmount: 100,
      servingUnit: 'g',
      estimatedCalories: 100,
      estimatedProtein: 5,
      estimatedCarbs: 15,
      estimatedFat: 2,
    };
    setEditableCandidates((prev) => [...prev, newItem]);
  };

  // Final Confirmation: Save to Food Log
  const handleConfirmAndSave = () => {
    if (editableCandidates.length === 0) return;

    const entriesToSave: Omit<FoodEntry, 'id' | 'createdAt'>[] = editableCandidates.map(
      (item) => ({
        name: item.name,
        mealType,
        servingAmount: item.servingAmount,
        servingUnit: item.servingUnit,
        estimatedCalories: item.estimatedCalories,
        estimatedProtein: item.estimatedProtein,
        estimatedCarbs: item.estimatedCarbs,
        estimatedFat: item.estimatedFat,
        estimatedFiber: item.estimatedFiber,
        source: 'ai_photo',
        notes: isIndonesian
          ? 'Estimasi foto visual AI disesuaikan pengguna'
          : 'AI Photo estimate adjusted by user',
        healthRating: analysisResult?.healthRating || 8.5,
        isVerified: false,
      })
    );

    onConfirmLog(entriesToSave);
    onClose();
  };

  // Calculated totals of candidates
  const totalCandidateCal = editableCandidates.reduce((sum, i) => sum + (Number(i.estimatedCalories) || 0), 0);
  const totalCandidateProt = editableCandidates.reduce((sum, i) => sum + (Number(i.estimatedProtein) || 0), 0);
  const totalCandidateCarbs = editableCandidates.reduce((sum, i) => sum + (Number(i.estimatedCarbs) || 0), 0);
  const totalCandidateFat = editableCandidates.reduce((sum, i) => sum + (Number(i.estimatedFat) || 0), 0);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
        >
          {/* Header */}
          <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-500 text-slate-950 flex items-center justify-center font-bold">
                <Camera className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <span>{isIndonesian ? 'AI Food Vision Analyzer' : 'AI Food Vision Analyzer'}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Multimodal Gemini
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  {isIndonesian
                    ? 'Pindai foto hidangan, tinjau estimasi porsi, dan konfirmasi sebelum dicatat.'
                    : 'Scan dish photo, review estimated candidate foods, and confirm before logging.'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="p-5 overflow-y-auto space-y-5 flex-1">
            {/* Step 1: Image Capture & Meal Selection */}
            {!analysisResult && (
              <div className="space-y-4">
                {/* Meal Slot Picker */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    {isIndonesian ? 'Pilih Waktu Makan:' : 'Select Meal Slot:'}
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {(['breakfast', 'lunch', 'dinner', 'snack'] as MealType[]).map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setMealType(type)}
                        className={`py-2 px-2 text-xs font-semibold rounded-xl border transition-all cursor-pointer capitalize ${
                          mealType === type
                            ? 'bg-emerald-600 border-emerald-400 text-white shadow-md'
                            : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                        }`}
                      >
                        {type === 'breakfast'
                          ? (isIndonesian ? 'Sarapan' : 'Breakfast')
                          : type === 'lunch'
                          ? (isIndonesian ? 'Makan Siang' : 'Lunch')
                          : type === 'dinner'
                          ? (isIndonesian ? 'Malam' : 'Dinner')
                          : (isIndonesian ? 'Snack' : 'Snack')}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Upload or Camera Area */}
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-700 hover:border-emerald-500 rounded-3xl p-6 text-center cursor-pointer transition-colors bg-slate-800/40 relative overflow-hidden group"
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handleImageFileChange}
                    className="hidden"
                  />

                  {selectedImage ? (
                    <div className="relative max-h-56 mx-auto rounded-2xl overflow-hidden shadow-lg border border-slate-700">
                      <img
                        src={selectedImage}
                        alt="Food preview"
                        className="w-full h-56 object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs font-semibold">
                        {isIndonesian ? 'Klik untuk mengganti foto' : 'Click to replace photo'}
                      </div>
                    </div>
                  ) : (
                    <div className="py-6 space-y-2">
                      <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 text-emerald-400 mx-auto flex items-center justify-center border border-emerald-500/30">
                        <Upload className="w-6 h-6" />
                      </div>
                      <h4 className="text-sm font-bold text-white">
                        {isIndonesian ? 'Ambil Foto atau Upload Gambar Makanan' : 'Take Photo or Upload Food Image'}
                      </h4>
                      <p className="text-xs text-slate-400 max-w-sm mx-auto">
                        {isIndonesian
                          ? 'Arahkan kamera ke piring Anda dengan pencahayaan yang cukup.'
                          : 'Point camera at your plate with clear lighting.'}
                      </p>
                    </div>
                  )}
                </div>

                {/* Sample Preset Dishes for Testing */}
                <div className="space-y-2">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    {isIndonesian ? 'Atau Pilih Contoh Foto Piring Uji Coba:' : 'Or Try Sample Test Dish:'}
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {sampleTestingDishes.map((dish, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => handleSelectSampleDish(dish.img)}
                        className={`p-2 rounded-2xl border text-left flex items-center gap-2 transition-all cursor-pointer ${
                          selectedImage === dish.img
                            ? 'bg-emerald-950/40 border-emerald-500 text-white'
                            : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:border-slate-600'
                        }`}
                      >
                        <img
                          src={dish.img}
                          alt={dish.name}
                          className="w-9 h-9 rounded-xl object-cover flex-shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <span className="text-[11px] font-medium leading-tight truncate">{dish.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Optional Note */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">
                    {isIndonesian ? 'Catatan Khusus (Opsional):' : 'Notes (Optional):'}
                  </label>
                  <input
                    type="text"
                    value={customNote}
                    onChange={(e) => setCustomNote(e.target.value)}
                    placeholder={
                      isIndonesian
                        ? 'Contoh: Minyak sedikit, tanpa saus mayones...'
                        : 'e.g. Cooked in olive oil, no mayo...'
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {errorMessage && (
                  <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* Analyze Trigger Button */}
                <button
                  type="button"
                  onClick={handleAnalyzePhoto}
                  disabled={!selectedImage || isAnalyzing}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl transition-all cursor-pointer disabled:opacity-50"
                >
                  {isAnalyzing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>{isIndonesian ? 'Menganalisis hidangan Anda...' : 'Analyzing your meal...'}</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>{isIndonesian ? 'Analisis Makanan dengan AI' : 'Analyze Food with AI'}</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Step 2: Confirmation / Edit Candidate Foods */}
            {analysisResult && (
              <div className="space-y-5">
                {/* Result Top Overview */}
                <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                        {isIndonesian ? 'Terdeteksi' : 'Detected Dish'}
                      </span>
                      <h4 className="text-base sm:text-lg font-black text-white">
                        {analysisResult.mealName}
                      </h4>
                    </div>

                    <div className="text-right">
                      <span className="text-xl font-black text-emerald-400 font-mono">
                        ~{totalCandidateCal}
                      </span>
                      <span className="text-xs text-slate-400 ml-1">kcal</span>
                    </div>
                  </div>

                  <p className="text-xs text-emerald-200/90 leading-relaxed">
                    {analysisResult.aiAdvice}
                  </p>

                  {/* Non-Exact Estimate Transparency Notice */}
                  <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-700/60 flex items-center gap-2 text-[11px] text-slate-300">
                    <Info className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>{analysisResult.isEstimateNotice}</span>
                  </div>
                </div>

                {/* Candidate Foods List with Editable Servings */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-bold text-white uppercase tracking-wider">
                      {isIndonesian ? 'Rincian Komponen Makanan (Dapat Diedit):' : 'Candidate Items (Editable):'}
                    </h5>
                    <button
                      onClick={handleAddCandidate}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-semibold flex items-center gap-1 cursor-pointer border border-slate-700"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{isIndonesian ? 'Tambah Bahan' : 'Add Item'}</span>
                    </button>
                  </div>

                  <div className="space-y-2.5">
                    {editableCandidates.map((cand) => (
                      <div
                        key={cand.id}
                        className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-2"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <input
                            type="text"
                            value={cand.name}
                            onChange={(e) => handleUpdateCandidate(cand.id, 'name', e.target.value)}
                            className="bg-transparent text-white font-bold text-xs sm:text-sm border-b border-transparent hover:border-slate-600 focus:border-emerald-500 focus:outline-none flex-1"
                          />
                          <button
                            onClick={() => handleRemoveCandidate(cand.id)}
                            className="p-1 rounded text-slate-400 hover:text-rose-400 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Serving Amount + Unit + Calories Editable Controls */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                          <div>
                            <label className="text-[10px] text-slate-400 block">{isIndonesian ? 'Porsi' : 'Portion'}</label>
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                value={cand.servingAmount}
                                onChange={(e) =>
                                  handleUpdateCandidate(cand.id, 'servingAmount', Number(e.target.value) || 0)
                                }
                                className="w-16 px-2 py-1 rounded bg-slate-900 text-white text-xs font-mono border border-slate-700"
                              />
                              <span className="text-xs text-slate-400">{cand.servingUnit}</span>
                            </div>
                          </div>

                          <div>
                            <label className="text-[10px] text-slate-400 block">Kalori (kcal)</label>
                            <input
                              type="number"
                              value={cand.estimatedCalories}
                              onChange={(e) =>
                                handleUpdateCandidate(cand.id, 'estimatedCalories', Number(e.target.value) || 0)
                              }
                              className="w-full px-2 py-1 rounded bg-slate-900 text-white text-xs font-mono border border-slate-700"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] text-slate-400 block">Protein (g)</label>
                            <input
                              type="number"
                              value={cand.estimatedProtein}
                              onChange={(e) =>
                                handleUpdateCandidate(cand.id, 'estimatedProtein', Number(e.target.value) || 0)
                              }
                              className="w-full px-2 py-1 rounded bg-slate-900 text-emerald-400 text-xs font-mono border border-slate-700"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] text-slate-400 block">Karbo (g) / Lemak (g)</label>
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                value={cand.estimatedCarbs}
                                onChange={(e) =>
                                  handleUpdateCandidate(cand.id, 'estimatedCarbs', Number(e.target.value) || 0)
                                }
                                className="w-1/2 px-2 py-1 rounded bg-slate-900 text-teal-400 text-xs font-mono border border-slate-700"
                                title="Carbs"
                              />
                              <input
                                type="number"
                                value={cand.estimatedFat}
                                onChange={(e) =>
                                  handleUpdateCandidate(cand.id, 'estimatedFat', Number(e.target.value) || 0)
                                }
                                className="w-1/2 px-2 py-1 rounded bg-slate-900 text-amber-400 text-xs font-mono border border-slate-700"
                                title="Fat"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Final Total Macro Summary Bar */}
                <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400 font-sans">{isIndonesian ? 'Total yang akan dicatat:' : 'Total to log:'}</span>
                  <div className="flex items-center gap-3">
                    <strong className="text-white">{totalCandidateCal} kcal</strong>
                    <span className="text-emerald-400">P: {totalCandidateProt}g</span>
                    <span className="text-teal-400">C: {totalCandidateCarbs}g</span>
                    <span className="text-amber-400">F: {totalCandidateFat}g</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{isIndonesian ? 'Foto tidak disimpan permanen' : 'Zero permanent image storage'}</span>
            </div>

            <div className="flex items-center gap-2">
              {analysisResult ? (
                <>
                  <button
                    onClick={() => {
                      setAnalysisResult(null);
                      setEditableCandidates([]);
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{isIndonesian ? 'Foto Ulang' : 'Scan Again'}</span>
                  </button>

                  <button
                    onClick={handleConfirmAndSave}
                    disabled={editableCandidates.length === 0}
                    className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg cursor-pointer disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{isIndonesian ? 'Konfirmasi & Catat Makanan' : 'Confirm & Log Meal'}</span>
                  </button>
                </>
              ) : (
                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
