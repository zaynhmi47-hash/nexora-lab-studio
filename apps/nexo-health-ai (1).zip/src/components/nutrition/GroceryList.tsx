import React, { useState } from 'react';
import {
  ShoppingCart,
  Plus,
  Trash2,
  Check,
  CheckCircle2,
  Filter,
  Layers,
  Leaf,
  Drumstick,
  Milk,
  Wheat,
  Archive,
} from 'lucide-react';
import { GroceryItem } from '../../types/nutrition';

interface GroceryListProps {
  items: GroceryItem[];
  isIndonesian: boolean;
  onToggleItem: (id: string) => void;
  onAddItem: (item: Omit<GroceryItem, 'id' | 'isChecked'>) => void;
  onRemoveItem: (id: string) => void;
  onClearChecked: () => void;
}

export const GroceryList: React.FC<GroceryListProps> = ({
  items,
  isIndonesian,
  onToggleItem,
  onAddItem,
  onRemoveItem,
  onClearChecked,
}) => {
  const [newItemName, setNewItemName] = useState<string>('');
  const [newItemAmount, setNewItemAmount] = useState<string>('');
  const [newItemCategory, setNewItemCategory] = useState<GroceryItem['category']>('produce');
  const [selectedFilter, setSelectedFilter] = useState<string>('all');

  const categories = [
    { id: 'produce', label: isIndonesian ? 'Sayur & Buah' : 'Produce', icon: Leaf, color: 'text-emerald-400' },
    { id: 'protein', label: isIndonesian ? 'Protein & Daging' : 'Protein', icon: Drumstick, color: 'text-rose-400' },
    { id: 'dairy', label: isIndonesian ? 'Susu & Olahan' : 'Dairy', icon: Milk, color: 'text-sky-400' },
    { id: 'grains', label: isIndonesian ? 'Biji & Gandum' : 'Grains', icon: Wheat, color: 'text-amber-400' },
    { id: 'pantry', label: isIndonesian ? 'Bumbu & Dapur' : 'Pantry', icon: Archive, color: 'text-purple-400' },
    { id: 'other', label: isIndonesian ? 'Lainnya' : 'Other', icon: Layers, color: 'text-slate-400' },
  ];

  const handleAddNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    onAddItem({
      name: newItemName.trim(),
      amount: newItemAmount.trim() || '1 item',
      category: newItemCategory,
    });

    setNewItemName('');
    setNewItemAmount('');
  };

  const filteredItems = selectedFilter === 'all' ? items : items.filter((i) => i.category === selectedFilter);
  const checkedCount = items.filter((i) => i.isChecked).length;

  return (
    <div id="grocery-list-container" className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/30">
            <ShoppingCart className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <span>{isIndonesian ? 'Daftar Belanja Bahan Sehat' : 'Smart Grocery Checklist'}</span>
              <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                {checkedCount}/{items.length} {isIndonesian ? 'selesai' : 'done'}
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              {isIndonesian
                ? 'Bahan otomatis teragregasi dari rencana makanan dan kebutuhan nutrisi.'
                : 'Aggregated automatically from your meal plans and nutritional needs.'}
            </p>
          </div>
        </div>

        {checkedCount > 0 && (
          <button
            onClick={onClearChecked}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/40 text-slate-300 hover:text-rose-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border border-slate-700 hover:border-rose-500/40 self-start sm:self-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Hapus Item Selesai' : 'Clear Checked'}</span>
          </button>
        )}
      </div>

      {/* Add New Item Form */}
      <form onSubmit={handleAddNewItem} className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
          <input
            type="text"
            value={newItemName}
            onChange={(e) => setNewItemName(e.target.value)}
            placeholder={isIndonesian ? 'Nama bahan (misal: Telur Ayam Kampung)' : 'Ingredient name (e.g. Greek Yogurt)'}
            className="sm:col-span-6 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-teal-500"
          />

          <input
            type="text"
            value={newItemAmount}
            onChange={(e) => setNewItemAmount(e.target.value)}
            placeholder={isIndonesian ? 'Takaran (misal: 500g)' : 'Amount (e.g. 500g)'}
            className="sm:col-span-3 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-teal-500"
          />

          <select
            value={newItemCategory}
            onChange={(e) => setNewItemCategory(e.target.value as GroceryItem['category'])}
            className="sm:col-span-3 px-2 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 text-xs focus:outline-none focus:border-teal-500"
          >
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.label}
              </option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          disabled={!newItemName.trim()}
          className="w-full py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{isIndonesian ? 'Tambah ke Daftar Belanja' : 'Add Item'}</span>
        </button>
      </form>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <button
          onClick={() => setSelectedFilter('all')}
          className={`px-3 py-1 rounded-xl border transition-all whitespace-nowrap cursor-pointer ${
            selectedFilter === 'all'
              ? 'bg-slate-700 border-teal-500 text-white font-bold'
              : 'bg-slate-800/70 border-slate-700 text-slate-400 hover:text-white'
          }`}
        >
          {isIndonesian ? 'Semua Kategori' : 'All Categories'} ({items.length})
        </button>
        {categories.map((cat) => {
          const count = items.filter((i) => i.category === cat.id).length;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedFilter(cat.id)}
              className={`px-3 py-1 rounded-xl border transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                selectedFilter === cat.id
                  ? 'bg-slate-700 border-teal-500 text-white font-bold'
                  : 'bg-slate-800/70 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              <cat.icon className={`w-3.5 h-3.5 ${cat.color}`} />
              <span>{cat.label}</span>
              <span className="text-[10px] font-mono opacity-70">({count})</span>
            </button>
          );
        })}
      </div>

      {/* Grocery Items List */}
      {filteredItems.length > 0 ? (
        <div className="space-y-2">
          {filteredItems.map((item) => {
            const cat = categories.find((c) => c.id === item.category) || categories[5];
            const CatIcon = cat.icon;

            return (
              <div
                key={item.id}
                className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                  item.isChecked
                    ? 'bg-slate-900/40 border-slate-800/50 opacity-60'
                    : 'bg-slate-800/80 border-slate-700/80 hover:border-slate-600'
                }`}
              >
                <div
                  onClick={() => onToggleItem(item.id)}
                  className="flex items-center gap-3 flex-1 cursor-pointer min-w-0"
                >
                  <div
                    className={`w-5 h-5 rounded-lg flex items-center justify-center border transition-all flex-shrink-0 ${
                      item.isChecked
                        ? 'bg-teal-500 border-teal-400 text-slate-950'
                        : 'border-slate-600 bg-slate-900'
                    }`}
                  >
                    {item.isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>

                  <div className="min-w-0">
                    <span
                      className={`text-xs sm:text-sm font-semibold block truncate ${
                        item.isChecked ? 'line-through text-slate-400' : 'text-white'
                      }`}
                    >
                      {item.name}
                    </span>
                    <span className="text-[11px] text-slate-400 flex items-center gap-2">
                      <span>{item.amount}</span>
                      {item.sourceMeal && <span>• {item.sourceMeal}</span>}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0">
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-900 border border-slate-700/60 flex items-center gap-1 ${cat.color}`}
                  >
                    <CatIcon className="w-3 h-3" />
                    <span>{cat.label}</span>
                  </span>

                  <button
                    onClick={() => onRemoveItem(item.id)}
                    className="p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-900 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-6 rounded-2xl bg-slate-800/40 border border-dashed border-slate-800 text-center space-y-1.5">
          <ShoppingCart className="w-6 h-6 text-slate-400 mx-auto" />
          <p className="text-xs text-slate-400">
            {isIndonesian
              ? 'Daftar belanja kosong. Buat meal plan atau tambahkan bahan di atas.'
              : 'Grocery list is empty. Generate a meal plan or add items above.'}
          </p>
        </div>
      )}
    </div>
  );
};
