import React, { useState } from 'react';
import {
  X,
  Mail,
  Lock,
  User as UserIcon,
  Eye,
  EyeOff,
  LogOut,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Loader2,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import {
  auth,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signInAnonymously,
  User,
} from '../../lib/firebase';
import { LanguageCode } from '../../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: LanguageCode;
  currentUser: User | null;
  onSignOut: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  language,
  currentUser,
  onSignOut,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const isIndonesian = language === 'id';

  const resetState = () => {
    setError(null);
    setSuccessMsg(null);
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    resetState();

    if (!email.trim() || !password.trim()) {
      setError(
        isIndonesian
          ? 'Email dan kata sandi wajib diisi.'
          : 'Email and password are required.'
      );
      return;
    }

    if (mode === 'register' && password.length < 6) {
      setError(
        isIndonesian
          ? 'Kata sandi minimal 6 karakter.'
          : 'Password must be at least 6 characters.'
      );
      return;
    }

    setLoading(true);

    try {
      if (mode === 'login') {
        await signInWithEmailAndPassword(auth, email, password);
        setSuccessMsg(
          isIndonesian ? 'Berhasil masuk!' : 'Signed in successfully!'
        );
        setTimeout(() => {
          onClose();
        }, 800);
      } else {
        const userCredential = await createUserWithEmailAndPassword(
          auth,
          email,
          password
        );
        if (displayName.trim() && userCredential.user) {
          await updateProfile(userCredential.user, {
            displayName: displayName.trim(),
          });
        }
        setSuccessMsg(
          isIndonesian
            ? 'Pendaftaran akun berhasil!'
            : 'Account registered successfully!'
        );
        setTimeout(() => {
          onClose();
        }, 800);
      }
    } catch (err: any) {
      console.error('Auth error:', err);
      let message = err.message || 'Terjadi kesalahan authentication.';
      if (
        err.code === 'auth/invalid-credential' ||
        err.code === 'auth/user-not-found' ||
        err.code === 'auth/wrong-password'
      ) {
        message = isIndonesian
          ? 'Email atau kata sandi tidak cocok.'
          : 'Invalid email or password.';
      } else if (err.code === 'auth/email-already-in-use') {
        message = isIndonesian
          ? 'Email sudah terdaftar. Silakan pilih menu Masuk.'
          : 'Email is already registered. Please sign in instead.';
      } else if (err.code === 'auth/weak-password') {
        message = isIndonesian
          ? 'Kata sandi terlalu lemah (minimal 6 karakter).'
          : 'Password is too weak (minimum 6 characters).';
      }
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    resetState();
    setLoading(true);

    try {
      await signInWithPopup(auth, googleProvider);
      setSuccessMsg(
        isIndonesian ? 'Masuk dengan Google berhasil!' : 'Google sign-in successful!'
      );
      setTimeout(() => {
        onClose();
      }, 800);
    } catch (err: any) {
      console.error('Google Sign In Error:', err);
      setError(
        err.message ||
          (isIndonesian
            ? 'Gagal masuk dengan Google.'
            : 'Failed to sign in with Google.')
      );
    } finally {
      setLoading(false);
    }
  };

  const handleGuestSignIn = async () => {
    resetState();
    setLoading(true);

    try {
      await signInAnonymously(auth);
      setSuccessMsg(
        isIndonesian
          ? 'Masuk sebagai Tamu berhasil!'
          : 'Signed in as Guest successfully!'
      );
      setTimeout(() => {
        onClose();
      }, 800);
    } catch (err: any) {
      console.error('Guest Sign In Error:', err);
      setError(
        isIndonesian
          ? 'Gagal masuk dalam mode Tamu.'
          : 'Failed to sign in as Guest.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-md bg-white border border-emerald-100 rounded-3xl p-6 sm:p-7 shadow-2xl transition-all overflow-hidden text-slate-800">
        {/* Subtle Decorative Glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-100/50 blur-3xl rounded-full pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-teal-100/40 blur-3xl rounded-full pointer-events-none" />

        {/* Header & Close Button */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-emerald-50 text-emerald-700 rounded-2xl border border-emerald-200">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900">
                {currentUser
                  ? isIndonesian
                    ? 'Profil Pengguna'
                    : 'User Account'
                  : mode === 'login'
                  ? isIndonesian
                    ? 'Masuk ke AI HealthMate'
                    : 'Sign In'
                  : isIndonesian
                  ? 'Daftar Akun Baru'
                  : 'Create Account'}
              </h2>
              <p className="text-[11px] text-emerald-700 font-semibold">
                {isIndonesian ? 'Keamanan Data Cloud Terenkripsi' : 'Encrypted Cloud Security'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* If User Already Logged In */}
        {currentUser ? (
          <div className="py-6 space-y-5 relative z-10 text-center">
            <div className="flex flex-col items-center gap-3">
              {currentUser.photoURL ? (
                <img
                  src={currentUser.photoURL}
                  alt="Profile"
                  className="w-20 h-20 rounded-2xl border-2 border-emerald-500 shadow-md object-cover"
                />
              ) : (
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 flex items-center justify-center text-2xl font-black text-white shadow-md">
                  {currentUser.displayName
                    ? currentUser.displayName.charAt(0).toUpperCase()
                    : currentUser.email
                    ? currentUser.email.charAt(0).toUpperCase()
                    : 'U'}
                </div>
              )}

              <div>
                <h3 className="text-lg font-black text-slate-900">
                  {currentUser.displayName || (isIndonesian ? 'Sobat Sehat' : 'Health User')}
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-0.5">
                  {currentUser.email || (currentUser.isAnonymous ? (isIndonesian ? 'Mode Tamu / Demo' : 'Guest Mode') : 'No Email')}
                </p>
                <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                  <span>{isIndonesian ? 'Terverifikasi & Aktif' : 'Verified & Active'}</span>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => {
                  onSignOut();
                  onClose();
                }}
                className="w-full bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold py-3 rounded-2xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs"
              >
                <LogOut className="w-4 h-4" />
                <span>{isIndonesian ? 'Keluar dari Akun' : 'Sign Out Account'}</span>
              </button>
            </div>
          </div>
        ) : (
          /* Form Sign In / Register */
          <div className="py-4 space-y-4 relative z-10">
            {/* Mode Selector Tabs */}
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 border border-slate-200/80 rounded-2xl">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  resetState();
                }}
                className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  mode === 'login'
                    ? 'bg-white text-emerald-800 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isIndonesian ? 'Masuk' : 'Sign In'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  resetState();
                }}
                className={`py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  mode === 'register'
                    ? 'bg-white text-emerald-800 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isIndonesian ? 'Daftar Baru' : 'Register'}
              </button>
            </div>

            {/* Error / Success Banners */}
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* Email Form */}
            <form onSubmit={handleEmailAuth} className="space-y-3">
              {mode === 'register' && (
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                    {isIndonesian ? 'Nama Lengkap' : 'Display Name'}
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder={isIndonesian ? 'Contoh: Alex Pratama' : 'e.g. Alex Pratama'}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl text-xs text-slate-900 focus:outline-none transition-colors"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="nama@domain.com"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl text-xs text-slate-900 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  {isIndonesian ? 'Kata Sandi' : 'Password'}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl text-xs text-slate-900 focus:outline-none transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold py-3 rounded-2xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-md shadow-emerald-600/20 cursor-pointer"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>
                      {mode === 'login'
                        ? isIndonesian
                          ? 'Masuk Sekarang'
                          : 'Sign In Now'
                        : isIndonesian
                        ? 'Daftar Akun Baru'
                        : 'Create Account'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            <div className="relative flex items-center justify-center my-2">
              <div className="border-t border-slate-200 w-full" />
              <span className="bg-white px-3 text-[10px] uppercase tracking-wider text-slate-400 font-bold shrink-0">
                {isIndonesian ? 'atau lanjutkan dengan' : 'or continue with'}
              </span>
            </div>

            {/* Social & Guest Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={loading}
                className="py-2.5 px-3 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 text-slate-800 font-semibold rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.28v3.14C3.25 21.27 7.31 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.59H1.28C.46 8.22 0 10.05 0 12s.46 3.78 1.28 5.41l4-3.14z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.25 2.73 1.28 6.59l4 3.14c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>Google</span>
              </button>

              <button
                type="button"
                onClick={handleGuestSignIn}
                disabled={loading}
                className="py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-semibold rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs"
              >
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>{isIndonesian ? 'Mode Tamu' : 'Guest Mode'}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
