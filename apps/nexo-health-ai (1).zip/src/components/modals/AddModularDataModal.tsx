import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Plus,
  Sparkles,
  Layers,
  Activity,
  CheckCircle2,
  Zap,
  Tag,
  FileText,
  Calendar,
  Heart,
  Droplets,
  Moon,
  Wind,
  ShieldCheck,
} from 'lucide-react';
import { HealthModuleId, ModularHealthDataEntry, UserProfile } from '../../types';
import { HEALTH_MODULES } from '../../data/healthModulesData';

interface AddModularDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  initialModuleId?: HealthModuleId;
  onSaveDataEntry: (entry: ModularHealthDataEntry) => void;
}

export const AddModularDataModal: React.FC<AddModularDataModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  initialModuleId,
  onSaveDataEntry,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [selectedModuleId, setSelectedModuleId] = useState<HealthModuleId>(
    initialModuleId || 'm5_posture_ergonomics'
  );
  const [summaryTitle, setSummaryTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [metric1Key, setMetric1Key] = useState('');
  const [metric1Val, setMetric1Val] = useState('');
  const [metric2Key, setMetric2Key] = useState('');
  const [metric2Val, setMetric2Val] = useState('');
  const [metric3Key, setMetric3Key] = useState('');
  const [metric3Val, setMetric3Val] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [statusFlag, setStatusFlag] = useState<'optimal' | 'attention_needed' | 'critical_alert'>('optimal');

  // Pre-fill smart defaults when module changes
  useEffect(() => {
    if (initialModuleId) {
      setSelectedModuleId(initialModuleId);
    }
  }, [initialModuleId]);

  useEffect(() => {
    const mod = HEALTH_MODULES.find((m) => m.id === selectedModuleId);
    if (!mod) return;

    if (selectedModuleId === 'm5_posture_ergonomics') {
      setSummaryTitle(isIndonesian ? 'Sesi Audit Ergonomi & Desk Yoga' : 'Ergonomics Audit & Desk Yoga');
      setMetric1Key('Craniovertebral Angle');
      setMetric1Val('52°');
      setMetric2Key('Beban Servikal C5-C7');
      setMetric2Val('6.5 kg');
      setMetric3Key('Skor Postur');
      setMetric3Val('92/100');
      setTags(['Ergonomi', 'Leher', 'Postur']);
    } else if (selectedModuleId === 'm8_smart_hydration') {
      setSummaryTitle(isIndonesian ? 'Catatan Asupan Cairan & Elektrolit' : 'Hydration & Electrolyte Intake');
      setMetric1Key('Volume Air');
      setMetric1Val('2500 ml');
      setMetric2Key('Elektrolit Isotonik');
      setMetric2Val('Ya (450mg Na+)');
      setMetric3Key('Efisiensi Hidrasi');
      setMetric3Val('96%');
      setTags(['Hidrasi', 'Elektrolit', 'Suhu Tropis']);
    } else if (selectedModuleId === 'm9_supplement_manager') {
      setSummaryTitle(isIndonesian ? 'Konsumsi Suplemen Pagi' : 'Morning Supplement Stack');
      setMetric1Key('Vitamin D3 + K2');
      setMetric1Val('5000 IU');
      setMetric2Key('Omega 3 (EPA/DHA)');
      setMetric2Val('1200 mg');
      setMetric3Key('Interaksi Negatif');
      setMetric3Val('Nol (Aman)');
      setTags(['Suplemen', 'Bioavailabilitas', 'Kesehatan Jantung']);
    } else if (selectedModuleId === 'm10_mindful_eating') {
      setSummaryTitle(isIndonesian ? 'Sesi Makan Sadar (20 Kunyahan)' : 'Mindful Eating 20-Chew Session');
      setMetric1Key('Rata-rata Kunyahan');
      setMetric1Val('22 kunyahan/suap');
      setMetric2Key('Durasi Makan');
      setMetric2Val('24 menit');
      setMetric3Key('Tingkat Kekenyangan');
      setMetric3Val('8/10 (Optimal)');
      setTags(['Mindful Eating', 'Pencernaan', 'Leptin']);
    } else if (selectedModuleId === 'm11_cbt_therapy') {
      setSummaryTitle(isIndonesian ? 'Restrukturisasi Kognitif & Grounding' : 'CBT Thought Challenge & Grounding');
      setMetric1Key('Tingkat Kecemasan Awal');
      setMetric1Val('7/10');
      setMetric2Key('Tingkat Kecemasan Akhir');
      setMetric2Val('2/10');
      setMetric3Key('Latihan Grounding');
      setMetric3Val('Selesai 5-4-3-2-1');
      setTags(['CBT', 'Kesehatan Mental', 'Grounding']);
    } else if (selectedModuleId === 'm12_emotion_stress_map') {
      setSummaryTitle(isIndonesian ? 'Log Suasana Hati & Indeks Stres' : 'Mood Log & Stress Score');
      setMetric1Key('Skor Stres');
      setMetric1Val('3/10 (Rendah)');
      setMetric2Key('Fokus Produktif');
      setMetric2Val('Tinggi (Flow State)');
      setMetric3Key('Energi Afektif');
      setMetric3Val('Optimis & Stabil');
      setTags(['Emosi', 'Stres', 'Afektif']);
    } else if (selectedModuleId === 'm13_adaptive_meditation') {
      setSummaryTitle(isIndonesian ? 'Sesi Meditasi Box Breathing 4-4-4-4' : 'Box Breathing Meditation');
      setMetric1Key('Durasi Sesi');
      setMetric1Val('15 menit');
      setMetric2Key('HRV Koherensi');
      setMetric2Val('74 ms');
      setMetric3Key('Frekuensi Gelombang');
      setMetric3Val('432 Hz Alpha');
      setTags(['Meditasi', 'HRV', 'Vagus Nerve']);
    } else if (selectedModuleId === 'm14_mental_resilience') {
      setSummaryTitle(isIndonesian ? 'Tantangan Tunda Dopamin & Stoikisme' : 'Dopamine Delay & Stoic Reflection');
      setMetric1Key('Tunda Impuls');
      setMetric1Val('12 menit');
      setMetric2Key('Refleksi Stoik');
      setMetric2Val('Dichotomy of Control');
      setMetric3Key('Sprint Fokus');
      setMetric3Val('45 menit');
      setTags(['Resiliensi', 'Stoik', 'Dopamin']);
    } else if (selectedModuleId === 'm15_sleep_rituals') {
      setSummaryTitle(isIndonesian ? 'Kualitas Tidur 5 Siklus 90-Menit' : 'Sleep Quality 5 Ultradian Cycles');
      setMetric1Key('Durasi Tidur');
      setMetric1Val('7.8 jam');
      setMetric2Key('Siklus Ultradian Selesai');
      setMetric2Val('5 Siklus');
      setMetric3Key('Efisiensi Tidur');
      setMetric3Val('94%');
      setTags(['Tidur Nyenyak', 'Sirkadian', 'Fase REM']);
    } else if (selectedModuleId === 'm17_electronic_health_record') {
      setSummaryTitle(isIndonesian ? 'Pembaruan Hasil Lab Darah' : 'Blood Biomarker Lab Update');
      setMetric1Key('HbA1c');
      setMetric1Val('5.3% (Optimal)');
      setMetric2Key('Gula Darah Puasa');
      setMetric2Val('92 mg/dL');
      setMetric3Key('Kolesterol Total');
      setMetric3Val('175 mg/dL');
      setTags(['Biomarker', 'EHR', 'Lab Darah']);
    } else if (selectedModuleId === 'm18_vitals_wearables') {
      setSummaryTitle(isIndonesian ? 'Pencatatan Live PPG & Tensi Darah' : 'Live PPG & Blood Pressure Log');
      setMetric1Key('Denyut Nadi');
      setMetric1Val('68 bpm');
      setMetric2Key('Saturasi O2 (SpO2)');
      setMetric2Val('99%');
      setMetric3Key('Tekanan Darah');
      setMetric3Val('118/76 mmHg');
      setTags(['Tanda Vital', 'PPG', 'Tekanan Darah']);
    } else if (selectedModuleId === 'm19_longevity_screening') {
      setSummaryTitle(isIndonesian ? 'Evaluasi Usia Biologis & Mitokondria' : 'Biological Age & Longevity Evaluation');
      setMetric1Key('Usia Biologis');
      setMetric1Val(`${Math.max(18, userProfile.age - 5)} Tahun`);
      setMetric2Key('Kardio Zona 2');
      setMetric2Val('3.5 jam/minggu');
      setMetric3Key('Puasa Autofagi');
      setMetric3Val('16 jam');
      setTags(['Longevity', 'Usia Biologis', 'Mitokondria']);
    } else if (selectedModuleId === 'm20_hormonal_reproductive') {
      setSummaryTitle(isIndonesian ? 'Log Fase Hormon & Suhu Basal BBT' : 'Hormone Phase & BBT Log');
      setMetric1Key('Hari Siklus');
      setMetric1Val('Hari ke-14');
      setMetric2Key('Suhu Tubuh Basal (BBT)');
      setMetric2Val('36.6 °C');
      setMetric3Key('Tingkat Energi');
      setMetric3Val('Tinggi (Puncak)');
      setTags(['Hormonal', 'BBT', 'Siklus']);
    } else {
      setSummaryTitle(isIndonesian ? `Catatan Aktivitas ${mod.title}` : `Activity Log ${mod.titleEn}`);
      setMetric1Key('Capaian Target');
      setMetric1Val('100%');
      setMetric2Key('Status');
      setMetric2Val('Optimal');
      setMetric3Key('Skor Sesi');
      setMetric3Val('95');
      setTags([mod.tag]);
    }
  }, [selectedModuleId, isIndonesian, userProfile.age]);

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const currentMod = HEALTH_MODULES.find((m) => m.id === selectedModuleId);
    const modName = currentMod ? (isIndonesian ? currentMod.title : currentMod.titleEn) : 'Modul Kesehatan';

    const metricsObj: Record<string, string | number | boolean> = {};
    if (metric1Key && metric1Val) metricsObj[metric1Key] = metric1Val;
    if (metric2Key && metric2Val) metricsObj[metric2Key] = metric2Val;
    if (metric3Key && metric3Val) metricsObj[metric3Key] = metric3Val;

    const newEntry: ModularHealthDataEntry = {
      id: `log_${Date.now()}`,
      moduleId: selectedModuleId,
      moduleName: modName,
      category: currentMod ? (currentMod.category as any) : 'general',
      timestamp: new Date().toISOString(),
      summaryTitle: summaryTitle || modName,
      metrics: metricsObj,
      tags: tags.length > 0 ? tags : ['Health Log'],
      notes: notes || undefined,
      aiAnalystFlag: statusFlag,
      xpAwarded: 50,
    };

    onSaveDataEntry(newEntry);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4" role="dialog" aria-modal="true">
      {/* Backdrop */}
      <div onClick={onClose} className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" />

      {/* Modal Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 12 }}
        className="relative z-10 w-full max-w-2xl bg-white border border-slate-200 rounded-[32px] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-white/20 backdrop-blur-md">
              <Plus className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight text-white">
                {isIndonesian ? 'Tambah Data & Catatan Modul' : 'Add Modular Health Data'}
              </h3>
              <p className="text-xs text-emerald-100 font-medium">
                {isIndonesian
                  ? 'Data langsung disinkronkan ke AI Analis di Dasbor'
                  : 'Instantly synced to AI Health Analyst in Dashboard'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {/* Module Selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-slate-700 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isIndonesian ? 'Pilih Modul Kesehatan (1 - 20):' : 'Select Health Module (1 - 20):'}</span>
            </label>
            <select
              value={selectedModuleId}
              onChange={(e) => setSelectedModuleId(e.target.value as HealthModuleId)}
              className="w-full p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-500 cursor-pointer"
            >
              {HEALTH_MODULES.map((mod) => (
                <option key={mod.id} value={mod.id}>
                  #{mod.moduleNumber} {isIndonesian ? mod.title : mod.titleEn} ({mod.tag})
                </option>
              ))}
            </select>
          </div>

          {/* Summary Title */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-slate-700 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isIndonesian ? 'Judul Ringkasan Log:' : 'Log Summary Title:'}</span>
            </label>
            <input
              type="text"
              required
              value={summaryTitle}
              onChange={(e) => setSummaryTitle(e.target.value)}
              placeholder={isIndonesian ? 'Contoh: Sesi 3x Desk Yoga & Koreksi Monitor' : 'e.g. 3x Desk Yoga Session'}
              className="w-full p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Dynamic Metrics (3 Key-Value Pairs) */}
          <div className="space-y-3">
            <span className="text-xs font-black text-slate-700 block">
              {isIndonesian ? 'Metrik Kunci & Parameter Terukur:' : 'Key Measured Metrics:'}
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Metric 1 */}
              <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-100 space-y-1.5">
                <input
                  type="text"
                  value={metric1Key}
                  onChange={(e) => setMetric1Key(e.target.value)}
                  placeholder="Nama Parameter 1"
                  className="w-full text-[11px] font-black text-emerald-950 bg-transparent border-b border-emerald-200 focus:outline-none pb-0.5"
                />
                <input
                  type="text"
                  value={metric1Val}
                  onChange={(e) => setMetric1Val(e.target.value)}
                  placeholder="Nilai (misal 52°)"
                  className="w-full text-xs font-mono font-bold text-slate-900 bg-white px-2 py-1 rounded-lg border border-slate-200 focus:outline-none"
                />
              </div>

              {/* Metric 2 */}
              <div className="p-3 rounded-2xl bg-teal-50/60 border border-teal-100 space-y-1.5">
                <input
                  type="text"
                  value={metric2Key}
                  onChange={(e) => setMetric2Key(e.target.value)}
                  placeholder="Nama Parameter 2"
                  className="w-full text-[11px] font-black text-teal-950 bg-transparent border-b border-teal-200 focus:outline-none pb-0.5"
                />
                <input
                  type="text"
                  value={metric2Val}
                  onChange={(e) => setMetric2Val(e.target.value)}
                  placeholder="Nilai (misal 6.5 kg)"
                  className="w-full text-xs font-mono font-bold text-slate-900 bg-white px-2 py-1 rounded-lg border border-slate-200 focus:outline-none"
                />
              </div>

              {/* Metric 3 */}
              <div className="p-3 rounded-2xl bg-cyan-50/60 border border-cyan-100 space-y-1.5">
                <input
                  type="text"
                  value={metric3Key}
                  onChange={(e) => setMetric3Key(e.target.value)}
                  placeholder="Nama Parameter 3"
                  className="w-full text-[11px] font-black text-cyan-950 bg-transparent border-b border-cyan-200 focus:outline-none pb-0.5"
                />
                <input
                  type="text"
                  value={metric3Val}
                  onChange={(e) => setMetric3Val(e.target.value)}
                  placeholder="Nilai (misal 92/100)"
                  className="w-full text-xs font-mono font-bold text-slate-900 bg-white px-2 py-1 rounded-lg border border-slate-200 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Status Flag */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-slate-700 block">
              {isIndonesian ? 'Status Evaluasi AI:' : 'AI Evaluation Status:'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setStatusFlag('optimal')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  statusFlag === 'optimal'
                    ? 'bg-emerald-600 text-white font-black shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                ✓ {isIndonesian ? 'Optimal / Prima' : 'Optimal'}
              </button>
              <button
                type="button"
                onClick={() => setStatusFlag('attention_needed')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  statusFlag === 'attention_needed'
                    ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                ! {isIndonesian ? 'Perlu Perhatian' : 'Attention'}
              </button>
              <button
                type="button"
                onClick={() => setStatusFlag('critical_alert')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  statusFlag === 'critical_alert'
                    ? 'bg-rose-600 text-white font-black shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                ⚠ {isIndonesian ? 'Peringatan Dini' : 'Alert'}
              </button>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-slate-700 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isIndonesian ? 'Catatan Tambahan & Observasi Klinis/Pribadi:' : 'Notes & Personal Observations:'}</span>
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={isIndonesian ? 'Tuliskan catatan kondisi tubuh, sensasi otot, atau reaksi setelah sesi...' : 'Add any qualitative notes or bodily sensations...'}
              className="w-full p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-900 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <label className="text-xs font-black text-slate-700 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isIndonesian ? 'Label / Tag Kategori:' : 'Tags:'}</span>
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
                placeholder={isIndonesian ? 'Ketik tag lalu tekan tambah...' : 'Add tag...'}
                className="flex-1 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-900 focus:outline-none focus:border-emerald-500"
              />
              <button
                type="button"
                onClick={handleAddTag}
                className="px-4 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition-all cursor-pointer"
              >
                + Tambah
              </button>
            </div>

            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px] font-black border border-emerald-200 flex items-center gap-1"
                  >
                    #{tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="text-emerald-700 hover:text-rose-600 font-bold ml-1"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Footer Submit */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-bold">
              <Zap className="w-4 h-4 text-emerald-600" />
              <span>+50 XP Play Points</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer"
              >
                {isIndonesian ? 'Batal' : 'Cancel'}
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-black shadow-md shadow-emerald-600/25 transition-all cursor-pointer"
              >
                {isIndonesian ? 'Simpan & Sinkronkan AI' : 'Save & Sync AI'}
              </button>
            </div>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
