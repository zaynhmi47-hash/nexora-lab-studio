import React, { useState, useEffect } from 'react';
import { Wind, Play, Pause, Volume2, Sparkles, Heart, Activity, RotateCcw } from 'lucide-react';
import { playMeditationAudio, stopAudio } from '../services/audioService';

const AUDIO_TRACKS = [
  { id: '1', title: 'Hujan Lembut Menenangkan', duration: '10 min', freq: '432 Hz', uri: 'https://cdn.freesound.org/previews/530/530415_1648170-lq.mp3' },
  { id: '2', title: 'Suara Hutan Tropis & Angin', duration: '15 min', freq: '528 Hz', uri: 'https://cdn.freesound.org/previews/243/243629_3509815-lq.mp3' },
  { id: '3', title: 'Gelombang Laut Rileksasi', duration: '20 min', freq: '396 Hz', uri: 'https://cdn.freesound.org/previews/400/400632_5121236-lq.mp3' },
];

export default function MeditationHubScreen() {
  const [activeTrack, setActiveTrack] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'Inhale (4s)' | 'Hold (4s)' | 'Exhale (4s)' | 'Hold (4s)'>('Inhale (4s)');
  const [breathScale, setBreathScale] = useState(1);

  // Breathing circle cycle
  useEffect(() => {
    if (!isPlaying) {
      setBreathScale(1);
      return;
    }

    const phases: Array<{ name: 'Inhale (4s)' | 'Hold (4s)' | 'Exhale (4s)' | 'Hold (4s)'; scale: number }> = [
      { name: 'Inhale (4s)', scale: 1.4 },
      { name: 'Hold (4s)', scale: 1.4 },
      { name: 'Exhale (4s)', scale: 1.0 },
      { name: 'Hold (4s)', scale: 1.0 },
    ];

    let currentIdx = 0;
    const interval = setInterval(() => {
      currentIdx = (currentIdx + 1) % phases.length;
      setBreathPhase(phases[currentIdx].name);
      setBreathScale(phases[currentIdx].scale);
    }, 4000);

    return () => clearInterval(interval);
  }, [isPlaying]);

  const toggleTrack = async (track: typeof AUDIO_TRACKS[0]) => {
    if (activeTrack === track.id && isPlaying) {
      await stopAudio();
      setIsPlaying(false);
      setActiveTrack(null);
    } else {
      setActiveTrack(track.id);
      setIsPlaying(true);
      await playMeditationAudio(track.uri);
    }
  };

  const handleStopAll = async () => {
    await stopAudio();
    setIsPlaying(false);
    setActiveTrack(null);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="bg-gradient-to-r from-teal-700 to-emerald-800 text-white rounded-3xl p-6 shadow-xl flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-200 text-xs font-bold uppercase tracking-wider mb-2 border border-teal-400/20">
            <Wind className="w-3.5 h-3.5" /> Modul 13: Meditasi & Pernapasan
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Pusat Meditasi & Harmoni 🧘</h1>
          <p className="text-teal-100/90 text-sm mt-1">
            Panduan pernapasan Box-Breathing berbasis ritme parasimpatis & audio gelombang alfa.
          </p>
        </div>
        <div className="hidden sm:flex w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-xs items-center justify-center border border-white/20">
          <Sparkles className="w-8 h-8 text-teal-200" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Breathing Visualizer */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col items-center justify-center min-h-[380px] shadow-sm text-center">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6">
            PANDUAN BOX BREATHING
          </div>

          <div className="relative flex items-center justify-center my-6">
            <div
              className="w-48 h-48 rounded-full bg-gradient-to-tr from-emerald-400/20 to-teal-500/30 flex items-center justify-center transition-transform duration-3000 ease-in-out border border-emerald-300/40"
              style={{ transform: `scale(${breathScale})` }}
            >
              <div className="w-32 h-32 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-600 flex flex-col items-center justify-center text-white shadow-lg shadow-emerald-500/20">
                <Wind className="w-8 h-8 mb-1" />
                <span className="text-xs font-bold">{isPlaying ? breathPhase : 'Mulai Sesi'}</span>
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-500 max-w-xs mt-4">
            {isPlaying
              ? 'Tarik napas perlahan melalui hidung, tahan, lalu hembuskan lewat mulut secara teratur.'
              : 'Pilih audio alam di samping untuk memulai sesi pernapasan meditatif.'}
          </p>

          {isPlaying && (
            <button
              onClick={handleStopAll}
              className="mt-4 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-2 cursor-pointer transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Hentikan Sesi
            </button>
          )}
        </div>

        {/* Audio Tracks */}
        <div className="space-y-4">
          <div className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-emerald-600" />
            <span>Pilih Soundscape Relaksasi</span>
          </div>

          <div className="space-y-3">
            {AUDIO_TRACKS.map((track) => {
              const isCurrentPlaying = activeTrack === track.id && isPlaying;
              return (
                <div
                  key={track.id}
                  onClick={() => toggleTrack(track)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                    isCurrentPlaying
                      ? 'bg-emerald-50/80 border-emerald-500 ring-2 ring-emerald-500/20 shadow-sm'
                      : 'bg-white border-slate-200 hover:border-emerald-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        isCurrentPlaying ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {isCurrentPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{track.title}</h4>
                      <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                        <span>{track.duration}</span>
                        <span>•</span>
                        <span className="text-emerald-700 font-semibold">{track.freq} Frekuensi Harmonis</span>
                      </div>
                    </div>
                  </div>

                  <span
                    className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                      isCurrentPlaying
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {isCurrentPlaying ? 'Memutar' : 'Putar'}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-100 text-xs text-emerald-900 leading-relaxed">
            💡 <strong>Rekomendasi Ahli:</strong> Lakukan pernapasan terarah selama 5 menit sebelum tidur atau setelah sesi latihan berat untuk menurunkan kadar kortisol dan mengaktifkan sistem pemulihan saraf.
          </div>
        </div>
      </div>
    </div>
  );
}
