import React, { useState } from 'react';
import { Calendar as CalendarIcon, Heart, Sparkles, AlertCircle, Clock, Droplets, Info } from 'lucide-react';

export default function ReproductiveHealthScreen() {
  const [selectedPhase, setSelectedPhase] = useState<'follicular' | 'ovulation' | 'luteal' | 'menstrual'>('follicular');
  const [cycleDay, setCycleDay] = useState(10);

  const phaseData = {
    follicular: {
      name: 'Fase Folikuler (Hari 6 - 13)',
      energy: 'Tinggi & Progresif',
      workoutRecommendation: 'Latihan beban intensitas tinggi (Hypertrophy / Strength), sprint intervals, atau HIIT.',
      nutritionTip: 'Tingkatkan karbohidrat kompleks & antioksidan. Sensitivitas insulin sedang optimal.',
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    },
    ovulation: {
      name: 'Fase Ovulasi (Hari 14 - 16)',
      energy: 'Puncak / Maksimal',
      workoutRecommendation: 'Waktu terbaik untuk Personal Best (PR) angkat beban. Waspadai stabilitas sendi lutut (ACL).',
      nutritionTip: 'Cukupi asupan protein dan magnesium untuk mendukung lonjakan hormon LH dan estrogen.',
      badgeColor: 'bg-teal-100 text-teal-800 border-teal-300',
    },
    luteal: {
      name: 'Fase Luteal (Hari 17 - 28)',
      energy: 'Menurun Perlahan',
      workoutRecommendation: 'Latihan beban moderat, pilates, jalan santai, atau yoga restoratif.',
      nutritionTip: 'Perbanyak lemak sehat (alpukat, omega-3) dan kurangi sodium untuk mencegah retensi air (bloating).',
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
    },
    menstrual: {
      name: 'Fase Menstruasi (Hari 1 - 5)',
      energy: 'Rendah / Butuh Istirahat',
      workoutRecommendation: 'Peregangan ringan, mobilitas panggul, pernapasan diafragma, atau istirahat total.',
      nutritionTip: 'Tingkatkan makanan kaya zat besi (bayam, daging merah) dan hidrasi hangat.',
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
    },
  };

  const current = phaseData[selectedPhase];

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="bg-gradient-to-r from-rose-600 to-pink-700 text-white rounded-3xl p-6 shadow-xl flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 text-rose-200 text-xs font-bold uppercase tracking-wider mb-2 border border-rose-400/20">
            <Heart className="w-3.5 h-3.5" /> Modul 20: Siklus & Kesehatan Hormonal
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Sinkronisasi Siklus & Hormon 🌸</h1>
          <p className="text-rose-100/90 text-sm mt-1">
            Penyesuaian ritme beban latihan & nutrisi berbasis fluktuasi hormon estrogen dan progesteron.
          </p>
        </div>
        <div className="hidden sm:flex w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-xs items-center justify-center border border-white/20">
          <CalendarIcon className="w-8 h-8 text-rose-200" />
        </div>
      </div>

      {/* Phase Selector */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {(['menstrual', 'follicular', 'ovulation', 'luteal'] as const).map((phase) => {
          const isSelected = selectedPhase === phase;
          const label = phase === 'menstrual' ? 'Menstruasi' : phase === 'follicular' ? 'Folikuler' : phase === 'ovulation' ? 'Ovulasi' : 'Luteal';
          return (
            <button
              key={phase}
              onClick={() => setSelectedPhase(phase)}
              className={`p-3.5 rounded-2xl border text-center font-bold text-xs transition-all cursor-pointer ${
                isSelected
                  ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                  : 'bg-white text-slate-700 border-slate-200 hover:border-rose-300 hover:bg-rose-50/50'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Detail Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-xl font-extrabold text-slate-900">{current.name}</h2>
            <p className="text-xs text-slate-500 mt-0.5">Tingkat Energi Tubuh: <strong className="text-slate-800">{current.energy}</strong></p>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-bold border ${current.badgeColor}`}>
            Fase Aktif
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
              <Sparkles className="w-4 h-4 text-rose-600" />
              <span>Rekomendasi Latihan & Beban</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              {current.workoutRecommendation}
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
              <Droplets className="w-4 h-4 text-rose-600" />
              <span>Strategi Nutrisi & Elektrolit</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              {current.nutritionTip}
            </p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-100 flex items-start gap-3 text-xs text-rose-950">
          <Info className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <p>
            Dengarkan sinyal biofeedback tubuhmu. Jika merasa sangat lelah atau mengalami kram, prioritaskan pemulihan aktif dan jangan memaksakan volume latihan tinggi.
          </p>
        </div>
      </div>
    </div>
  );
}
