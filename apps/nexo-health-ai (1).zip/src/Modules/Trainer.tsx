import React, { useState } from 'react';
import { Dumbbell, Sparkles, Loader2, Play, CheckCircle2, Clock, RotateCcw, AlertCircle } from 'lucide-react';
import { generateWorkoutPlan, GeneratedExercise } from '../services/aiService';

export default function TrainerScreen() {
  const [goal, setGoal] = useState('Membangun Otot (Hypertrophy)');
  const [level, setLevel] = useState('Menengah');
  const [equipment, setEquipment] = useState('Dumbbell & Bodyweight');
  const [fatigueLevel, setFatigueLevel] = useState('Normal');

  const [loading, setLoading] = useState(false);
  const [workout, setWorkout] = useState<GeneratedExercise[] | null>(null);

  const handleGenerateWorkout = async () => {
    setLoading(true);
    try {
      const plan = await generateWorkoutPlan(goal, level, equipment, fatigueLevel);
      setWorkout(plan);
    } catch (error) {
      console.error('Error generating workout:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-3xl p-6 shadow-xl flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-200 text-xs font-bold uppercase tracking-wider mb-2 border border-emerald-400/20">
            <Dumbbell className="w-3.5 h-3.5" /> AI Personal Trainer
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Generator Latihan Adaptif 🏋️‍♂️</h1>
          <p className="text-emerald-100/90 text-sm mt-1">
            Program latihan biomekanik terpersonalisasi sesuai alat, kesiapan, dan target harianmu.
          </p>
        </div>
        <div className="hidden sm:flex w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-xs items-center justify-center border border-white/20">
          <Sparkles className="w-8 h-8 text-emerald-200" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Form Settings */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
            Parameter Latihan
          </h3>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Tujuan:</label>
            <select
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold focus:outline-none focus:border-emerald-500 bg-slate-50 text-slate-900"
            >
              <option value="Membangun Otot (Hypertrophy)">Membangun Otot (Hypertrophy)</option>
              <option value="Kekuatan Maksimal (Strength)">Kekuatan Maksimal (Strength)</option>
              <option value="Pembakaran Lemak & Kardio">Pembakaran Lemak & Kardio</option>
              <option value="Mobilitas & Perbaikan Postur">Mobilitas & Perbaikan Postur</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Level Kebugaran:</label>
            <select
              value={level}
              onChange={(e) => setLevel(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold focus:outline-none focus:border-emerald-500 bg-slate-50 text-slate-900"
            >
              <option value="Pemula">Pemula</option>
              <option value="Menengah">Menengah</option>
              <option value="Lanjutan (Advanced)">Lanjutan (Advanced)</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Alat Tersedia:</label>
            <select
              value={equipment}
              onChange={(e) => setEquipment(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold focus:outline-none focus:border-emerald-500 bg-slate-50 text-slate-900"
            >
              <option value="Dumbbell & Bodyweight">Dumbbell & Bodyweight</option>
              <option value="Hanya Bodyweight (Tanpa Alat)">Hanya Bodyweight (Tanpa Alat)</option>
              <option value="Full Gym (Barbell, Cable, Machine)">Full Gym (Barbell, Cable, Machine)</option>
              <option value="Resistance Bands">Resistance Bands</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Kesiapan Tubuh / Kelelahan:</label>
            <select
              value={fatigueLevel}
              onChange={(e) => setFatigueLevel(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-semibold focus:outline-none focus:border-emerald-500 bg-slate-50 text-slate-900"
            >
              <option value="Segar & Berenergi (Rendah)">Segar & Berenergi</option>
              <option value="Normal">Normal</option>
              <option value="Agak Lelah / Pegal (Tinggi)">Agak Lelah / Pegal</option>
            </select>
          </div>

          <button
            onClick={handleGenerateWorkout}
            disabled={loading}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-sm cursor-pointer mt-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Menghasilkan Sesi...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Buat Sesi AI Sekarang</span>
              </>
            )}
          </button>
        </div>

        {/* Workout Plan Results */}
        <div className="md:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Dumbbell className="w-4 h-4 text-emerald-600" />
              <span>Rangkaian Gerakan Latihan</span>
            </h3>
            {workout && (
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
                {workout.length} Variasi Gerakan
              </span>
            )}
          </div>

          {workout ? (
            <div className="space-y-3">
              {workout.map((item, idx) => (
                <div
                  key={idx}
                  className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs hover:border-emerald-300 transition-all space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-black flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <h4 className="text-sm font-extrabold text-slate-900">{item.exerciseName}</h4>
                    </div>
                    <div className="flex items-center gap-2 text-xs font-bold">
                      <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                        {item.sets} Sets
                      </span>
                      <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                        {item.reps}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                    <span className="flex items-center gap-1 text-slate-600 font-medium">
                      <Clock className="w-3.5 h-3.5 text-slate-400" /> Istirahat: {item.rest}
                    </span>
                  </div>

                  {item.tips && (
                    <p className="text-xs text-emerald-900 bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-100/60 leading-relaxed">
                      💡 <strong>Tips Ahli:</strong> {item.tips}
                    </p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200/80 p-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center">
                <Dumbbell className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-800">Belum Ada Sesi yang Dibuat</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Tentukan target dan ketersediaan alat di panel sebelah kiri, lalu klik &quot;Buat Sesi AI Sekarang&quot; untuk menyusun program.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
