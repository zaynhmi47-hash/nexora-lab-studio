import React, { useState, useEffect } from 'react';
import { Moon, Play, Pause, RotateCcw, Sparkles, Volume2, Clock, ShieldCheck, SunMedium } from 'lucide-react';
import { playMeditationAudio, stopAudio } from '../services/audioService';

const SLEEP_SOUNDS = [
  { id: 'rain', title: 'Hujan Malam Rintik', uri: 'https://cdn.freesound.org/previews/530/530415_1648170-lq.mp3' },
  { id: 'forest', title: 'Angin Semilir Malam', uri: 'https://cdn.freesound.org/previews/243/243629_3509815-lq.mp3' },
  { id: 'white', title: 'White Noise Pink Calming', uri: 'https://cdn.freesound.org/previews/400/400632_5121236-lq.mp3' },
];

export default function SleepRitualScreen() {
  const [selectedSound, setSelectedSound] = useState<string | null>(null);
  const [durationMin, setDurationMin] = useState<number>(30);
  const [isRunning, setIsRunning] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState<number>(0);
  const [dimMode, setDimMode] = useState(false);

  useEffect(() => {
    let interval: any;
    if (isRunning && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((prev) => prev - 1);
      }, 1000);
    } else if (secondsLeft === 0 && isRunning) {
      handleStop();
    }
    return () => clearInterval(interval);
  }, [isRunning, secondsLeft]);

  const handleStart = async () => {
    setIsRunning(true);
    setSecondsLeft(durationMin * 60);
    setDimMode(true);
    const sound = SLEEP_SOUNDS.find((s) => s.id === selectedSound) || SLEEP_SOUNDS[0];
    await playMeditationAudio(sound.uri);
  };

  const handleStop = async () => {
    setIsRunning(false);
    setSecondsLeft(0);
    setDimMode(false);
    await stopAudio();
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`max-w-4xl mx-auto p-4 sm:p-6 space-y-6 transition-colors duration-500 ${dimMode ? 'bg-slate-950 text-slate-100 rounded-3xl p-6' : ''}`}>
      <div className="bg-gradient-to-r from-indigo-900 to-slate-900 text-white rounded-3xl p-6 shadow-xl flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-200 text-xs font-bold uppercase tracking-wider mb-2 border border-indigo-400/20">
            <Moon className="w-3.5 h-3.5" /> Modul 15: Ritual Tidur & Sirkadian
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Ritual Tidur Nyenyak 🌙</h1>
          <p className="text-indigo-200/90 text-sm mt-1">
            Optimalkan gelombang delta otak & sinkronisasi hormon melatonin alami.
          </p>
        </div>
        <div className="hidden sm:flex w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-xs items-center justify-center border border-white/20">
          <Moon className="w-8 h-8 text-indigo-300" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Timer & Controls */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 flex flex-col items-center justify-center shadow-sm text-center">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-indigo-500" /> TIMER TIDUR OTOMATIS
          </div>

          <div className="text-5xl font-black font-mono tracking-tight text-slate-900 dark:text-white my-4">
            {isRunning ? formatTime(secondsLeft) : `${durationMin}:00`}
          </div>

          {!isRunning ? (
            <div className="w-full max-w-xs space-y-4">
              <div className="flex justify-center gap-2">
                {[15, 30, 45, 60].map((min) => (
                  <button
                    key={min}
                    onClick={() => setDurationMin(min)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      durationMin === min
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    {min} min
                  </button>
                ))}
              </div>

              <button
                onClick={handleStart}
                className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" /> Mulai Ritual Tidur
              </button>
            </div>
          ) : (
            <div className="w-full max-w-xs space-y-3">
              <p className="text-xs text-indigo-400">Audio akan perlahan memudar saat timer selesai.</p>
              <button
                onClick={handleStop}
                className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Pause className="w-4 h-4" /> Hentikan Audio & Timer
              </button>
            </div>
          )}
        </div>

        {/* Sound Selection */}
        <div className="space-y-3">
          <div className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-indigo-500" />
            <span>Pilih Suara Pengantar Tidur</span>
          </div>

          {SLEEP_SOUNDS.map((sound) => {
            const isSelected = selectedSound === sound.id || (!selectedSound && sound.id === 'rain');
            return (
              <div
                key={sound.id}
                onClick={() => setSelectedSound(sound.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? 'bg-indigo-50/80 dark:bg-indigo-950/40 border-indigo-500 ring-2 ring-indigo-500/20'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-indigo-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/60 text-indigo-600 dark:text-indigo-300 flex items-center justify-center">
                    <Moon className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-bold text-slate-900 dark:text-white">{sound.title}</span>
                </div>

                <span
                  className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                    isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                  }`}
                >
                  {isSelected ? 'Terpilih' : 'Pilih'}
                </span>
              </div>
            );
          })}

          <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 text-xs text-indigo-900 dark:text-indigo-300 leading-relaxed">
            ✨ <strong>Pro-Tip:</strong> Jauhkan ponsel dari jangkauan tangan dan redupkan lampu kamar 30 menit sebelum tidur untuk memacu produksi melatonin optimal.
          </div>
        </div>
      </div>
    </div>
  );
}
