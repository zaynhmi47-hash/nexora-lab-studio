import React, { useState, useRef, useEffect } from 'react';
import { Brain, Send, User, Sparkles, AlertCircle, HeartHandshake, ShieldCheck } from 'lucide-react';
import { startCBTSession } from '../services/aiService';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

export default function CBTTherapyScreen() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Halo. Saya di sini untuk mendengarkan tanpa menghakimi. Apa yang sedang membebani pikiran atau perasaanmu hari ini?',
      isUser: false,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      text: input.trim(),
      isUser: true,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMsg]);
    const currentInput = input;
    setInput('');
    setLoading(true);

    try {
      const history = messages.map((m) => `${m.isUser ? 'User' : 'AI'}: ${m.text}`);
      const aiResponseText = await startCBTSession(currentInput, history);

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponseText,
        isUser: false,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (error) {
      console.error('CBT Error:', error);
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: 'Maaf, koneksi AI terganggu. Silakan ceritakan kembali apa yang sedang kamu rasakan.',
        isUser: false,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex items-center justify-between">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-200 text-xs font-bold uppercase tracking-wider mb-2 border border-emerald-400/20">
              <Brain className="w-3.5 h-3.5" /> Modul 11: Mental Wellness
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Ruang Aman CBT 🧠</h1>
            <p className="text-emerald-100/90 text-sm mt-1">
              Reframing pola pikir kognitif adaptif & eksplorasi emosi empatik bersama AI.
            </p>
          </div>
          <div className="hidden sm:flex w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-xs items-center justify-center border border-white/20">
            <HeartHandshake className="w-8 h-8 text-emerald-200" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col h-[520px] overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/80 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Sesi Terenkripsi & Privasi Terjaga</span>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">Cognitive Restructuring Active</span>
        </div>

        <div ref={scrollRef} className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 bg-slate-50/30">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex items-start gap-3 ${m.isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-white ${
                  m.isUser ? 'bg-slate-700' : 'bg-emerald-600 shadow-sm'
                }`}
              >
                {m.isUser ? <User className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
              </div>
              <div
                className={`max-w-[80%] rounded-2xl p-4 text-sm leading-relaxed ${
                  m.isUser
                    ? 'bg-slate-900 text-white rounded-tr-none'
                    : 'bg-white border border-slate-200/80 text-slate-800 rounded-tl-none shadow-xs'
                }`}
              >
                {m.text}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex items-center gap-2 text-xs text-slate-400 pl-11">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>AI sedang memformulasikan refleksi kognitif...</span>
            </div>
          )}
        </div>

        <div className="p-4 border-t border-slate-100 bg-white">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ceritakan apa yang kamu rasakan tanpa ragu..."
              className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm focus:outline-none focus:border-emerald-500 focus:bg-white transition-all text-slate-900"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-2xl text-sm font-bold flex items-center gap-2 transition-all cursor-pointer shadow-sm"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Kirim</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
