import React, { useState } from 'react';
import {
  Trophy,
  Flame,
  Activity,
  Award,
  Sparkles,
  TrendingUp,
  Clock,
  Dumbbell,
  Heart,
  BarChart3,
  Calendar,
  Zap,
  Users,
  ChevronRight,
  BookOpen,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Sliders,
  Play,
  RotateCcw,
  Target,
  ShieldCheck,
  Plus,
} from 'lucide-react';
import { UserProfile, SportActivityLog, PersonalRecordItem } from '../../types';
import { MultiDisciplineCockpit } from './components/MultiDisciplineCockpit';
import { OneRepMaxCalculator } from './components/OneRepMaxCalculator';
import { PersonalRecordsWall } from './components/PersonalRecordsWall';
import { RunningEconomyCardioDashboard } from './components/RunningEconomyCardioDashboard';
import { WeeklyPerformanceReportView } from './components/WeeklyPerformanceReportView';
import { ActivityHeatmapCalendar } from './components/ActivityHeatmapCalendar';
import { CaseStudyRinaModal } from './components/CaseStudyRinaModal';

interface SportScreenProps {
  userProfile: UserProfile;
  onLogSportActivity?: (activity: SportActivityLog) => void;
  onNavigateTab?: (tab: string) => void;
}

type PerformanceTab =
  | 'cockpit'
  | 'one_rm'
  | 'pr_wall'
  | 'running_economy'
  | 'weekly_report'
  | 'heatmap'
  | 'community';

interface CommunityMatch {
  id: string;
  title: string;
  sport: string;
  location: string;
  time: string;
  participants: number;
  maxParticipants: number;
  level: string;
  joined: boolean;
}

const INITIAL_MATCHES: CommunityMatch[] = [
  {
    id: 'm1',
    title: 'Badminton Ganda Santai #12',
    sport: 'Badminton 🏸',
    location: 'GOR Senayan, Jakarta',
    time: 'Sabtu, 08:00 WIB',
    participants: 6,
    maxParticipants: 8,
    level: 'Semua Level',
    joined: false,
  },
  {
    id: 'm2',
    title: 'Sunday Morning Ride (SCBD Loop 25km)',
    sport: 'Cycling 🚴',
    location: 'SCBD South Entrance',
    time: 'Minggu, 06:00 WIB',
    participants: 18,
    maxParticipants: 25,
    level: 'Menengah (26-28 km/h)',
    joined: true,
  },
  {
    id: 'm3',
    title: 'Futsal Friendly Match 5v5',
    sport: 'Futsal ⚽',
    location: 'Halim Futsal Center',
    time: 'Rabu, 19:30 WIB',
    participants: 8,
    maxParticipants: 10,
    level: 'Kasual',
    joined: false,
  },
  {
    id: 'm4',
    title: '5K Tempo Pace Run Senayan',
    sport: 'Running 🏃',
    location: 'Gelora Bung Karno Gate 5',
    time: 'Selasa, 19:00 WIB',
    participants: 12,
    maxParticipants: 15,
    level: 'Pace 5:00 - 5:30',
    joined: false,
  },
];

export const SportScreen: React.FC<SportScreenProps> = ({
  userProfile,
  onLogSportActivity,
  onNavigateTab,
}) => {
  const [activeTab, setActiveTab] = useState<PerformanceTab>('cockpit');
  const [isCaseStudyModalOpen, setIsCaseStudyModalOpen] = useState<boolean>(false);
  const [matches, setMatches] = useState<CommunityMatch[]>(INITIAL_MATCHES);
  const [appliedCaseStudyToast, setAppliedCaseStudyToast] = useState<string | null>(null);

  const handleApplyRinaProtocol = () => {
    setAppliedCaseStudyToast(
      'Protokol 80/20 Polarized Training (Kasus Rina) berhasil diaktifkan ke kalender latihan mingguan Anda!'
    );
    setTimeout(() => setAppliedCaseStudyToast(null), 5000);
  };

  const handleToggleJoinMatch = (id: string) => {
    setMatches((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          const nextJoined = !m.joined;
          return {
            ...m,
            joined: nextJoined,
            participants: nextJoined ? m.participants + 1 : m.participants - 1,
          };
        }
        return m;
      })
    );
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-3 sm:px-6 py-4 pb-16">
      {/* TOP NAVIGATION BREADCRUMB & BACK BUTTON */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('landing') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Beranda / Google Health Hub</span>
        </button>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <span className="hidden sm:inline">Halaman Modul:</span>
          <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 font-extrabold border border-amber-300">
            #4 Performance Pulse (Sport & PR Tracker)
          </span>
        </div>
      </div>

      {/* Module 4 Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-amber-950 text-white p-6 sm:p-8 border border-amber-900/40 shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-black uppercase tracking-wider border border-amber-500/30 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Modul 4: Performance Pulse
              </span>
              <span className="text-xs text-slate-400 font-medium">
                Pelacak Performa Olahraga Spesifik
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white">
              Ukur Kemajuanmu, Pecahkan Batasmu.
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Dashboard kokpit analitik data performa atletik: Estimasi 1RM Epley & Brzycki, Running Economy (HR vs Speed), 5 Zona Detak Jantung, Dinding Rekor Pribadi (PR Vault), dan Laporan Autoregulasi Mingguan AI.
            </p>
          </div>

          {/* Quick Case Study & Readiness Widget */}
          <div className="flex flex-col sm:flex-row md:flex-col gap-3 shrink-0">
            <button
              onClick={() => setIsCaseStudyModalOpen(true)}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-black text-xs transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <BookOpen className="w-4 h-4" />
              <span>Studi Kasus: Kasus Rina (80/20 Run)</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <div className="px-4 py-2.5 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-400" />
                <span className="text-slate-300 text-[11px]">Total PR Aktif:</span>
              </div>
              <span className="font-black text-amber-300 font-mono text-sm">6 Rekor Terpecahkan</span>
            </div>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {appliedCaseStudyToast && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2.5 shadow-sm animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{appliedCaseStudyToast}</span>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        <button
          onClick={() => setActiveTab('cockpit')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'cockpit'
              ? 'bg-slate-900 text-white shadow-md'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <Activity className="w-4 h-4 text-amber-400" />
          <span>Cockpit Multi-Disiplin</span>
        </button>

        <button
          onClick={() => setActiveTab('one_rm')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'one_rm'
              ? 'bg-amber-600 text-white shadow-md'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <Dumbbell className="w-4 h-4 text-amber-200" />
          <span>Kalkulator 1RM & Epley</span>
        </button>

        <button
          onClick={() => setActiveTab('pr_wall')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'pr_wall'
              ? 'bg-amber-700 text-white shadow-md'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <Trophy className="w-4 h-4 text-amber-300" />
          <span>Rekor Pribadi (PR Vault)</span>
        </button>

        <button
          onClick={() => setActiveTab('running_economy')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'running_economy'
              ? 'bg-rose-600 text-white shadow-md'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <Heart className="w-4 h-4 text-rose-200" />
          <span>Running Economy & Zona HR</span>
        </button>

        <button
          onClick={() => setActiveTab('weekly_report')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'weekly_report'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-indigo-200" />
          <span>Laporan Mingguan AI</span>
        </button>

        <button
          onClick={() => setActiveTab('heatmap')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'heatmap'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <Calendar className="w-4 h-4 text-emerald-200" />
          <span>Heatmap & Konsistensi</span>
        </button>

        <button
          onClick={() => setActiveTab('community')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'community'
              ? 'bg-teal-600 text-white shadow-md'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <Users className="w-4 h-4 text-teal-200" />
          <span>Teman Olahraga ({matches.length})</span>
        </button>
      </div>

      {/* SUBTAB CONTENT */}

      {/* 1. Multi-Discipline Cockpit */}
      {activeTab === 'cockpit' && (
        <div className="space-y-6">
          <MultiDisciplineCockpit />
        </div>
      )}

      {/* 2. One Rep Max Calculator */}
      {activeTab === 'one_rm' && (
        <div className="space-y-6">
          <OneRepMaxCalculator />
        </div>
      )}

      {/* 3. Personal Records Wall */}
      {activeTab === 'pr_wall' && (
        <div className="space-y-6">
          <PersonalRecordsWall />
        </div>
      )}

      {/* 4. Running Economy & Cardio */}
      {activeTab === 'running_economy' && (
        <div className="space-y-6">
          <RunningEconomyCardioDashboard />
        </div>
      )}

      {/* 5. Weekly Performance Intelligence Report */}
      {activeTab === 'weekly_report' && (
        <div className="space-y-6">
          <WeeklyPerformanceReportView />
        </div>
      )}

      {/* 6. Activity Heatmap Calendar */}
      {activeTab === 'heatmap' && (
        <div className="space-y-6">
          <ActivityHeatmapCalendar />
        </div>
      )}

      {/* 7. Community Match Finder */}
      {activeTab === 'community' && (
        <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-full bg-teal-100 text-teal-800 text-[10.5px] font-black uppercase tracking-wider">
                  Sport Matchmaking & Social Hub
                </span>
                <span className="text-xs text-slate-400 font-bold">Komunitas Olahraga Sehat</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Teman Latihan & Pertandingan Komunitas
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
                Temukan rekan tanding badminton, peloton road bike, grup lari sore, atau sesi futsal di dekat lokasi Anda.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {matches.map((match) => (
              <div
                key={match.id}
                className="p-5 rounded-3xl border border-slate-200 bg-slate-50/70 hover:bg-white hover:border-teal-300 hover:shadow-md transition-all space-y-4 flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-teal-800 bg-teal-50 px-2.5 py-0.5 rounded-full border border-teal-200">
                      {match.sport}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">{match.level}</span>
                  </div>

                  <h4 className="text-base font-black text-slate-900">{match.title}</h4>

                  <div className="space-y-1 text-xs text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>{match.time}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Activity className="w-3.5 h-3.5 text-slate-400" />
                      <span>{match.location}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                  <div className="text-xs text-slate-600 font-medium">
                    Peserta: <strong className="text-slate-900 font-mono">{match.participants}</strong>/{match.maxParticipants} orang
                  </div>

                  <button
                    onClick={() => handleToggleJoinMatch(match.id)}
                    className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                      match.joined
                        ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                        : 'bg-slate-900 text-white hover:bg-slate-800'
                    }`}
                  >
                    {match.joined ? 'Tergabung (Batal)' : 'Gabung Sesi'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Case Study Modal: Kasus Rina */}
      <CaseStudyRinaModal
        isOpen={isCaseStudyModalOpen}
        onClose={() => setIsCaseStudyModalOpen(false)}
        onApplyProtocol={handleApplyRinaProtocol}
      />
    </div>
  );
};
