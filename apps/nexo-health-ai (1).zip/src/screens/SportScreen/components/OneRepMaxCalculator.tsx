import React, { useState } from 'react';
import {
  Dumbbell,
  Calculator,
  Sparkles,
  TrendingUp,
  Award,
  CheckCircle2,
  Sliders,
  RotateCcw,
  Zap,
  Info,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { ONE_RM_EXERCISE_PRESETS } from '../data/performanceData';

interface OneRepMaxCalculatorProps {
  onSavePersonalRecord?: (record: {
    exerciseName: string;
    weightKg: number;
    reps: number;
    estimated1RmKg: number;
    rpe: number;
  }) => void;
}

export const OneRepMaxCalculator: React.FC<OneRepMaxCalculatorProps> = ({
  onSavePersonalRecord,
}) => {
  const [selectedExerciseId, setSelectedExerciseId] = useState<string>('bench_press');
  const [weightKg, setWeightKg] = useState<number>(80);
  const [repsCompleted, setRepsCompleted] = useState<number>(6);
  const [rpeScore, setRpeScore] = useState<number>(8.5); // Rate of Perceived Exertion (1-10)
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  const selectedPreset =
    ONE_RM_EXERCISE_PRESETS.find((p) => p.id === selectedExerciseId) ||
    ONE_RM_EXERCISE_PRESETS[0];

  // Mathematical 1RM Estimations
  // 1. Epley Formula: W * (1 + r / 30)
  const epley1Rm = weightKg * (1 + repsCompleted / 30);

  // 2. Brzycki Formula: W * (36 / (37 - r)) (valid for r < 37)
  const brzycki1Rm =
    repsCompleted < 37 ? weightKg * (36 / (37 - repsCompleted)) : epley1Rm;

  // 3. Lombardi Formula: W * (r ^ 0.10)
  const lombardi1Rm = weightKg * Math.pow(repsCompleted, 0.1);

  // Blended AI Consensus Estimate
  const consensus1Rm = (epley1Rm + brzycki1Rm + lombardi1Rm) / 3;

  // RPE RIR Adjustment: If RPE is 8.5, RIR is 1.5. If true max tested, RPE = 10.
  const repsInReserve = Math.max(0, 10 - rpeScore);
  const adjustedPotential1Rm =
    repsInReserve > 0
      ? weightKg * (1 + (repsCompleted + repsInReserve) / 30)
      : consensus1Rm;

  // Percentages Table
  const percentages = [
    { pct: 100, reps: 1, desc: 'Kekuatan Maksimal Absolut' },
    { pct: 95, reps: 2, desc: 'Kekuatan Maksimal (Heavy Double)' },
    { pct: 90, reps: 3, desc: 'Kekuatan Murni (Heavy Triple)' },
    { pct: 85, reps: 5, desc: 'Kekuatan & Densitas (5x5 Standard)' },
    { pct: 80, reps: 7, desc: 'Hipertrofi Berat (Strength Hypertrophy)' },
    { pct: 75, reps: 10, desc: 'Hipertrofi Optimal (Metabolic Stress)' },
    { pct: 70, reps: 12, desc: 'Daya Tahan Otot & Pompa Vaskular' },
    { pct: 65, reps: 15, desc: 'Ketahanan Otot & Pemulihan Aktif' },
  ];

  const handleSaveToPr = () => {
    if (onSavePersonalRecord) {
      onSavePersonalRecord({
        exerciseName: selectedPreset.name,
        weightKg,
        reps: repsCompleted,
        estimated1RmKg: Math.round(consensus1Rm * 10) / 10,
        rpe: rpeScore,
      });
    }
    setSaveSuccessMessage(
      `Berhasil dicatat! Rekor estimasi 1RM untuk ${selectedPreset.name} sebesar ${consensus1Rm.toFixed(1)} kg telah disimpan.`
    );
    setTimeout(() => setSaveSuccessMessage(null), 4000);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10.5px] font-black uppercase tracking-wider">
              Kalkulator 1RM Cerdas & Epley Engine
            </span>
            <span className="text-xs text-slate-400 font-bold">Scientific Submaximal Testing</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Estimasi 1RM (One Rep Max) & Distribusi Beban
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
            Perkirakan kapasitas angkatan maksimal 1 repetisi Anda secara aman melalui repetisi sub-maksimal tanpa risiko cedera spinal atau sendi.
          </p>
        </div>

        {/* Exercise Switcher */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {ONE_RM_EXERCISE_PRESETS.map((ex) => (
            <button
              key={ex.id}
              onClick={() => {
                setSelectedExerciseId(ex.id);
                setWeightKg(ex.defaultWeightKg);
                setRepsCompleted(ex.standardReps);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                selectedExerciseId === ex.id
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {ex.name.split(' ')[ex.name.split(' ').length - 1]}
            </button>
          ))}
        </div>
      </div>

      {saveSuccessMessage && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{saveSuccessMessage}</span>
        </div>
      )}

      {/* Main Grid: Controls + Big Result Hero */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs (5 cols) */}
        <div className="lg:col-span-5 bg-slate-50 rounded-3xl p-5 border border-slate-200/90 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-slate-800 uppercase tracking-wider">
              Parameter Angkatan Terakhir
            </span>
            <span className="text-[11px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md">
              {selectedPreset.name}
            </span>
          </div>

          {/* Weight Slider & Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600 font-bold">Beban yang Diangkat:</span>
              <span className="text-sm font-black text-slate-900 font-mono bg-white px-2.5 py-0.5 rounded-lg border border-slate-200">
                {weightKg} kg
              </span>
            </div>
            <input
              type="range"
              min="10"
              max="260"
              step="2.5"
              value={weightKg}
              onChange={(e) => setWeightKg(parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-2 bg-slate-200 rounded-lg"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>10 kg</span>
              <span>130 kg</span>
              <span>260 kg</span>
            </div>
          </div>

          {/* Repetitions Slider */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600 font-bold">Repetisi yang Berhasil:</span>
              <span className="text-sm font-black text-slate-900 font-mono bg-white px-2.5 py-0.5 rounded-lg border border-slate-200">
                {repsCompleted} reps
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="15"
              step="1"
              value={repsCompleted}
              onChange={(e) => setRepsCompleted(parseInt(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-2 bg-slate-200 rounded-lg"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>1 rep (Actual Max)</span>
              <span>8 reps (Ideal Estimasi)</span>
              <span>15 reps</span>
            </div>
          </div>

          {/* RPE (Rate of Perceived Exertion) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600 font-bold">RPE (Skala Usaha):</span>
              <span className="text-xs font-black text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md">
                RPE {rpeScore} ({repsInReserve} Reps in Reserve)
              </span>
            </div>
            <input
              type="range"
              min="6.0"
              max="10.0"
              step="0.5"
              value={rpeScore}
              onChange={(e) => setRpeScore(parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-2 bg-slate-200 rounded-lg"
            />
            <p className="text-[11px] text-slate-500 leading-tight">
              {rpeScore === 10
                ? 'Gagal jika tambah 1 repetisi lagi (True Failure).'
                : `Masih sanggup ${repsInReserve} repetisi lagi dengan form bersih.`}
            </p>
          </div>

          {/* Save to PR Button */}
          <button
            onClick={handleSaveToPr}
            className="w-full py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer"
          >
            <Award className="w-4 h-4 text-amber-400" />
            <span>Simpan ke Dinding Rekor Pribadi (PR)</span>
          </button>
        </div>

        {/* Right Consensus Showcase & Formulas (7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
          {/* Main 1RM Hero Card */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-950 to-amber-950 text-white border border-amber-900/40 shadow-lg space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                Konsensus Estimasi 1RM AI
              </span>
              <span className="text-[11px] font-mono bg-white/10 px-2.5 py-0.5 rounded-full text-white/90">
                Akurasi 95%+
              </span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
              <div>
                <div className="text-4xl sm:text-5xl font-black font-mono tracking-tight text-white">
                  {consensus1Rm.toFixed(1)} <span className="text-2xl text-amber-400 font-sans">kg</span>
                </div>
                <div className="text-xs text-slate-300 mt-1">
                  Kekuatan maksimal 1 repetisi teoritis untuk <strong className="text-white">{selectedPreset.name}</strong>.
                </div>
              </div>

              {repsInReserve > 0 && (
                <div className="bg-amber-500/20 border border-amber-500/30 p-3 rounded-2xl text-right sm:max-w-[180px]">
                  <span className="text-[10px] text-amber-200 font-bold block uppercase">Potensi Max (RPE 10):</span>
                  <span className="text-lg font-black text-amber-300 font-mono">
                    {adjustedPotential1Rm.toFixed(1)} kg
                  </span>
                </div>
              )}
            </div>

            {/* 3 Scientific Formula Badges */}
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-center">
              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-mono">Formula Epley</span>
                <span className="text-sm font-black text-white font-mono">{epley1Rm.toFixed(1)} kg</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-mono">Formula Brzycki</span>
                <span className="text-sm font-black text-white font-mono">{brzycki1Rm.toFixed(1)} kg</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-mono">Formula Lombardi</span>
                <span className="text-sm font-black text-white font-mono">{lombardi1Rm.toFixed(1)} kg</span>
              </div>
            </div>
          </div>

          {/* Training Percentages Quick Table */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Tabel Beban Latihan Berdasarkan % 1RM
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {percentages.slice(0, 4).map((p) => {
                const targetWeight = (consensus1Rm * p.pct) / 100;
                return (
                  <div
                    key={p.pct}
                    className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-0.5"
                  >
                    <div className="text-[10.5px] font-black text-amber-800">{p.pct}% 1RM</div>
                    <div className="text-base font-black text-slate-900 font-mono">
                      {targetWeight.toFixed(1)} kg
                    </div>
                    <div className="text-[10px] text-slate-500 font-medium">~{p.reps} reps</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
