import React, { useState } from 'react';
import {
  Heart,
  Activity,
  Flame,
  Zap,
  Clock,
  TrendingUp,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Info,
  Layers,
  ChevronRight,
  RefreshCw,
} from 'lucide-react';
import { CardioPerformanceLog, HeartRateZoneDistribution } from '../../../types';
import { SAMPLE_CARDIO_LOGS } from '../data/performanceData';

export const RunningEconomyCardioDashboard: React.FC = () => {
  const [cardioLogs, setCardioLogs] = useState<CardioPerformanceLog[]>(SAMPLE_CARDIO_LOGS);
  const [selectedLog, setSelectedLog] = useState<CardioPerformanceLog>(SAMPLE_CARDIO_LOGS[0]);

  const zoneColors = [
    { zone: 'Zona 1 (Recovery <60%)', key: 'zone1RecoverySec', bg: 'bg-blue-500', text: 'text-blue-700', light: 'bg-blue-50' },
    { zone: 'Zona 2 (Aerobic Base 60-70%)', key: 'zone2AerobicBaseSec', bg: 'bg-emerald-500', text: 'text-emerald-700', light: 'bg-emerald-50' },
    { zone: 'Zona 3 (Tempo 70-80%)', key: 'zone3TempoSec', bg: 'bg-amber-500', text: 'text-amber-700', light: 'bg-amber-50' },
    { zone: 'Zona 4 (Threshold 80-90%)', key: 'zone4ThresholdSec', bg: 'bg-orange-500', text: 'text-orange-700', light: 'bg-orange-50' },
    { zone: 'Zona 5 (Anaerobic >90%)', key: 'zone5AnaerobicSec', bg: 'bg-rose-600', text: 'text-rose-700', light: 'bg-rose-50' },
  ];

  const totalZoneTimeSec =
    (selectedLog.heartRateZones.zone1RecoverySec || 0) +
    (selectedLog.heartRateZones.zone2AerobicBaseSec || 0) +
    (selectedLog.heartRateZones.zone3TempoSec || 0) +
    (selectedLog.heartRateZones.zone4ThresholdSec || 0) +
    (selectedLog.heartRateZones.zone5AnaerobicSec || 0) || 1;

  const formatSecToMin = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}m ${s}s`;
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 text-[10.5px] font-black uppercase tracking-wider">
              Aerobic Efficiency & Biomechanical Economy
            </span>
            <span className="text-xs text-slate-400 font-bold">Lactate & Heart Rate Analytics</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Analisis Running Economy & Distribusi Zona Jantung
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
            Mengukur rasio efisiensi antara kecepatan lari (m/min) terhadap beban kardiovaskular (Detak Jantung). Makin rendah detak jantung pada kecepatan yang sama, makin tinggi efisiensi energi Anda.
          </p>
        </div>

        {/* Log Switcher */}
        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl overflow-x-auto no-scrollbar">
          {cardioLogs.map((log) => (
            <button
              key={log.id}
              onClick={() => setSelectedLog(log)}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
                selectedLog.id === log.id
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {log.distanceKm}k {log.activityType === 'running' ? 'Lari' : 'Sepeda'} ({log.avgPaceMinPerKm.split(' ')[0]})
            </button>
          ))}
        </div>
      </div>

      {/* Main Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
          <span className="text-xs font-bold text-slate-400 block">Pace Rata-Rata</span>
          <div className="text-xl sm:text-2xl font-black text-slate-900 font-mono">
            {selectedLog.avgPaceMinPerKm}
          </div>
          <span className="text-[10.5px] font-bold text-slate-500">Jarak: {selectedLog.distanceKm} km</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
          <span className="text-xs font-bold text-slate-400 block">Detak Jantung Rata-Rata</span>
          <div className="text-xl sm:text-2xl font-black text-rose-600 font-mono">
            {selectedLog.avgHeartRateBpm} <span className="text-xs text-slate-500 font-sans">BPM</span>
          </div>
          <span className="text-[10.5px] font-bold text-slate-500">Maks: {selectedLog.maxHeartRateBpm} BPM</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
          <span className="text-xs font-bold text-slate-400 block">Cadence (Langkah/Menit)</span>
          <div className="text-xl sm:text-2xl font-black text-indigo-600 font-mono">
            {selectedLog.cadenceSpm} <span className="text-xs text-slate-500 font-sans">SPM</span>
          </div>
          <span className="text-[10.5px] font-bold text-emerald-700">Zona Ideal: 170-180 SPM</span>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-rose-950 text-white border border-rose-900/50 space-y-1 shadow-sm">
          <span className="text-xs font-bold text-rose-300 block">Running Economy Score</span>
          <div className="text-xl sm:text-2xl font-black text-white font-mono">
            {selectedLog.runningEconomyIndex}
          </div>
          <span className="text-[10.5px] font-bold text-rose-200">
            {selectedLog.powerWattsAvg ? `${selectedLog.powerWattsAvg} W (${selectedLog.powerWattsPerKg} W/kg)` : 'Aerobik Efisien'}
          </span>
        </div>
      </div>

      {/* Heart Rate Zones 1-5 Visualizer Stack */}
      <div className="p-5 rounded-3xl bg-slate-50 border border-slate-200 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-black text-slate-900 uppercase tracking-wider block">
              Distribusi 5 Zona Detak Jantung
            </span>
            <span className="text-xs text-slate-500">
              Analisis waktu yang dihabiskan di setiap zona energi fisiologis.
            </span>
          </div>

          <span className="text-xs font-bold text-slate-400 font-mono">
            Total: {Math.round(selectedLog.durationSec / 60)} Menit
          </span>
        </div>

        {/* Stacked Progress Bar */}
        <div className="w-full h-4 bg-slate-200 rounded-full overflow-hidden flex shadow-inner">
          <div
            style={{ width: `${((selectedLog.heartRateZones.zone1RecoverySec || 0) / totalZoneTimeSec) * 100}%` }}
            className="h-full bg-blue-500 transition-all duration-300"
            title="Zona 1 Recovery"
          />
          <div
            style={{ width: `${((selectedLog.heartRateZones.zone2AerobicBaseSec || 0) / totalZoneTimeSec) * 100}%` }}
            className="h-full bg-emerald-500 transition-all duration-300"
            title="Zona 2 Aerobic Base"
          />
          <div
            style={{ width: `${((selectedLog.heartRateZones.zone3TempoSec || 0) / totalZoneTimeSec) * 100}%` }}
            className="h-full bg-amber-500 transition-all duration-300"
            title="Zona 3 Tempo"
          />
          <div
            style={{ width: `${((selectedLog.heartRateZones.zone4ThresholdSec || 0) / totalZoneTimeSec) * 100}%` }}
            className="h-full bg-orange-500 transition-all duration-300"
            title="Zona 4 Threshold"
          />
          <div
            style={{ width: `${((selectedLog.heartRateZones.zone5AnaerobicSec || 0) / totalZoneTimeSec) * 100}%` }}
            className="h-full bg-rose-600 transition-all duration-300"
            title="Zona 5 Anaerobic"
          />
        </div>

        {/* Zone Details Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 pt-1 text-xs">
          {zoneColors.map((z) => {
            const sec = (selectedLog.heartRateZones as any)[z.key] || 0;
            const pct = Math.round((sec / totalZoneTimeSec) * 100);
            return (
              <div key={z.key} className={`p-3 rounded-2xl border border-slate-200/80 ${z.light} space-y-1`}>
                <div className="flex items-center gap-1.5 font-bold">
                  <div className={`w-2.5 h-2.5 rounded-full ${z.bg}`} />
                  <span className={`text-[11px] font-black ${z.text} truncate`}>{z.zone.split(' ')[0]} {z.zone.split(' ')[1]}</span>
                </div>
                <div className="text-base font-black text-slate-900 font-mono">{pct}%</div>
                <div className="text-[10.5px] text-slate-500">{formatSecToMin(sec)}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Aerobic Decoupling & Physiological Diagnosis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
        <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-2">
          <span className="font-black text-emerald-950 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            Evaluasi Efisiensi Energi Kardiovaskular
          </span>
          <p className="text-emerald-900/90 leading-relaxed text-[11.5px]">
            {selectedLog.heartRateZones.zone2AerobicBaseSec > selectedLog.durationSec * 0.6
              ? 'Luar biasa! 68% durasi lari Anda berada di Zona 2 murni. Ini mengoptimalkan kepadatan mitokondria, mempercepat pembakaran lemak intraseluler, dan menjaga sistem saraf tetap segar untuk latihan intensif berikutnya.'
              : 'Sesi ini didominasi oleh zona ambang laktat (Zona 3-4). Pastikan sesi lari berikutnya dialokasikan untuk pemulihan Zona 2 murni guna menghindari kelelahan kardiovaskular akumulatif.'}
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
          <span className="font-black text-slate-900 flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-rose-600" />
            Catatan Sesi & Perlengkapan (Logbook)
          </span>
          <div className="space-y-1 text-slate-600 text-[11.5px]">
            <div><strong>Catatan Atlet: </strong>{selectedLog.notes || 'Lari pagi lancar.'}</div>
            <div><strong>Sepatu / Gear: </strong>{selectedLog.shoesGearUsed || 'Sepatu Lari Standar'}</div>
            <div><strong>Cuaca: </strong>{selectedLog.weatherCondition || 'Normal'}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
