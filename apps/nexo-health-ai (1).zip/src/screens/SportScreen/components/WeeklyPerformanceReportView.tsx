import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Award,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Moon,
  Dumbbell,
  HeartPulse,
  Utensils,
  Clock,
  CheckCircle2,
  ChevronRight,
  Activity,
} from 'lucide-react';
import { WeeklyPerformanceReport } from '../../../types';
import { WEEKLY_PERFORMANCE_REPORT_DATA } from '../data/performanceData';

export const WeeklyPerformanceReportView: React.FC = () => {
  const [report, setReport] = useState<WeeklyPerformanceReport>(WEEKLY_PERFORMANCE_REPORT_DATA);

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10.5px] font-black uppercase tracking-wider">
              AI Weekly Intelligence Brief
            </span>
            <span className="text-xs text-slate-400 font-bold">Periode: {report.weekRange}</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Laporan Performa Mingguan & Autoregulasi Ekosistem
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
            Sintesis data komprehensif performa 7 hari terakhir dari beban angkatan, jarak kardio, dan korelasi kualitas tidur terhadap adaptasi kekuatan.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-xl bg-emerald-100 text-emerald-900 font-black text-xs border border-emerald-200 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Status: Beban Latihan Optimal</span>
          </span>
        </div>
      </div>

      {/* Main Aggregates 4-Box Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Strength Volume */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
          <span className="text-xs font-bold text-slate-400 block">Total Volume Beban</span>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {report.totalStrengthVolumeKg.toLocaleString()} <span className="text-xs text-slate-500 font-sans">kg</span>
          </div>
          <div className="flex items-center gap-1 text-[11px] font-black text-emerald-700">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+{report.strengthVolumeDeltaPercent}% vs minggu lalu</span>
          </div>
        </div>

        {/* Total Cardio Distance */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
          <span className="text-xs font-bold text-slate-400 block">Total Jarak Kardio</span>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {report.totalCardioDistanceKm} <span className="text-xs text-slate-500 font-sans">km</span>
          </div>
          <div className="flex items-center gap-1 text-[11px] font-black text-emerald-700">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+{report.aerobicEfficiencyDeltaPercent}% efisiensi energi</span>
          </div>
        </div>

        {/* Active Hours & Sets */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
          <span className="text-xs font-bold text-slate-400 block">Waktu Latihan Aktif</span>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {report.totalActiveTimeHours} <span className="text-xs text-slate-500 font-sans">Jam</span>
          </div>
          <span className="text-[11px] text-slate-500 font-medium">{report.totalStrengthSets} Set Kerja Bersih</span>
        </div>

        {/* PRs Unlocked */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 text-slate-950 border border-amber-400 space-y-1 shadow-sm">
          <span className="text-xs font-bold text-amber-950 block">Rekor Baru (PR)</span>
          <div className="text-2xl font-black text-slate-950 font-mono">
            {report.personalRecordsUnlockedCount} Rekor
          </div>
          <span className="text-[10.5px] font-black text-amber-950">Squat, Bench & 5K Run</span>
        </div>
      </div>

      {/* Sleep-to-Performance Correlation Highlight */}
      <div className="p-4 sm:p-5 rounded-2xl bg-indigo-50/80 border border-indigo-200 flex items-start gap-3.5 text-xs">
        <div className="p-2.5 rounded-xl bg-indigo-600 text-white shrink-0 shadow-2xs">
          <Moon className="w-5 h-5" />
        </div>
        <div className="space-y-1">
          <div className="font-black text-indigo-950 uppercase tracking-wider text-[11px]">
            Korelasi Fisiologis: Kualitas Tidur vs Output Performa
          </div>
          <p className="text-indigo-900 leading-relaxed text-[11.5px]">
            {report.sleepToPerformanceCorrelation}
          </p>
        </div>
      </div>

      {/* AI Coach Actionable Directives & Cross-Module Directives */}
      <div className="p-6 rounded-3xl bg-slate-900 text-white border border-slate-800 space-y-5 shadow-md">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-black text-emerald-300 uppercase tracking-wider">
              Instruksi AI Coach untuk Minggu Depan
            </span>
          </div>
          <h4 className="text-lg font-black text-white">{report.aiCoachDirectives.headline}</h4>
        </div>

        {/* Actionable Tips List */}
        <div className="space-y-2">
          {report.aiCoachDirectives.actionableTips.map((tip, idx) => (
            <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-200">
              <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 text-[10.5px] font-black flex items-center justify-center shrink-0 mt-0.5">
                {idx + 1}
              </span>
              <span className="leading-relaxed">{tip}</span>
            </div>
          ))}
        </div>

        {/* Cross Module 3-Pillar Directives */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-800 text-xs">
          <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-amber-300">
              <Dumbbell className="w-3.5 h-3.5" />
              <span>Modul 1: AI Trainer</span>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              {report.aiCoachDirectives.crossModuleDirectives.trainerWeightAdjustment}
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-teal-300">
              <HeartPulse className="w-3.5 h-3.5" />
              <span>Modul 3: Recovery Lab</span>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              {report.aiCoachDirectives.crossModuleDirectives.recoveryPrescription}
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-emerald-300">
              <Utensils className="w-3.5 h-3.5" />
              <span>Modul 6: AI Dietitian</span>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              {report.aiCoachDirectives.crossModuleDirectives.nutritionCarbAdjustment}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
