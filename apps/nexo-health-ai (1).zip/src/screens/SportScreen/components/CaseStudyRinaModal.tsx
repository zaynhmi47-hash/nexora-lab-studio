import React from 'react';
import {
  X,
  User,
  Heart,
  TrendingUp,
  Flame,
  Clock,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Layers,
  ArrowRight,
  ShieldCheck,
  Award,
  Zap,
} from 'lucide-react';
import { CASE_STUDY_RINA_DATA } from '../data/performanceData';

interface CaseStudyRinaModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyProtocol?: () => void;
}

export const CaseStudyRinaModal: React.FC<CaseStudyRinaModalProps> = ({
  isOpen,
  onClose,
  onApplyProtocol,
}) => {
  if (!isOpen) return null;
  const data = CASE_STUDY_RINA_DATA;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-rose-950 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-black uppercase tracking-wider border border-rose-500/30">
                Studi Kasus Performa Riil AI
              </span>
              <span className="text-xs text-slate-400 font-bold">Endurance Breakdown</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Kasus Rina: Menembus Plateau 7:00 min/km via Pola 80/20
            </h3>
            <p className="text-xs text-rose-200">
              Penyelesaian ilmiah fenomena &quot;Junk Miles&quot; dan pembangunan efisiensi aerobik mitokondria.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-800">
          {/* Persona Card */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div>
              <div className="font-black text-slate-900 text-sm">{data.personaName} ({data.age} thn)</div>
              <div className="text-slate-500">{data.sport}</div>
            </div>
            <div className="text-xs sm:text-right">
              <span className="text-slate-400 block">Target Sasaran:</span>
              <span className="font-bold text-rose-700">{data.goal}</span>
            </div>
          </div>

          {/* Problem & Baseline vs Struggle */}
          <div className="space-y-2">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              Keluhan Awal & Data Baseline yang Terjebak
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              {data.initialStruggle}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs">
              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-center">
                <span className="text-[10px] text-amber-800 block">Pace Rata-Rata</span>
                <span className="font-black text-slate-900 font-mono">{data.baselineData.paceAvgMinKm}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-center">
                <span className="text-[10px] text-rose-800 block">Detak Jantung Rata-Rata</span>
                <span className="font-black text-rose-700 font-mono">{data.baselineData.avgHeartRateBpm} BPM</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-100 border border-slate-200 text-center">
                <span className="text-[10px] text-slate-600 block">Zona Dominan</span>
                <span className="font-black text-slate-900 text-[11px]">Zona 4 (78%)</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-100 border border-slate-200 text-center">
                <span className="text-[10px] text-slate-600 block">Cadence</span>
                <span className="font-black text-slate-900 font-mono">{data.baselineData.cadenceSpm} SPM</span>
              </div>
            </div>
          </div>

          {/* AI Diagnosis: Junk Miles Syndrome */}
          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs space-y-2">
            <div className="flex items-center gap-2 font-black text-rose-950">
              <Sparkles className="w-4 h-4 text-rose-600" />
              <span>Diagnosis AI: {data.aiDiagnosis.primaryMistake}</span>
            </div>
            <p className="text-rose-900 text-[11.5px] leading-relaxed">
              {data.aiDiagnosis.physiologicalCause}
            </p>
            <p className="text-slate-600 text-[11px]">
              <strong>Keterangan Biomekanika: </strong>{data.aiDiagnosis.lactateThresholdDisparity}
            </p>
          </div>

          {/* Intervention: 80/20 Polarized Protocol */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-indigo-600" />
                Intervensi Protokol 80/20 Polarized Training
              </h4>
              <span className="text-[11px] font-black text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-md border border-indigo-200">
                80% Zona 2 : 20% Zona 4-5
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {data.intervention8020Plan.weeklySchedule.map((item, idx) => (
                <div key={idx} className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-slate-900">{item.day} - {item.workoutType}</span>
                    <span className="text-[10px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md">
                      {item.targetZone.split(' ')[0]} {item.targetZone.split(' ')[1]}
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-slate-700">{item.targetPace}</div>
                  <p className="text-[10.5px] text-slate-500 leading-tight">{item.purpose}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Outcome after 4 weeks */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 text-xs space-y-3">
            <div className="flex items-center gap-2 font-black text-emerald-950">
              <Award className="w-5 h-5 text-emerald-600" />
              <span className="text-sm">Hasil Nyata Setelah 4 Minggu Protokol 80/20</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div className="p-2.5 rounded-xl bg-white border border-emerald-200 text-center">
                <span className="text-[10px] text-slate-500 block">Peningkatan Pace Santai</span>
                <span className="font-black text-emerald-800 text-xs">{data.outcomeAfter4Weeks.easyRunPaceChange}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-emerald-200 text-center">
                <span className="text-[10px] text-slate-500 block">Penurunan Detak Jantung</span>
                <span className="font-black text-emerald-800 text-xs font-mono">{data.outcomeAfter4Weeks.averageHeartRateDropBpm} BPM (Zona 2)</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-emerald-200 text-center">
                <span className="text-[10px] text-slate-500 block">Kenaikan VO2 Max</span>
                <span className="font-black text-emerald-800 text-xs font-mono">{data.outcomeAfter4Weeks.vo2MaxImprovement}</span>
              </div>
            </div>

            <p className="text-emerald-900 text-[11.5px] leading-relaxed">
              {data.outcomeAfter4Weeks.marathonReadinessVerdict}
            </p>
          </div>

          {/* Takeaway Principles */}
          <div className="space-y-1.5 text-xs text-slate-600">
            <span className="font-black text-slate-900 block uppercase tracking-wider text-[10.5px]">
              Prinsip Kunci (Takeaways)
            </span>
            <ul className="list-disc list-inside space-y-1 text-[11px]">
              {data.takeawayPrinciples.map((principle, idx) => (
                <li key={idx}>{principle}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 cursor-pointer"
          >
            Tutup
          </button>
          <button
            onClick={() => {
              if (onApplyProtocol) onApplyProtocol();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Zap className="w-4 h-4" />
            <span>Terapkan Pola 80/20 ke Profil Saya</span>
          </button>
        </div>
      </div>
    </div>
  );
};
