import React, { useState } from 'react';
import {
  Trophy,
  Award,
  Sparkles,
  Flame,
  Zap,
  Dumbbell,
  CheckCircle2,
  TrendingUp,
  Plus,
  ArrowRight,
  ShieldCheck,
  Target,
  Clock,
  ChevronRight,
} from 'lucide-react';
import { PersonalRecordItem, SportDisciplineType } from '../../../types';
import { PERSONAL_RECORDS_LIST } from '../data/performanceData';

interface PersonalRecordsWallProps {
  onAddNewRecord?: (record: PersonalRecordItem) => void;
}

export const PersonalRecordsWall: React.FC<PersonalRecordsWallProps> = ({
  onAddNewRecord,
}) => {
  const [records, setRecords] = useState<PersonalRecordItem[]>(PERSONAL_RECORDS_LIST);
  const [selectedDiscipline, setSelectedDiscipline] = useState<string>('all');
  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);

  // Form State for manual PR entry
  const [newMetricName, setNewMetricName] = useState<string>('Barbell Hip Thrust');
  const [newDiscipline, setNewDiscipline] = useState<SportDisciplineType>('strength');
  const [newRecordValue, setNewRecordValue] = useState<number>(140);
  const [newUnit, setNewUnit] = useState<string>('kg');

  const filteredRecords = records.filter(
    (rec) => selectedDiscipline === 'all' || rec.discipline === selectedDiscipline
  );

  const getDisciplineBadge = (discipline: SportDisciplineType) => {
    switch (discipline) {
      case 'strength':
        return { label: 'Strength 1RM', color: 'bg-amber-100 text-amber-800 border-amber-200' };
      case 'cardio':
        return { label: 'Kardio Endurance', color: 'bg-rose-100 text-rose-800 border-rose-200' };
      case 'hiit_calisthenics':
        return { label: 'HIIT & Calisthenics', color: 'bg-indigo-100 text-indigo-800 border-indigo-200' };
      case 'court_field_sport':
        return { label: 'Court / Field Sport', color: 'bg-emerald-100 text-emerald-800 border-emerald-200' };
      default:
        return { label: 'Multi-Sport', color: 'bg-slate-100 text-slate-800 border-slate-200' };
    }
  };

  const handleSaveNewPr = (e: React.FormEvent) => {
    e.preventDefault();
    const newPrItem: PersonalRecordItem = {
      id: `pr_${Date.now()}`,
      discipline: newDiscipline,
      metricName: newMetricName,
      recordValue: newRecordValue,
      recordUnit: newUnit,
      recordValueFormatted: `${newRecordValue} ${newUnit}`,
      dateAchieved: new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }),
      badgeIcon: 'Trophy',
      targetNextGoal: Math.round(newRecordValue * 1.06 * 10) / 10,
      targetNextGoalFormatted: `${(newRecordValue * 1.06).toFixed(1)} ${newUnit}`,
      aiPredictionCommentary: 'Progresi beban baru tercatat! AI memprediksi adaptasi saraf membutuhkan waktu 2-3 minggu sebelum menaikkan target berikutnya.',
      confidenceScorePercent: 90,
    };

    setRecords((prev) => [newPrItem, ...prev]);
    if (onAddNewRecord) onAddNewRecord(newPrItem);
    setIsAddingNew(false);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10.5px] font-black uppercase tracking-wider">
              Hall of Fame & PR Detection
            </span>
            <span className="text-xs text-slate-400 font-bold">Personal Record Vault</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Dinding Rekor Pribadi & Prediksi Target AI
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
            Kumpulan rekor angkatan terberat, pace lari tercepat, dan repetisi maksimal Anda yang diperbarui secara otomatis dengan target sasaran ilmiah berikutnya.
          </p>
        </div>

        <button
          onClick={() => setIsAddingNew(!isAddingNew)}
          className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-sm self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 text-amber-400" />
          <span>{isAddingNew ? 'Tutup Formulir' : 'Catat PR Baru'}</span>
        </button>
      </div>

      {/* Manual PR Add Form Modal / Expandable */}
      {isAddingNew && (
        <form
          onSubmit={handleSaveNewPr}
          className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4 animate-in fade-in"
        >
          <span className="text-xs font-black text-slate-900 uppercase tracking-wider block">
            Catat Rekor Pribadi Baru
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
            <div className="space-y-1">
              <label className="text-slate-600 font-bold">Disiplin Olahraga:</label>
              <select
                value={newDiscipline}
                onChange={(e) => setNewDiscipline(e.target.value as SportDisciplineType)}
                className="w-full p-2 rounded-xl bg-white border border-slate-200 text-slate-800"
              >
                <option value="strength">Strength (Angkat Beban)</option>
                <option value="cardio">Cardio (Lari / Sepeda / Renang)</option>
                <option value="hiit_calisthenics">HIIT & Calisthenics</option>
                <option value="court_field_sport">Court / Team Sport</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-600 font-bold">Nama Gerakan / Metrik:</label>
              <input
                type="text"
                value={newMetricName}
                onChange={(e) => setNewMetricName(e.target.value)}
                placeholder="Misal: 1RM Hip Thrust"
                required
                className="w-full p-2 rounded-xl bg-white border border-slate-200 text-slate-800"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-600 font-bold">Nilai Rekor Baru:</label>
              <input
                type="number"
                step="0.1"
                value={newRecordValue}
                onChange={(e) => setNewRecordValue(parseFloat(e.target.value))}
                required
                className="w-full p-2 rounded-xl bg-white border border-slate-200 text-slate-800"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-600 font-bold">Satuan (Unit):</label>
              <input
                type="text"
                value={newUnit}
                onChange={(e) => setNewUnit(e.target.value)}
                placeholder="kg, min, reps, km/h"
                required
                className="w-full p-2 rounded-xl bg-white border border-slate-200 text-slate-800"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsAddingNew(false)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black"
            >
              Simpan Rekor
            </button>
          </div>
        </form>
      )}

      {/* Discipline Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
        <button
          onClick={() => setSelectedDiscipline('all')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            selectedDiscipline === 'all'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Semua Disiplin ({records.length})
        </button>
        <button
          onClick={() => setSelectedDiscipline('strength')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            selectedDiscipline === 'strength'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Strength 1RM
        </button>
        <button
          onClick={() => setSelectedDiscipline('cardio')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            selectedDiscipline === 'cardio'
              ? 'bg-rose-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Kardio & Pace
        </button>
        <button
          onClick={() => setSelectedDiscipline('hiit_calisthenics')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            selectedDiscipline === 'hiit_calisthenics'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          HIIT / Calisthenics
        </button>
        <button
          onClick={() => setSelectedDiscipline('court_field_sport')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            selectedDiscipline === 'court_field_sport'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Court & Field Sport
        </button>
      </div>

      {/* PR Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRecords.map((item) => {
          const badge = getDisciplineBadge(item.discipline);
          const hasDelta = item.previousRecordValue !== undefined;
          const deltaValue = hasDelta
            ? Math.round((item.recordValue - item.previousRecordValue!) * 10) / 10
            : 0;

          return (
            <div
              key={item.id}
              className="p-5 rounded-3xl border border-slate-200/90 bg-white hover:border-amber-300 hover:shadow-md transition-all space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full border ${badge.color}`}>
                    {badge.label}
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium">{item.dateAchieved}</span>
                </div>

                <div>
                  <h4 className="text-sm font-black text-slate-900">{item.metricName}</h4>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight">
                      {item.recordValueFormatted}
                    </span>
                    {hasDelta && deltaValue > 0 && (
                      <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md flex items-center gap-0.5">
                        <TrendingUp className="w-3 h-3" />
                        <span>+{deltaValue} {item.recordUnit}</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* AI Target Recommendation */}
                <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200/70 text-xs space-y-1.5">
                  <div className="flex items-center justify-between font-black text-amber-900">
                    <span className="flex items-center gap-1">
                      <Target className="w-3.5 h-3.5 text-amber-600" />
                      Sasaran Target AI Berikutnya:
                    </span>
                    <span className="font-mono text-amber-800 bg-white px-2 py-0.5 rounded-md border border-amber-200">
                      {item.targetNextGoalFormatted}
                    </span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    {item.aiPredictionCommentary}
                  </p>
                </div>
              </div>

              {/* Confidence Score Pill */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                <span>Prediksi AI Confidence:</span>
                <span className="font-black text-slate-700 font-mono">{item.confidenceScorePercent}%</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
