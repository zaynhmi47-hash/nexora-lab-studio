import React, { useState } from 'react';
import {
  Calendar,
  Flame,
  TrendingUp,
  Activity,
  Award,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Info,
  CheckCircle2,
} from 'lucide-react';

interface DayActivity {
  date: string;
  intensity: 'heavy' | 'moderate' | 'light' | 'rest';
  sportName?: string;
  volumeKg?: number;
  distanceKm?: number;
  durationMin: number;
}

export const ActivityHeatmapCalendar: React.FC = () => {
  const [selectedMonth, setSelectedMonth] = useState<string>('Agustus 2026');
  const [hoveredDay, setHoveredDay] = useState<DayActivity | null>(null);

  // Generate 28-35 days for current visual representation
  const daysInMonth: DayActivity[] = Array.from({ length: 31 }, (_, i) => {
    const day = i + 1;
    const dateStr = `2026-08-${day < 10 ? '0' + day : day}`;
    if (day % 7 === 0) {
      return { date: dateStr, intensity: 'rest', durationMin: 0 };
    } else if (day % 4 === 0) {
      return {
        date: dateStr,
        intensity: 'heavy',
        sportName: 'Squat & Leg Hypertrophy',
        volumeKg: 2400,
        durationMin: 65,
      };
    } else if (day % 3 === 0) {
      return {
        date: dateStr,
        intensity: 'moderate',
        sportName: 'Morning SCBD Run',
        distanceKm: 8.5,
        durationMin: 48,
      };
    } else {
      return {
        date: dateStr,
        intensity: 'light',
        sportName: 'Recovery Stretch & Core',
        durationMin: 25,
      };
    }
  });

  const getIntensityColor = (intensity: DayActivity['intensity']) => {
    switch (intensity) {
      case 'heavy':
        return 'bg-emerald-600 border-emerald-700 hover:bg-emerald-500';
      case 'moderate':
        return 'bg-emerald-400 border-emerald-500 hover:bg-emerald-300';
      case 'light':
        return 'bg-emerald-200 border-emerald-300 hover:bg-emerald-100';
      case 'rest':
      default:
        return 'bg-slate-100 border-slate-200 hover:bg-slate-200';
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10.5px] font-black uppercase tracking-wider">
              Konsistensi & Heatmap Kalender
            </span>
            <span className="text-xs text-slate-400 font-bold">Activity Density Index</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Heatmap Aktivitas & Komparasi Periode Bulanan
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
            Visualisasi keteraturan latihan harian. Warna hijau pekat merefleksikan sesi latihan volume berat/intensitas tinggi.
          </p>
        </div>

        {/* Month Selector */}
        <div className="flex items-center gap-2 bg-slate-50 p-1.5 rounded-2xl border border-slate-200">
          <button className="p-1.5 rounded-xl hover:bg-white text-slate-600 transition-all cursor-pointer">
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-black text-slate-900 px-2">{selectedMonth}</span>
          <button className="p-1.5 rounded-xl hover:bg-white text-slate-600 transition-all cursor-pointer">
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Heatmap Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
          <span>Sen</span>
          <span>Sel</span>
          <span>Rab</span>
          <span>Kam</span>
          <span>Jum</span>
          <span>Sab</span>
          <span>Min</span>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {daysInMonth.map((day, idx) => (
            <div
              key={idx}
              onMouseEnter={() => setHoveredDay(day)}
              className={`aspect-square rounded-2xl border transition-all cursor-pointer flex flex-col items-center justify-center relative group ${getIntensityColor(
                day.intensity
              )}`}
            >
              <span
                className={`text-xs font-black font-mono ${
                  day.intensity === 'heavy'
                    ? 'text-white'
                    : day.intensity === 'moderate'
                    ? 'text-slate-900'
                    : 'text-slate-700'
                }`}
              >
                {idx + 1}
              </span>
            </div>
          ))}
        </div>

        {/* Heatmap Legend */}
        <div className="flex flex-wrap items-center justify-between pt-2 text-xs text-slate-500 gap-2">
          <div className="flex items-center gap-2">
            <span>Intensitas:</span>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 rounded-md bg-slate-100 border border-slate-200" title="Istirahat" />
              <span className="text-[11px]">Istirahat</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 rounded-md bg-emerald-200 border border-emerald-300" title="Ringan" />
              <span className="text-[11px]">Ringan</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 rounded-md bg-emerald-400 border border-emerald-500" title="Sedang" />
              <span className="text-[11px]">Sedang</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 rounded-md bg-emerald-600 border border-emerald-700" title="Berat" />
              <span className="text-[11px]">Berat / PR</span>
            </div>
          </div>

          <span className="text-[11px] font-bold text-slate-700">26 Hari Aktif / 31 Hari (83.8% Kepatuhan)</span>
        </div>
      </div>

      {/* Compare Months Delta Card */}
      <div className="p-5 rounded-3xl bg-slate-50 border border-slate-200 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black text-slate-900 uppercase tracking-wider">
            Komparasi Performa: Agustus 2026 vs Juli 2026
          </span>
          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
            +18.4% Kemajuan Menyeluruh
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1">
            <span className="text-slate-400 font-bold block">Tonase Angkat Beban:</span>
            <div className="text-lg font-black text-slate-900 font-mono">58,400 kg</div>
            <span className="text-emerald-700 font-black text-[11px] block">+12.5% vs Juli (51,900 kg)</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1">
            <span className="text-slate-400 font-bold block">Total Jarak Kardio:</span>
            <div className="text-lg font-black text-slate-900 font-mono">194.2 km</div>
            <span className="text-emerald-700 font-black text-[11px] block">+22.1% vs Juli (159.0 km)</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-white border border-slate-200 space-y-1">
            <span className="text-slate-400 font-bold block">Resting Heart Rate:</span>
            <div className="text-lg font-black text-rose-600 font-mono">54 BPM</div>
            <span className="text-emerald-700 font-black text-[11px] block">-3 BPM (Makin Bugar)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
