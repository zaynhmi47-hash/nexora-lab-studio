import React, { useState } from 'react';
import {
  Dumbbell,
  Flame,
  Activity,
  Zap,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Plus,
  TrendingUp,
  Award,
  Clock,
  MapPin,
  Sparkles,
  CheckCircle2,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import {
  SportDisciplineType,
  StrengthPerformanceLog,
  CardioPerformanceLog,
  HiitPerformanceLog,
  CourtSportPerformanceLog,
} from '../../../types';
import {
  SAMPLE_STRENGTH_LOGS,
  SAMPLE_CARDIO_LOGS,
  SAMPLE_HIIT_LOGS,
  SAMPLE_COURT_LOGS,
} from '../data/performanceData';

interface MultiDisciplineCockpitProps {
  onStartLiveSession?: (discipline: SportDisciplineType) => void;
}

export const MultiDisciplineCockpit: React.FC<MultiDisciplineCockpitProps> = ({
  onStartLiveSession,
}) => {
  const [activeDiscipline, setActiveDiscipline] = useState<SportDisciplineType>('strength');
  const [audioFeedbackActive, setAudioFeedbackActive] = useState<boolean>(true);
  const [liveAudioMessage, setLiveAudioMessage] = useState<string>(
    'Pace stabil di 5:40 min/km. Detak jantung di Zona 2 (142 BPM). Efisiensi energi sangat optimal!'
  );

  const speakAudioCue = (text: string) => {
    setLiveAudioMessage(text);
    if (audioFeedbackActive && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'id-ID';
      utterance.rate = 1.05;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
      {/* Header & Mode Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10.5px] font-black uppercase tracking-wider">
              Multi-Discipline Cockpit Hub
            </span>
            <span className="text-xs text-slate-400 font-bold">Comprehensive Performance Engine</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Dashboard Kokpit Multi-Disiplin Olahraga
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
            Pilih disiplin olahraga untuk meninjau metrik biomekanika, densitas beban, output watt, dan pelacakan kelincahan secara spesifik.
          </p>
        </div>

        {/* Audio Cue Toggle */}
        <button
          onClick={() => {
            const next = !audioFeedbackActive;
            setAudioFeedbackActive(next);
            if (next) speakAudioCue('Audio coaching aktif.');
          }}
          className={`px-3.5 py-2 rounded-2xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer border ${
            audioFeedbackActive
              ? 'bg-amber-50 text-amber-900 border-amber-200'
              : 'bg-slate-100 text-slate-500 border-slate-200'
          }`}
        >
          {audioFeedbackActive ? (
            <Volume2 className="w-4 h-4 text-amber-600 animate-pulse" />
          ) : (
            <VolumeX className="w-4 h-4 text-slate-400" />
          )}
          <span>{audioFeedbackActive ? 'Audio Coach: ON' : 'Audio Coach: Muted'}</span>
        </button>
      </div>

      {/* Discipline Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <button
          onClick={() => {
            setActiveDiscipline('strength');
            speakAudioCue('Disiplin Angkat Beban aktif. Melacak 1RM dan total tonase volume.');
          }}
          className={`p-3.5 rounded-2xl border transition-all text-left flex items-center gap-3 cursor-pointer ${
            activeDiscipline === 'strength'
              ? 'bg-slate-900 text-white border-slate-900 shadow-md'
              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
          }`}
        >
          <div className={`p-2 rounded-xl ${activeDiscipline === 'strength' ? 'bg-amber-500 text-slate-950' : 'bg-white text-slate-700 border border-slate-200'}`}>
            <Dumbbell className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-black">Strength Training</div>
            <div className="text-[10px] opacity-70">1RM, Volume, RPE</div>
          </div>
        </button>

        <button
          onClick={() => {
            setActiveDiscipline('cardio');
            speakAudioCue('Disiplin Kardio aktif. Memantau pace lari, cadence, dan zona jantung.');
          }}
          className={`p-3.5 rounded-2xl border transition-all text-left flex items-center gap-3 cursor-pointer ${
            activeDiscipline === 'cardio'
              ? 'bg-slate-900 text-white border-slate-900 shadow-md'
              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
          }`}
        >
          <div className={`p-2 rounded-xl ${activeDiscipline === 'cardio' ? 'bg-rose-500 text-white' : 'bg-white text-slate-700 border border-slate-200'}`}>
            <Flame className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-black">Running & Cycling</div>
            <div className="text-[10px] opacity-70">Pace, Cadence, HR</div>
          </div>
        </button>

        <button
          onClick={() => {
            setActiveDiscipline('hiit_calisthenics');
            speakAudioCue('Disiplin HIIT & Kalistenik aktif. Mengukur konsistensi putaran dan interval istirahat.');
          }}
          className={`p-3.5 rounded-2xl border transition-all text-left flex items-center gap-3 cursor-pointer ${
            activeDiscipline === 'hiit_calisthenics'
              ? 'bg-slate-900 text-white border-slate-900 shadow-md'
              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
          }`}
        >
          <div className={`p-2 rounded-xl ${activeDiscipline === 'hiit_calisthenics' ? 'bg-indigo-500 text-white' : 'bg-white text-slate-700 border border-slate-200'}`}>
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-black">HIIT & Calisthenics</div>
            <div className="text-[10px] opacity-70">Rounds, Rest, Reps</div>
          </div>
        </button>

        <button
          onClick={() => {
            setActiveDiscipline('court_field_sport');
            speakAudioCue('Disiplin Sport Tim aktif. Melacak sprint GPS, kelincahan, dan jarak tempuh.');
          }}
          className={`p-3.5 rounded-2xl border transition-all text-left flex items-center gap-3 cursor-pointer ${
            activeDiscipline === 'court_field_sport'
              ? 'bg-slate-900 text-white border-slate-900 shadow-md'
              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
          }`}
        >
          <div className={`p-2 rounded-xl ${activeDiscipline === 'court_field_sport' ? 'bg-emerald-500 text-white' : 'bg-white text-slate-700 border border-slate-200'}`}>
            <Activity className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-black">Court & Field Sport</div>
            <div className="text-[10px] opacity-70">Sprint, Agility, Speed</div>
          </div>
        </button>
      </div>

      {/* Real-time Audio Feedback Banner */}
      <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 text-amber-950 font-bold">
          <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping shrink-0" />
          <span>Feedback Audio Real-Time:</span>
          <span className="font-normal text-amber-900">&quot;{liveAudioMessage}&quot;</span>
        </div>
        <button
          onClick={() => speakAudioCue('Detak jantung Anda masuk Zona 4 (165 BPM). Kurangi kecepatan jika tujuan adalah pembakaran lemak aerobik.')}
          className="px-3 py-1 bg-amber-200 hover:bg-amber-300 text-amber-900 text-[11px] font-black rounded-lg transition-all cursor-pointer shrink-0"
        >
          Uji Suara
        </button>
      </div>

      {/* DISCIPLINE CONTENT SECTION */}

      {/* 1. STRENGTH DISCIPLINE */}
      {activeDiscipline === 'strength' && (
        <div className="space-y-4 animate-in fade-in">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SAMPLE_STRENGTH_LOGS.map((log) => (
              <div
                key={log.id}
                className="p-5 rounded-3xl border border-slate-200 bg-slate-50/70 hover:bg-white hover:border-amber-300 hover:shadow-md transition-all space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="font-black text-slate-900 text-sm">{log.exerciseName}</div>
                  <span className="text-[11px] text-slate-400 font-medium">{log.date}</span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2.5 rounded-2xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block font-bold">Beban Kerja</span>
                    <span className="font-black text-slate-900 font-mono text-sm">{log.weightKg} kg</span>
                    <span className="text-[10px] text-slate-500 block">{log.sets} set x {log.reps} reps</span>
                  </div>
                  <div className="p-2.5 rounded-2xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block font-bold">Estimasi 1RM</span>
                    <span className="font-black text-amber-800 font-mono text-sm">{log.estimated1RmEpleyKg.toFixed(1)} kg</span>
                    <span className="text-[10px] text-emerald-600 font-bold block">RPE {log.rpe}</span>
                  </div>
                  <div className="p-2.5 rounded-2xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block font-bold">Total Volume</span>
                    <span className="font-black text-slate-900 font-mono text-sm">{log.totalVolumeKg} kg</span>
                    <span className="text-[10px] text-slate-500 block">{log.barbellVelocityMs} m/s</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-600 bg-white p-2.5 rounded-xl border border-slate-100">
                  <strong>Catatan: </strong>{log.notes}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. CARDIO DISCIPLINE */}
      {activeDiscipline === 'cardio' && (
        <div className="space-y-4 animate-in fade-in">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SAMPLE_CARDIO_LOGS.map((log) => (
              <div
                key={log.id}
                className="p-5 rounded-3xl border border-slate-200 bg-slate-50/70 hover:bg-white hover:border-rose-300 hover:shadow-md transition-all space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-black text-slate-900 text-sm">{log.title}</div>
                    <span className="text-[11px] text-slate-400 font-medium">{log.date} • {log.weatherCondition}</span>
                  </div>
                  {log.isPersonalRecord && (
                    <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 text-[10px] font-black">
                      NEW PR
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-2 rounded-xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block">Jarak</span>
                    <span className="font-black text-slate-900 font-mono text-sm">{log.distanceKm} km</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block">Pace Rata</span>
                    <span className="font-black text-slate-900 font-mono text-xs">{log.avgPaceMinPerKm}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block">Avg HR</span>
                    <span className="font-black text-rose-600 font-mono text-sm">{log.avgHeartRateBpm}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block">Cadence</span>
                    <span className="font-black text-indigo-600 font-mono text-sm">{log.cadenceSpm}</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-600 bg-white p-2.5 rounded-xl border border-slate-100">
                  <strong>Catatan: </strong>{log.notes} ({log.shoesGearUsed})
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. HIIT & CALISTHENICS */}
      {activeDiscipline === 'hiit_calisthenics' && (
        <div className="space-y-4 animate-in fade-in">
          {SAMPLE_HIIT_LOGS.map((log) => (
            <div
              key={log.id}
              className="p-5 rounded-3xl border border-slate-200 bg-slate-50/70 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-black text-slate-900 text-base">{log.routineName}</h4>
                  <span className="text-xs text-slate-400 font-medium">{log.date} • {log.workIntervalSec}s Kerja / {log.restIntervalSec}s Istirahat</span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-slate-400 block">Konsistensi Intensitas:</span>
                  <span className="text-lg font-black text-indigo-600 font-mono">{log.intensityConsistencyPercent}%</span>
                </div>
              </div>

              {/* Reps Breakdown */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                {log.calisthenicsRepCounts.map((ex, i) => (
                  <div key={i} className="p-3 rounded-2xl bg-white border border-slate-200 space-y-1">
                    <span className="text-[11px] font-bold text-slate-700 block truncate">{ex.exerciseName}</span>
                    <div className="text-lg font-black text-slate-900 font-mono">
                      {ex.reps > 0 ? `${ex.reps} Reps` : `${ex.maxHoldSec}s Hold`}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 4. COURT & FIELD SPORT */}
      {activeDiscipline === 'court_field_sport' && (
        <div className="space-y-4 animate-in fade-in">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SAMPLE_COURT_LOGS.map((log) => (
              <div
                key={log.id}
                className="p-5 rounded-3xl border border-slate-200 bg-slate-50/70 hover:bg-white hover:border-emerald-300 hover:shadow-md transition-all space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-black text-slate-900 text-sm">{log.matchName}</div>
                    <span className="text-[11px] text-slate-400 font-medium">{log.date} • Durasi {log.durationMin} Menit</span>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase">
                    {log.matchOutcome}
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-2 rounded-xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block">Jarak Tempuh</span>
                    <span className="font-black text-slate-900 font-mono text-sm">{log.totalDistanceCoveredKm} km</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block">Sprint Peaks</span>
                    <span className="font-black text-emerald-700 font-mono text-sm">{log.sprintBurstCount}x</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block">Top Speed</span>
                    <span className="font-black text-slate-900 font-mono text-sm">{log.topSprintSpeedKmh} km/h</span>
                  </div>
                  <div className="p-2 rounded-xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-400 block">Agility Turns</span>
                    <span className="font-black text-indigo-700 font-mono text-sm">{log.agilityDirectionChangesCount}x</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-600 bg-white p-2.5 rounded-xl border border-slate-100">
                  <strong>Analisis GPS: </strong>{log.notes}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
