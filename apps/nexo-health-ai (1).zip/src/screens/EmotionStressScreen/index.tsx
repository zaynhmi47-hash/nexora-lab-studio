import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Compass,
  Smile,
  Meh,
  Frown,
  Flame,
  Moon,
  Coffee,
  Sparkles,
  ArrowLeft,
  Calendar,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Zap,
  Plus,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface EmotionStressScreenProps {
  userProfile: UserProfile;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const EmotionStressScreen: React.FC<EmotionStressScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [selectedMood, setSelectedMood] = useState<'great' | 'good' | 'neutral' | 'anxious' | 'exhausted'>('good');
  const [stressLevel, setStressLevel] = useState<number>(4); // 1-10
  const [selectedTriggers, setSelectedTriggers] = useState<string[]>(['work_deadline']);
  const [journalNote, setJournalNote] = useState('');

  const triggersList = [
    { id: 'work_deadline', label: isIndonesian ? 'Tenggat Pekerjaan' : 'Work Deadlines' },
    { id: 'lack_of_sleep', label: isIndonesian ? 'Kurang Tidur' : 'Sleep Debt' },
    { id: 'caffeine_spike', label: isIndonesian ? 'Kafein Berlebih' : 'High Caffeine' },
    { id: 'social_conflict', label: isIndonesian ? 'Dinamika Sosial/Keluarga' : 'Social Conflict' },
    { id: 'financial', label: isIndonesian ? 'Finansial / Rencana' : 'Financial Strain' },
    { id: 'physical_pain', label: isIndonesian ? 'Kelelahan Fisik' : 'Physical Fatigue' },
  ];

  // 7-day hourly stress heatmap sample matrix
  const daysOfWeek = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
  const timeSlots = ['08:00', '11:00', '14:00', '17:00', '20:00'];
  const sampleHeatmap = [
    [2, 3, 7, 5, 2], // Mon
    [3, 4, 8, 6, 3], // Tue (High stress at 14:00)
    [2, 2, 4, 3, 1], // Wed
    [4, 6, 9, 7, 4], // Thu (Peak deadline stress)
    [3, 3, 5, 2, 1], // Fri
    [1, 1, 2, 2, 1], // Sat
    [1, 1, 3, 4, 2], // Sun (Sunday scaries)
  ];

  const handleToggleTrigger = (id: string) => {
    setSelectedTriggers((prev) =>
      prev.includes(id) ? prev.filter((t) => t !== id) : [...prev, id]
    );
  };

  const handleSaveMoodLog = () => {
    if (onAwardXp) onAwardXp(35);
    alert(isIndonesian ? 'Log emosi harian berhasil dicatat! Analisis korelasi AI diperbarui (+35 XP).' : 'Mood & stress log saved! (+35 XP)');
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-rose-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-rose-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m12_emotion_stress')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log Emosi' : 'Log Emotion Data'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #12:</span>
            <span className="px-3 py-1 rounded-full bg-rose-100 text-rose-900 font-extrabold border border-rose-300">
              {isIndonesian ? 'Jurnal Emosi & Peta Pemicu Stres' : 'Emotion Journal & Stress Heatmap'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-rose-600 via-pink-700 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-rose-100 text-xs font-black">
              <Compass className="w-3.5 h-3.5 text-rose-300" />
              <span>{isIndonesian ? 'Pemetaan Pola Afektif & Heatmap Stres' : 'Affective Mapping & Triggers'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Jurnal Emosi & Peta Pemicu Stres' : 'Emotion Journal & Stress Heatmap'}
            </h1>
            <p className="text-xs sm:text-sm text-rose-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Identifikasi korelasi tersembunyi antara jam kerja, hutang tidur, dan lonjakan kortisol melalui heatmap afektif 7 hari.'
                : 'Uncover hidden correlations between schedule density, sleep debt, and stress spikes via a 7-day affective heatmap.'}
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-5 text-center min-w-[200px] shrink-0">
            <span className="text-[11px] text-rose-200 uppercase font-black tracking-wider block">
              {isIndonesian ? 'Indeks Stres Hari Ini' : 'Current Stress Index'}
            </span>
            <div className="text-3xl font-black text-white mt-1 font-mono">
              {stressLevel} <span className="text-xs font-bold text-rose-200">/ 10</span>
            </div>
            <span className="text-[10px] text-rose-200 mt-1 block font-bold">
              {stressLevel <= 3 ? 'Tenang / Terkendali' : stressLevel <= 6 ? 'Waspada Moderat' : 'Tingkat Beban Tinggi'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Mood Logger + Stress Heatmap Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Interactive Emotion & Stress Logger */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-6 shadow-sm">
          <h2 className="text-lg font-black text-slate-900 tracking-tight">
            {isIndonesian ? 'Catat Suasana Hati Saat Ini' : 'Log Current Emotional State'}
          </h2>

          {/* Mood Icons Selection */}
          <div className="grid grid-cols-5 gap-2">
            {[
              { id: 'great', label: 'Luar Biasa', icon: Smile, color: 'text-emerald-600 bg-emerald-50' },
              { id: 'good', label: 'Baik', icon: Smile, color: 'text-teal-600 bg-teal-50' },
              { id: 'neutral', label: 'Biasa', icon: Meh, color: 'text-slate-600 bg-slate-100' },
              { id: 'anxious', label: 'Cemas', icon: Frown, color: 'text-amber-600 bg-amber-50' },
              { id: 'exhausted', label: 'Lelah', icon: Frown, color: 'text-rose-600 bg-rose-50' },
            ].map((m) => {
              const Icon = m.icon;
              return (
                <button
                  key={m.id}
                  onClick={() => setSelectedMood(m.id as any)}
                  className={`p-3 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    selectedMood === m.id
                      ? 'ring-2 ring-rose-500 shadow-md bg-rose-50'
                      : 'hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  <Icon className="w-5 h-5 text-slate-700" />
                  <span className="text-[10px] font-bold text-slate-700">{m.label}</span>
                </button>
              );
            })}
          </div>

          {/* Stress Level Slider */}
          <div className="space-y-2 pt-2">
            <div className="flex justify-between text-xs font-bold text-slate-700">
              <span>{isIndonesian ? 'Skala Intensitas Beban Mental' : 'Stress Level (1-10)'}</span>
              <span className="text-rose-700 font-black">{stressLevel}/10</span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={stressLevel}
              onChange={(e) => setStressLevel(Number(e.target.value))}
              className="w-full accent-rose-600 cursor-pointer"
            />
          </div>

          {/* Triggers Tags Selection */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-700 block">
              {isIndonesian ? 'Faktor Pemicu (Pilih yang relevan):' : 'Active Trigger Factors:'}
            </span>
            <div className="flex flex-wrap gap-2">
              {triggersList.map((trig) => (
                <button
                  key={trig.id}
                  onClick={() => handleToggleTrigger(trig.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                    selectedTriggers.includes(trig.id)
                      ? 'bg-rose-600 text-white font-black shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 border border-slate-200'
                  }`}
                >
                  {trig.label}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <textarea
              rows={2}
              placeholder={isIndonesian ? 'Tuliskan catatan singkat tentang peristiwa hari ini...' : 'Brief note about what triggered this feeling...'}
              value={journalNote}
              onChange={(e) => setJournalNote(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 text-xs text-slate-800 focus:outline-rose-500"
            />
          </div>

          <button
            onClick={handleSaveMoodLog}
            className="w-full py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition-all cursor-pointer shadow-md"
          >
            {isIndonesian ? 'Simpan Jurnal Emosi (+35 XP)' : 'Save Emotion Log'}
          </button>
        </div>

        {/* Right: 7-Day Stress Heatmap Matrix & AI Correlation Insight */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h2 className="text-lg font-black text-slate-900 tracking-tight">
              {isIndonesian ? 'Heatmap Pemicu Stres Mingguan' : 'Weekly Stress Heatmap'}
            </h2>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-rose-100 text-rose-800">
              AI Trend
            </span>
          </div>

          {/* Heatmap Grid */}
          <div className="space-y-2">
            <div className="grid grid-cols-6 text-center text-[10px] font-bold text-slate-400 pb-1">
              <span>Hari</span>
              {timeSlots.map((ts, i) => (
                <span key={i}>{ts}</span>
              ))}
            </div>

            {daysOfWeek.map((day, dIdx) => (
              <div key={day} className="grid grid-cols-6 items-center gap-1.5 text-xs">
                <span className="font-bold text-slate-600 text-center">{day}</span>
                {sampleHeatmap[dIdx].map((val, tIdx) => {
                  const bgClass =
                    val <= 2
                      ? 'bg-emerald-100 text-emerald-800'
                      : val <= 4
                      ? 'bg-amber-100 text-amber-800'
                      : val <= 7
                      ? 'bg-rose-200 text-rose-900 font-bold'
                      : 'bg-rose-600 text-white font-black';

                  return (
                    <div
                      key={tIdx}
                      className={`h-7 rounded-lg flex items-center justify-center text-[11px] font-mono transition-transform hover:scale-110 cursor-pointer shadow-2xs ${bgClass}`}
                      title={`${day} @ ${timeSlots[tIdx]}: Skor Stres ${val}/10`}
                    >
                      {val}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          {/* AI Pattern Finding Box */}
          <div className="p-4 rounded-2xl bg-rose-50/70 border border-rose-200 space-y-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-rose-600" />
              <span className="text-xs font-black text-rose-950">
                {isIndonesian ? 'Temuan Pola Gemini AI' : 'Gemini AI Pattern Discovery'}
              </span>
            </div>
            <p className="text-xs text-rose-900 leading-relaxed font-medium">
              {isIndonesian
                ? 'Lonjakan stres tertinggi teratur terjadi setiap hari Kamis pukul 14:00 (rata-rata 9/10). Korelasi menunjukkan jadwal rapat padat bersamaan dengan durasi tidur malam kurang dari 6 jam.'
                : 'Highest stress spikes consistently occur on Thursdays around 14:00 (avg 9/10), correlating with dense afternoon sprint syncs combined with sub-6h sleep nights.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
