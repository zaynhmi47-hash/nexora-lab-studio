import React, { useState, useEffect } from 'react';
import { Database, Shield, Lock, Trash2, Layers, AlertTriangle, CheckCircle2, Server, Cpu, ArrowLeft, RefreshCw, Download } from 'lucide-react';
import { FirestoreSchemaNode, UserProfile, DailyLog, MealItem, ModularHealthDataEntry } from '../../types';
import { INITIAL_FIRESTORE_TREE } from '../../data/sampleData';
import { auth, db } from '../../lib/firebase';
import { FirestoreDataService } from '../../services/firestoreService';

interface FirestoreSchemaViewProps {
  onClearAllUserData: () => void;
  onNavigateTab?: (tab: string) => void;
  userProfile?: UserProfile;
  dailyLog?: DailyLog;
  loggedMeals?: MealItem[];
  modularLogs?: ModularHealthDataEntry[];
}

export const FirestoreSchemaView: React.FC<FirestoreSchemaViewProps> = ({
  onClearAllUserData,
  onNavigateTab,
  userProfile,
  dailyLog,
  loggedMeals = [],
  modularLogs = [],
}) => {
  const [activeTab, setActiveTab] = useState<'live' | 'tree' | 'rules' | 'privacy'>('live');
  const [treeData] = useState<FirestoreSchemaNode[]>(INITIAL_FIRESTORE_TREE);
  const [dataDeleted, setDataDeleted] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const currentUser = auth.currentUser;

  const handleDeleteData = async () => {
    if (confirm('Apakah Anda yakin ingin menghapus permanen semua data & dummy data dari Firestore dan memulainya dari lembar bersih?')) {
      await onClearAllUserData();
      setDataDeleted(true);
      setTimeout(() => setDataDeleted(false), 4000);
    }
  };

  const handleExportJson = () => {
    const exportData = {
      userProfile,
      dailyLog,
      loggedMeals,
      modularLogs,
      exportedAt: new Date().toISOString(),
      firebaseProjectId: 'ai-studio-nexohealthai-a8872dd1-6a4f-471b-aa76-7c1d633aeafd',
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexohealth_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-emerald-500 selection:text-white">
      {/* TOP NAVIGATION BREADCRUMB & BACK BUTTON */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('landing') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali ke Beranda / Google Health Hub</span>
        </button>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <span className="hidden sm:inline">Konektivitas Cloud:</span>
          <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 font-extrabold border border-emerald-200 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Firestore Aktif & Tersinkron</span>
          </span>
        </div>
      </div>

      {/* Header Banner */}
      <div className="bg-white border border-emerald-100 rounded-[32px] p-6 sm:p-8 shadow-sm space-y-4 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 z-10 relative">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-emerald-600 text-white rounded-2xl shadow-xs">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
                <span>Pusat Data Cloud Firestore & Privasi</span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
                Penyimpanan data riil terdesentralisasi, aturan keamanan terenkripsi, dan kepatuhan GDPR.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
            <button
              onClick={() => setActiveTab('live')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'live' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Data Aktif Riil
            </button>
            <button
              onClick={() => setActiveTab('tree')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'tree' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Skema NoSQL Tree
            </button>
            <button
              onClick={() => setActiveTab('rules')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'rules' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Security Rules
            </button>
            <button
              onClick={() => setActiveTab('privacy')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'privacy' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Privasi & Reset Data
            </button>
          </div>
        </div>
      </div>

      {/* Tab 0: Live Real-Time Data Overview */}
      {activeTab === 'live' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200/90 rounded-[24px] p-5 shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
                <span>Status Otentikasi</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-sm font-extrabold text-slate-900 truncate">
                {currentUser ? currentUser.email || currentUser.displayName || 'Akun Terhubung' : 'Mode Tamu (Lokal & Cloud)'}
              </p>
              <p className="text-[11px] text-slate-400 font-mono truncate">UID: {currentUser?.uid || 'guest_user_local'}</p>
            </div>

            <div className="bg-white border border-slate-200/90 rounded-[24px] p-5 shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
                <span>Log 20 Modul Riil</span>
                <Layers className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-2xl font-black text-slate-900">{modularLogs.length} <span className="text-xs font-semibold text-slate-500">entri</span></p>
              <p className="text-[11px] text-emerald-700 font-medium">Tersimpan di `users/{'{uid}'}/modular_logs`</p>
            </div>

            <div className="bg-white border border-slate-200/90 rounded-[24px] p-5 shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
                <span>Jurnal Makanan</span>
                <Server className="w-4 h-4 text-amber-600" />
              </div>
              <p className="text-2xl font-black text-slate-900">{loggedMeals.length} <span className="text-xs font-semibold text-slate-500">menu</span></p>
              <p className="text-[11px] text-amber-700 font-medium">Tersimpan di `users/{'{uid}'}/meals`</p>
            </div>

            <div className="bg-white border border-slate-200/90 rounded-[24px] p-5 shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
                <span>Metrik Hari Ini</span>
                <Cpu className="w-4 h-4 text-cyan-600" />
              </div>
              <p className="text-2xl font-black text-slate-900">{dailyLog?.waterIntakeMl || 0} <span className="text-xs font-semibold text-slate-500">ml air</span></p>
              <p className="text-[11px] text-cyan-700 font-medium">{dailyLog?.caloriesConsumed || 0} kcal kalori tercatat</p>
            </div>
          </div>

          <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 space-y-4 shadow-2xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-slate-900 text-base">Manajemen Data Riil & Ekspor Cadangan</h3>
                <p className="text-xs text-slate-500">Unduh data kesehatan Anda atau reset data dummy kapan saja.</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportJson}
                  className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-all shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Ekspor JSON</span>
                </button>
                <button
                  onClick={handleDeleteData}
                  className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-800 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-all shadow-2xs"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Bersihkan Semua Data</span>
                </button>
              </div>
            </div>

            {dataDeleted && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-bold">
                ✓ Data berhasil dibersihkan! Mulai mencatat dengan data Anda yang asli.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 1: Interactive JSON Tree Inspector */}
      {activeTab === 'tree' && (
        <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 sm:p-8 space-y-4 shadow-2xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <h3 className="font-bold text-slate-900 text-base sm:text-lg flex items-center gap-2">
              <Layers className="w-5 h-5 text-emerald-700" />
              <span>Koleksi Cloud Firestore (JSON Tree)</span>
            </h3>
            <span className="text-xs bg-emerald-50 text-emerald-800 px-3 py-1 rounded-full border border-emerald-200 font-bold">
              Sinkronisasi NoSQL Real-Time
            </span>
          </div>

          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 font-mono text-xs text-slate-800 overflow-x-auto space-y-4">
            {treeData.map((node, i) => (
              <div key={i} className="space-y-2.5">
                <div className="text-emerald-800 font-bold flex items-center gap-2">
                  <span>📂 Koleksi:</span>
                  <span className="text-emerald-600 bg-emerald-100 px-2 py-0.5 rounded-md">"{node.collection}"</span>
                </div>
                <div className="pl-4 space-y-2 border-l-2 border-emerald-200 ml-2">
                  <div className="text-slate-700 font-semibold">
                    📄 Document ID: <span className="text-slate-900 font-mono bg-white px-2 py-0.5 rounded border border-slate-200">"{node.docId}"</span>
                  </div>
                  <pre className="bg-white p-4 rounded-xl border border-slate-200 text-slate-800 overflow-x-auto text-[11px] leading-relaxed shadow-2xs">
                    {JSON.stringify(node.data, null, 2)}
                  </pre>

                  {/* Subcollections */}
                  {node.subcollections && (
                    <div className="pl-4 space-y-2.5 border-l-2 border-emerald-300 mt-3">
                      <div className="text-slate-500 font-bold text-[11px]">Sub-koleksi (Real-time Trackers):</div>
                      {node.subcollections.map((sub, sIdx) => (
                        <div key={sIdx} className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
                          <p className="text-emerald-800 font-bold mb-1 text-xs">
                            📁 {sub.collection} / <span className="text-slate-600 font-normal">{sub.docId}</span>
                          </p>
                          <pre className="text-[10px] text-slate-700 font-mono overflow-x-auto">
                            {JSON.stringify(sub.data, null, 2)}
                          </pre>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Security Rules Auditor */}
      {activeTab === 'rules' && (
        <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 sm:p-8 space-y-4 shadow-2xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <h3 className="font-bold text-slate-900 text-base sm:text-lg flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-700" />
              <span>Aturan Keamanan Firestore (firestore.rules)</span>
            </h3>
            <span className="text-xs bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold px-3 py-1 rounded-full">
              ✓ Isolasi Otentikasi Ketat
            </span>
          </div>

          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 font-mono text-xs text-emerald-300 overflow-x-auto space-y-2 shadow-inner">
            <p className="text-slate-400">// Firestore Rules: Mencegah kebocoran data antar-pengguna</p>
            <pre className="leading-relaxed">
{`rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // User Data Isolation
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      
      // Health Logs, Meals, Workouts, & Habits
      match /{allPaths=**} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}`}
            </pre>
          </div>

          <div className="bg-emerald-50/70 p-5 rounded-2xl border border-emerald-100 space-y-2 text-xs">
            <p className="font-bold text-emerald-900 flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-emerald-700" />
              <span>Prinsip Keamanan Nexo Health:</span>
            </p>
            <ul className="list-disc list-inside text-slate-700 space-y-1 pl-1 font-medium">
              <li>Pengguna hanya dapat membaca dan memodifikasi data yang sesuai dengan UID otentikasi mereka.</li>
              <li>Parameter sensitif dan kunci API diproses di rute proxy server backend secara aman.</li>
              <li>Token JWT Firebase Auth diverifikasi di setiap operasi baca/tulis.</li>
            </ul>
          </div>
        </div>
      )}

      {/* Tab 3: Privacy, Medical Disclaimer & GDPR Delete Data */}
      {activeTab === 'privacy' && (
        <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 sm:p-8 space-y-6 shadow-2xs">
          {/* Medical Disclaimer Callout */}
          <div className="bg-amber-50/80 border border-amber-200 p-5 rounded-2xl space-y-2">
            <h4 className="font-bold text-amber-900 text-sm flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              <span>Disklaimer Medis Resmi</span>
            </h4>
            <p className="text-xs text-slate-700 leading-relaxed font-medium">
              Nexo Health AI adalah asisten cerdas gaya hidup sehat yang dirancang untuk pelacakan aktivitas, pembuatan rekomendasi latihan, dan estimasi nutrisi makanan. <strong>Aplikasi ini bukan pengganti diagnosis medis dokter atau tenaga kesehatan berlisensi.</strong> Selalu konsultasikan dengan dokter untuk keputusan medis serius.
            </p>
          </div>

          {/* GDPR Right to Erasure / Delete My Data */}
          <div className="bg-slate-50 border border-slate-200 p-5 rounded-2xl space-y-4">
            <div>
              <h4 className="font-bold text-slate-900 text-base">Hak Privasi Pengguna & GDPR</h4>
              <p className="text-xs text-slate-500 mt-0.5">
                Anda dapat menghapus permanen seluruh riwayat kesehatan, log nutrisi, dan data pribadi Anda dari database kami kapan saja.
              </p>
            </div>

            {dataDeleted ? (
              <div className="bg-rose-50 border border-rose-200 text-rose-800 p-3.5 rounded-xl text-xs font-bold text-center">
                Semua catatan data pengguna telah dihapus secara permanen dari Firestore.
              </div>
            ) : (
              <button
                onClick={handleDeleteData}
                className="py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition-all shadow-xs flex items-center gap-2 cursor-pointer active:scale-98"
              >
                <Trash2 className="w-4 h-4" />
                <span>Hapus Semua Data Saya (GDPR Delete)</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
