import React, { useState } from 'react';
import {
  Droplets,
  Flame,
  Footprints,
  Moon,
  Plus,
  Scale,
  Sparkles,
  TrendingDown,
  Utensils,
  RefreshCw,
  Zap,
  ChevronRight,
  Award,
  Dumbbell,
  Activity,
  Heart,
  ShieldCheck,
  CheckCircle2,
  TrendingUp,
  Brain,
  Lightbulb,
  Loader2,
  Menu,
  Trophy,
  Target,
  ArrowRight,
  ArrowLeft,
  Clock,
  Coffee,
  Stethoscope,
  Play,
} from 'lucide-react';
import { UserProfile, DailyLog, MealItem } from '../../types';
import { getTranslation } from '../../data/translations';
import { CardCarousel } from '../../components/common/CardCarousel';
import { AiHealthCompanionModal } from '../../components/modules/AiHealthCompanionModal';
import { SleepAnalysisStudio } from '../../components/modules/SleepAnalysisStudio';
import { LiveWorkoutPoseGuard } from '../../components/modules/LiveWorkoutPoseGuard';
import { HealthConnectIntegrationCard } from '../../components/modules/HealthConnectIntegrationCard';
import { AiHealthAnalystSection } from '../../components/dashboard/AiHealthAnalystSection';
import { ModularHealthDataEntry } from '../../types';

interface DailyInsight {
  headline: string;
  healthScore: number;
  insightTip: string;
  actionSteps: string[];
  macroAnalysis: string;
}

interface DashboardViewProps {
  userProfile: UserProfile;
  dailyLog: DailyLog;
  loggedMeals: MealItem[];
  modularLogs?: ModularHealthDataEntry[];
  onAddWater: (amountMl: number) => void;
  onLogMeal: (meal: MealItem) => void;
  onUpdateWeight: (weightKg: number) => void;
  onNavigateToNutrition: () => void;
  onNavigateTab?: (tab: string) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  userProfile,
  dailyLog,
  loggedMeals,
  modularLogs = [],
  onAddWater,
  onLogMeal,
  onUpdateWeight,
  onNavigateToNutrition,
  onNavigateTab,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';
  const [showMealModal, setShowMealModal] = useState(false);
  const [showWeightModal, setShowWeightModal] = useState(false);
  const [showWellnessDetails, setShowWellnessDetails] = useState(false);

  // New UI/UX Modals
  const [isAiCompanionOpen, setIsAiCompanionOpen] = useState(false);
  const [isSleepStudioOpen, setIsSleepStudioOpen] = useState(false);
  const [isLiveWorkoutOpen, setIsLiveWorkoutOpen] = useState(false);

  // Daily AI Insight state
  const [insightData, setInsightData] = useState<DailyInsight | null>(null);
  const [isLoadingInsight, setIsLoadingInsight] = useState(false);
  const [showInsightCard, setShowInsightCard] = useState(false);

  // Quick Meal Form State
  const [customMealName, setCustomMealName] = useState('');
  const [customCalories, setCustomCalories] = useState('350');
  const [customCarbs, setCustomCarbs] = useState('40');
  const [customProtein, setCustomProtein] = useState('25');
  const [customFat, setCustomFat] = useState('10');

  // Quick Weight Form State
  const [newWeight, setNewWeight] = useState(dailyLog.weightKg.toString());

  const waterPercent = Math.min(100, Math.round((dailyLog.waterIntakeMl / userProfile.dailyWaterTargetMl) * 100));
  const calPercent = Math.min(100, Math.round((dailyLog.caloriesConsumed / userProfile.dailyCalorieTarget) * 100));
  const carbsPercent = Math.min(100, Math.round((dailyLog.carbsG / userProfile.dailyCarbsTargetG) * 100));
  const proteinPercent = Math.min(100, Math.round((dailyLog.proteinG / userProfile.dailyProteinTargetG) * 100));
  const fatPercent = Math.min(100, Math.round((dailyLog.fatG / userProfile.dailyFatTargetG) * 100));

  // Calculate SehatAI Wellness Index (0-100)
  const hydrationScore = Math.min(100, Math.round((dailyLog.waterIntakeMl / userProfile.dailyWaterTargetMl) * 100));
  const sleepScore = Math.min(100, Math.round((dailyLog.sleepHours / userProfile.dailySleepTargetHours) * 100));
  const activityScore = Math.min(100, Math.round((dailyLog.stepsCount / userProfile.dailyStepsTarget) * 100));
  const calorieScore = dailyLog.caloriesConsumed > 0
    ? Math.max(30, 100 - Math.abs(100 - Math.round((dailyLog.caloriesConsumed / userProfile.dailyCalorieTarget) * 100)))
    : 65;
  const wellnessIndex = Math.min(100, Math.round((hydrationScore * 0.25) + (sleepScore * 0.25) + (activityScore * 0.25) + (calorieScore * 0.25)));

  const handleGetDailyInsight = async () => {
    setIsLoadingInsight(true);
    setShowInsightCard(true);

    try {
      const response = await fetch('/api/insight/daily', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userProfile,
          dailyLog,
          loggedMeals,
          language: userProfile.language || 'id',
        }),
      });

      const json = await response.json();
      if (json.success && json.data) {
        setInsightData(json.data);
      } else if (json.fallback) {
        setInsightData(json.fallback);
      } else {
        throw new Error(json.error || 'Failed to analyze insight');
      }
    } catch (error) {
      console.error('Error fetching daily insight:', error);
      setInsightData({
        headline: isIndonesian ? 'Progress & Insight Kesehatan Hari Ini' : 'Today\'s Health Insight & Tips',
        healthScore: wellnessIndex,
        insightTip: isIndonesian
          ? `Nutrisi (${dailyLog.caloriesConsumed} kcal) dan hidrasi (${dailyLog.waterIntakeMl} ml) Anda terpantau sangat baik. Untuk mempertahankan metabolisme prima, minumlah 1 gelas air lagi dan pertahankan keseimbangan porsi makro.`
          : `Your calories (${dailyLog.caloriesConsumed} kcal) and hydration (${dailyLog.waterIntakeMl} ml) are on track. Drink 1 more glass of water to optimize your metabolism and energy.`,
        actionSteps: isIndonesian
          ? [
              'Tambah 250ml air putih sebelum malam',
              'Selesaikan sisa target langkah harian',
              'Istirahat dan tidur 7-8 jam untuk pemulihan optimal'
            ]
          : [
              'Add 250ml extra water before night',
              'Complete your daily steps target',
              'Sleep 7-8 hours for optimal muscle recovery'
            ],
        macroAnalysis: isIndonesian
          ? 'Distribusi karbohidrat dan protein seimbang untuk mendukung aktivitas harian.'
          : 'Macro distribution is balanced to support daily activities.',
      });
    } finally {
      setIsLoadingInsight(false);
    }
  };

  const handleQuickAddMeal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customMealName) return;
    const newMeal: MealItem = {
      id: `meal_quick_${Date.now()}`,
      name: customMealName,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      category: 'snack',
      calories: parseInt(customCalories) || 0,
      carbsG: parseInt(customCarbs) || 0,
      proteinG: parseInt(customProtein) || 0,
      fatG: parseInt(customFat) || 0,
      healthRating: 8.5,
      detectedObjects: ['Custom Meal'],
      aiAdvice: isIndonesian ? 'Makanan dicatat ke database NoSQL Firestore.' : 'Meal logged to Firestore NoSQL database.',
    };
    onLogMeal(newMeal);
    setCustomMealName('');
    setShowMealModal(false);
  };

  const handleQuickWeightSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const w = parseFloat(newWeight);
    if (!isNaN(w) && w > 0) {
      onUpdateWeight(w);
      setShowWeightModal(false);
    }
  };

  // Quick Action Tool Cards for Carousel
  const quickToolCards = [
    {
      id: 'add-modular-data-entry',
      title: isIndonesian ? 'Tambah Data 20 Modul' : 'Add Modular Data (1-20)',
      desc: isIndonesian ? 'Input data terukur dari modul manapun' : 'Log measured data into any module',
      icon: Plus,
      badge: 'Data Entry',
      color: 'bg-emerald-50 text-emerald-950 border-emerald-300',
      iconBg: 'bg-emerald-700 text-white',
      btnText: isIndonesian ? 'Catat Sekarang' : 'Log Data',
      action: () => onOpenAddDataModal ? onOpenAddDataModal() : undefined,
    },
    {
      id: 'add-water-250',
      title: isIndonesian ? '+250ml Air Minum' : '+250ml Water',
      desc: isIndonesian ? 'Tambah 1 gelas air hidrasi cepat' : 'Add 1 glass hydration quickly',
      icon: Droplets,
      badge: 'Hidrasi',
      color: 'bg-cyan-50 text-cyan-800 border-cyan-200',
      iconBg: 'bg-cyan-600 text-white',
      btnText: isIndonesian ? 'Tambah Air' : 'Log Water',
      action: () => onAddWater(250),
    },
    {
      id: 'add-water-500',
      title: isIndonesian ? '+500ml Botol Air' : '+500ml Water Bottle',
      desc: isIndonesian ? 'Tambah 1 botol sedang hidrasi' : 'Add 1 water bottle hydration',
      icon: Droplets,
      badge: 'Hidrasi',
      color: 'bg-blue-50 text-blue-800 border-blue-200',
      iconBg: 'bg-blue-600 text-white',
      btnText: isIndonesian ? 'Tambah Botol' : 'Log 500ml',
      action: () => onAddWater(500),
    },
    {
      id: 'clara-ai-guide',
      title: isIndonesian ? 'Tanya Clara AI Guide' : 'Ask Clara AI Guide',
      desc: isIndonesian ? 'Dialog kesehatan & cek gejala cepat' : 'AI voice & quick symptom triage',
      icon: Sparkles,
      badge: 'Gemini 3.6',
      color: 'bg-emerald-50 text-emerald-900 border-emerald-200',
      iconBg: 'bg-emerald-600 text-white',
      btnText: isIndonesian ? 'Buka Clara' : 'Launch Clara',
      action: () => setIsAiCompanionOpen(true),
    },
    {
      id: 'sleep-studio-tool',
      title: isIndonesian ? 'Studio Tidur & REM' : 'Sleep Studio & REM',
      desc: isIndonesian ? 'Arsitektur tidur & pelacak dengkuran' : 'Sleep stages & snore tracking',
      icon: Moon,
      badge: 'Pemulihan',
      color: 'bg-indigo-50 text-indigo-900 border-indigo-200',
      iconBg: 'bg-indigo-600 text-white',
      btnText: isIndonesian ? 'Buka Studio' : 'Open Sleep',
      action: () => setIsSleepStudioOpen(true),
    },
    {
      id: 'pose-guard-live',
      title: isIndonesian ? 'Pose Guard AI' : 'Live Pose Guard',
      desc: isIndonesian ? 'Pelacak pose & landmark sendi real-time' : 'Real-time joint landmark tracking',
      icon: Play,
      badge: 'Vision AI',
      color: 'bg-teal-50 text-teal-900 border-teal-200',
      iconBg: 'bg-teal-600 text-white',
      btnText: isIndonesian ? 'Mulai Latihan' : 'Start Pose AI',
      action: () => setIsLiveWorkoutOpen(true),
    },
    {
      id: 'scan-nutrition-ai',
      title: isIndonesian ? 'Scan Foto Gizi AI' : 'Scan Food AI',
      desc: isIndonesian ? 'Foto piring makanan dengan Gemini AI' : 'Snap dish with Gemini Vision AI',
      icon: Utensils,
      badge: 'AI Vision',
      color: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      iconBg: 'bg-emerald-600 text-white',
      btnText: isIndonesian ? 'Buka Scanner' : 'Open Scanner',
      action: onNavigateToNutrition,
    },
    {
      id: 'get-daily-insight',
      title: isIndonesian ? 'Tips & Analisis AI' : 'Daily AI Insight',
      desc: isIndonesian ? 'Evaluasi nutrisi & tips dokter AI' : 'Evaluate macros & health tips',
      icon: Brain,
      badge: 'Gemini AI',
      color: 'bg-teal-50 text-teal-800 border-teal-200',
      iconBg: 'bg-teal-600 text-white',
      btnText: isIndonesian ? 'Analisis Sekarang' : 'Analyze Now',
      action: handleGetDailyInsight,
    },
    {
      id: 'update-weight-tool',
      title: isIndonesian ? 'Catat Timbangan Berat' : 'Update Weight',
      desc: isIndonesian ? 'Perbarui timbangan berat badan' : 'Log your latest morning weight',
      icon: Scale,
      badge: 'Metrik Tubuh',
      color: 'bg-slate-50 text-slate-800 border-slate-200',
      iconBg: 'bg-slate-700 text-white',
      btnText: isIndonesian ? 'Perbarui Berat' : 'Update Weight',
      action: () => setShowWeightModal(true),
    },
    {
      id: 'quick-log-meal',
      title: isIndonesian ? 'Catat Makanan Cepat' : 'Quick Log Meal',
      desc: isIndonesian ? 'Input kalori & nama makanan manual' : 'Manually record meal & calories',
      icon: Plus,
      badge: 'Jurnal Makanan',
      color: 'bg-amber-50 text-amber-800 border-amber-200',
      iconBg: 'bg-amber-600 text-white',
      btnText: isIndonesian ? 'Input Makanan' : 'Add Meal',
      action: () => setShowMealModal(true),
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-emerald-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* TOP NAVIGATION BREADCRUMB & BACK BUTTON */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('landing') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Beranda / Google Health Hub' : 'Back to Home / Google Health Hub'}</span>
        </button>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <span className="hidden sm:inline">Halaman Modul:</span>
          <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-extrabold border border-emerald-300">
            Health Connect Dasbor Terpadu
          </span>
        </div>
      </div>

      {/* HERO BENTO HEADER BANNER */}
      <div className="bg-white border border-emerald-100 rounded-[32px] p-6 sm:p-8 relative overflow-hidden shadow-sm">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 blur-[100px] rounded-full pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 z-10 relative">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-emerald-700 text-xs font-black uppercase tracking-wider flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-emerald-600" />
                <span>Nexo Health Intelligence</span>
              </span>
              <span className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold px-2.5 py-0.5 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                Cloud Sync Aktif
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black mt-2 tracking-tight text-slate-900">
              {isIndonesian ? 'Halo, ' : 'Welcome back, '}<span className="text-emerald-700">{userProfile.name}</span>
            </h2>

            <p className="text-slate-600 mt-1.5 text-xs sm:text-sm md:text-base max-w-2xl leading-relaxed font-medium">
              {isIndonesian ? (
                <>
                  Anda telah mencapai <strong className="text-emerald-700 font-black">{calPercent}%</strong> dari target kalori harian dengan tujuan <strong className="text-slate-900 capitalize font-bold">{userProfile.fitnessGoal.replace('_', ' ')}</strong>.
                </>
              ) : (
                <>
                  You've reached <strong className="text-emerald-700 font-black">{calPercent}%</strong> of your daily target for <strong className="text-slate-900 capitalize font-bold">{userProfile.fitnessGoal.replace('_', ' ')}</strong>.
                </>
              )}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 self-stretch md:self-auto">
            <button
              onClick={handleGetDailyInsight}
              disabled={isLoadingInsight}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2.5 rounded-2xl text-xs uppercase tracking-wider transition-all active:scale-95 shadow-sm flex items-center gap-2 cursor-pointer disabled:opacity-75"
            >
              {isLoadingInsight ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : (
                <Brain className="w-4 h-4 text-amber-200" />
              )}
              <span>{isLoadingInsight ? (isIndonesian ? 'Menganalisis...' : 'Analyzing...') : (isIndonesian ? 'Tips Harian AI' : 'Get Daily Insight')}</span>
            </button>

            <button
              onClick={onNavigateToNutrition}
              className="bg-teal-50 hover:bg-teal-100 border border-teal-200 text-teal-800 font-bold px-4 py-2.5 rounded-2xl text-xs uppercase tracking-wider transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-teal-600" />
              <span>Scan Foto AI</span>
            </button>
          </div>
        </div>

        {/* Metric Summary Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 items-end mt-6 pt-5 border-t border-slate-100 z-10 relative">
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
            <div className="text-xl sm:text-2xl md:text-3xl font-black text-slate-900 tracking-tight">
              {dailyLog.weightKg} <span className="text-xs text-slate-400 font-semibold">kg</span>
            </div>
            <div className="text-[11px] text-slate-500 font-bold uppercase mt-0.5">Berat Badan</div>
          </div>

          <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-100">
            <div className="text-xl sm:text-2xl md:text-3xl font-black text-emerald-800 tracking-tight">
              {dailyLog.caloriesConsumed} <span className="text-xs text-emerald-600 font-semibold">kcal</span>
            </div>
            <div className="text-[11px] text-emerald-700 font-bold uppercase mt-0.5">Kalori Tercatat</div>
          </div>

          <div className="p-3 rounded-2xl bg-cyan-50/60 border border-cyan-100">
            <div className="text-xl sm:text-2xl md:text-3xl font-black text-cyan-800 tracking-tight">
              {dailyLog.waterIntakeMl} <span className="text-xs text-cyan-600 font-semibold">ml</span>
            </div>
            <div className="text-[11px] text-cyan-700 font-bold uppercase mt-0.5">Hidrasi Air</div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col justify-center">
            <div className="flex justify-between items-center mb-1 text-xs">
              <span className="text-[10px] text-slate-500 font-bold uppercase">Target Harian</span>
              <span className="text-xs text-emerald-700 font-black">{calPercent}%</span>
            </div>
            <div className="h-2.5 w-full bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all duration-500"
                style={{ width: `${calPercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* GOOGLE HEALTH CONNECT REAL-TIME INTEGRATION CARD */}
      <section>
        <HealthConnectIntegrationCard
          userProfile={userProfile}
          dailyLog={dailyLog}
          isIndonesian={isIndonesian}
          onOpenSleepStudio={() => setIsSleepStudioOpen(true)}
          onOpenHeartDetails={() => onNavigateTab ? onNavigateTab('doctor_consultation') : undefined}
        />
      </section>

      {/* AI HEALTH ANALYST: INTEGRATED CROSS-MODULE SYNTHESIS */}
      <AiHealthAnalystSection
        userProfile={userProfile}
        modularLogs={modularLogs}
        onOpenAddDataModal={(modId) => onOpenAddDataModal ? onOpenAddDataModal(modId) : undefined}
        onNavigateToModule={onNavigateTab}
      />

      {/* QUICK ACTIONS & HEALTH TOOLS CARD CAROUSEL (CARD CORSEL) */}
      <section className="space-y-3">
        <CardCarousel
          title={isIndonesian ? 'Aksi Cepat & Alat Kesehatan' : 'Quick Actions & Health Tools'}
          subtitle={isIndonesian ? 'Akses instan untuk mencatat air, makanan, atau konsultasi AI' : 'Instant access to hydration, logging, and AI consultation'}
          badge={isIndonesian ? 'Aksi Cepat' : 'Quick Tools'}
          cardWidthClass="w-[260px] sm:w-[290px] md:w-[310px]"
        >
          {quickToolCards.map((tool) => {
            const Icon = tool.icon;
            return (
              <div
                key={tool.id}
                onClick={tool.action}
                className="h-full bg-white border border-slate-200/90 hover:border-emerald-300 rounded-[24px] p-5 space-y-3 shadow-2xs hover:shadow-md transition-all duration-200 flex flex-col justify-between cursor-pointer group"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className={`p-2.5 rounded-xl ${tool.iconBg} shadow-2xs`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${tool.color}`}>
                      {tool.badge}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                      {tool.title}
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                      {tool.desc}
                    </p>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-700 group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                    <span>{tool.btnText}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </CardCarousel>
      </section>

      {/* DYNAMIC GEMINI AI DAILY INSIGHT CARD */}
      {showInsightCard && (
        <div className="bg-gradient-to-br from-emerald-50 via-white to-teal-50 border border-emerald-200 rounded-[28px] p-6 md:p-8 shadow-sm relative overflow-hidden animate-in fade-in duration-300">
          {isLoadingInsight ? (
            <div className="py-8 text-center flex flex-col items-center justify-center space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-emerald-100 border border-emerald-200 flex items-center justify-center animate-pulse text-emerald-700">
                <Brain className="w-7 h-7 animate-bounce" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {isIndonesian ? 'Gemini AI Sedang Menganalisis Jurnal Kesehatan...' : 'Analyzing Daily Health Log with Gemini AI...'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isIndonesian ? 'Mengevaluasi kalori, makronutrisi, hidrasi, dan target aktivitas harian.' : 'Evaluating calories, macros, hydration, and active goals.'}
                </p>
              </div>
            </div>
          ) : insightData ? (
            <div className="space-y-5 relative z-10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-emerald-100 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-emerald-600 text-white rounded-2xl shadow-xs shrink-0">
                    <Brain className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black uppercase tracking-wider text-emerald-700">
                        Gemini 3.6 Health Intelligence
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-100 border border-emerald-200 text-emerald-800 text-[10px] font-black">
                        AI Verified
                      </span>
                    </div>
                    <h3 className="text-lg md:text-xl font-bold text-slate-900 mt-0.5">{insightData.headline}</h3>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-start md:self-auto">
                  <div className="px-4 py-1.5 rounded-2xl bg-white border border-emerald-200 text-center shadow-2xs">
                    <span className="block text-xl font-black text-emerald-700">{insightData.healthScore}</span>
                    <span className="block text-[9px] text-slate-400 font-bold uppercase tracking-wider">AI Score</span>
                  </div>

                  <button
                    onClick={handleGetDailyInsight}
                    className="p-2.5 rounded-xl bg-white hover:bg-emerald-50 border border-slate-200 text-slate-600 hover:text-emerald-800 transition-all cursor-pointer shadow-2xs"
                    title="Refresh AI Insight"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Tip & Action Steps */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                <div className="md:col-span-7 bg-white p-5 rounded-2xl border border-emerald-100 shadow-2xs space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-700 uppercase tracking-wider">
                    <Lightbulb className="w-4 h-4 text-amber-600" />
                    <span>{isIndonesian ? 'Rekomendasi Utama AI' : 'Core AI Recommendation'}</span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
                    {insightData.insightTip}
                  </p>
                  <div className="pt-2 text-xs text-emerald-800 font-semibold border-t border-slate-100">
                    💡 <span className="font-bold">{isIndonesian ? 'Analisis Makro:' : 'Macro Analysis:'}</span> <span className="text-slate-600 font-normal">{insightData.macroAnalysis}</span>
                  </div>
                </div>

                <div className="md:col-span-5 bg-white p-5 rounded-2xl border border-emerald-100 shadow-2xs space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 uppercase tracking-wider">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>{isIndonesian ? 'Langkah Selanjutnya' : 'Next Action Steps'}</span>
                  </div>
                  <ul className="space-y-1.5">
                    {insightData.actionSteps.map((step, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-600">
                        <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      )}

      {/* SEHATAI WELLNESS INDEX & RECOVERY PULSE */}
      <div className="bg-white border border-emerald-100 rounded-[28px] p-6 shadow-sm relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-4 sm:gap-5">
            {/* Health Score Circular Ring */}
            <div className="relative w-18 h-18 sm:w-20 sm:h-20 shrink-0 flex items-center justify-center rounded-full bg-emerald-50 border-4 border-emerald-200 shadow-inner">
              <div className="text-center">
                <span className="text-2xl font-black text-slate-900">{wellnessIndex}</span>
                <span className="block text-[9px] text-emerald-700 font-bold uppercase tracking-wider">/ 100</span>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>SehatAI Wellness Index</span>
                </span>
                <span className="text-xs text-slate-500 font-semibold">
                  {wellnessIndex >= 80 ? (isIndonesian ? 'Optimal' : 'Optimal') : wellnessIndex >= 60 ? (isIndonesian ? 'Baik' : 'Good') : (isIndonesian ? 'Perlu Ditingkatkan' : 'Needs Boost')}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                {isIndonesian ? 'Skor Kebugaran & Recovery Harian' : 'Daily Fitness & Recovery Score'}
              </h3>
              <p className="text-xs text-slate-600 max-w-xl mt-0.5 leading-relaxed">
                {isIndonesian ? (
                  <>
                    Kalori terukur <strong className="text-slate-900">{calPercent}%</strong>, dengan hidrasi{' '}
                    <strong className="text-cyan-700">{waterPercent}%</strong>. Rekomendasi: konsumsi air teratur untuk menjaga fokus & energi.
                  </>
                ) : (
                  <>
                    Calories at <strong className="text-slate-900">{calPercent}%</strong>, hydration at{' '}
                    <strong className="text-cyan-700">{waterPercent}%</strong>. Keep hydrated to maintain optimal energy.
                  </>
                )}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowWellnessDetails(!showWellnessDetails)}
            className="px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer self-stretch md:self-auto justify-center shadow-2xs"
          >
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <span>{showWellnessDetails ? (isIndonesian ? 'Tutup Detail' : 'Close Details') : (isIndonesian ? 'Lihat Analisis Vital' : 'View Vitals')}</span>
          </button>
        </div>

        {/* Expandable Vitals Breakdown */}
        {showWellnessDetails && (
          <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-2 md:grid-cols-4 gap-3 animate-in fade-in duration-200">
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
              <div className="text-xs text-slate-600 flex items-center justify-between mb-1">
                <span>Hidrasi Air</span>
                <span className="text-cyan-700 font-bold">{hydrationScore}/100</span>
              </div>
              <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                <div className="h-full bg-cyan-500 rounded-full" style={{ width: `${hydrationScore}%` }} />
              </div>
            </div>

            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
              <div className="text-xs text-slate-600 flex items-center justify-between mb-1">
                <span>Kualitas Tidur</span>
                <span className="text-purple-700 font-bold">{sleepScore}/100</span>
              </div>
              <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                <div className="h-full bg-purple-500 rounded-full" style={{ width: `${sleepScore}%` }} />
              </div>
            </div>

            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
              <div className="text-xs text-slate-600 flex items-center justify-between mb-1">
                <span>Aktivitas Langkah</span>
                <span className="text-emerald-700 font-bold">{activityScore}/100</span>
              </div>
              <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${activityScore}%` }} />
              </div>
            </div>

            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
              <div className="text-xs text-slate-600 flex items-center justify-between mb-1">
                <span>Keseimbangan Kalori</span>
                <span className="text-amber-700 font-bold">{calorieScore}/100</span>
              </div>
              <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full" style={{ width: `${calorieScore}%` }} />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* CORE VITALS & HABITS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Card 1: Hydration Tracker Widget */}
        <div className="md:col-span-6 lg:col-span-4 bg-white border border-slate-200/90 hover:border-cyan-300 rounded-[28px] p-6 flex flex-col justify-between shadow-2xs transition-all duration-200">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-cyan-50 text-cyan-700 border border-cyan-200 shadow-2xs">
                <Droplets className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm sm:text-base">{isIndonesian ? 'Asupan Air Minum' : 'Water Intake'}</h3>
                <p className="text-xs text-slate-500">{dailyLog.waterIntakeMl} / {userProfile.dailyWaterTargetMl} ml</p>
              </div>
            </div>
            <span className="text-cyan-800 text-xs font-bold bg-cyan-50 px-3 py-1 rounded-full border border-cyan-200">
              {waterPercent}%
            </span>
          </div>

          <div className="my-5">
            <div className="flex gap-1.5">
              {[...Array(10)].map((_, i) => {
                const filled = (i + 1) * 10 <= waterPercent;
                return (
                  <div
                    key={i}
                    className={`flex-1 h-10 rounded-xl transition-all ${
                      filled
                        ? 'bg-cyan-500 border border-cyan-600'
                        : 'bg-slate-100 border border-slate-200/70'
                    }`}
                  />
                );
              })}
            </div>
            <p className="text-[11px] text-cyan-800 font-bold uppercase tracking-wider text-center mt-2.5">
              {waterPercent >= 100 ? (isIndonesian ? '🎉 Target Air Tercapai!' : '🎉 Daily Goal Reached!') : `${Math.max(0, userProfile.dailyWaterTargetMl - dailyLog.waterIntakeMl)} ml ${isIndonesian ? 'tersisa hari ini' : 'left today'}`}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onAddWater(250)}
              className="py-2 bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 text-cyan-800 text-xs font-bold rounded-xl transition-all cursor-pointer active:scale-98"
            >
              +250 ml
            </button>
            <button
              onClick={() => onAddWater(500)}
              className="py-2 bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-bold rounded-xl transition-all cursor-pointer active:scale-98 shadow-2xs"
            >
              +500 ml
            </button>
          </div>
        </div>

        {/* Card 2: Calories & Macro Breakdown Widget */}
        <div className="md:col-span-6 lg:col-span-5 bg-white border border-slate-200/90 hover:border-emerald-300 rounded-[28px] p-6 flex flex-col justify-between shadow-2xs transition-all duration-200">
          <div className="flex justify-between items-center pb-3 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-amber-50 text-amber-700 border border-amber-200 shadow-2xs">
                <Flame className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm sm:text-base">{isIndonesian ? 'Kalori & Makronutrisi' : 'Calories & Macros'}</h3>
                <p className="text-xs text-slate-500">{isIndonesian ? 'Target:' : 'Budget:'} {userProfile.dailyCalorieTarget} kcal</p>
              </div>
            </div>
            <button
              onClick={() => setShowMealModal(true)}
              className="text-xs bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border border-slate-200 px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer"
            >
              + {isIndonesian ? 'Catat Cepat' : 'Quick Meal'}
            </button>
          </div>

          <div className="space-y-2.5 my-3">
            {/* Carbs */}
            <div>
              <div className="flex justify-between text-xs mb-1 font-semibold">
                <span className="text-slate-500">{isIndonesian ? 'Karbohidrat' : 'Carbohydrates'}</span>
                <span className="font-bold text-amber-700">{dailyLog.carbsG} / {userProfile.dailyCarbsTargetG}g</span>
              </div>
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full transition-all" style={{ width: `${carbsPercent}%` }} />
              </div>
            </div>

            {/* Protein */}
            <div>
              <div className="flex justify-between text-xs mb-1 font-semibold">
                <span className="text-slate-500">Protein</span>
                <span className="font-bold text-emerald-700">{dailyLog.proteinG} / {userProfile.dailyProteinTargetG}g</span>
              </div>
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full transition-all" style={{ width: `${proteinPercent}%` }} />
              </div>
            </div>

            {/* Fats */}
            <div>
              <div className="flex justify-between text-xs mb-1 font-semibold">
                <span className="text-slate-500">{isIndonesian ? 'Lemak Sehat' : 'Healthy Fats'}</span>
                <span className="font-bold text-teal-700">{dailyLog.fatG} / {userProfile.dailyFatTargetG}g</span>
              </div>
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-teal-500 rounded-full transition-all" style={{ width: `${fatPercent}%` }} />
              </div>
            </div>
          </div>

          <div>
            <button
              onClick={onNavigateToNutrition}
              className="w-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-bold py-2 rounded-2xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Utensils className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isIndonesian ? 'Scan Piring dengan Gemini AI' : 'Scan Food with Gemini AI'}</span>
            </button>
          </div>
        </div>

        {/* Card 3: Health Streak & Level Badge Widget */}
        <div className="md:col-span-12 lg:col-span-3 bg-white border border-slate-200/90 hover:border-amber-300 rounded-[28px] p-6 flex flex-col justify-between items-center text-center shadow-2xs transition-all duration-200">
          <div className="text-4xl mb-1">🔥</div>
          <div className="text-4xl font-black text-slate-900 tracking-tight">{userProfile.streakCount}</div>
          <div className="text-xs text-slate-500 uppercase tracking-wider font-bold">
            {isIndonesian ? 'Hari Streak Sehat' : 'Day Health Streak'}
          </div>

          <div className="mt-3 px-4 py-1 bg-amber-50 text-amber-800 rounded-full text-xs font-bold border border-amber-200">
            LEVEL {userProfile.level} MASTER
          </div>

          <p className="text-[11px] text-slate-400 mt-2 font-medium">
            {isIndonesian ? 'Level berikutnya:' : 'Next level at:'} {userProfile.xpNextLevel} XP
          </p>
        </div>
      </div>

      {/* SECONDARY METRICS: WEIGHT, STEPS, SLEEP */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Weight Widget */}
        <div className="bg-white border border-slate-200/90 rounded-[24px] p-5 flex items-center justify-between shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-2xl">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500 font-semibold">{isIndonesian ? 'Berat Badan' : 'Body Weight'}</p>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-xl font-bold text-slate-900">{dailyLog.weightKg} kg</span>
                <span className="text-xs text-emerald-700 font-semibold">{isIndonesian ? 'Target:' : 'Target:'} {userProfile.targetWeightKg} kg</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => setShowWeightModal(true)}
            className="px-3 py-1.5 bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 rounded-xl text-xs font-bold transition-all cursor-pointer"
          >
            {isIndonesian ? 'Ubah' : 'Update'}
          </button>
        </div>

        {/* Steps Widget */}
        <div className="bg-white border border-slate-200/90 rounded-[24px] p-5 flex items-center justify-between shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-teal-50 text-teal-700 border border-teal-200 rounded-2xl">
              <Footprints className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500 font-semibold">{isIndonesian ? 'Langkah Kaki' : 'Daily Steps'}</p>
              <div className="flex items-baseline gap-1.5 mt-0.5">
                <span className="text-xl font-bold text-slate-900">{dailyLog.stepsCount.toLocaleString()}</span>
                <span className="text-xs text-slate-400 font-semibold">/ {userProfile.dailyStepsTarget.toLocaleString()}</span>
              </div>
            </div>
          </div>
          <div className="w-14 bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-teal-500 h-full rounded-full"
              style={{ width: `${Math.min(100, (dailyLog.stepsCount / userProfile.dailyStepsTarget) * 100)}%` }}
            />
          </div>
        </div>

        {/* Sleep Widget */}
        <div className="bg-white border border-slate-200/90 rounded-[24px] p-5 flex items-center justify-between shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-purple-50 text-purple-700 border border-purple-200 rounded-2xl">
              <Moon className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500 font-semibold">{isIndonesian ? 'Waktu Tidur' : 'Sleep Tracker'}</p>
              <div className="flex items-baseline gap-1.5 mt-0.5">
                <span className="text-xl font-bold text-slate-900">{dailyLog.sleepHours} hrs</span>
                <span className="text-xs text-slate-400 font-semibold">/ {userProfile.dailySleepTargetHours} hrs</span>
              </div>
            </div>
          </div>
          <div className="w-14 bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-purple-500 h-full rounded-full"
              style={{ width: `${Math.min(100, (dailyLog.sleepHours / userProfile.dailySleepTargetHours) * 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* TODAY'S MEAL JOURNAL CONTAINER */}
      <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-200">
              <Utensils className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-slate-900 text-base sm:text-lg">
              {isIndonesian ? 'Jurnal Makanan Hari Ini' : 'Today\'s Meal Journal'}
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-bold">
            {loggedMeals.length} {isIndonesian ? 'Menu Tercatat' : 'Meals Logged'}
          </span>
        </div>

        {loggedMeals.length === 0 ? (
          <div className="py-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
            <Coffee className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-xs text-slate-500 font-medium">
              {isIndonesian ? 'Belum ada makanan dicatat hari ini.' : 'No meals recorded yet today.'}
            </p>
            <button
              onClick={onNavigateToNutrition}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 cursor-pointer"
            >
              + {isIndonesian ? 'Scan Makanan Pertama Anda' : 'Scan Your First Meal'}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {loggedMeals.map((meal) => (
              <div
                key={meal.id}
                className="bg-slate-50 hover:bg-emerald-50/40 border border-slate-200/80 hover:border-emerald-200 p-4 rounded-2xl space-y-2.5 transition-all"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm line-clamp-1">{meal.name}</h4>
                    <p className="text-[11px] text-slate-500 capitalize">{meal.category} • {meal.timestamp}</p>
                  </div>
                  <span className="bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold text-xs px-2 py-0.5 rounded-lg">
                    ★ {meal.healthRating}/10
                  </span>
                </div>

                <div className="flex items-center gap-2 text-xs bg-white p-2 rounded-xl border border-slate-100 font-semibold">
                  <span className="font-bold text-amber-700">{meal.calories} kcal</span>
                  <span className="text-slate-300">|</span>
                  <span className="text-slate-600">C: {meal.carbsG}g</span>
                  <span className="text-slate-600">P: {meal.proteinG}g</span>
                  <span className="text-slate-600">F: {meal.fatG}g</span>
                </div>

                {meal.aiAdvice && (
                  <p className="text-xs text-emerald-900 italic bg-emerald-50/80 p-2 rounded-xl border border-emerald-100 leading-relaxed">
                    💡 "{meal.aiAdvice}"
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* QUICK MEAL MODAL */}
      {showMealModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-[28px] p-6 w-full max-w-md space-y-4 shadow-xl">
            <h3 className="font-bold text-lg text-slate-900">{isIndonesian ? 'Catat Makanan Cepat' : 'Add Quick Meal'}</h3>
            <form onSubmit={handleQuickAddMeal} className="space-y-3">
              <div>
                <label className="text-xs text-slate-600 font-semibold block mb-1">
                  {isIndonesian ? 'Nama Makanan' : 'Meal Name'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={isIndonesian ? 'mis. Salad Ayam Panggang 200g' : 'e.g. Grilled Chicken Salad 200g'}
                  value={customMealName}
                  onChange={(e) => setCustomMealName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-600 font-semibold block mb-1">Kalori (kcal)</label>
                  <input
                    type="number"
                    value={customCalories}
                    onChange={(e) => setCustomCalories(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-600 font-semibold block mb-1">Karbohidrat (g)</label>
                  <input
                    type="number"
                    value={customCarbs}
                    onChange={(e) => setCustomCarbs(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-600 font-semibold block mb-1">Protein (g)</label>
                  <input
                    type="number"
                    value={customProtein}
                    onChange={(e) => setCustomProtein(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-600 font-semibold block mb-1">Lemak (g)</label>
                  <input
                    type="number"
                    value={customFat}
                    onChange={(e) => setCustomFat(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowMealModal(false)}
                  className="w-1/2 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs cursor-pointer"
                >
                  {isIndonesian ? 'Simpan Makanan' : 'Save Meal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QUICK WEIGHT MODAL */}
      {showWeightModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-[28px] p-6 w-full max-w-sm space-y-4 shadow-xl">
            <h3 className="font-bold text-lg text-slate-900">{isIndonesian ? 'Perbarui Berat Badan' : 'Update Weight'}</h3>
            <form onSubmit={handleQuickWeightSubmit} className="space-y-4">
              <div>
                <label className="text-xs text-slate-600 font-semibold block mb-1">
                  {isIndonesian ? 'Berat Saat Ini (kg)' : 'Current Weight (kg)'}
                </label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={newWeight}
                  onChange={(e) => setNewWeight(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-base text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowWeightModal(false)}
                  className="w-1/2 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  {isIndonesian ? 'Batal' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs cursor-pointer"
                >
                  {isIndonesian ? 'Simpan' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* NEW MODULAR UI/UX MODALS */}
      <AiHealthCompanionModal
        isOpen={isAiCompanionOpen}
        onClose={() => setIsAiCompanionOpen(false)}
        userProfile={userProfile}
        onLaunchDoctorConsult={() => {
          setIsAiCompanionOpen(false);
          if (onNavigateTab) onNavigateTab('doctor_consultation');
        }}
      />

      <SleepAnalysisStudio
        isOpen={isSleepStudioOpen}
        onClose={() => setIsSleepStudioOpen(false)}
        userProfile={userProfile}
      />

      <LiveWorkoutPoseGuard
        isOpen={isLiveWorkoutOpen}
        onClose={() => setIsLiveWorkoutOpen(false)}
        userProfile={userProfile}
      />
    </div>
  );
};
