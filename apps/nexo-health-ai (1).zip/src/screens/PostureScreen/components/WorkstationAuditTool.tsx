import React, { useState } from 'react';
import {
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ShoppingBag,
  Info,
  ShieldCheck,
  Zap,
  ArrowRight,
  ExternalLink,
  Laptop,
  Layers,
  ChevronDown,
} from 'lucide-react';
import { ErgonomicAuditItem } from '../../../types';
import { INITIAL_ERGONOMIC_AUDIT_ITEMS } from '../data/postureData';

export const WorkstationAuditTool: React.FC = () => {
  const [auditItems, setAuditItems] = useState<ErgonomicAuditItem[]>(INITIAL_ERGONOMIC_AUDIT_ITEMS);
  const [isAuditingAi, setIsAuditingAi] = useState<boolean>(false);
  const [aiAuditResult, setAiAuditResult] = useState<any>(null);

  // Quick State Toggles
  const handleStatusChange = (id: string, newStatus: ErgonomicAuditItem['currentStatus']) => {
    setAuditItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, currentStatus: newStatus } : item))
    );
  };

  // Calculate Ergonomic Score
  const idealCount = auditItems.filter((i) => i.currentStatus === 'ideal').length;
  const needsAdjustmentCount = auditItems.filter((i) => i.currentStatus === 'needs_adjustment').length;
  const highRiskCount = auditItems.filter((i) => i.currentStatus === 'high_risk').length;
  const calculatedScore = Math.round(((idealCount * 1.0 + needsAdjustmentCount * 0.5) / auditItems.length) * 100);

  const handleRunAiAudit = async () => {
    setIsAuditingAi(true);
    try {
      const res = await fetch('/api/posture/workstation-audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          monitorHeightStatus: auditItems.find((i) => i.category === 'monitor')?.currentStatus || 'needs_adjustment',
          elbowAngleDegrees: auditItems.find((i) => i.category === 'keyboard_mouse')?.currentStatus === 'ideal' ? 95 : 120,
          lumbarSupportPresent: auditItems.find((i) => i.category === 'chair_lumbar')?.currentStatus === 'ideal',
          feetFlatOnFloor: auditItems.find((i) => i.category === 'foot_placement')?.currentStatus === 'ideal',
          mouseType: auditItems.find((i) => i.category === 'keyboard_mouse')?.currentStatus === 'ideal' ? 'vertical_mouse' : 'flat_standard',
          language: 'id',
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setAiAuditResult(data.data);
      }
    } catch (e) {
      console.error('Failed to run workstation AI audit:', e);
    } finally {
      setIsAuditingAi(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Ergonomic Rating Overview */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10.5px] font-black uppercase tracking-wider">
                Workstation Ergonomics Assessment
              </span>
              <span className="text-xs text-slate-400 font-bold">Audit Stasiun Kerja & Peralatan</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Audit Setup Meja Kerja & Rekomendasi Perlengkapan
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
              Identifikasi sumber ketegangan biomekanika: sudut layar monitor, elevasi bahu akibat mouse datar, dan kurva lumbar kursi.
            </p>
          </div>

          <button
            onClick={handleRunAiAudit}
            disabled={isAuditingAi}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-black text-xs transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-700/20 cursor-pointer shrink-0 disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4 text-emerald-200 animate-spin" />
            <span>{isAuditingAi ? 'Menganalisis Ergonomi...' : 'Jalankan Audit AI Gemini'}</span>
          </button>
        </div>

        {/* Score Summary Metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="text-[11px] font-bold text-slate-400 block">Skor Ergonomi Meja:</span>
            <div className="text-2xl font-black text-slate-900 font-mono">
              {calculatedScore}/100
            </div>
            <span className="text-[11px] font-bold text-emerald-700">
              {calculatedScore >= 80 ? 'Sangat Ergonomis' : calculatedScore >= 60 ? 'Cukup Baik' : 'Perlu Penyesuaian'}
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
            <span className="text-[11px] font-bold text-emerald-700 block">Posisi Ideal (Aman):</span>
            <div className="text-2xl font-black text-emerald-900 font-mono">{idealCount} Elemen</div>
            <span className="text-[10px] text-emerald-600 font-medium">Bebas kompresi sendi</span>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-1">
            <span className="text-[11px] font-bold text-amber-700 block">Perlu Penyesuaian:</span>
            <div className="text-2xl font-black text-amber-900 font-mono">{needsAdjustmentCount} Elemen</div>
            <span className="text-[10px] text-amber-600 font-medium">Bisa diatasi DIY</span>
          </div>

          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 space-y-1">
            <span className="text-[11px] font-bold text-rose-700 block">Risiko Cedera Tinggi:</span>
            <div className="text-2xl font-black text-rose-900 font-mono">{highRiskCount} Elemen</div>
            <span className="text-[10px] text-rose-600 font-medium">Memicu saraf terjepit</span>
          </div>
        </div>

        {/* Audit Checklist Items */}
        <div className="space-y-4 pt-2">
          {auditItems.map((item) => {
            return (
              <div
                key={item.id}
                className="p-5 rounded-3xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-slate-300 transition-all space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-black text-slate-900">{item.title}</h4>
                    </div>
                    <p className="text-xs text-slate-500">
                      <strong>Standar Ideal:</strong> {item.idealStandard}
                    </p>
                  </div>

                  {/* Status Switcher Buttons */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => handleStatusChange(item.id, 'ideal')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        item.currentStatus === 'ideal'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      ✅ Sesuai
                    </button>
                    <button
                      onClick={() => handleStatusChange(item.id, 'needs_adjustment')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        item.currentStatus === 'needs_adjustment'
                          ? 'bg-amber-600 text-white shadow-xs'
                          : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      ⚠️ Perlu Ditata
                    </button>
                    <button
                      onClick={() => handleStatusChange(item.id, 'high_risk')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        item.currentStatus === 'high_risk'
                          ? 'bg-rose-600 text-white shadow-xs'
                          : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      🚫 Berisiko
                    </button>
                  </div>
                </div>

                {/* Biomechanical Risk & Actionable Fix */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-2xl bg-white border border-slate-200 space-y-1">
                    <span className="text-rose-700 font-bold text-[11px] block">
                      Dampak Biomekanika Tubuh:
                    </span>
                    <p className="text-slate-600 leading-relaxed">{item.biomechanicalReason}</p>
                  </div>

                  <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1">
                    <span className="text-emerald-800 font-bold text-[11px] block">
                      Solusi Cepat (Zero-Cost DIY):
                    </span>
                    <p className="text-emerald-950 leading-relaxed">{item.actionableFix}</p>
                  </div>
                </div>

                {/* Equipment Suggestion if available */}
                {item.recommendedGear && (
                  <div className="p-3.5 rounded-2xl bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <ShoppingBag className="w-3.5 h-3.5 text-amber-400" />
                        <span className="font-black text-amber-300">
                          Rekomendasi Gear: {item.recommendedGear.name}
                        </span>
                      </div>
                      <p className="text-slate-300 text-[11px]">
                        {item.recommendedGear.benefit}
                      </p>
                    </div>

                    <div className="shrink-0 text-right">
                      <span className="text-[11px] text-slate-400 font-mono block">
                        Estimasi: {item.recommendedGear.estimatedPriceIdr}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* AI Audit Synthesis Card */}
        {aiAuditResult && (
          <div className="p-5 rounded-3xl bg-slate-900 text-white border border-slate-800 space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10.5px] font-black uppercase tracking-wider border border-emerald-500/30">
                Hasil Audit Klinis Ergonomis Gemini AI
              </span>
              <span className="text-xs font-bold text-amber-300">
                Rating: {aiAuditResult.ergonomicRating}
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              {aiAuditResult.primaryRiskSummary}
            </p>

            <div className="space-y-2">
              <span className="text-xs font-black uppercase tracking-wider text-emerald-400 block">
                3 Langkah Penyesuaian Gratis Hari Ini:
              </span>
              <ul className="space-y-1 text-xs text-slate-300 list-disc list-inside">
                {aiAuditResult.immediateFreeAdjustments?.map((adj: string, idx: number) => (
                  <li key={idx}>{adj}</li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
