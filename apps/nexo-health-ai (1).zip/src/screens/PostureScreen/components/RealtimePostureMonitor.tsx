import React, { useState, useEffect, useRef } from 'react';
import {
  Camera,
  CameraOff,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  Volume2,
  VolumeX,
  Eye,
  RefreshCw,
  Zap,
  Info,
  ShieldCheck,
  Smartphone,
  Laptop,
  Flame,
  ArrowRight,
  TrendingDown,
  Activity,
  HeartPulse,
} from 'lucide-react';
import { PostureAnomalyType, PostureLiveMetrics } from '../../../types';

interface RealtimePostureMonitorProps {
  onTriggerDeskYoga?: () => void;
}

export const RealtimePostureMonitor: React.FC<RealtimePostureMonitorProps> = ({
  onTriggerDeskYoga,
}) => {
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'mobile'>('desktop');
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);
  const [calibrationProgress, setCalibrationProgress] = useState<number>(0);
  const [speechEnabled, setSpeechEnabled] = useState<boolean>(false);
  const [flowStateProtection, setFlowStateProtection] = useState<boolean>(true);
  const [showAlertFlash, setShowAlertFlash] = useState<boolean>(false);
  const [analyzingAi, setAnalyzingAi] = useState<boolean>(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<any>(null);

  // Live Metrics State
  const [metrics, setMetrics] = useState<PostureLiveMetrics>({
    craniovertebralAngle: 43,
    thoracicKyphosisAngle: 49,
    shoulderSymmetryDeltaDeg: 4.8,
    cervicalSpineLoadKg: 22.4,
    currentPostureState: 'severe_risk',
    activeAnomaly: 'forward_head',
    consecutiveBadPostureSec: 38,
    dailyPostureScore: 72,
    totalTrackedMinutesToday: 215,
    uprightMinutesToday: 155,
    slouchedMinutesToday: 60,
    flowStateProtectionActive: true,
    hapticOrVisualAlertEnabled: true,
    audioSpeechAlertEnabled: false,
  });

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Camera stream starter
  const startCamera = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
          audio: false,
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
      }
      setIsCameraActive(true);
    } catch (err) {
      console.warn('Webcam not accessible or permission denied, using simulated biomechanical feed:', err);
      setIsCameraActive(true);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((t) => t.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  // Calibration trigger
  const handleStartCalibration = () => {
    setIsCalibrating(true);
    setCalibrationProgress(0);

    const interval = setInterval(() => {
      setCalibrationProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsCalibrating(false);
          // Set to optimal baseline
          setMetrics((m) => ({
            ...m,
            craniovertebralAngle: 54,
            thoracicKyphosisAngle: 32,
            shoulderSymmetryDeltaDeg: 0.8,
            cervicalSpineLoadKg: 5.4,
            currentPostureState: 'optimal',
            activeAnomaly: 'optimal',
            consecutiveBadPostureSec: 0,
            dailyPostureScore: Math.min(100, m.dailyPostureScore + 5),
          }));
          return 100;
        }
        return prev + 20;
      });
    }, 400);
  };

  // Canvas drawing loop (Real-time Skeleton Simulation with Interactive Posture Overlay)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;

    const render = () => {
      frame++;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const width = canvas.width;
      const height = canvas.height;

      // Draw subtle background grid
      ctx.strokeStyle = '#f1f5f9';
      ctx.lineWidth = 1;
      for (let x = 0; x < width; x += 30) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 30) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Biomechanical skeleton coordinates based on current active anomaly
      const isBad = metrics.activeAnomaly !== 'optimal';
      const headForwardOffset = metrics.activeAnomaly === 'forward_head' ? 45 : isBad ? 25 : 0;
      const slouchDownOffset = metrics.activeAnomaly === 'slouching' ? 28 : isBad ? 12 : 0;
      const rightShoulderTilt = metrics.activeAnomaly === 'asymmetrical_shoulder' ? 18 : 0;
      const shoulderHunch = metrics.activeAnomaly === 'shoulder_hunch' ? -15 : 0;

      // Center reference lines
      const spineBaseX = width / 2;
      const spineBaseY = height - 40;

      // Key Joint Points
      const headCenter = {
        x: width / 2 + headForwardOffset + Math.sin(frame * 0.03) * 1.5,
        y: 90 + slouchDownOffset,
      };
      const earPoint = { x: headCenter.x - 18, y: headCenter.y + 5 };
      const neckC7 = { x: width / 2 + 10, y: 160 + slouchDownOffset };
      const shoulderL = { x: width / 2 - 70, y: 175 + slouchDownOffset + shoulderHunch };
      const shoulderR = {
        x: width / 2 + 80,
        y: 175 + slouchDownOffset + rightShoulderTilt + shoulderHunch,
      };
      const thoracicT8 = { x: width / 2 - 10, y: 240 + slouchDownOffset };
      const lumbarL3 = { x: width / 2 - 5, y: 310 };
      const pelvisCenter = { x: spineBaseX, y: spineBaseY };

      // Draw Plumb Line (Ideal Vertical Gravity Line)
      ctx.save();
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(width / 2, 40);
      ctx.lineTo(width / 2, height - 20);
      ctx.stroke();
      ctx.restore();

      // Draw Skeleton Bones
      const boneColor = isBad ? '#f43f5e' : '#10b981';
      ctx.strokeStyle = boneColor;
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      // Spine chain: Head -> C7 -> T8 -> L3 -> Pelvis
      ctx.beginPath();
      ctx.moveTo(headCenter.x, headCenter.y);
      ctx.lineTo(neckC7.x, neckC7.y);
      ctx.lineTo(thoracicT8.x, thoracicT8.y);
      ctx.lineTo(lumbarL3.x, lumbarL3.y);
      ctx.lineTo(pelvisCenter.x, pelvisCenter.y);
      ctx.stroke();

      // Clavicle & Shoulders: ShoulderL -> C7 -> ShoulderR
      ctx.beginPath();
      ctx.moveTo(shoulderL.x, shoulderL.y);
      ctx.lineTo(neckC7.x, neckC7.y);
      ctx.lineTo(shoulderR.x, shoulderR.y);
      ctx.stroke();

      // Arms down to desk
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(shoulderL.x, shoulderL.y);
      ctx.lineTo(shoulderL.x - 20, shoulderL.y + 70);
      ctx.lineTo(shoulderL.x + 15, shoulderL.y + 110);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(shoulderR.x, shoulderR.y);
      ctx.lineTo(shoulderR.x + 25, shoulderR.y + 70);
      ctx.lineTo(shoulderR.x - 10, shoulderR.y + 110);
      ctx.stroke();

      // Draw Head circle & Gaze Vector
      ctx.fillStyle = isBad ? 'rgba(244, 63, 94, 0.15)' : 'rgba(16, 185, 129, 0.15)';
      ctx.strokeStyle = boneColor;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(headCenter.x, headCenter.y, 32, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Gaze ray towards monitor (left or straight)
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(headCenter.x + 20, headCenter.y);
      ctx.lineTo(headCenter.x + 90, headCenter.y + 10);
      ctx.stroke();

      // Draw Craniovertebral Angle Visual Arc
      ctx.strokeStyle = '#e11d48';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(earPoint.x, earPoint.y);
      ctx.lineTo(neckC7.x, neckC7.y);
      ctx.lineTo(neckC7.x + 60, neckC7.y);
      ctx.stroke();

      // Joint Nodes (Pills & Dots)
      const joints = [headCenter, neckC7, shoulderL, shoulderR, thoracicT8, lumbarL3, pelvisCenter];
      joints.forEach((j) => {
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = boneColor;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(j.x, j.y, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      });

      // Overlay text on canvas
      ctx.font = 'bold 11px monospace';
      ctx.fillStyle = isBad ? '#e11d48' : '#059669';
      ctx.fillText(
        `Sudut CV: ${metrics.craniovertebralAngle}° | Beban: ${metrics.cervicalSpineLoadKg} kg`,
        16,
        28
      );

      animationFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [metrics]);

  // Handle Speech Alert
  const speakVoiceCue = (text: string) => {
    if ('speechSynthesis' in window && speechEnabled) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'id-ID';
      utterance.rate = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Run AI Diagnosis with Gemini
  const handleRunAiPostureAnalysis = async () => {
    setAnalyzingAi(true);
    try {
      const res = await fetch('/api/posture/live-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          craniovertebralAngle: metrics.craniovertebralAngle,
          thoracicKyphosisAngle: metrics.thoracicKyphosisAngle,
          shoulderSymmetryDeltaDeg: metrics.shoulderSymmetryDeltaDeg,
          activeAnomaly: metrics.activeAnomaly,
          consecutiveBadPostureSec: metrics.consecutiveBadPostureSec,
          language: 'id',
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setAiAnalysisResult(data.data);
        if (speechEnabled && data.data.spokenVoiceCue) {
          speakVoiceCue(data.data.spokenVoiceCue);
        }
      }
    } catch (e) {
      console.error('Failed to run AI analysis:', e);
    } finally {
      setAnalyzingAi(false);
    }
  };

  // Simulate Anomaly Switcher for Interactive Demonstration
  const handleSelectAnomalySimulation = (anomaly: PostureAnomalyType) => {
    if (anomaly === 'optimal') {
      setMetrics((m) => ({
        ...m,
        craniovertebralAngle: 55,
        thoracicKyphosisAngle: 30,
        shoulderSymmetryDeltaDeg: 0.6,
        cervicalSpineLoadKg: 5.2,
        currentPostureState: 'optimal',
        activeAnomaly: 'optimal',
        consecutiveBadPostureSec: 0,
      }));
      setShowAlertFlash(false);
    } else if (anomaly === 'forward_head') {
      setMetrics((m) => ({
        ...m,
        craniovertebralAngle: 41,
        thoracicKyphosisAngle: 46,
        shoulderSymmetryDeltaDeg: 2.1,
        cervicalSpineLoadKg: 22.8,
        currentPostureState: 'severe_risk',
        activeAnomaly: 'forward_head',
        consecutiveBadPostureSec: 42,
      }));
      setShowAlertFlash(true);
      setTimeout(() => setShowAlertFlash(false), 2000);
      if (speechEnabled) speakVoiceCue('Tegakkan punggung, tarik dagu ke belakang.');
    } else if (anomaly === 'slouching') {
      setMetrics((m) => ({
        ...m,
        craniovertebralAngle: 44,
        thoracicKyphosisAngle: 52,
        shoulderSymmetryDeltaDeg: 3.4,
        cervicalSpineLoadKg: 19.5,
        currentPostureState: 'severe_risk',
        activeAnomaly: 'slouching',
        consecutiveBadPostureSec: 55,
      }));
      setShowAlertFlash(true);
      setTimeout(() => setShowAlertFlash(false), 2000);
      if (speechEnabled) speakVoiceCue('Punggung Anda melengkung. Bersandarlah tegak di kursi.');
    } else if (anomaly === 'shoulder_hunch') {
      setMetrics((m) => ({
        ...m,
        craniovertebralAngle: 48,
        thoracicKyphosisAngle: 38,
        shoulderSymmetryDeltaDeg: 1.5,
        cervicalSpineLoadKg: 14.2,
        currentPostureState: 'mild_risk',
        activeAnomaly: 'shoulder_hunch',
        consecutiveBadPostureSec: 25,
      }));
      if (speechEnabled) speakVoiceCue('Turunkan dan rilekskan kedua bahu Anda.');
    } else if (anomaly === 'asymmetrical_shoulder') {
      setMetrics((m) => ({
        ...m,
        craniovertebralAngle: 49,
        thoracicKyphosisAngle: 40,
        shoulderSymmetryDeltaDeg: 5.6,
        cervicalSpineLoadKg: 16.0,
        currentPostureState: 'mild_risk',
        activeAnomaly: 'asymmetrical_shoulder',
        consecutiveBadPostureSec: 32,
      }));
      if (speechEnabled) speakVoiceCue('Bahu kanan Anda terangkat tinggi. Sesuaikan posisi mouse.');
    } else if (anomaly === 'leg_crossing') {
      setMetrics((m) => ({
        ...m,
        craniovertebralAngle: 50,
        thoracicKyphosisAngle: 42,
        shoulderSymmetryDeltaDeg: 3.8,
        cervicalSpineLoadKg: 12.5,
        currentPostureState: 'mild_risk',
        activeAnomaly: 'leg_crossing',
        consecutiveBadPostureSec: 70,
      }));
      if (speechEnabled) speakVoiceCue('Turunkan silangan kaki untuk menjaga panggul tetap seimbang.');
    }
  };

  return (
    <div
      className={`space-y-6 transition-all duration-300 ${
        showAlertFlash ? 'ring-4 ring-rose-500/50 rounded-3xl bg-rose-50/20' : ''
      }`}
    >
      {/* Top Controls & Mode Switcher */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10.5px] font-black uppercase tracking-wider">
                Privacy-First Computer Vision
              </span>
              <span className="text-xs text-slate-400 font-bold">On-Device Edge Inference</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Pemantauan Postur Real-Time & Sensor Sudut Tulang
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
              Melacak titik sendi kepala, leher C7, torakal, dan bahu. Semua analisis visual diproses secara lokal tanpa video dikirim ke server.
            </p>
          </div>

          {/* Device & Voice Controls */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200">
              <button
                onClick={() => setDeviceMode('desktop')}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                  deviceMode === 'desktop'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Laptop className="w-3.5 h-3.5" />
                <span>Laptop/Webcam</span>
              </button>
              <button
                onClick={() => setDeviceMode('mobile')}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                  deviceMode === 'mobile'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Mobile Gyro</span>
              </button>
            </div>

            <button
              onClick={() => setSpeechEnabled(!speechEnabled)}
              className={`p-2.5 rounded-2xl border transition-all cursor-pointer ${
                speechEnabled
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
                  : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-600'
              }`}
              title={speechEnabled ? 'Suara AI Aktif' : 'Suara AI Nonaktif'}
            >
              {speechEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Live Canvas View & Telemetry Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Visual Canvas Feed */}
          <div className="lg:col-span-7 space-y-3">
            <div className="relative rounded-3xl bg-slate-950 overflow-hidden border border-slate-800 aspect-[4/3] flex items-center justify-center shadow-inner">
              <canvas
                ref={canvasRef}
                width={480}
                height={360}
                className="w-full h-full object-contain"
              />

              {/* Hidden video element for live camera feed if enabled */}
              <video
                ref={videoRef}
                className="hidden"
                playsInline
                muted
              />

              {/* Anomaly Live Status Pill */}
              <div className="absolute top-4 left-4 z-10 flex items-center gap-2">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider backdrop-blur-md border flex items-center gap-1.5 ${
                    metrics.currentPostureState === 'optimal'
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                      : metrics.currentPostureState === 'mild_risk'
                      ? 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                      : 'bg-rose-950/80 text-rose-300 border-rose-500/40 animate-pulse'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      metrics.currentPostureState === 'optimal'
                        ? 'bg-emerald-400'
                        : metrics.currentPostureState === 'mild_risk'
                        ? 'bg-amber-400'
                        : 'bg-rose-400'
                    }`}
                  />
                  {metrics.activeAnomaly === 'optimal' && 'Postur Tegak Sempurna'}
                  {metrics.activeAnomaly === 'forward_head' && 'Forward Head (Text Neck)'}
                  {metrics.activeAnomaly === 'slouching' && 'Punggung Membungkuk (Slouch)'}
                  {metrics.activeAnomaly === 'shoulder_hunch' && 'Bahu Tegang & Naik'}
                  {metrics.activeAnomaly === 'asymmetrical_shoulder' && 'Bahu Miring Asimetris'}
                  {metrics.activeAnomaly === 'leg_crossing' && 'Silangan Kaki >30 Menit'}
                </span>
              </div>

              {/* Head Load Gauge Badge */}
              <div className="absolute top-4 right-4 z-10">
                <div className="px-3 py-1.5 rounded-2xl bg-black/70 backdrop-blur-md border border-white/10 text-right">
                  <span className="text-[10px] text-slate-400 font-bold block uppercase">
                    Beban Servikal C5-C7
                  </span>
                  <span
                    className={`text-base font-black font-mono ${
                      metrics.cervicalSpineLoadKg > 18
                        ? 'text-rose-400'
                        : metrics.cervicalSpineLoadKg > 10
                        ? 'text-amber-400'
                        : 'text-emerald-400'
                    }`}
                  >
                    {metrics.cervicalSpineLoadKg} kg
                  </span>
                </div>
              </div>

              {/* Calibration Overlay if active */}
              {isCalibrating && (
                <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center z-20 space-y-4">
                  <div className="w-16 h-16 rounded-full border-4 border-emerald-500 border-t-transparent animate-spin flex items-center justify-center text-emerald-400 font-black font-mono">
                    {calibrationProgress}%
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-lg font-black text-white">Kalibrasi Postur Duduk Netral</h4>
                    <p className="text-xs text-slate-300 max-w-sm">
                      Duduk tegak santai, pandangan sejajar monitor, rilekskan kedua bahu selama 5 detik...
                    </p>
                  </div>
                </div>
              )}

              {/* Bottom Quick Action Bar on Canvas */}
              <div className="absolute bottom-3 inset-x-3 flex items-center justify-between gap-2 z-10">
                <button
                  onClick={handleStartCalibration}
                  disabled={isCalibrating}
                  className="px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 backdrop-blur-md text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Kalibrasi Ulang (5s)</span>
                </button>

                <div className="flex items-center gap-2">
                  {!isCameraActive ? (
                    <button
                      onClick={startCamera}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>Aktifkan Webcam</span>
                    </button>
                  ) : (
                    <button
                      onClick={stopCamera}
                      className="px-3 py-1.5 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <CameraOff className="w-3.5 h-3.5" />
                      <span>Matikan Webcam</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Simulation Scenario Buttons */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="text-[11px] font-black text-slate-500 uppercase tracking-wider block">
                Uji Coba Deteksi Anomali Biomekanika:
              </span>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => handleSelectAnomalySimulation('optimal')}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                    metrics.activeAnomaly === 'optimal'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  ✅ Tegak Normal (54°)
                </button>
                <button
                  onClick={() => handleSelectAnomalySimulation('forward_head')}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                    metrics.activeAnomaly === 'forward_head'
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  ⚠️ Text Neck (41°)
                </button>
                <button
                  onClick={() => handleSelectAnomalySimulation('slouching')}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                    metrics.activeAnomaly === 'slouching'
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  🪑 Slouching / Membungkuk
                </button>
                <button
                  onClick={() => handleSelectAnomalySimulation('shoulder_hunch')}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                    metrics.activeAnomaly === 'shoulder_hunch'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  ⚡ Bahu Naik Tegang
                </button>
                <button
                  onClick={() => handleSelectAnomalySimulation('asymmetrical_shoulder')}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                    metrics.activeAnomaly === 'asymmetrical_shoulder'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  🖱️ Bahu Kanan Miring
                </button>
                <button
                  onClick={() => handleSelectAnomalySimulation('leg_crossing')}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                    metrics.activeAnomaly === 'leg_crossing'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  🦵 Silang Kaki
                </button>
              </div>
            </div>
          </div>

          {/* Telemetry Metrics & Diagnostic Cards */}
          <div className="lg:col-span-5 space-y-4 flex flex-col justify-between">
            {/* Primary Score & Head Load Metrics */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-3xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-slate-400 font-bold text-[11px] block">Sudut Craniovertebral:</span>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-black text-slate-900 font-mono">
                    {metrics.craniovertebralAngle}°
                  </span>
                  <span className="text-[11px] font-bold text-slate-400">(Ideal: &gt;50°)</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-1.5 mt-2 overflow-hidden">
                  <div
                    className={`h-full transition-all ${
                      metrics.craniovertebralAngle >= 50
                        ? 'bg-emerald-500'
                        : metrics.craniovertebralAngle >= 44
                        ? 'bg-amber-500'
                        : 'bg-rose-500'
                    }`}
                    style={{ width: `${Math.min(100, (metrics.craniovertebralAngle / 60) * 100)}%` }}
                  />
                </div>
              </div>

              <div className="p-4 rounded-3xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-slate-400 font-bold text-[11px] block">Skor Postur Hari Ini:</span>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-black text-emerald-700 font-mono">
                    {metrics.dailyPostureScore}
                  </span>
                  <span className="text-[11px] font-bold text-slate-400">/100</span>
                </div>
                <span className="text-[10px] text-emerald-600 font-bold block">
                  {metrics.uprightMinutesToday}m Tegak vs {metrics.slouchedMinutesToday}m Bungkuk
                </span>
              </div>
            </div>

            {/* Cervical Spine Mechanical Pressure Comparison */}
            <div className="p-4 rounded-3xl bg-amber-50/70 border border-amber-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-amber-600" />
                  Kalkulator Tekanan Leher (Dr. Hansraj Scale)
                </span>
              </div>

              <p className="text-xs text-amber-800 leading-relaxed">
                Setiap 15° kepala maju ke depan menggandakan beban pada tulang leher. Saat ini kepala menjorok menghasilkan beban{' '}
                <strong className="text-rose-700 font-mono text-sm">{metrics.cervicalSpineLoadKg} kg</strong> (setara galon air kecil di atas tengkuk).
              </p>

              <div className="grid grid-cols-4 gap-1.5 text-center pt-1 text-[10px]">
                <div className="p-1.5 rounded-xl bg-white border border-amber-200">
                  <span className="text-slate-400 block">0° Netral</span>
                  <strong className="text-emerald-700 font-mono">5.0 kg</strong>
                </div>
                <div className="p-1.5 rounded-xl bg-white border border-amber-200">
                  <span className="text-slate-400 block">15° Miring</span>
                  <strong className="text-amber-700 font-mono">12.2 kg</strong>
                </div>
                <div className="p-1.5 rounded-xl bg-white border border-amber-200">
                  <span className="text-slate-400 block">30° Bungkuk</span>
                  <strong className="text-rose-600 font-mono">18.1 kg</strong>
                </div>
                <div className="p-1.5 rounded-xl bg-white border border-amber-200">
                  <span className="text-slate-400 block">45° Parah</span>
                  <strong className="text-rose-700 font-mono">22.4 kg</strong>
                </div>
              </div>
            </div>

            {/* Smart Non-Intrusive Notification & Flow State Switch */}
            <div className="p-4 rounded-3xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-black text-slate-800">
                    Flow State Protection (Frekuensi Adaptif)
                  </span>
                </div>
                <button
                  onClick={() => setFlowStateProtection(!flowStateProtection)}
                  className={`w-10 h-5 rounded-full transition-all relative cursor-pointer ${
                    flowStateProtection ? 'bg-emerald-600' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition-all absolute top-0.5 ${
                      flowStateProtection ? 'left-5.5' : 'left-0.5'
                    }`}
                  />
                </button>
              </div>
              <p className="text-[11px] text-slate-500">
                AI mempelajari respon Anda. Peringatan hanya muncul jika postur buruk bertahan &gt;30 detik agar tidak memecah konsentrasi kerja.
              </p>
            </div>

            {/* Action Buttons: Run AI Diagnostic & Trigger Desk Yoga */}
            <div className="space-y-2 pt-1">
              <button
                onClick={handleRunAiPostureAnalysis}
                disabled={analyzingAi}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white text-xs font-black transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-700/20 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4 text-emerald-200 animate-spin" />
                <span>{analyzingAi ? 'Menganalisis Biomekanika...' : 'Analisis Biomekanika Gemini AI'}</span>
              </button>

              {onTriggerDeskYoga && (
                <button
                  onClick={onTriggerDeskYoga}
                  className="w-full py-2.5 rounded-2xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <HeartPulse className="w-3.5 h-3.5 text-rose-500" />
                  <span>Buka Protokol Micro-Break & Desk Yoga (30s)</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Gemini AI Biomechanical Insight Card */}
        {aiAnalysisResult && (
          <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-950 text-white border border-slate-800 space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10.5px] font-black uppercase tracking-wider border border-emerald-500/30">
                  Diagnosis Fisioterapis Digital AI
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  Beban Leher: {aiAnalysisResult.cervicalLoadKg} kg
                </span>
              </div>
              <span
                className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                  aiAnalysisResult.urgencyLevel === 'IMMEDIATE_ACTION'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                }`}
              >
                Status: {aiAnalysisResult.urgencyLevel}
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              {aiAnalysisResult.postureDiagnosis}
            </p>

            {/* Corrective Micro-Break Recommendation */}
            {aiAnalysisResult.microBreakRecommended && (
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    Rekomendasi Intervensi: {aiAnalysisResult.microBreakRecommended.exerciseName}
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Durasi: {aiAnalysisResult.microBreakRecommended.durationSec} detik
                  </span>
                </div>
                <p className="text-xs text-slate-300">
                  {aiAnalysisResult.microBreakRecommended.techniqueTip}
                </p>
              </div>
            )}

            {/* Cross-Module Integrations */}
            {aiAnalysisResult.crossModuleAdaptations && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 text-xs">
                <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1">
                  <span className="text-emerald-300 font-black text-[11px] block">
                    Modul 3 (Recovery Lab):
                  </span>
                  <p className="text-slate-300 text-[11px]">
                    {aiAnalysisResult.crossModuleAdaptations.module3RecoveryAction}
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1">
                  <span className="text-sky-300 font-black text-[11px] block">
                    Modul 2 (FormGuard CV):
                  </span>
                  <p className="text-slate-300 text-[11px]">
                    {aiAnalysisResult.crossModuleAdaptations.module2FormGuardAdvice}
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1">
                  <span className="text-indigo-300 font-black text-[11px] block">
                    Modul 15 (Mata 20-20-20):
                  </span>
                  <p className="text-slate-300 text-[11px]">
                    {aiAnalysisResult.crossModuleAdaptations.module15EyeHealthCue}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
