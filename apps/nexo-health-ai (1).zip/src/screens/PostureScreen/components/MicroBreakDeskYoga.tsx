import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Eye,
  Clock,
  CheckCircle2,
  Heart,
  ChevronRight,
  Flame,
  ShieldCheck,
  Zap,
  Info,
  Timer,
} from 'lucide-react';
import { DeskYogaExercise } from '../../../types';
import { DESK_YOGA_EXERCISES } from '../data/postureData';

export const MicroBreakDeskYoga: React.FC = () => {
  const [selectedExercise, setSelectedExercise] = useState<DeskYogaExercise>(DESK_YOGA_EXERCISES[0]);
  const [exerciseTimer, setExerciseTimer] = useState<number>(DESK_YOGA_EXERCISES[0].durationSec);
  const [isExerciseTimerRunning, setIsExerciseTimerRunning] = useState<boolean>(false);
  const [completedExercisesCount, setCompletedExercisesCount] = useState<number>(2);

  // 20-20-20 Digital Eye Health Timer State
  const [eyeRestTimer, setEyeRestTimer] = useState<number>(20);
  const [isEyeRestActive, setIsEyeRestActive] = useState<boolean>(false);
  const [eyeRestStage, setEyeRestStage] = useState<'look_far' | 'palming' | 'done'>('look_far');

  // Integrated Pomodoro Ergonomic Timer (25m work / 5m desk stretch)
  const [pomodoroSeconds, setPomodoroSeconds] = useState<number>(25 * 60);
  const [isPomodoroRunning, setIsPomodoroRunning] = useState<boolean>(false);
  const [pomodoroMode, setPomodoroMode] = useState<'work' | 'desk_stretch'>('work');
  const [pomodoroCyclesCompleted, setPomodoroCyclesCompleted] = useState<number>(3);

  // Handle Desk Yoga Exercise Timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isExerciseTimerRunning && exerciseTimer > 0) {
      interval = setInterval(() => {
        setExerciseTimer((prev) => prev - 1);
      }, 1000);
    } else if (exerciseTimer === 0 && isExerciseTimerRunning) {
      setIsExerciseTimerRunning(false);
      setCompletedExercisesCount((c) => c + 1);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isExerciseTimerRunning, exerciseTimer]);

  // Handle 20-20-20 Eye Rest Timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isEyeRestActive && eyeRestTimer > 0) {
      interval = setInterval(() => {
        setEyeRestTimer((prev) => prev - 1);
      }, 1000);
    } else if (eyeRestTimer === 0 && isEyeRestActive) {
      if (eyeRestStage === 'look_far') {
        setEyeRestStage('palming');
        setEyeRestTimer(10);
      } else {
        setEyeRestStage('done');
        setIsEyeRestActive(false);
      }
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isEyeRestActive, eyeRestTimer, eyeRestStage]);

  // Handle Pomodoro Timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isPomodoroRunning && pomodoroSeconds > 0) {
      interval = setInterval(() => {
        setPomodoroSeconds((prev) => prev - 1);
      }, 1000);
    } else if (pomodoroSeconds === 0 && isPomodoroRunning) {
      if (pomodoroMode === 'work') {
        setPomodoroMode('desk_stretch');
        setPomodoroSeconds(5 * 60); // 5 min stretch break
        setPomodoroCyclesCompleted((c) => c + 1);
      } else {
        setPomodoroMode('work');
        setPomodoroSeconds(25 * 60);
      }
      setIsPomodoroRunning(false);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPomodoroRunning, pomodoroSeconds, pomodoroMode]);

  const handleSelectExercise = (ex: DeskYogaExercise) => {
    setSelectedExercise(ex);
    setExerciseTimer(ex.durationSec);
    setIsExerciseTimerRunning(false);
  };

  const handleStartEyeRest = () => {
    setIsEyeRestActive(true);
    setEyeRestStage('look_far');
    setEyeRestTimer(20);
  };

  const formatMinSec = (totalSeconds: number) => {
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m < 10 ? '0' + m : m}:${s < 10 ? '0' + s : s}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Ergonomic Pomodoro & 20-20-20 Quick Bar */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Ergonomic Pomodoro Timer Card */}
        <div className="p-5 rounded-3xl bg-white border border-slate-200/80 shadow-sm space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10.5px] font-black uppercase tracking-wider">
                Pomodoro Ergonomis
              </span>
              <span className="text-xs text-slate-400 font-bold">25m Kerja / 5m Stretch</span>
            </div>
            <span className="text-xs font-mono font-bold text-slate-600">
              {pomodoroCyclesCompleted} Siklus Selesai
            </span>
          </div>

          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-3xl sm:text-4xl font-black text-slate-900 font-mono tracking-tight">
                {formatMinSec(pomodoroSeconds)}
              </div>
              <span className="text-xs text-slate-500 font-medium">
                Mode:{' '}
                <strong className={pomodoroMode === 'work' ? 'text-indigo-600' : 'text-emerald-600'}>
                  {pomodoroMode === 'work' ? 'Fokus Bekerja (Flow State)' : 'Peregangan Meja (Desk Yoga)'}
                </strong>
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPomodoroRunning(!isPomodoroRunning)}
                className={`p-3 rounded-2xl text-white font-black transition-all cursor-pointer shadow-md ${
                  isPomodoroRunning
                    ? 'bg-amber-600 hover:bg-amber-700'
                    : 'bg-indigo-600 hover:bg-indigo-700'
                }`}
              >
                {isPomodoroRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </button>
              <button
                onClick={() => {
                  setIsPomodoroRunning(false);
                  setPomodoroSeconds(pomodoroMode === 'work' ? 25 * 60 : 5 * 60);
                }}
                className="p-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition-all cursor-pointer"
                title="Reset Timer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* 20-20-20 Digital Eye Health Relaxation Card */}
        <div className="p-5 rounded-3xl bg-gradient-to-br from-teal-900 to-slate-900 text-white shadow-sm space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-300 text-[10.5px] font-black uppercase tracking-wider border border-teal-500/30">
                Aturan 20-20-20 Digital
              </span>
              <span className="text-xs text-teal-200/70 font-medium">Relaksasi Mata Siliaris</span>
            </div>
            <Eye className="w-4 h-4 text-teal-400" />
          </div>

          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-3xl font-black text-teal-300 font-mono">
                {isEyeRestActive ? `${eyeRestTimer}s` : '20-20-20'}
              </div>
              <p className="text-xs text-slate-300 max-w-xs">
                {isEyeRestActive
                  ? eyeRestStage === 'look_far'
                    ? 'Tatap objek sejauh 6 meter (20 kaki) di luar jendela...'
                    : 'Tangkupkan telapak tangan hangat di depan mata (Palming)...'
                  : 'Alihkan mata dari layar setiap 20 menit selama 20 detik.'}
              </p>
            </div>

            <button
              onClick={handleStartEyeRest}
              disabled={isEyeRestActive}
              className="px-4 py-2.5 rounded-2xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-xs transition-all cursor-pointer shadow-md disabled:opacity-50"
            >
              {isEyeRestActive ? 'Berjalan...' : 'Mulai 20s'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Guided Desk Yoga Video/Interactive Stretches */}
      <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10.5px] font-black uppercase tracking-wider">
                Protokol Micro-Break Fisioterapi
              </span>
              <span className="text-xs text-slate-400 font-bold">1-2 Menit Sambil Duduk / Berdiri</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Peregangan Meja Kerja (Desk Yoga) & Mobilitas Sendi
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
              Rangkaian gerakan cepat untuk melepaskan spasme otot suboccipital, dekompresi tulang torakal, dan relaksasi terowongan karpal tangan.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-emerald-50 px-3 py-1.5 rounded-2xl border border-emerald-200 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span className="text-emerald-900 font-bold">
              {completedExercisesCount} Sesi Selesai Hari Ini
            </span>
          </div>
        </div>

        {/* Interactive Stretch Selector & Active Guide */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Exercise List Tabs */}
          <div className="lg:col-span-5 space-y-2">
            {DESK_YOGA_EXERCISES.map((ex) => {
              const isSelected = selectedExercise.id === ex.id;
              return (
                <button
                  key={ex.id}
                  onClick={() => handleSelectExercise(ex)}
                  className={`w-full p-4 rounded-2xl border text-left transition-all flex items-center justify-between gap-3 cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-50/80 border-emerald-300 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'bg-slate-50 hover:bg-white border-slate-200'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-slate-900">{ex.title}</span>
                    </div>
                    <span className="text-[11px] text-slate-500 block">
                      Target: {ex.targetArea}
                    </span>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-xs font-mono font-black text-emerald-700 bg-white px-2 py-0.5 rounded-md border border-emerald-200">
                      {ex.durationSec}s
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Active Guided Card & Live Timer */}
          <div className="lg:col-span-7 p-6 rounded-3xl bg-slate-900 text-white space-y-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-black uppercase tracking-wider border border-emerald-500/30">
                  {selectedExercise.title}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  {selectedExercise.repsOrHold}
                </span>
              </div>

              {/* Big Visual Countdown Timer */}
              <div className="flex items-center justify-center p-6 rounded-2xl bg-white/5 border border-white/10">
                <div className="text-center space-y-2">
                  <div className="text-5xl sm:text-6xl font-black font-mono tracking-tight text-emerald-400">
                    {exerciseTimer}s
                  </div>
                  <span className="text-xs text-slate-300 font-medium">
                    {isExerciseTimerRunning ? 'Pegang & rasakan tarikan lembut...' : 'Siap memulai gerakan'}
                  </span>
                </div>
              </div>

              {/* Step-by-Step Instructions */}
              <div className="space-y-2">
                <h5 className="text-xs font-black uppercase tracking-wider text-slate-400">
                  Langkah-Langkah Gerakan:
                </h5>
                <ol className="space-y-1.5 text-xs text-slate-300 list-decimal list-inside">
                  {selectedExercise.instructions.map((step, idx) => (
                    <li key={idx} className="leading-relaxed">
                      {step}
                    </li>
                  ))}
                </ol>
              </div>

              {/* Biomechanical Clinical Benefit */}
              <div className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 text-xs text-emerald-200">
                <strong>Manfaat Klinis:</strong> {selectedExercise.biomechanicalBenefit}
              </div>
            </div>

            {/* Timer Control Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setIsExerciseTimerRunning(!isExerciseTimerRunning)}
                className={`flex-1 py-3.5 rounded-2xl font-black text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md ${
                  isExerciseTimerRunning
                    ? 'bg-amber-600 hover:bg-amber-500 text-white'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-700/30'
                }`}
              >
                {isExerciseTimerRunning ? (
                  <>
                    <Pause className="w-4 h-4" />
                    <span>Jeda Peregangan</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4" />
                    <span>Mulai Timer ({selectedExercise.durationSec}s)</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  setIsExerciseTimerRunning(false);
                  setExerciseTimer(selectedExercise.durationSec);
                }}
                className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 text-slate-300 transition-all cursor-pointer"
                title="Reset"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
