import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  UserCheck,
  Camera,
  Activity,
  Sparkles,
  ArrowLeft,
  Sliders,
  ShieldCheck,
  Flame,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Volume2,
  Plus,
} from 'lucide-react';
import { UserProfile } from '../../types';
import { RealtimePostureMonitor } from './components/RealtimePostureMonitor';
import { MicroBreakDeskYoga } from './components/MicroBreakDeskYoga';
import { WorkstationAuditTool } from './components/WorkstationAuditTool';
import { DESK_YOGA_EXERCISES } from './data/postureData';

interface PostureScreenProps {
  userProfile: UserProfile;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const PostureScreen: React.FC<PostureScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';
  const [activeSubTab, setActiveSubTab] = useState<'monitor' | 'desk_yoga' | 'audit'>('monitor');

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-emerald-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m5_posture_ergonomics')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log Postur' : 'Log Posture Data'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #5:</span>
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-extrabold border border-emerald-300">
              {isIndonesian ? 'Kesehatan Postur & Ergonomi Kerja' : 'Posture Health & Ergonomics'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-emerald-600 via-teal-700 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-emerald-100 text-xs font-black">
              <UserCheck className="w-3.5 h-3.5 text-emerald-300" />
              <span>{isIndonesian ? 'Computer Vision & Analisis Biomekanika' : 'Computer Vision & Biomechanics'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Kesehatan Postur & Ergonomi Kerja' : 'Posture & Workspace Ergonomics'}
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Deteksi kemiringan leher (forward-head tilt), kompresi servikal C5-C7, dan dapatkan pengingat mikro-gerakan meja serta peregangan Desk Yoga.'
                : 'Real-time forward-head tilt analysis, cervical C5-C7 load tracking, and micro-stretch desk breaks.'}
            </p>
          </div>

          <div className="flex gap-2 bg-slate-950/40 p-1.5 rounded-2xl border border-white/10 shrink-0">
            <button
              onClick={() => setActiveSubTab('monitor')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'monitor'
                  ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {isIndonesian ? 'Live Monitor' : 'Live Monitor'}
            </button>
            <button
              onClick={() => setActiveSubTab('desk_yoga')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'desk_yoga'
                  ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {isIndonesian ? 'Desk Yoga' : 'Desk Yoga'}
            </button>
            <button
              onClick={() => setActiveSubTab('audit')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeSubTab === 'audit'
                  ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {isIndonesian ? 'Audit Meja' : 'Desk Audit'}
            </button>
          </div>
        </div>
      </div>

      {/* Subtab Views */}
      {activeSubTab === 'monitor' && (
        <RealtimePostureMonitor onTriggerDeskYoga={() => setActiveSubTab('desk_yoga')} />
      )}

      {activeSubTab === 'desk_yoga' && (
        <MicroBreakDeskYoga
          exercises={DESK_YOGA_EXERCISES}
          onCompleteSession={() => onAwardXp && onAwardXp(60)}
        />
      )}

      {activeSubTab === 'audit' && (
        <WorkstationAuditTool
          userProfile={userProfile}
          onSaveAuditScore={(score) => onAwardXp && onAwardXp(score)}
        />
      )}
    </div>
  );
};
