import { DeskYogaExercise, ErgonomicAuditItem, PostureHourlyHeatmapPoint, CaseStudyBudiProfile } from '../../../types';

export const DESK_YOGA_EXERCISES: DeskYogaExercise[] = [
  {
    id: 'dy1',
    title: 'Chin Tuck Retraction (Anti-Text Neck)',
    titleEn: 'Chin Tuck Retraction',
    category: 'neck_cervical',
    targetArea: 'Otot Deep Neck Flexors & Suboccipital',
    durationSec: 30,
    repsOrHold: '5 repetisi x 5 detik tahan',
    instructions: [
      'Duduk tegak, pandangan lurus ke depan.',
      'Tarik dagu horizontal lurus ke belakang tanpa menundukkan kepala (seperti membuat double chin).',
      'Rasakan peregangan lembut di pangkal tengkorak dan bagian belakang leher.',
      'Tahan selama 5 detik, lalu rileks kembali ke posisi netral.',
    ],
    biomechanicalBenefit: 'Mengaktifkan longus colli & capitis, meredakan tekanan kompresi pada diskus intervertebra C5-C7.',
    recommendedFrequency: 'Setiap 45-60 menit saat bekerja di depan monitor.',
  },
  {
    id: 'dy2',
    title: 'Doorway & Seated Chest Opener (Pectoral Stretch)',
    titleEn: 'Seated Chest Opener',
    category: 'shoulder_chest',
    targetArea: 'Pectoralis Major & Minor, Anterior Deltoid',
    durationSec: 45,
    repsOrHold: '3 set x 15 detik tahan',
    instructions: [
      'Kaitkan kedua jemari tangan di belakang punggung bawah atau pegang sandaran kursi.',
      'Tarik kedua tulang belikat (scapula) saling mendekat ke arah tengah tulang belakang.',
      'Dorong dada ke depan dan ke atas perlahan sambil menarik napas dalam.',
      'Jaga leher tetap rileks dan jangan mendongak berlebihan.',
    ],
    biomechanicalBenefit: 'Melawan postur bahu melorot ke depan (Rounded Shoulders) dan memperluas kapasitas ekspansi rongga dada.',
    recommendedFrequency: '2-3 kali sehari, terutama setelah mengetik intens.',
  },
  {
    id: 'dy3',
    title: 'Seated Thoracic Spinal Twist (Rotasi Tulang Belakang)',
    titleEn: 'Seated Spinal Twist',
    category: 'thoracic_back',
    targetArea: 'Torakal T1-T12, Obliques, Rhomboids',
    durationSec: 40,
    repsOrHold: '2 set per sisi x 10 detik',
    instructions: [
      'Duduk tegak dengan kedua telapak kaki menapak rata di lantai.',
      'Letakkan tangan kanan di bagian luar paha kiri atau pegangan kursi kiri.',
      'Putar torso perlahan ke arah kiri dari perut hingga dada dan bahu.',
      'Tahan selama 10 detik dengan napas teratur, ulangi untuk sisi sebaliknya.',
    ],
    biomechanicalBenefit: 'Meningkatkan hidrasi diskus torakal dan mobilitas rotasi tulang punggung yang kaku akibat duduk diam.',
    recommendedFrequency: 'Setiap jeda Pomodoro (25-50 menit).',
  },
  {
    id: 'dy4',
    title: 'Wrist Flexor & Extensor Stretch (Anti-Carpal Tunnel)',
    titleEn: 'Wrist & Forearm Release',
    category: 'wrist_hands',
    targetArea: 'Flexor Digitorum, Pronator Teres, Median Nerve Path',
    durationSec: 30,
    repsOrHold: '15 detik per variasi per tangan',
    instructions: [
      'Luruskan satu tangan ke depan setinggi bahu dengan telapak menghadap ke depan (jari mengarah ke atas).',
      'Gunakan tangan lain untuk menarik lembut jari-jari ke arah tubuh hingga terasa tarikan di pergelangan tangan bawah.',
      'Balikkan tangan (jari mengarah ke bawah) dan tarik lembut punggung tangan ke arah tubuh.',
    ],
    biomechanicalBenefit: 'Mengurangi tekanan mekanis pada terowongan karpal (Carpal Tunnel) akibat posisi mengetik dan menggeser mouse datar.',
    recommendedFrequency: 'Setiap 60 menit atau sebelum mengetik laporan panjang.',
  },
  {
    id: 'dy5',
    title: 'Seated Figure-4 Hip & Glute Opener (Anti-Kaku Pinggul)',
    titleEn: 'Seated Figure-4 Stretch',
    category: 'hips_lumbar',
    targetArea: 'Piriformis, Gluteus Medius, Otot Panggul Dalam',
    durationSec: 45,
    repsOrHold: '20 detik per kaki',
    instructions: [
      'Duduk di ujung kursi dengan punggung tegak.',
      'Silangkan pergelangan kaki kanan di atas lutut kiri (membentuk angka 4).',
      'Condongkan tubuh ke depan dari engsel pinggul (bukan membungkukkan punggung) sampai terasa tarikan di bokong kanan.',
      'Tahan 20 detik, lalu ganti kaki kiri.',
    ],
    biomechanicalBenefit: 'Meredakan kompresi saraf skiatika (Sciatic Nerve) dan mengurangi kekakuan pinggul akibat duduk lama.',
    recommendedFrequency: 'Siang dan sore hari saat istirahat kerja.',
  },
  {
    id: 'dy6',
    title: 'Aturan 20-20-20 & Gaze Palming (Relaksasi Mata Digital)',
    titleEn: '20-20-20 Eye Rest & Palming',
    category: 'eyes_20_20',
    targetArea: 'Otot Siliaris Mata & Syaraf Optik',
    durationSec: 30,
    repsOrHold: '20 detik tatap jauh + 10 detik palming hangat',
    instructions: [
      'Setiap 20 menit, alihkan pandangan dari layar.',
      'Fokuskan mata pada objek yang berada setidaknya 20 kaki (sekitar 6 meter) di luar jendela.',
      'Gosokkan kedua telapak tangan hingga terasa hangat, lalu tangkupkan di atas kedua kelopak mata tanpa menekan bola mata.',
      'Kedipkan mata 5 kali perlahan untuk melumasi kornea.',
    ],
    biomechanicalBenefit: 'Mengurangi spasme akomodasi otot mata, mencegah Computer Vision Syndrome dan mata kering.',
    recommendedFrequency: 'Setiap 20 menit (otomatis dengan Pomodoro Vision).',
  },
];

export const INITIAL_ERGONOMIC_AUDIT_ITEMS: ErgonomicAuditItem[] = [
  {
    id: 'ea1',
    category: 'monitor',
    title: 'Ketinggian & Jarak Monitor',
    idealStandard: 'Tepi atas layar sejajar garis mata, jarak 50-70 cm (sepanjang satu lengan).',
    currentStatus: 'needs_adjustment',
    userChoiceOption: 'Layar laptop berada di atas meja tanpa ganjalan',
    actionableFix: 'Ganjal laptop setinggi 10-15 cm menggunakan laptop stand atau tumpukan buku, gunakan keyboard dan mouse eksternal.',
    biomechanicalReason: 'Layar yang terlalu rendah memaksa fleksi leher 30°-45°, membebani leher setara 18-22 kg.',
    recommendedGear: {
      name: 'Aluminium Adjustable Laptop Stand + Keyboard Nirkabel',
      benefit: 'Menaikkan titik fokus pandang sejajar mata tanpa mengangkat bahu saat mengetik.',
      estimatedPriceIdr: 'Rp 149.000 - Rp 280.000',
    },
  },
  {
    id: 'ea2',
    category: 'keyboard_mouse',
    title: 'Posisi Siku, Keyboard & Mouse',
    idealStandard: 'Siku membentuk sudut 90°-100°, pergelangan tangan lurus netral, bahu rileks.',
    currentStatus: 'high_risk',
    userChoiceOption: 'Menggunakan mouse datar konvensional, siku menggantung di udara',
    actionableFix: 'Rapatkan kursi ke meja sehingga lengan bawah tertopang armrest atau permukaan meja. Ganti mouse datar dengan vertical mouse.',
    biomechanicalReason: 'Mouse konvensional memaksa pronasi lengan bawah 90° konstan, memicu ketegangan otot ekstensor pergelangan dan trapezius atas.',
    recommendedGear: {
      name: 'Ergonomic Vertical Mouse 57° Handshake Angle',
      benefit: 'Mengembalikan posisi lengan bawah ke handshake netral, meredakan Carpal Tunnel & nyeri bahu.',
      estimatedPriceIdr: 'Rp 185.000 - Rp 350.000',
    },
  },
  {
    id: 'ea3',
    category: 'chair_lumbar',
    title: 'Dukungan Sandaran Punggung Bawah (Lumbar Support)',
    idealStandard: 'Sandaran kursi menyentuh dan menopang lengkung lordosis pinggang bawah (L1-L5).',
    currentStatus: 'needs_adjustment',
    userChoiceOption: 'Kursi kerja tanpa lengkungan lumbar, punggung bawah menggantung',
    actionableFix: 'Tempatkan bantal memori lumbar atau gulungan handuk berdiameter 10 cm tepat di atas tulang panggul belakang.',
    biomechanicalReason: 'Ketiadaan dukungan lumbar menyebabkan panggul miring ke belakang (posterior pelvic tilt), memicu herniasi diskus lumbal.',
    recommendedGear: {
      name: 'Memory Foam Ergonomic Lumbar Cushion',
      benefit: 'Mempertahankan kurva natural lordosis tulang belakang saat duduk berjam-jam.',
      estimatedPriceIdr: 'Rp 95.000 - Rp 220.000',
    },
  },
  {
    id: 'ea4',
    category: 'foot_placement',
    title: 'Pijakan Kaki & Ketinggian Kursi',
    idealStandard: 'Kedua telapak kaki menapak rata di lantai atau footrest, paha paralel dengan lantai (sudut lutut 90°-100°).',
    currentStatus: 'ideal',
    userChoiceOption: 'Kaki menapak rata di lantai dengan sudut lutut 90°',
    actionableFix: 'Pertahankan posisi ini. Hindari kebiasaan menyilangkan kaki lebih dari 10 menit.',
    biomechanicalReason: 'Menyilangkan kaki menghambat sirkulasi balik vena dan menyebabkan rotasi asimetris pada sendi sakroiliaka panggul.',
    recommendedGear: {
      name: 'Angled Ergonomic Footrest Rocker',
      benefit: 'Mendorong sirkulasi darah betis dan menjaga posisi duduk tegak optimal.',
      estimatedPriceIdr: 'Rp 120.000 - Rp 210.000',
    },
  },
  {
    id: 'ea5',
    category: 'lighting_eyes',
    title: 'Pencahayaan Ruangan & Silau Layar',
    idealStandard: 'Pencahayaan merata tanpa silau langsung ke layar, layar bebas pantulan lampu.',
    currentStatus: 'ideal',
    userChoiceOption: 'Lampu ruangan cukup terang dan monitor bebas pantulan',
    actionableFix: 'Gunakan lampu meja bias atau screenbar jika bekerja di malam hari.',
    biomechanicalReason: 'Silau layar menyebabkan mata menyipit dan kepala otomatis maju mendekat ke layar (memicu forward head posture).',
    recommendedGear: {
      name: 'Monitor LED Screenbar Light with Asymmetric Optics',
      benefit: 'Menerangi area kerja tanpa memantulkan silau ke layar monitor.',
      estimatedPriceIdr: 'Rp 199.000 - Rp 450.000',
    },
  },
];

export const SAMPLE_HOURLY_POSTURE_HEATMAP: PostureHourlyHeatmapPoint[] = [
  { hourLabel: '08:00', score: 94, dominantAnomaly: 'optimal', slouchPercentage: 6, microBreakTaken: true },
  { hourLabel: '09:00', score: 91, dominantAnomaly: 'optimal', slouchPercentage: 9, microBreakTaken: true },
  { hourLabel: '10:00', score: 85, dominantAnomaly: 'forward_head', slouchPercentage: 15, microBreakTaken: true },
  { hourLabel: '11:00', score: 80, dominantAnomaly: 'shoulder_hunch', slouchPercentage: 20, microBreakTaken: false },
  { hourLabel: '12:00', score: 95, dominantAnomaly: 'optimal', slouchPercentage: 5, microBreakTaken: true }, // Lunch break
  { hourLabel: '13:00', score: 78, dominantAnomaly: 'slouching', slouchPercentage: 24, microBreakTaken: true },
  { hourLabel: '14:00', score: 58, dominantAnomaly: 'slouching', slouchPercentage: 42, microBreakTaken: false }, // Fatigue peak start
  { hourLabel: '15:00', score: 46, dominantAnomaly: 'forward_head', slouchPercentage: 54, microBreakTaken: false }, // Critical zone
  { hourLabel: '16:00', score: 52, dominantAnomaly: 'asymmetrical_shoulder', slouchPercentage: 48, microBreakTaken: true }, // After stretch
  { hourLabel: '17:00', score: 72, dominantAnomaly: 'forward_head', slouchPercentage: 28, microBreakTaken: true },
];

export const CASE_STUDY_BUDI: CaseStudyBudiProfile = {
  personaName: 'Budi Santoso',
  role: 'Senior Software Engineer (Remote WFH)',
  age: 28,
  dailyScreenTimeHours: 9.5,
  initialComplaint:
    'Sering mengalami sakit kepala tegang (Tension Headache) berdenyut di sore hari (pukul 15:00), nyeri pegal konstan di pundak kanan, dan leher kaku saat menoleh.',
  baselinePostureMetrics: {
    forwardHeadDistanceCm: 10,
    craniovertebralAngle: 38, // Severe text neck (normal >50°)
    cervicalSpineLoadKg: 24.5, // Berat setara membawa galon kecil di leher
    rightShoulderElevationDeg: 5.2, // Bahu kanan naik karena mouse datar
    dailyPostureScore: 48,
  },
  aiInterventionPlan: {
    workstationAdjustments: [
      'Menaikkan laptop 12 cm dengan laptop stand agar tepi atas layar pas di garis pupil mata.',
      'Menambahkan gulungan handuk/bantal lumbar pada lekukan pinggang bawah kursi kerja.',
      'Mengatur tinggi meja sehingga lengan bertumpu dengan sudut siku 90 derajat rileks.',
    ],
    equipmentPrescriptions: [
      'Beralih dari mouse flat standar ke Ergonomic Vertical Mouse 57° untuk meredakan rotasi internal bahu kanan.',
      'Menggunakan keyboard eksternal tenkeyless agar mouse lebih dekat dengan garis tengah tubuh.',
    ],
    deskYogaMicroBreaks: [
      'Chin Tuck Retraction: 5 repetisi x 5 detik tahan setiap 45 menit.',
      'Doorway Pec Stretch: 3 set x 15 detik saat jam 12:00 dan 15:30.',
      'Aturan 20-20-20 Pomodoro untuk relaksasi mata dan otot leher atas.',
    ],
    adaptiveAlertCadence: 'Peringatan visual lembut jika postur kepala maju >30 detik tanpa mengganggu saat mode coding intens.',
  },
  clinicalOutcomeAfter14Days: {
    headacheFrequencyReductionPercent: 85, // Dari 5 hari/minggu menjadi <1 kali
    craniovertebralAngleIncrease: 14, // dari 38° naik ke 52° (Zona Normal)
    cervicalSpineLoadReductionKg: 18.3, // Beban turun dari 24.5kg menjadi 6.2kg
    dailyPostureScoreFinal: 88,
    productivityRatingDeltaPercent: 28, // Peningkatan fokus dan kenyamanan kerja
  },
  keyTakeaways: [
    'Sakit kepala tegang di tempat kerja mayoritas berakar dari kompresi otot suboccipital akibat posisi kepala menjorok ke depan.',
    'Vertical mouse terbukti secara klinis menurunkan aktivitas otot trapezius atas hingga 35%.',
    'Intervensi mikro 30 detik (Chin Tucks) jauh lebih efektif dibanding menunggu nyeri parah di akhir pekan.',
  ],
};
