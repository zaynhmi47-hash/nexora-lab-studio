import React, { useState, useEffect, useRef } from 'react';
import {
  Camera,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  ShieldCheck,
  ShieldAlert,
  Award,
  Activity,
  Sparkles,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Flame,
  ArrowRight,
  ArrowLeft,
  TrendingUp,
  User,
  Zap,
  Info,
  RefreshCw,
  Eye,
  Settings,
  Layers,
} from 'lucide-react';
import {
  UserProfile,
  LanguageCode,
  FormGuardExerciseId,
  BiomechanicalFrameState,
  LandmarkPoint,
  FormGuardPostSetReport,
} from '../../types';
import { FORM_GUARD_EXERCISES, CASE_STUDY_SARI_DATA } from '../../data/formGuardExercises';
import {
  generateSimulatedLandmarks,
  evaluateFrameBiometrics,
  generatePostSetReport,
} from '../../services/FormGuardEngine';
import { VideoMotionTracker, MotionAnalysisResult } from '../../services/VideoMotionTracker';
import { SkeletonCanvasOverlay } from './components/SkeletonCanvasOverlay';
import { PostSetBreakdownModal } from './components/PostSetBreakdownModal';
import { CaseStudySariModal } from './components/CaseStudySariModal';
import { CalibrationGuideModal } from './components/CalibrationGuideModal';
import { Upload, Video as VideoIcon, Gauge, Compass } from 'lucide-react';

interface FormGuardScreenProps {
  userProfile: UserProfile;
  initialExerciseId?: FormGuardExerciseId;
  onNavigateTab?: (tab: string) => void;
}

export const FormGuardScreen: React.FC<FormGuardScreenProps> = ({
  userProfile,
  initialExerciseId = 'push_up',
  onNavigateTab,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // Exercise selection
  const [selectedExerciseId, setSelectedExerciseId] = useState<FormGuardExerciseId>(initialExerciseId);
  const currentExerciseConfig =
    FORM_GUARD_EXERCISES.find((e) => e.id === selectedExerciseId) || FORM_GUARD_EXERCISES[0];

  // Video Source & Mode States: 'camera' | 'upload' | 'simulated'
  const [videoMode, setVideoMode] = useState<'camera' | 'upload' | 'simulated'>('camera');
  const [useRealCamera, setUseRealCamera] = useState(true);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('user');
  const [uploadedVideoUrl, setUploadedVideoUrl] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Video Computer Vision Motion Tracker
  const motionTrackerRef = useRef<VideoMotionTracker>(new VideoMotionTracker(1.2));
  const [motionSensitivity, setMotionSensitivity] = useState<'low' | 'medium' | 'high' | 'ultra'>('high');
  const [motionMetrics, setMotionMetrics] = useState<MotionAnalysisResult>({
    motionEnergy: 0,
    centroidX: 0.5,
    centroidY: 0.5,
    verticalDisplacement: 0,
    horizontalDisplacement: 0,
    motionDirection: 'stationary',
    cycleProgress: 0,
    detectedRepIncrement: false,
    isFormCompromised: false,
    asymmetryScore: 0,
    tempoSpeed: 0,
    motionHeatPoints: [],
  });

  // Active Session & Rep Counter States
  const [isRunning, setIsRunning] = useState(true);
  const [repCount, setRepCount] = useState(5);
  const [cleanReps, setCleanReps] = useState(4);
  const [compromisedReps, setCompromisedReps] = useState(1);
  const [cycleProgress, setCycleProgress] = useState(0); // 0 to 1
  const [errorSimulationType, setErrorSimulationType] = useState<string>('sari_case');

  // Error distribution accumulator for post-set heatmap
  const [errorDistribution, setErrorDistribution] = useState<Record<string, number>>({
    left_elbow: 3,
    left_shoulder: 1,
    hips: 1,
  });

  // Audio Voice Coach State
  const [isVoiceMuted, setIsVoiceMuted] = useState(false);
  const [lastSpokenCue, setLastSpokenCue] = useState<string>(
    'Kamera AI aktif membaca pergerakan tubuh Anda secara real-time.'
  );
  const lastSpokenTimestampRef = useRef<number>(0);

  // Modals
  const [isPostSetModalOpen, setIsPostSetModalOpen] = useState(false);
  const [isCaseStudyModalOpen, setIsCaseStudyModalOpen] = useState(false);
  const [isCalibrationModalOpen, setIsCalibrationModalOpen] = useState(false);
  const [activeTabSubView, setActiveTabSubView] = useState<'studio' | 'matrix'>('studio');
  const [sensitivityLevel, setSensitivityLevel] = useState<'beginner' | 'intermediate' | 'elite'>('beginner');

  // Live Biomechanical Frame State
  const [landmarks, setLandmarks] = useState<Record<string, LandmarkPoint>>(() =>
    generateSimulatedLandmarks(selectedExerciseId, 0, true, errorSimulationType)
  );
  const [frameState, setFrameState] = useState<BiomechanicalFrameState>(() =>
    evaluateFrameBiometrics(currentExerciseConfig, landmarks, repCount, 0, true, errorSimulationType)
  );

  // Update motion tracker sensitivity
  useEffect(() => {
    motionTrackerRef.current.setSensitivity(motionSensitivity);
  }, [motionSensitivity]);

  // Speech Synthesis Helper with Smart Debouncing
  const triggerVoiceCue = (cueText: string) => {
    if (isVoiceMuted || typeof window === 'undefined' || !window.speechSynthesis) return;
    const now = Date.now();
    if (now - lastSpokenTimestampRef.current < 4500) return; // Cooldown 4.5s

    lastSpokenTimestampRef.current = now;
    setLastSpokenCue(cueText);

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(cueText);
      utterance.lang = isIndonesian ? 'id-ID' : 'en-US';
      utterance.rate = 1.05;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error:', e);
    }
  };

  // Real Webcam MediaStream Handler
  useEffect(() => {
    let stream: MediaStream | null = null;
    if (videoMode === 'camera' && useRealCamera) {
      navigator.mediaDevices
        ?.getUserMedia({
          video: { facingMode: cameraFacing, width: { ideal: 640 }, height: { ideal: 480 } },
          audio: false,
        })
        .then((s) => {
          stream = s;
          if (videoRef.current) {
            videoRef.current.srcObject = s;
            videoRef.current.play().catch(() => {});
            setIsCameraReady(true);
          }
        })
        .catch((err) => {
          console.warn('Webcam permission denied or not available:', err);
          setIsCameraReady(false);
        });
    } else {
      if (videoRef.current && videoRef.current.srcObject) {
        const s = videoRef.current.srcObject as MediaStream;
        s.getTracks().forEach((t) => t.stop());
        videoRef.current.srcObject = null;
      }
      setIsCameraReady(false);
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [videoMode, useRealCamera, cameraFacing]);

  // Handle Video File Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setUploadedVideoUrl(url);
    setVideoMode('upload');
    setUseRealCamera(false);
    motionTrackerRef.current.resetCalibration();
    if (videoRef.current) {
      videoRef.current.src = url;
      videoRef.current.loop = true;
      videoRef.current.play().catch(() => {});
    }
  };

  // Main Motion Engine & Computer Vision Video Reading Loop
  useEffect(() => {
    let animFrame: number;
    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      if (isRunning) {
        const delta = (currentTime - lastTime) / 1000;
        lastTime = currentTime;

        let activeProgress = cycleProgress;
        let isRealMotionActive = false;

        // Process real video movement if video element is active and ready
        if (videoRef.current && (videoMode === 'camera' || videoMode === 'upload') && videoRef.current.readyState >= 2) {
          const mResult = motionTrackerRef.current.processFrame(videoRef.current);
          setMotionMetrics(mResult);

          if (mResult.motionEnergy > 2) {
            isRealMotionActive = true;
            activeProgress = mResult.cycleProgress;
            setCycleProgress(mResult.cycleProgress);

            // Real Rep Count Trigger from Video Inflection
            if (mResult.detectedRepIncrement) {
              setRepCount((r) => {
                const newRep = r + 1;
                if (mResult.isFormCompromised || errorSimulationType !== 'none') {
                  setCompromisedReps((c) => c + 1);
                  if (mResult.asymmetryScore > 40) {
                    setErrorDistribution((d) => ({ ...d, left_elbow: (d.left_elbow || 0) + 1 }));
                  }
                } else {
                  setCleanReps((c) => c + 1);
                }
                return newRep;
              });

              if (mResult.isFormCompromised) {
                triggerVoiceCue(
                  isIndonesian
                    ? 'Asimetri atau ketidakstabilan gerakan terdeteksi! Jaga keseimbangan.'
                    : 'Asymmetry or instability detected! Maintain balance.'
                );
              }
            }
          }
        }

        // If no real motion or in pure simulation mode, advance simulated rep cycle
        if (!isRealMotionActive) {
          setCycleProgress((prev) => {
            const next = prev + delta * 0.32;
            if (next >= 1.0) {
              setRepCount((r) => {
                const newRep = r + 1;
                if (errorSimulationType !== 'none') {
                  setCompromisedReps((c) => c + 1);
                  if (errorSimulationType === 'sari_case' || errorSimulationType === 'elbow_flare') {
                    setErrorDistribution((d) => ({ ...d, left_elbow: (d.left_elbow || 0) + 1 }));
                  } else if (errorSimulationType === 'valgus') {
                    setErrorDistribution((d) => ({ ...d, left_knee: (d.left_knee || 0) + 1 }));
                  } else if (errorSimulationType === 'lumbar_flexion' || errorSimulationType === 'hip_sag') {
                    setErrorDistribution((d) => ({ ...d, lumbar_spine: (d.lumbar_spine || 0) + 1 }));
                  }
                } else {
                  setCleanReps((c) => c + 1);
                }
                return newRep;
              });
              return 0;
            }
            return next;
          });
          activeProgress = cycleProgress;
        }

        // Compute simulated landmarks modulated by real video motion centroid offsets
        const isError = errorSimulationType !== 'none' || motionMetrics.isFormCompromised;
        const newLandmarks = generateSimulatedLandmarks(
          selectedExerciseId,
          activeProgress,
          isError,
          errorSimulationType
        );

        // Dynamically adjust landmark positions based on real detected body shift
        if (isRealMotionActive) {
          const shiftX = (motionMetrics.centroidX - 0.5) * 0.4;
          const shiftY = motionMetrics.verticalDisplacement * 0.3;
          Object.keys(newLandmarks).forEach((k) => {
            newLandmarks[k].x = Math.max(0.05, Math.min(0.95, newLandmarks[k].x + shiftX));
            newLandmarks[k].y = Math.max(0.05, Math.min(0.95, newLandmarks[k].y + shiftY));
          });
        }

        setLandmarks(newLandmarks);

        // Biomechanical Evaluation
        const newFrameState = evaluateFrameBiometrics(
          currentExerciseConfig,
          newLandmarks,
          repCount,
          activeProgress,
          isError,
          errorSimulationType
        );
        setFrameState(newFrameState);

        // Active voice cues
        if (newFrameState.activeCorrections.length > 0) {
          triggerVoiceCue(newFrameState.activeCorrections[0].message);
        }
      }

      animFrame = requestAnimationFrame(loop);
    };

    animFrame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrame);
  }, [
    isRunning,
    cycleProgress,
    selectedExerciseId,
    currentExerciseConfig,
    repCount,
    errorSimulationType,
    videoMode,
    motionMetrics.isFormCompromised,
    motionMetrics.asymmetryScore,
    isIndonesian,
  ]);

  // Handle post set modal generation
  const handleOpenPostSetReport = () => {
    setIsRunning(false);
    setIsPostSetModalOpen(true);
  };

  const currentReport: FormGuardPostSetReport = generatePostSetReport(
    selectedExerciseId,
    repCount,
    cleanReps,
    compromisedReps,
    frameState.overallFormScore,
    frameState.technicalFatigueDetected || errorSimulationType === 'sari_case',
    errorDistribution
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-24 transition-colors">
      {/* TOP NAVIGATION BREADCRUMB & BACK BUTTON */}
      <div className="bg-white border-b border-slate-200 px-3 sm:px-6 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <button
            onClick={() => onNavigateTab ? onNavigateTab('landing') : undefined}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{isIndonesian ? 'Kembali ke Beranda / Google Health Hub' : 'Back to Home / Google Health Hub'}</span>
          </button>

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Halaman Modul:</span>
            <span className="px-3 py-1 rounded-full bg-teal-100 text-teal-900 font-extrabold border border-teal-300">
              #2 FormGuard CV Biomekanik
            </span>
          </div>
        </div>
      </div>

      {/* Header Banner */}
      <div className="bg-white border-b border-emerald-100 sticky top-0 z-20 shadow-2xs backdrop-blur-md bg-white/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-linear-to-tr from-emerald-600 to-teal-700 flex items-center justify-center text-white shadow-xs">
              <Camera className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black text-slate-900 tracking-tight">FormGuard AI</h1>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-2xs font-bold uppercase tracking-wider border border-emerald-200">
                  {isIndonesian ? 'Modul 2: Computer Vision' : 'Module 2: Computer Vision'}
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 text-2xs font-bold border border-teal-200">
                  Edge AI &lt;50ms
                </span>
              </div>
              <p className="text-xs text-slate-700 font-medium">
                {isIndonesian
                  ? 'Teknik Sempurna, Cedera Minimal, Hasil Maksimal • 33 Titik Sendi On-Device'
                  : 'Perfect Technique, Minimal Injury, Maximum Results • 33-Point On-Device Pose Scan'}
              </p>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
            <button
              onClick={() => setIsCaseStudyModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 border border-teal-200 text-teal-800 text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer shadow-2xs"
            >
              <User className="w-3.5 h-3.5 text-teal-700" />
              <span>{isIndonesian ? 'Studi Kasus Sari' : 'Sari Case Study'}</span>
            </button>

            <button
              onClick={() => setIsCalibrationModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-slate-600" />
              <span>{isIndonesian ? 'Kalibrasi Sensor' : 'Calibration'}</span>
            </button>

            <button
              onClick={() => setActiveTabSubView(activeTabSubView === 'studio' ? 'matrix' : 'studio')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
                activeTabSubView === 'matrix'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{activeTabSubView === 'matrix' ? 'Kembali ke Studio' : 'Matriks Sudut'}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-5 space-y-6">
        {/* Sub-view Matrix Table (if selected) */}
        {activeTabSubView === 'matrix' ? (
          <div className="bg-white rounded-3xl p-6 border border-emerald-100 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-black text-slate-900">
                  {isIndonesian ? 'Matriks Sudut Biomekanika Kritis & Risiko Cedera' : 'Biomechanical Angle & Injury Matrix'}
                </h2>
                <p className="text-xs text-slate-700">
                  {isIndonesian
                    ? 'Batas sudut fisiologis yang dipantau real-time oleh FormGuard AI untuk setiap latihan.'
                    : 'Physiological angle thresholds tracked in real-time by FormGuard AI.'}
                </p>
              </div>
              <button
                onClick={() => setActiveTabSubView('studio')}
                className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold shadow-xs cursor-pointer"
              >
                {isIndonesian ? 'Buka Live Studio CV' : 'Open CV Studio'}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {FORM_GUARD_EXERCISES.map((ex) => (
                <div key={ex.id} className="bg-slate-50 rounded-2xl p-4.5 border border-slate-200/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-slate-900">{ex.name}</h3>
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-2xs font-bold uppercase">
                      {ex.category.replace('_', ' ')}
                    </span>
                  </div>
                  <p className="text-2xs text-slate-700 font-medium">
                    <strong className="text-slate-900 font-bold">Target Otot: </strong>
                    {ex.primaryTarget}
                  </p>

                  <div className="space-y-1.5 pt-2 border-t border-slate-200">
                    <span className="text-2xs font-bold uppercase tracking-wider text-slate-700 block">
                      {isIndonesian ? 'Sudut Kritis yang Dipantau:' : 'Monitored Angles:'}
                    </span>
                    {ex.criticalAngles.map((ang, i) => (
                      <div key={i} className="bg-white p-2.5 rounded-xl border border-slate-200 text-xs">
                        <div className="flex items-center justify-between font-bold text-slate-800">
                          <span>{ang.name}</span>
                          <span className="text-emerald-700">
                            {ang.idealMin}{ang.unit} - {ang.idealMax}{ang.unit}
                          </span>
                        </div>
                        <p className="text-3xs text-slate-700 mt-1 leading-tight">{ang.riskDescription}</p>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => {
                      setSelectedExerciseId(ex.id);
                      setActiveTabSubView('studio');
                    }}
                    className="w-full py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-2xs cursor-pointer text-center block mt-2"
                  >
                    {isIndonesian ? 'Latih Gerakan Ini di CV Studio' : 'Train This in CV Studio'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <>
            {/* Top Video Mode Selector & Exercise Switcher */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs">
              {/* Exercise Selector */}
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 md:pb-0">
                <span className="text-xs font-bold text-slate-500 shrink-0">Gerakan:</span>
                {FORM_GUARD_EXERCISES.map((ex) => {
                  const isSelected = selectedExerciseId === ex.id;
                  return (
                    <button
                      key={ex.id}
                      onClick={() => {
                        setSelectedExerciseId(ex.id);
                        setCycleProgress(0);
                        setRepCount(1);
                        setCleanReps(1);
                        setCompromisedReps(0);
                      }}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      <span>{ex.name}</span>
                      {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />}
                    </button>
                  );
                })}
              </div>

              {/* Video Source Modes: Webcam, Upload Video, Simulated */}
              <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl shrink-0">
                <button
                  onClick={() => {
                    setVideoMode('camera');
                    setUseRealCamera(true);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    videoMode === 'camera'
                      ? 'bg-white text-emerald-800 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Kamera Live</span>
                </button>

                <button
                  onClick={() => fileInputRef.current?.click()}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    videoMode === 'upload'
                      ? 'bg-white text-emerald-800 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Unggah Video</span>
                </button>

                <button
                  onClick={() => {
                    setVideoMode('simulated');
                    setUseRealCamera(false);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    videoMode === 'simulated'
                      ? 'bg-white text-emerald-800 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <VideoIcon className="w-3.5 h-3.5" />
                  <span>Simulasi</span>
                </button>
              </div>
            </div>

            {/* Main Computer Vision Studio Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              {/* Left Column: Visual Viewport with Skeleton Overlay & Real Motion HUD */}
              <div className="lg:col-span-8 space-y-4">
                <div className="relative aspect-4/3 w-full bg-slate-950 rounded-3xl overflow-hidden border-2 border-slate-800 shadow-xl flex items-center justify-center">
                  {/* Real Camera Feed or Uploaded Video */}
                  {videoMode === 'camera' ? (
                    <video
                      ref={videoRef}
                      playsInline
                      autoPlay
                      muted
                      className={`w-full h-full object-cover ${cameraFacing === 'user' ? 'scale-x-[-1]' : ''}`}
                    />
                  ) : videoMode === 'upload' && uploadedVideoUrl ? (
                    <video
                      ref={videoRef}
                      src={uploadedVideoUrl}
                      playsInline
                      autoPlay
                      loop
                      muted
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full relative bg-linear-to-b from-slate-900 via-slate-950 to-slate-900 flex items-center justify-center overflow-hidden">
                      {/* Perspective Grid Background */}
                      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-30" />
                      <div className="absolute bottom-6 left-0 right-0 h-1 bg-emerald-500/20 border-b border-emerald-500/40" />
                      <div className="w-56 h-80 rounded-full bg-emerald-500/5 blur-3xl" />
                    </div>
                  )}

                  {/* Interactive Skeleton Canvas Overlay with Real-time Motion Heatpoints */}
                  <SkeletonCanvasOverlay
                    landmarks={landmarks}
                    frameState={frameState}
                    width={640}
                    height={480}
                    showAngleBadges={true}
                    showArrows={true}
                    motionHeatPoints={motionMetrics.motionHeatPoints}
                    motionEnergy={motionMetrics.motionEnergy}
                    motionDirection={motionMetrics.motionDirection}
                    isRealVisionActive={videoMode !== 'simulated'}
                  />

                  {/* HUD Top Left: Rep Counter & Real-Time Motion Direction */}
                  <div className="absolute top-4 left-4 z-20 flex flex-col gap-1.5">
                    <div className="bg-slate-900/85 backdrop-blur-md px-3.5 py-2 rounded-2xl border border-white/10 text-white flex items-center gap-2.5 shadow-lg">
                      <Flame className="w-4 h-4 text-amber-400" />
                      <div>
                        <span className="text-3xs uppercase font-bold text-slate-400 block">REPETISI AKTIF</span>
                        <div className="flex items-baseline gap-1">
                          <span className="text-xl font-black">{repCount}</span>
                          <span className="text-xs text-slate-400 font-medium">/ 10</span>
                        </div>
                      </div>
                    </div>

                    {/* Live Motion Direction Indicator */}
                    <div className="bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 text-2xs font-bold flex items-center gap-2">
                      <span className="text-slate-400">Arah Gerak:</span>
                      <span
                        className={`px-2 py-0.5 rounded text-3xs font-black uppercase ${
                          motionMetrics.motionDirection === 'descending'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : motionMetrics.motionDirection === 'ascending'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : motionMetrics.motionDirection === 'holding'
                            ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                            : 'bg-slate-700/50 text-slate-300'
                        }`}
                      >
                        {motionMetrics.motionDirection === 'descending'
                          ? '⬇ Turun (Eccentric)'
                          : motionMetrics.motionDirection === 'ascending'
                          ? '⬆ Naik (Concentric)'
                          : motionMetrics.motionDirection === 'holding'
                          ? '🛑 Tahan (Bottom/Top)'
                          : '⏸ Diam / Menunggu'}
                      </span>
                    </div>
                  </div>

                  {/* HUD Top Right: Status Verdict & Real-Time Optical Energy */}
                  <div className="absolute top-4 right-4 z-20 flex flex-col items-end gap-1.5">
                    <div
                      className={`px-3.5 py-1.5 rounded-2xl backdrop-blur-md border text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-lg ${
                        frameState.statusVerdict === 'OPTIMAL'
                          ? 'bg-emerald-500/90 text-white border-emerald-400'
                          : frameState.statusVerdict === 'CAUTION'
                          ? 'bg-amber-500/90 text-white border-amber-400'
                          : 'bg-rose-600/90 text-white border-rose-400 animate-pulse'
                      }`}
                    >
                      {frameState.statusVerdict === 'OPTIMAL' && <CheckCircle2 className="w-4 h-4" />}
                      {frameState.statusVerdict === 'CAUTION' && <AlertTriangle className="w-4 h-4" />}
                      {(frameState.statusVerdict === 'DANGER' || frameState.statusVerdict === 'TECHNICAL_FATIGUE') && (
                        <ShieldAlert className="w-4 h-4" />
                      )}
                      <span>
                        {frameState.statusVerdict === 'TECHNICAL_FATIGUE'
                          ? 'Kelelahan Teknik!'
                          : frameState.statusVerdict}
                      </span>
                    </div>

                    {/* Motion Energy Telemetry Bar */}
                    <div className="bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 text-white text-xs font-bold flex items-center gap-2">
                      <Activity className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-slate-400 text-3xs uppercase">Motion:</span>
                      <span className="text-emerald-400 font-mono">{motionMetrics.motionEnergy}%</span>
                      <div className="w-12 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-emerald-400 transition-all duration-75"
                          style={{ width: `${Math.min(100, motionMetrics.motionEnergy)}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* HUD Bottom: Live Audio Speech Transcript Banner */}
                  <div className="absolute bottom-4 left-4 right-4 z-20">
                    <div className="bg-slate-900/90 backdrop-blur-md p-3 rounded-2xl border border-white/15 text-white flex items-center justify-between gap-3 shadow-2xl">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0">
                          <Volume2 className="w-4 h-4 text-emerald-400 animate-pulse" />
                        </div>
                        <div className="min-w-0">
                          <span className="text-3xs uppercase font-bold tracking-wider text-emerald-400 block">
                            AI AUDIO COACHING (SPEECH SYNTHESIS)
                          </span>
                          <p className="text-xs font-medium text-slate-200 truncate">"{lastSpokenCue}"</p>
                        </div>
                      </div>

                      <button
                        onClick={() => setIsVoiceMuted(!isVoiceMuted)}
                        className={`p-2 rounded-xl border transition-all cursor-pointer ${
                          isVoiceMuted
                            ? 'bg-rose-500/20 border-rose-500/40 text-rose-400'
                            : 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                        }`}
                        title={isVoiceMuted ? 'Suara Dimatikan' : 'Suara Aktif'}
                      >
                        {isVoiceMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Studio Control Toolbar & Sensitivity Settings */}
                <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center flex-wrap gap-2">
                    <button
                      onClick={() => setIsRunning(!isRunning)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-2xs ${
                        isRunning
                          ? 'bg-amber-500 hover:bg-amber-600 text-white'
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      }`}
                    >
                      {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      <span>{isRunning ? 'Jeda Motion' : 'Mulai Motion'}</span>
                    </button>

                    <button
                      onClick={() => {
                        setRepCount(0);
                        setCleanReps(0);
                        setCompromisedReps(0);
                        setCycleProgress(0);
                        setErrorDistribution({});
                        motionTrackerRef.current.resetCalibration();
                      }}
                      className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer"
                      title="Reset Repetisi & Kalibrasi"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>

                    {/* Camera Facing Switch */}
                    {videoMode === 'camera' && (
                      <button
                        onClick={() => setCameraFacing(cameraFacing === 'user' ? 'environment' : 'user')}
                        className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                        title="Ganti Kamera Depan/Belakang"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">{cameraFacing === 'user' ? 'Kamera Depan' : 'Kamera Belakang'}</span>
                      </button>
                    )}

                    {/* Motion Sensitivity Selector */}
                    <div className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded-xl">
                      <span className="text-3xs font-bold text-slate-500">Sensitivitas:</span>
                      {(['low', 'medium', 'high', 'ultra'] as const).map((lvl) => (
                        <button
                          key={lvl}
                          onClick={() => setMotionSensitivity(lvl)}
                          className={`px-2 py-1 rounded-lg text-3xs font-extrabold uppercase transition-all cursor-pointer ${
                            motionSensitivity === lvl
                              ? 'bg-emerald-600 text-white shadow-2xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          {lvl === 'low' ? 'Rendah' : lvl === 'medium' ? 'Normal' : lvl === 'high' ? 'Tinggi' : 'Ultra'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Finish Set & Trigger Report */}
                  <button
                    onClick={handleOpenPostSetReport}
                    className="px-5 py-2 rounded-xl bg-linear-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white text-xs font-black flex items-center gap-2 shadow-sm cursor-pointer ml-auto"
                  >
                    <Award className="w-4 h-4 text-emerald-200" />
                    <span>{isIndonesian ? 'Selesaikan Set & Analisis Pasca-Set' : 'Finish Set & View Report'}</span>
                  </button>
                </div>
              </div>

              {/* Right Column: Live Telemetry, Motion Balance & Flaw Injector Bench */}
              <div className="lg:col-span-4 space-y-4">
                {/* Real-time Video Movement Balance Card */}
                <div className="bg-linear-to-br from-slate-900 to-slate-950 text-white rounded-3xl p-5 border border-slate-800 shadow-sm space-y-3.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Activity className="w-4 h-4 text-emerald-400" />
                      <h3 className="font-bold text-xs uppercase tracking-wider text-emerald-300">
                        {isIndonesian ? 'Metrik Pergerakan Kamera (CV)' : 'Camera Motion Metrology'}
                      </h3>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-3xs font-bold border border-emerald-500/30">
                      Edge Zero-Latency
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
                      <span className="text-3xs font-bold text-slate-400 uppercase block">Simetri Kiri/Kanan</span>
                      <span className="text-base font-black text-white">
                        {100 - motionMetrics.asymmetryScore}%
                      </span>
                      <span className="text-3xs text-emerald-400 block mt-0.5 font-medium">
                        {motionMetrics.asymmetryScore < 20 ? 'Keseimbangan Baik' : 'Deviasi Sisi'}
                      </span>
                    </div>

                    <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
                      <span className="text-3xs font-bold text-slate-400 uppercase block">Kecepatan Gerak</span>
                      <span className="text-base font-black text-emerald-400 font-mono">
                        {motionMetrics.tempoSpeed} <span className="text-2xs text-slate-400 font-normal">m/s</span>
                      </span>
                      <span className="text-3xs text-slate-400 block mt-0.5 font-medium">
                        {motionMetrics.tempoSpeed > 1.8 ? 'Tempo Cepat' : 'Tempo Terkontrol'}
                      </span>
                    </div>
                  </div>
                </div>
                {/* Real-time Angle Badges */}
                <div className="bg-white rounded-3xl p-5 border border-emerald-100 shadow-sm space-y-3.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Activity className="w-4 h-4 text-emerald-600" />
                      <h3 className="font-bold text-xs uppercase tracking-wider text-slate-700">
                        {isIndonesian ? 'Telemetri Sudut Waktu Nyata' : 'Live Angle Telemetry'}
                      </h3>
                    </div>
                    <span className="text-2xs font-bold text-emerald-700">Edge 60 FPS</span>
                  </div>

                  <div className="space-y-2">
                    {frameState.measuredAngles.map((ang) => (
                      <div
                        key={ang.jointKey}
                        className={`p-3 rounded-2xl border transition-all ${
                          ang.status === 'critical'
                            ? 'bg-rose-50/80 border-rose-200 text-rose-900'
                            : ang.status === 'warning'
                            ? 'bg-amber-50/80 border-amber-200 text-amber-900'
                            : 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-bold">{ang.displayName}</span>
                          <span className="text-sm font-black tracking-tight">{ang.currentAngle}°</span>
                        </div>
                        <div className="flex items-center justify-between text-3xs font-medium">
                          <span className="text-slate-500">
                            Rentang Ideal: {ang.idealRange[0]}° - {ang.idealRange[1]}°
                          </span>
                          <span
                            className={`px-1.5 py-0.5 rounded font-bold uppercase ${
                              ang.status === 'critical'
                                ? 'bg-rose-200/80 text-rose-900'
                                : ang.status === 'warning'
                                ? 'bg-amber-200/80 text-amber-900'
                                : 'bg-emerald-200/80 text-emerald-900'
                            }`}
                          >
                            {ang.status === 'critical' ? 'Bahaya' : ang.status === 'warning' ? 'Waspada' : 'Optimal'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Simulated Deviation Bench (Interactive Tester) */}
                <div className="bg-slate-900 text-white rounded-3xl p-5 shadow-sm space-y-3.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-400" />
                      <h3 className="font-bold text-xs uppercase tracking-wider text-amber-300">
                        {isIndonesian ? 'Simulasi Uji Kasus Deviasi Form' : 'Form Flaw Test Bench'}
                      </h3>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-3xs font-bold">
                      Live Testing
                    </span>
                  </div>

                  <p className="text-2xs text-slate-300 leading-relaxed">
                    {isIndonesian
                      ? 'Pilih skenario deviasi di bawah ini untuk melihat reaksi seketika Computer Vision & Audio Coach:'
                      : 'Trigger error patterns to test FormGuard AI’s instant correction response:'}
                  </p>

                  <div className="space-y-1.5">
                    {[
                      {
                        id: 'sari_case',
                        label: 'Siku Melebar 74° (Kasus Sari Push-Up)',
                        badge: 'Rotator Cuff Alert',
                      },
                      {
                        id: 'valgus',
                        label: 'Knee Valgus (Lutut Mengarah ke Dalam)',
                        badge: 'ACL Strain',
                      },
                      {
                        id: 'hip_sag',
                        label: 'Hip Sagging (Panggul Amblas)',
                        badge: 'Lumbar Drop',
                      },
                      {
                        id: 'lumbar_flexion',
                        label: 'Lumbar Flexion (Butt-Wink Squat)',
                        badge: 'Disc Compression',
                      },
                      {
                        id: 'none',
                        label: 'Form Sempurna (Perfect Technique)',
                        badge: '100% Bersih',
                      },
                    ].map((item) => {
                      const isSelected = errorSimulationType === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => setErrorSimulationType(item.id)}
                          className={`w-full p-2.5 rounded-xl border text-left text-xs font-bold transition-all flex items-center justify-between gap-2 cursor-pointer ${
                            isSelected
                              ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-xs'
                              : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700 text-slate-300'
                          }`}
                        >
                          <span className="truncate">{item.label}</span>
                          <span
                            className={`px-2 py-0.5 rounded text-3xs font-bold shrink-0 ${
                              isSelected ? 'bg-slate-950 text-white' : 'bg-slate-700 text-slate-300'
                            }`}
                          >
                            {item.badge}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Edge Computing & Privacy Card */}
                <div className="bg-emerald-50 border border-emerald-200/80 rounded-3xl p-4.5 text-xs text-emerald-950 space-y-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    <h4 className="font-bold text-xs uppercase tracking-wider text-emerald-900">
                      {isIndonesian ? 'Privasi & Kecepatan On-Device' : 'On-Device Privacy First'}
                    </h4>
                  </div>
                  <p className="text-2xs text-emerald-900/90 leading-relaxed font-medium">
                    {isIndonesian
                      ? 'Video kamera diproses secara lokal di memori browser pengguna (Zero Server Transmission). Hanya koordinat titik numerik yang dihitung untuk latensi <50ms.'
                      : 'Camera frames are processed on-device in browser memory with zero video streaming to servers.'}
                  </p>
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Post-Set Breakdown Modal */}
      <PostSetBreakdownModal
        isOpen={isPostSetModalOpen}
        onClose={() => setIsPostSetModalOpen(false)}
        report={currentReport}
        language={userProfile.language}
        onSyncToTrainer={(rec) => {
          console.log('Synced to Trainer:', rec);
        }}
        onSyncToRecovery={(rec) => {
          console.log('Synced to Recovery:', rec);
        }}
      />

      {/* Case Study Sari Modal */}
      <CaseStudySariModal
        isOpen={isCaseStudyModalOpen}
        onClose={() => setIsCaseStudyModalOpen(false)}
        language={userProfile.language}
        onLaunchSimulationWithSari={() => {
          setSelectedExerciseId('push_up');
          setErrorSimulationType('sari_case');
          setRepCount(6);
          setIsRunning(true);
        }}
      />

      {/* Calibration Guide Modal */}
      <CalibrationGuideModal
        isOpen={isCalibrationModalOpen}
        onClose={() => setIsCalibrationModalOpen(false)}
        language={userProfile.language}
        onApplyCalibration={(sens) => {
          setSensitivityLevel(sens);
        }}
      />
    </div>
  );
};
