import React, { useRef, useEffect } from 'react';
import { LandmarkPoint, BiomechanicalFrameState } from '../../../types';

interface SkeletonCanvasOverlayProps {
  landmarks: Record<string, LandmarkPoint>;
  frameState: BiomechanicalFrameState;
  width?: number;
  height?: number;
  showAngleBadges?: boolean;
  showArrows?: boolean;
  motionHeatPoints?: { x: number; y: number; intensity: number }[];
  motionEnergy?: number;
  motionDirection?: string;
  isRealVisionActive?: boolean;
}

const BONE_CONNECTIONS: [string, string][] = [
  // Torso & Spine
  ['nose', 'left_shoulder'],
  ['nose', 'right_shoulder'],
  ['left_shoulder', 'right_shoulder'],
  ['left_shoulder', 'left_hip'],
  ['right_shoulder', 'right_hip'],
  ['left_hip', 'right_hip'],

  // Arms
  ['left_shoulder', 'left_elbow'],
  ['left_elbow', 'left_wrist'],
  ['right_shoulder', 'right_elbow'],
  ['right_elbow', 'right_wrist'],

  // Legs
  ['left_hip', 'left_knee'],
  ['left_knee', 'left_ankle'],
  ['right_hip', 'right_knee'],
  ['right_knee', 'right_ankle'],
];

export const SkeletonCanvasOverlay: React.FC<SkeletonCanvasOverlayProps> = ({
  landmarks,
  frameState,
  width = 640,
  height = 480,
  showAngleBadges = true,
  showArrows = true,
  motionHeatPoints = [],
  motionEnergy = 0,
  motionDirection = 'stationary',
  isRealVisionActive = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear previous frame
    ctx.clearRect(0, 0, width, height);

    // 0. Render Live Real-Time Motion Heatpoints from Camera
    if (motionHeatPoints.length > 0) {
      motionHeatPoints.forEach((hp) => {
        const hx = hp.x * width;
        const hy = hp.y * height;
        const radius = 14 * hp.intensity;

        const grad = ctx.createRadialGradient(hx, hy, 1, hx, hy, radius);
        grad.addColorStop(0, `rgba(52, 211, 153, ${0.7 * hp.intensity})`);
        grad.addColorStop(0.6, `rgba(16, 185, 129, ${0.3 * hp.intensity})`);
        grad.addColorStop(1, 'rgba(16, 185, 129, 0)');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(hx, hy, radius, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // Get color theme based on verdict
    let primaryColor = '#10B981'; // Emerald (Good)
    let glowColor = 'rgba(16, 185, 129, 0.4)';
    if (frameState.statusVerdict === 'CAUTION') {
      primaryColor = '#F59E0B'; // Amber
      glowColor = 'rgba(245, 158, 11, 0.4)';
    } else if (frameState.statusVerdict === 'DANGER' || frameState.statusVerdict === 'TECHNICAL_FATIGUE') {
      primaryColor = '#EF4444'; // Red
      glowColor = 'rgba(239, 68, 68, 0.5)';
    }

    // 1. Draw Bones
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    BONE_CONNECTIONS.forEach(([startKey, endKey]) => {
      const p1 = landmarks[startKey];
      const p2 = landmarks[endKey];
      if (!p1 || !p2) return;

      const x1 = p1.x * width;
      const y1 = p1.y * height;
      const x2 = p2.x * width;
      const y2 = p2.y * height;

      // Glow effect
      ctx.strokeStyle = glowColor;
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();

      // Main bone line
      ctx.strokeStyle = primaryColor;
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    });

    // 2. Draw Landmark Keypoints / Joints
    (Object.entries(landmarks) as [string, LandmarkPoint][]).forEach(([key, pt]) => {
      if (!pt) return;
      const px = pt.x * width;
      const py = pt.y * height;

      // Check if this joint has an active error
      const hasError = frameState.activeCorrections.some(
        (c) => c.bodyPart.toLowerCase().includes(key.replace('_', ' ')) || (key.includes('elbow') && c.bodyPart.includes('Siku'))
      );

      const jointColor = hasError ? '#EF4444' : primaryColor;

      // Outer halo
      ctx.fillStyle = hasError ? 'rgba(239, 68, 68, 0.3)' : glowColor;
      ctx.beginPath();
      ctx.arc(px, py, hasError ? 10 : 7, 0, Math.PI * 2);
      ctx.fill();

      // Core joint circle
      ctx.fillStyle = jointColor;
      ctx.beginPath();
      ctx.arc(px, py, hasError ? 5 : 4, 0, Math.PI * 2);
      ctx.fill();

      // Center white dot
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(px, py, 2, 0, Math.PI * 2);
      ctx.fill();
    });

    // 3. Draw Dynamic Correction Direction Arrows
    if (showArrows && frameState.activeCorrections.length > 0) {
      frameState.activeCorrections.forEach((corr) => {
        const ox = corr.arrowOrigin.x * width;
        const oy = corr.arrowOrigin.y * height;
        const targetX = ox + corr.arrowDirection.dx * width * 2;
        const targetY = oy + corr.arrowDirection.dy * height * 2;

        // Draw animated pulsing arrow
        ctx.save();
        ctx.strokeStyle = corr.severity === 'danger' ? '#EF4444' : '#F59E0B';
        ctx.fillStyle = corr.severity === 'danger' ? '#EF4444' : '#F59E0B';
        ctx.lineWidth = 3;

        // Arrow line
        ctx.beginPath();
        ctx.moveTo(ox, oy);
        ctx.lineTo(targetX, targetY);
        ctx.stroke();

        // Arrowhead
        const angle = Math.atan2(targetY - oy, targetX - ox);
        const headLength = 12;
        ctx.beginPath();
        ctx.moveTo(targetX, targetY);
        ctx.lineTo(
          targetX - headLength * Math.cos(angle - Math.PI / 6),
          targetY - headLength * Math.sin(angle - Math.PI / 6)
        );
        ctx.lineTo(
          targetX - headLength * Math.cos(angle + Math.PI / 6),
          targetY - headLength * Math.sin(angle + Math.PI / 6)
        );
        ctx.closePath();
        ctx.fill();

        // Label near arrow
        ctx.font = 'bold 11px system-ui, sans-serif';
        ctx.fillStyle = '#FFFFFF';
        ctx.strokeStyle = 'rgba(0,0,0,0.8)';
        ctx.lineWidth = 3;
        const textX = targetX + 8;
        const textY = targetY + 4;
        ctx.strokeText(corr.message.slice(0, 32) + '...', textX, textY);
        ctx.fillText(corr.message.slice(0, 32) + '...', textX, textY);

        ctx.restore();
      });
    }

    // 4. Draw Angle Badges on Joints
    if (showAngleBadges) {
      frameState.measuredAngles.forEach((angleData) => {
        let targetPt: LandmarkPoint | undefined;
        if (angleData.jointKey.includes('knee')) targetPt = landmarks.left_knee;
        else if (angleData.jointKey.includes('elbow')) targetPt = landmarks.left_elbow;
        else if (angleData.jointKey.includes('hinge') || angleData.jointKey.includes('torso'))
          targetPt = landmarks.left_hip;
        else if (angleData.jointKey.includes('spine')) targetPt = landmarks.left_shoulder;

        if (targetPt) {
          const bx = targetPt.x * width + 14;
          const by = targetPt.y * height - 8;

          ctx.save();
          // Badge background
          ctx.fillStyle =
            angleData.status === 'critical'
              ? 'rgba(239, 68, 68, 0.9)'
              : angleData.status === 'warning'
              ? 'rgba(245, 158, 11, 0.9)'
              : 'rgba(16, 185, 129, 0.9)';
          ctx.beginPath();
          ctx.roundRect(bx, by - 12, 46, 18, 4);
          ctx.fill();

          // Text
          ctx.fillStyle = '#FFFFFF';
          ctx.font = 'bold 10px monospace';
          ctx.fillText(`${angleData.currentAngle}°`, bx + 6, by + 1);
          ctx.restore();
        }
      });
    }

    // 5. Optical Flow Tracking Active Badge on Bottom Right
    if (isRealVisionActive) {
      ctx.save();
      ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
      ctx.beginPath();
      ctx.roundRect(width - 170, height - 38, 160, 28, 8);
      ctx.fill();
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.4)';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Pulsing green dot
      ctx.fillStyle = '#10B981';
      ctx.beginPath();
      ctx.arc(width - 156, height - 24, 4, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 10px system-ui, sans-serif';
      ctx.fillText(`CV Tracking • ${motionEnergy}% Ener`, width - 146, height - 21);
      ctx.restore();
    }
  }, [landmarks, frameState, width, height, showAngleBadges, showArrows, motionHeatPoints, motionEnergy, motionDirection, isRealVisionActive]);

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className="absolute inset-0 w-full h-full pointer-events-none z-10"
    />
  );
};

