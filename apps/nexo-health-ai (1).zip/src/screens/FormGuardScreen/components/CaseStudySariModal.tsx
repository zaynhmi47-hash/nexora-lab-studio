import React, { useState } from 'react';
import {
  X,
  User,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  Volume2,
  ArrowRight,
  Zap,
  Flame,
  Award,
  Activity,
} from 'lucide-react';
import { CASE_STUDY_SARI_DATA } from '../../../data/formGuardExercises';
import { LanguageCode } from '../../../types';

interface CaseStudySariModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: LanguageCode;
  onLaunchSimulationWithSari?: () => void;
}

export const CaseStudySariModal: React.FC<CaseStudySariModalProps> = ({
  isOpen,
  onClose,
  language,
  onLaunchSimulationWithSari,
}) => {
  const isIndonesian = language === 'id';
  const data = CASE_STUDY_SARI_DATA;
  const [activeStep, setActiveStep] = useState<number>(1);
  const [isPlayingAudio, setIsPlayingAudio] = useState<string | null>(null);

  if (!isOpen) return null;

  const playSimulatedAudio = (cue: string) => {
    setIsPlayingAudio(cue);
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(cue);
        utterance.lang = 'id-ID';
        utterance.rate = 1.05;
        utterance.onend = () => setIsPlayingAudio(null);
        window.speechSynthesis.speak(utterance);
      } catch (e) {
        setTimeout(() => setIsPlayingAudio(null), 3000);
      }
    } else {
      setTimeout(() => setIsPlayingAudio(null), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-emerald-100 overflow-hidden my-auto max-h-[92vh] flex flex-col text-slate-800">
        {/* Header */}
        <div className="bg-linear-to-r from-emerald-600 via-teal-600 to-emerald-700 p-5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 text-2xl">
              👩‍🦰
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black tracking-tight">
                  {isIndonesian ? 'Studi Kasus Nyata: Kasus Sari' : 'Real-World Case Study: Sari'}
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-white/20 text-white text-2xs font-bold uppercase tracking-wider">
                  Modul 2 FormGuard AI
                </span>
              </div>
              <p className="text-xs text-emerald-100/90 font-medium">
                {data.personaName} ({data.age} thn) • {data.exerciseTested} • {data.fitnessLevel}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stepper Navigation */}
        <div className="bg-slate-50 border-b border-slate-200 px-5 py-3 flex items-center justify-between overflow-x-auto gap-2 shrink-0">
          <button
            onClick={() => setActiveStep(1)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeStep === 1
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200'
            }`}
          >
            1. {isIndonesian ? 'Keluhan & Masalah' : 'Complaint & Problem'}
          </button>
          <button
            onClick={() => setActiveStep(2)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeStep === 2
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200'
            }`}
          >
            2. {isIndonesian ? 'Deteksi CV & Biomekanik' : 'CV Biomechanical Scan'}
          </button>
          <button
            onClick={() => setActiveStep(3)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeStep === 3
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200'
            }`}
          >
            3. {isIndonesian ? 'Intervensi & Solusi AI' : 'AI Interventions & Fix'}
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
          {/* Step 1: Complaint & Initial Assessment */}
          {activeStep === 1 && (
            <div className="space-y-4">
              <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4.5">
                <div className="flex items-center gap-2 mb-2">
                  <ShieldAlert className="w-5 h-5 text-rose-600" />
                  <h4 className="font-black text-sm text-rose-950">
                    {isIndonesian ? 'Keluhan Utama Sari' : 'Primary Complaint'}
                  </h4>
                </div>
                <p className="text-xs text-rose-900 leading-relaxed font-medium bg-white/70 p-3 rounded-xl border border-rose-100">
                  "{data.complaint}"
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4.5">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 mb-3">
                  {isIndonesian ? 'Profil Biometrik & Kebiasaan' : 'Biometrics & Activity Baseline'}
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-500 text-2xs block">Pekerjaan</span>
                    <span className="font-bold text-slate-800">Software UI Designer (Duduk 8 Jam)</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-500 text-2xs block">Level Latihan</span>
                    <span className="font-bold text-slate-800">Pemula Rumahan</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-500 text-2xs block">Target</span>
                    <span className="font-bold text-slate-800">15 Push-up Lantai Bersih</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200">
                    <span className="text-slate-500 text-2xs block">Pola Nyeri</span>
                    <span className="font-bold text-rose-600">Muncul di Rep ke-5+</span>
                  </div>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <h5 className="font-bold text-xs text-emerald-950">
                    {isIndonesian ? 'Ingin melihat bagaimana FormGuard AI mendiagnosis Sari?' : 'Ready to see the FormGuard AI diagnosis?'}
                  </h5>
                  <p className="text-2xs text-emerald-800">
                    {isIndonesian ? 'Lanjut ke tahap pemindaian Computer Vision' : 'Proceed to Computer Vision angle scan'}
                  </p>
                </div>
                <button
                  onClick={() => setActiveStep(2)}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <span>{isIndonesian ? 'Lihat Scan CV' : 'View CV Scan'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Computer Vision & Biomechanical Diagnostics */}
          {activeStep === 2 && (
            <div className="space-y-4">
              <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-emerald-400" />
                    <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                      {isIndonesian ? 'Diagnosis Akar Masalah oleh FormGuard AI' : 'Root Cause Diagnosis'}
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 text-2xs font-bold border border-rose-500/40">
                    Rotator Cuff Impingement Risk
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {data.rootCauseDetectedByFormGuard}
                </p>
              </div>

              {/* Measured Metrics Table */}
              <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 mb-3">
                  {isIndonesian ? 'Telemetri Sudut Biomekanik Sari' : 'Sari’s Biomechanical Angle Telemetry'}
                </h4>
                <div className="space-y-2">
                  {data.measuredMetrics.map((metric, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-slate-800 block">{metric.metric}</span>
                        <span className="text-2xs text-slate-500">Rentang Aman: {metric.safeRange}</span>
                      </div>
                      <div className="text-right">
                        <span
                          className={`font-black px-2.5 py-1 rounded-lg text-xs inline-block ${
                            metric.riskStatus === 'critical'
                              ? 'bg-rose-100 text-rose-700 border border-rose-200'
                              : metric.riskStatus === 'warning'
                              ? 'bg-amber-100 text-amber-700 border border-amber-200'
                              : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                          }`}
                        >
                          {metric.measuredValue}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between gap-3">
                <button
                  onClick={() => setActiveStep(1)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  ← {isIndonesian ? 'Kembali' : 'Back'}
                </button>
                <button
                  onClick={() => setActiveStep(3)}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <span>{isIndonesian ? 'Lihat Intervensi Audio & Hasil' : 'View AI Interventions'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Step 3: AI Audio Interventions & Autonomous Resolution */}
          {activeStep === 3 && (
            <div className="space-y-4">
              {/* Audio Cues Player */}
              <div className="bg-linear-to-r from-teal-50 to-emerald-50 border border-teal-200 rounded-2xl p-4.5">
                <div className="flex items-center gap-2 mb-3">
                  <Volume2 className="w-5 h-5 text-teal-700" />
                  <h4 className="font-bold text-xs uppercase tracking-wider text-teal-950">
                    {isIndonesian ? 'Instruksi Suara AI Real-Time yang Diberikan ke Sari' : 'Real-Time Voice Coaching Audio Cues'}
                  </h4>
                </div>

                <div className="space-y-2">
                  {data.aiAudioInterventions.map((cue, idx) => (
                    <div
                      key={idx}
                      className="bg-white/90 p-3 rounded-xl border border-teal-200 flex items-center justify-between gap-3 shadow-2xs"
                    >
                      <span className="text-xs text-slate-800 font-medium italic">"{cue}"</span>
                      <button
                        onClick={() => playSimulatedAudio(cue)}
                        className={`px-3 py-1.5 rounded-lg text-2xs font-bold flex items-center gap-1 shrink-0 transition-all cursor-pointer ${
                          isPlayingAudio === cue
                            ? 'bg-teal-600 text-white animate-pulse'
                            : 'bg-teal-100 text-teal-800 hover:bg-teal-200'
                        }`}
                      >
                        <Volume2 className="w-3 h-3" />
                        <span>{isPlayingAudio === cue ? 'Memutar...' : 'Dengar Suara'}</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* 2-Week Autonomous Resolution Card */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <h4 className="font-bold text-sm text-slate-900">
                    {isIndonesian ? 'Resolusi Otonom & Hasil Setelah 2 Minggu' : 'Autonomous Resolution & 2-Week Outcome'}
                  </h4>
                </div>

                <div className="space-y-2 text-xs text-slate-700">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900 font-bold">{isIndonesian ? 'Pencegahan Akut: ' : 'Acute Prevention: '}</strong>
                      {data.autonomousResolution.immediateCorrection}
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-start gap-2">
                    <Zap className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900 font-bold">{isIndonesian ? 'Regresi Program (Modul 1): ' : 'Regression (Modul 1): '}</strong>
                      {data.autonomousResolution.regressionRecommended}
                    </div>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-start gap-2">
                    <Award className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-900 font-bold">{isIndonesian ? 'Latihan Penguat Rotator Cuff: ' : 'Accessory Drill: '}</strong>
                      {data.autonomousResolution.accessoryExercise}
                    </div>
                  </div>

                  <div className="bg-emerald-100/70 p-3.5 rounded-xl border border-emerald-300 text-emerald-950 font-medium">
                    <strong className="font-bold text-emerald-950 block mb-0.5">
                      🎉 {isIndonesian ? 'Hasil Nyata Pasca 2 Minggu: ' : 'Outcome after 2 weeks: '}
                    </strong>
                    {data.autonomousResolution.progressAfter2Weeks}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <button
                  onClick={() => setActiveStep(2)}
                  className="w-full sm:w-auto px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  ← {isIndonesian ? 'Kembali' : 'Back'}
                </button>

                {onLaunchSimulationWithSari && (
                  <button
                    onClick={() => {
                      onClose();
                      onLaunchSimulationWithSari();
                    }}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                  >
                    <Play className="w-4 h-4" />
                    <span>{isIndonesian ? 'Jalankan Simulasi Live Kasus Sari di FormGuard AI' : 'Run Live Simulation with Sari’s Data'}</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-xs text-slate-500 font-medium">
            AI HealthMate FormGuard Case Studies • Biomechanics Lab
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold cursor-pointer transition-colors"
          >
            {isIndonesian ? 'Tutup' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
