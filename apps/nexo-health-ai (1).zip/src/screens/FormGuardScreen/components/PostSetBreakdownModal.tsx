import React, { useState } from 'react';
import {
  X,
  Award,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Activity,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Sliders,
  RefreshCw,
  Zap,
  Heart,
  Share2,
} from 'lucide-react';
import { FormGuardPostSetReport, LanguageCode } from '../../../types';

interface PostSetBreakdownModalProps {
  isOpen: boolean;
  onClose: () => void;
  report: FormGuardPostSetReport;
  language: LanguageCode;
  onSyncToTrainer?: (recommendation: string) => void;
  onSyncToRecovery?: (recommendation: string) => void;
}

export const PostSetBreakdownModal: React.FC<PostSetBreakdownModalProps> = ({
  isOpen,
  onClose,
  report,
  language,
  onSyncToTrainer,
  onSyncToRecovery,
}) => {
  const isIndonesian = language === 'id';
  const [selectedBodyPartIndex, setSelectedBodyPartIndex] = useState<number>(0);
  const [isSyncedTrainer, setIsSyncedTrainer] = useState(false);
  const [isSyncedRecovery, setIsSyncedRecovery] = useState(false);

  if (!isOpen) return null;

  const selectedBodyPart = report.bodyErrorHeatmap[selectedBodyPartIndex] || report.bodyErrorHeatmap[0];

  const handleSyncTrainer = () => {
    setIsSyncedTrainer(true);
    if (onSyncToTrainer) {
      onSyncToTrainer(report.crossModuleSync.trainerModuleAction);
    }
  };

  const handleSyncRecovery = () => {
    setIsSyncedRecovery(true);
    if (onSyncToRecovery) {
      onSyncToRecovery(report.crossModuleSync.recoveryModuleAction);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-emerald-100 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="bg-linear-to-r from-emerald-600 to-teal-700 p-5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30">
              <Award className="w-6 h-6 text-emerald-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black tracking-tight">
                  {isIndonesian ? 'Laporan Analisis Biomekanika Pasca-Set' : 'Post-Set Biomechanical Report'}
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/40 text-emerald-100 text-2xs font-bold uppercase tracking-wider border border-white/20">
                  FormGuard AI
                </span>
              </div>
              <p className="text-xs text-emerald-100/90 font-medium">
                {report.exerciseName} • {report.totalReps} Reps ({report.cleanReps} Clean, {report.compromisedReps} Compromised)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 text-slate-800">
          {/* Section 1: Score & Failure Diagnostics Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
            {/* Technique Score Gauge */}
            <div className="sm:col-span-4 bg-linear-to-b from-emerald-50 to-teal-50/40 border border-emerald-200/60 rounded-2xl p-4 flex flex-col items-center justify-center text-center relative overflow-hidden">
              <span className="text-2xs font-bold tracking-wider text-emerald-800 uppercase mb-1">
                {isIndonesian ? 'Skor Teknik AI' : 'Technique Score'}
              </span>
              <div className="flex items-baseline gap-1 my-1">
                <span className="text-5xl font-black text-emerald-900 tracking-tight">{report.techniqueScore}</span>
                <span className="text-sm font-bold text-emerald-700">/100</span>
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-600 text-white text-xs font-bold shadow-2xs mt-1">
                <span>Grade: {report.techniqueGrade}</span>
                <span>•</span>
                <span>{report.techniqueScore >= 80 ? 'Optimal' : 'Perlu Koreksi'}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 w-full mt-4 pt-3 border-t border-emerald-200/60 text-2xs">
                <div>
                  <span className="text-slate-700 block">{isIndonesian ? 'Simetri Gerak' : 'Symmetry'}</span>
                  <span className="font-bold text-slate-800">{report.symmetryScore}%</span>
                </div>
                <div>
                  <span className="text-slate-700 block">{isIndonesian ? 'Tempo Rata-rata' : 'Avg Cadence'}</span>
                  <span className="font-bold text-slate-800">{report.averageCadenceSec}s/rep</span>
                </div>
              </div>
            </div>

            {/* Neural vs Muscular Failure Classification */}
            <div className="sm:col-span-8 bg-slate-50 border border-slate-200 rounded-2xl p-4.5 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-600" />
                    <h4 className="text-xs font-black uppercase tracking-wider text-slate-700">
                      {isIndonesian ? 'Klasifikasi Kelelahan Gerakan' : 'Failure Classification'}
                    </h4>
                  </div>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-2xs font-bold uppercase tracking-wider ${
                      report.failureTypeAnalysis.classifiedFailure === 'TECHNICAL_FORM_BREAKDOWN'
                        ? 'bg-amber-100 text-amber-900 border border-amber-300'
                        : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                    }`}
                  >
                    {report.failureTypeAnalysis.classifiedFailure === 'TECHNICAL_FORM_BREAKDOWN'
                      ? 'Technical Breakdown'
                      : 'Muscle Failure'}
                  </span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed">
                  {report.failureTypeAnalysis.explanation}
                </p>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-200 flex items-start gap-2 bg-white p-2.5 rounded-xl border border-slate-100">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <p className="text-2xs text-slate-700 font-medium leading-normal">
                  <strong className="text-slate-900 font-bold">{isIndonesian ? 'Keputusan Keamanan AI: ' : 'Safety Verdict: '}</strong>
                  {report.failureTypeAnalysis.clinicalSafetyVerdict}
                </p>
              </div>
            </div>
          </div>

          {/* Section 2: Interactive Body Error Heatmap */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs">
            <div className="flex items-center justify-between mb-3.5">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-600" />
                <h4 className="text-sm font-bold text-slate-900">
                  {isIndonesian ? 'Heatmap Kesalahan Anatomi & Sendi' : 'Body Joint Error Heatmap'}
                </h4>
              </div>
              <span className="text-2xs text-slate-600 font-medium">
                {isIndonesian ? 'Klik titik sendi untuk melihat risiko biomekanik' : 'Click a joint to view biomechanical risks'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 mb-4">
              {report.bodyErrorHeatmap.map((item, idx) => {
                const isSelected = idx === selectedBodyPartIndex;
                let badgeBg = 'bg-emerald-50 border-emerald-200 text-emerald-800';
                if (item.severityGrade === 'yellow') badgeBg = 'bg-amber-50 border-amber-200 text-amber-800';
                if (item.severityGrade === 'red') badgeBg = 'bg-rose-50 border-rose-200 text-rose-800';

                return (
                  <button
                    key={item.bodyPartId}
                    onClick={() => setSelectedBodyPartIndex(idx)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'ring-2 ring-emerald-500 shadow-xs ' + badgeBg
                        : 'hover:bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-2xs font-bold truncate">{item.displayName.split(' ')[0]}</span>
                      <span
                        className={`w-2 h-2 rounded-full ${
                          item.severityGrade === 'red'
                            ? 'bg-rose-500'
                            : item.severityGrade === 'yellow'
                            ? 'bg-amber-500'
                            : 'bg-emerald-500'
                        }`}
                      />
                    </div>
                    <span className="text-xs font-black block">
                      {item.errorCount} {isIndonesian ? 'flaws' : 'flaws'}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Selected Joint Risk Breakdown Card */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 flex flex-col sm:flex-row items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-slate-900">{selectedBodyPart.displayName}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-2xs font-bold uppercase ${
                      selectedBodyPart.severityGrade === 'red'
                        ? 'bg-rose-100 text-rose-700'
                        : selectedBodyPart.severityGrade === 'yellow'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-emerald-100 text-emerald-700'
                    }`}
                  >
                    {selectedBodyPart.severityGrade === 'red'
                      ? 'Tinggi Risiko'
                      : selectedBodyPart.severityGrade === 'yellow'
                      ? 'Perhatian'
                      : 'Aman'}
                  </span>
                </div>
                <p className="text-xs text-slate-700">
                  <strong className="text-slate-900 font-semibold">{isIndonesian ? 'Penyebab: ' : 'Cause: '}</strong>
                  {selectedBodyPart.primaryIssue}
                </p>
                <p className="text-xs text-slate-700">
                  <strong className="text-slate-900 font-semibold">{isIndonesian ? 'Risiko Klinis: ' : 'Clinical Risk: '}</strong>
                  {selectedBodyPart.injuryRiskFactor}
                </p>
              </div>
              <div className="shrink-0 text-right">
                <span className="text-2xs text-slate-600 block">{isIndonesian ? 'Jumlah Deviasi' : 'Total Deviations'}</span>
                <span className="text-2xl font-black text-slate-900">{selectedBodyPart.errorCount}x</span>
              </div>
            </div>
          </div>

          {/* Section 3: 3D Ideal vs Actual Kinematics Variance */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              <h4 className="text-sm font-bold text-slate-900">
                {isIndonesian ? 'Komparasi Kinematika 3D: Ideal vs Aktual' : '3D Kinematics: Ideal vs Actual'}
              </h4>
            </div>

            <div className="space-y-3">
              {report.idealVsActualKinematics.map((kine, idx) => (
                <div key={idx} className="bg-slate-50 rounded-xl p-3.5 border border-slate-200/80">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-bold text-slate-800">{kine.jointName}</span>
                    <span className="text-slate-600">
                      Aktual: <strong className="text-rose-600 font-bold">{kine.actualAngleAvg}°</strong> / Target Ideal: <strong className="text-emerald-700 font-bold">{kine.idealAngleTarget}°</strong>
                    </span>
                  </div>
                  {/* Progress comparison visual */}
                  <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden flex">
                    <div
                      className="bg-emerald-500 h-full rounded-full transition-all"
                      style={{ width: `${Math.min(100, (kine.idealAngleTarget / 120) * 100)}%` }}
                    />
                    <div
                      className="bg-rose-500 h-full rounded-full transition-all opacity-80"
                      style={{ width: `${Math.min(100, Math.abs(kine.variancePercent))}%` }}
                    />
                  </div>
                  <p className="text-2xs text-slate-700 mt-2 leading-relaxed">
                    <span className="font-bold text-slate-900">Dampak Biomekanik: </span>
                    {kine.biomechanicalImpact}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Section 4: Corrective Prescription & Warmup Drills */}
          <div className="bg-linear-to-r from-emerald-50 via-teal-50 to-emerald-50 border border-emerald-200 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-emerald-700" />
              <h4 className="text-sm font-bold text-emerald-950">
                {isIndonesian ? 'Preskripsi Korektif & Pemanasan Fisioterapi' : 'Corrective Prescription & Rehab Drills'}
              </h4>
            </div>

            <p className="text-xs text-emerald-900 font-medium mb-3 leading-relaxed">
              {report.correctivePrescription.immediateAdvice}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-3">
              {report.correctivePrescription.rehabWarmupMovements.map((drill, idx) => (
                <div key={idx} className="bg-white/80 rounded-xl p-3 border border-emerald-200/80 shadow-2xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-slate-900">{drill.movement}</span>
                    <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-2xs font-bold">
                      {drill.repsDuration}
                    </span>
                  </div>
                  <p className="text-2xs text-slate-600 leading-normal">{drill.targetBenefit}</p>
                </div>
              ))}
            </div>

            <div className="bg-white/90 p-3 rounded-xl border border-emerald-200 text-xs text-slate-700 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-900 font-bold">Saran Regresi/Progresi: </strong>
                {report.correctivePrescription.regressionProgressionAdvice}
              </div>
            </div>
          </div>

          {/* Section 5: Cross-Module Ecosystem Sync Actions */}
          <div className="bg-slate-900 text-white rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-black uppercase tracking-wider text-emerald-300">
                  {isIndonesian ? 'Sinkronisasi Otomatis Lintas Modul' : 'Cross-Module Autonomous Sync'}
                </h4>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-2xs font-bold border border-emerald-500/30">
                Ecosystem Active
              </span>
            </div>

            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex items-center justify-between gap-3 bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                <div>
                  <span className="font-bold text-white block">Modul 1: AI Personal Trainer</span>
                  <span className="text-2xs text-slate-400">{report.crossModuleSync.trainerModuleAction}</span>
                </div>
                <button
                  onClick={handleSyncTrainer}
                  disabled={isSyncedTrainer}
                  className={`px-3 py-1.5 rounded-lg text-2xs font-bold transition-all cursor-pointer ${
                    isSyncedTrainer
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-xs'
                  }`}
                >
                  {isSyncedTrainer ? 'Tersinkronisasi ✓' : 'Terapkan ke Modul 1'}
                </button>
              </div>

              <div className="flex items-center justify-between gap-3 bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                <div>
                  <span className="font-bold text-white block">Modul 3: Pemulihan Aktif & Manajemen Nyeri</span>
                  <span className="text-2xs text-slate-400">{report.crossModuleSync.recoveryModuleAction}</span>
                </div>
                <button
                  onClick={handleSyncRecovery}
                  disabled={isSyncedRecovery}
                  className={`px-3 py-1.5 rounded-lg text-2xs font-bold transition-all cursor-pointer ${
                    isSyncedRecovery
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-teal-500 hover:bg-teal-400 text-slate-950 shadow-xs'
                  }`}
                >
                  {isSyncedRecovery ? 'Tersinkronisasi ✓' : 'Terapkan ke Modul 3'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-xs text-slate-700 font-medium">
            {isIndonesian ? 'Privasi: Video diolah lokal di perangkat (Zero Server Video Transmission)' : 'Edge Computing: Zero server video transfer'}
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm transition-all shadow-xs cursor-pointer"
          >
            {isIndonesian ? 'Selesai & Simpan Hasil' : 'Done & Save Report'}
          </button>
        </div>
      </div>
    </div>
  );
};
