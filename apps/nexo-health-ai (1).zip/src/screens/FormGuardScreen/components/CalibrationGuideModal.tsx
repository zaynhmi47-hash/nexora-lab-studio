import React, { useState, useEffect } from 'react';
import {
  X,
  Camera,
  Sliders,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  RefreshCw,
  RotateCcw,
  Volume2,
  Info,
} from 'lucide-react';
import { LanguageCode } from '../../../types';

interface CalibrationGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: LanguageCode;
  onApplyCalibration: (sensitivity: 'beginner' | 'intermediate' | 'elite') => void;
}

export const CalibrationGuideModal: React.FC<CalibrationGuideModalProps> = ({
  isOpen,
  onClose,
  language,
  onApplyCalibration,
}) => {
  const isIndonesian = language === 'id';
  const [activeStep, setActiveStep] = useState<number>(1);
  const [selectedSensitivity, setSelectedSensitivity] = useState<'beginner' | 'intermediate' | 'elite'>('beginner');
  const [countdown, setCountdown] = useState<number | null>(null);
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [isCalibratedDone, setIsCalibratedDone] = useState(false);

  useEffect(() => {
    let timer: any = null;
    if (countdown !== null && countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000);
    } else if (countdown === 0) {
      setIsCalibrating(false);
      setIsCalibratedDone(true);
      setCountdown(null);
    }
    return () => clearTimeout(timer);
  }, [countdown]);

  if (!isOpen) return null;

  const startCountdown = () => {
    setIsCalibrating(true);
    setIsCalibratedDone(false);
    setCountdown(3);
  };

  const handleFinish = () => {
    onApplyCalibration(selectedSensitivity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-emerald-100 overflow-hidden my-auto max-h-[92vh] flex flex-col text-slate-800">
        {/* Header */}
        <div className="bg-linear-to-r from-emerald-600 to-teal-700 p-5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30">
              <Camera className="w-5 h-5 text-emerald-200" />
            </div>
            <div>
              <h3 className="text-base font-black tracking-tight">
                {isIndonesian ? 'Kalibrasi Sensor & Panduan Kamera' : 'Camera Calibration & Pose Setup'}
              </h3>
              <p className="text-xs text-emerald-100 font-medium">
                {isIndonesian ? 'Memastikan akurasi pelacakan sudut 33 titik sendi' : 'Optimize 33-point joint tracking accuracy'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          {/* Step 1: Camera Placement Checklist */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2.5">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Info className="w-4 h-4 text-emerald-600" />
              <span>{isIndonesian ? '1. Posisi Kamera yang Direkomendasikan' : '1. Camera Setup Checklist'}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700">
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 flex items-center gap-2">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Jarak 2.0 - 3.0 Meter dari tubuh</span>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 flex items-center gap-2">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Kamera setinggi pinggang / matras</span>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 flex items-center gap-2">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Seluruh tubuh terlihat (kepala s.d tumit)</span>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 flex items-center gap-2">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Pencahayaan terang merata (tanpa backlight)</span>
              </div>
            </div>
          </div>

          {/* Step 2: Live Calibration T-Pose */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4.5 text-center space-y-3">
            <h4 className="font-bold text-xs uppercase tracking-wider text-emerald-950">
              {isIndonesian ? '2. Kalibrasi Proporsi Tubuh (Berdiri Tegak)' : '2. Neutral Baseline Calibration'}
            </h4>
            <p className="text-xs text-emerald-900 leading-relaxed">
              {isIndonesian
                ? 'Berdiri tegak menghadap kamera selama 3 detik untuk mengukur rasio panjang tungkai dan baseline sudut.'
                : 'Stand straight facing the camera for 3 seconds to measure limb proportions.'}
            </p>

            {countdown !== null ? (
              <div className="py-4">
                <span className="text-5xl font-black text-emerald-700 animate-ping inline-block">
                  {countdown}
                </span>
                <p className="text-xs font-bold text-emerald-900 mt-2">
                  {isIndonesian ? 'Tahan posisi berdiri tegak...' : 'Hold your neutral standing pose...'}
                </p>
              </div>
            ) : isCalibratedDone ? (
              <div className="bg-white p-3 rounded-xl border border-emerald-300 inline-flex items-center gap-2 text-xs font-bold text-emerald-800">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>{isIndonesian ? 'Kalibrasi Berhasil! Baseline Terkunci.' : 'Calibrated! Baseline locked.'}</span>
              </div>
            ) : (
              <button
                onClick={startCountdown}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs inline-flex items-center gap-2 shadow-xs cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isIndonesian ? 'Mulai Hitung Mundur 3 Detik' : 'Start 3-Sec Calibration'}</span>
              </button>
            )}
          </div>

          {/* Step 3: Sensitivity Tuning */}
          <div className="space-y-2">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-600" />
              <span>{isIndonesian ? '3. Tingkat Sensitivitas Koreksi AI' : '3. AI Strictness Sensitivity'}</span>
            </h4>
            <div className="grid grid-cols-3 gap-2">
              {[
                {
                  id: 'beginner',
                  name: 'Pemula (Toleran)',
                  tolerance: '±15° toleransi',
                  desc: 'Hanya menegur jika form berbahaya',
                },
                {
                  id: 'intermediate',
                  name: 'Menengah (Standar)',
                  tolerance: '±8° toleransi',
                  desc: 'Keseimbangan kenyamanan & teknik',
                },
                {
                  id: 'elite',
                  name: 'Elite (Ketat)',
                  tolerance: '±4° toleransi',
                  desc: 'Presisi tinggi atlet & powerlifter',
                },
              ].map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSelectedSensitivity(s.id as any)}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                    selectedSensitivity === s.id
                      ? 'border-emerald-600 bg-emerald-50/80 ring-2 ring-emerald-500 shadow-xs'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <span className="font-bold text-xs text-slate-900 block">{s.name}</span>
                  <span className="text-2xs font-bold text-emerald-700 block mb-0.5">{s.tolerance}</span>
                  <span className="text-3xs text-slate-500 leading-tight block">{s.desc}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-2xs text-slate-500">
            {isIndonesian ? 'Edge Computing • Video tidak disimpan' : 'Edge Computing • Video processed locally'}
          </span>
          <button
            onClick={handleFinish}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs cursor-pointer"
          >
            {isIndonesian ? 'Terapkan & Mulai Sesi' : 'Save & Start Session'}
          </button>
        </div>
      </div>
    </div>
  );
};
