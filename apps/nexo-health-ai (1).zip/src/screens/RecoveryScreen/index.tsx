import React, { useState } from 'react';
import {
  HeartPulse,
  Activity,
  Layers,
  Droplets,
  Zap,
  Sparkles,
  Play,
  RotateCcw,
  Flame,
  CheckCircle2,
  Info,
  Calendar,
  Clock,
  ShieldCheck,
  UserCheck,
  ChevronRight,
  ArrowLeft,
  TrendingUp,
  Sliders,
  Wind,
  Footprints,
  BookOpen,
} from 'lucide-react';
import { UserProfile, BodyPainPoint, PainSensationType, RecoveryRoutine } from '../../types';
import { TabType } from '../../components/layout/NavBar';
import { InteractiveBodyMap } from './components/InteractiveBodyMap';
import { GuidedRecoverySessionPlayer } from './components/GuidedRecoverySessionPlayer';
import { FoamRollingSMRGuide } from './components/FoamRollingSMRGuide';
import { ContrastTherapyGuide } from './components/ContrastTherapyGuide';
import { WearableRecoveryFusion } from './components/WearableRecoveryFusion';
import { CaseStudyAndiModal } from './components/CaseStudyAndiModal';
import {
  ANATOMICAL_BODY_ZONES,
  AnatomicalBodyZone,
  PRESET_RECOVERY_ROUTINES,
} from './data/recoveryData';

interface RecoveryScreenProps {
  userProfile: UserProfile;
  onNavigateTab?: (tab: TabType) => void;
  onAwardXp?: (xp: number) => void;
}

export const RecoveryScreen: React.FC<RecoveryScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // Subtab navigation inside Recovery Lab
  const [activeRecoverySubTab, setActiveRecoverySubTab] = useState<
    'body_map' | 'foam_rolling' | 'contrast_hydro' | 'biometric_hrv'
  >('body_map');

  // Selected pain points in Body Map
  const [selectedPainPoints, setSelectedPainPoints] = useState<BodyPainPoint[]>([
    {
      id: 'lower_back_back',
      bodyPartId: 'lower_back',
      name: 'Punggung Bawah (Lumbar & Erector Spinae)',
      nameEn: 'Lower Back / Lumbar',
      view: 'back',
      side: 'center',
      sensation: 'tight',
      severity: 6,
      probableCause: 'Duduk kerja laptop 8 jam & deadlift 2 hari lalu',
      anatomicalConnection: 'Terhubung ke fleksor panggul yang memendek & glutes kurang aktif',
    },
    {
      id: 'left_calf_back',
      bodyPartId: 'left_calf',
      name: 'Betis Kiri (Gastrocnemius)',
      nameEn: 'Left Calf',
      view: 'back',
      side: 'left',
      sensation: 'tight',
      severity: 5,
      probableCause: 'Lari jarak jauh 10K tempo 2 hari lalu',
      anatomicalConnection: 'Menarik tendon achilles dan plantar fascia kaki kiri',
    },
  ]);

  // Active Generated or Preset Routine
  const [activeRoutine, setActiveRoutine] = useState<RecoveryRoutine>(
    PRESET_RECOVERY_ROUTINES[0]
  );
  const [isGeneratingRoutine, setIsGeneratingRoutine] = useState<boolean>(false);

  // Player & Modal States
  const [isPlayerOpen, setIsPlayerOpen] = useState<boolean>(false);
  const [isCaseStudyModalOpen, setIsCaseStudyModalOpen] = useState<boolean>(false);
  const [sessionCompletedFeedback, setSessionCompletedFeedback] = useState<string | null>(null);

  // Toggle or add point
  const handleTogglePainPoint = (
    zone: AnatomicalBodyZone,
    sensation: PainSensationType,
    severity: number
  ) => {
    setSelectedPainPoints((prev) => {
      const exists = prev.find((p) => p.id === zone.id);
      if (exists) {
        // Update existing point
        return prev.map((p) =>
          p.id === zone.id ? { ...p, sensation, severity } : p
        );
      } else {
        // Add new point
        const newPoint: BodyPainPoint = {
          id: zone.id,
          bodyPartId: zone.id as any,
          name: zone.name,
          nameEn: zone.nameEn,
          view: zone.view,
          side: zone.side,
          sensation,
          severity,
          probableCause: zone.commonCauses[0],
          anatomicalConnection: zone.anatomicalConnections,
        };
        return [...prev, newPoint];
      }
    });
  };

  const handleRemovePainPoint = (id: string) => {
    setSelectedPainPoints((prev) => prev.filter((p) => p.id !== id));
  };

  const handleUpdatePainPoint = (id: string, updates: Partial<BodyPainPoint>) => {
    setSelectedPainPoints((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
  };

  // Load Presets
  const handleLoadPreset = (presetId: 'andi_plantar' | 'desk_neck_back' | 'post_squat_legs') => {
    if (presetId === 'andi_plantar') {
      setSelectedPainPoints([
        {
          id: 'right_plantar_heel_back',
          bodyPartId: 'right_plantar_heel',
          name: 'Tumit & Telapak Kanan (Plantar Fascia)',
          nameEn: 'Right Heel & Plantar Fascia',
          view: 'back',
          side: 'right',
          sensation: 'sharp',
          severity: 8,
          probableCause: 'Lari 10K di aspal dengan overstriding & sepatu aus',
          anatomicalConnection: 'Mikro-inflamasi insersio kalkaneus & rantai betis tegang',
        },
        {
          id: 'right_calf_back',
          bodyPartId: 'right_calf',
          name: 'Betis Kanan (Gastrocnemius & Soleus)',
          nameEn: 'Right Calf',
          view: 'back',
          side: 'right',
          sensation: 'tight',
          severity: 6,
          probableCause: 'Otot betis kaku menarik tendon achilles',
          anatomicalConnection: 'Rantai kinetik posterior tungkai kanan',
        },
      ]);
      setActiveRoutine(PRESET_RECOVERY_ROUTINES[2]); // Acute Plantar Fascia RICE
      setIsCaseStudyModalOpen(true);
    } else if (presetId === 'desk_neck_back') {
      setSelectedPainPoints([
        {
          id: 'head_neck_front',
          bodyPartId: 'head_neck',
          name: 'Leher Depan & SCM',
          nameEn: 'Anterior Neck',
          view: 'front',
          side: 'center',
          sensation: 'tight',
          severity: 6,
          probableCause: 'Tech-neck menatap layar laptop 8 jam',
          anatomicalConnection: 'Forward head posture memicu kompresi trapezius atas',
        },
        {
          id: 'left_hip_flexor_front',
          bodyPartId: 'left_hip_flexor',
          name: 'Fleksor Panggul Kiri (Iliopsoas)',
          nameEn: 'Left Hip Flexor',
          view: 'front',
          side: 'left',
          sensation: 'tight',
          severity: 7,
          probableCause: 'Duduk terlalu lama memendekkan otot psoas',
          anatomicalConnection: 'Anterior pelvic tilt membebani tulang lumbal L4-L5',
        },
      ]);
      setActiveRoutine(PRESET_RECOVERY_ROUTINES[1]); // Desk worker protocol
    } else {
      setSelectedPainPoints([
        {
          id: 'lower_back_back',
          bodyPartId: 'lower_back',
          name: 'Punggung Bawah (Lumbar & Erector Spinae)',
          nameEn: 'Lower Back / Lumbar',
          view: 'back',
          side: 'center',
          sensation: 'tight',
          severity: 6,
          probableCause: 'Squat berat & deadlift 2 hari lalu',
          anatomicalConnection: 'Kompresi facet lumbal pasca-beban aksial',
        },
        {
          id: 'left_calf_back',
          bodyPartId: 'left_calf',
          name: 'Betis Kiri (Gastrocnemius)',
          nameEn: 'Left Calf',
          view: 'back',
          side: 'left',
          sensation: 'tight',
          severity: 5,
          probableCause: 'Lari tempo 10K',
          anatomicalConnection: 'Akumulasi asam laktat & tegangan fascia',
        },
      ]);
      setActiveRoutine(PRESET_RECOVERY_ROUTINES[0]);
    }
  };

  // Generate Custom Routine via AI
  const handleGenerateCustomRoutine = async () => {
    setIsGeneratingRoutine(true);
    try {
      const response = await fetch('/api/recovery/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          primaryMuscle: selectedPainPoints.map((p) => p.name).join(', '),
          painSeverity: Math.max(...selectedPainPoints.map((p) => p.severity), 5),
          workoutType: 'Lari 10K & Deadlift / Duduk Kantor',
          language: userProfile.language,
        }),
      });

      if (response.ok) {
        const resData = await response.json();
        if (resData.success && resData.data) {
          const generated = resData.data;
          // Build custom routine object
          const newRoutine: RecoveryRoutine = {
            id: `routine_${Date.now()}`,
            title: generated.recoveryStrategy || 'Protokol Pemulihan Personalisasi AI',
            subtitle: generated.recommendedModality || 'SMR Foam Rolling & Dekompresi Fasia',
            category: 'tightness',
            durationMinutes: generated.durationMin || 15,
            targetPainPoints: selectedPainPoints.map((p) => p.id),
            aiClinicalRationale:
              'Protokol diracik berdasarkan analisis silang titik nyeri anatomi dan beban latihan 48 jam terakhir untuk meredakan ketegangan tanpa memicu inflamasi baru.',
            cnsParasympatheticGainPercent: 45,
            estimatedPainReliefPercent: 75,
            hydrationTip: generated.hydrationTip || 'Minum 350ml air hangat elektrolit.',
            antiInflammatoryDietTip: 'Konsumsi suplemen Curcumin & 2 kapsul Omega-3 pasca-sesi.',
            crossModuleSyncDirectives: {
              trainerModuleAction: 'Kurangi beban aksial besok, prioritaskan gerakan isolasi seated.',
              nutritionRehabRecommendation: 'Asupan 20g protein kolagen & vitamin C untuk sintesis jaringan.',
              telemedicineFlag: selectedPainPoints.some((p) => p.sensation === 'sharp'),
            },
            steps: generated.steps?.map((st: any, idx: number) => ({
              id: `step_${idx}`,
              title: st.action,
              modality: idx === 0 ? 'foam_rolling' : idx === 1 ? 'dynamic_mobility' : 'diaphragmatic_breathing',
              durationSeconds: st.durationSec || 120,
              targetArea: selectedPainPoints[0]?.name || 'Otot Terpilih',
              instructions: [st.benefit, 'Lakukan dengan pernapasan rileks dan jangan menahan napas.'],
              triggerPointCue: 'Tahan tekanan stabil 30 detik pada titik paling kaku.',
              audioPrompt: `Lakukan ${st.action}. Rasakan pelepasan tegangan secara bertahap.`,
            })) || PRESET_RECOVERY_ROUTINES[0].steps,
          };
          setActiveRoutine(newRoutine);
        }
      }
    } catch (err) {
      console.warn('Fallback to preset routine', err);
      setActiveRoutine(PRESET_RECOVERY_ROUTINES[0]);
    } finally {
      setIsGeneratingRoutine(false);
    }
  };

  // Complete session handler
  const handleCompleteSession = (report: {
    routineId: string;
    durationMinutes: number;
    initialPainScore: number;
    finalPainScore: number;
    reliefScore: number;
    xpEarned: number;
  }) => {
    if (onAwardXp) {
      onAwardXp(report.xpEarned);
    }
    setSessionCompletedFeedback(
      `Sesi berhasil diselesaikan! Nyeri berkurang dari ${report.initialPainScore}/10 ke ${report.finalPainScore}/10. +${report.xpEarned} XP ditambahkan ke profil Anda.`
    );
    setTimeout(() => setSessionCompletedFeedback(null), 8000);
  };

  return (
    <div className="min-h-screen bg-slate-50/50 pb-24 pt-4 px-3 sm:px-6 lg:px-8 space-y-6 max-w-7xl mx-auto">
      {/* TOP NAVIGATION BREADCRUMB & BACK BUTTON */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('landing') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Beranda / Google Health Hub' : 'Back to Home / Google Health Hub'}</span>
        </button>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <span className="hidden sm:inline">Halaman Modul:</span>
          <span className="px-3 py-1 rounded-full bg-teal-100 text-teal-900 font-extrabold border border-teal-300">
            #3 Recovery Lab & Peta Nyeri Otot
          </span>
        </div>
      </div>

      {/* Top Banner: Module 3 Identity & Ecosystem Tag */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-emerald-800/80 shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-black uppercase tracking-wider">
                Modul 3: Pemulihan Aktif & Manajemen Nyeri
              </span>
              <span className="text-xs text-emerald-200 font-bold bg-white/10 px-2.5 py-0.5 rounded-full">
                Recovery Lab AI
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-tight">
              Pulih Lebih Cepat, Kembali Lebih Kuat.
            </h1>

            <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
              Jika Modul 1 (Trainer) adalah gas dan Modul 2 (FormGuard) adalah kemudi, maka Recovery Lab adalah sistem rem dan perawatan mesin. Mengubah istirahat pasif menjadi pemulihan aktif terukur dengan peta anatomi 3D, SMR foam rolling, dan terapi kontras.
            </p>

            {/* Sub navigation buttons inside Hero */}
            <div className="flex flex-wrap items-center gap-2 pt-2">
              <button
                onClick={() => setIsCaseStudyModalOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer backdrop-blur-xs border border-white/20"
              >
                <BookOpen className="w-3.5 h-3.5 text-emerald-300" />
                <span>Studi Kasus: Kasus Andi (Plantar Fasciitis)</span>
              </button>

              {onNavigateTab && (
                <button
                  onClick={() => onNavigateTab('workout')}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-600/60 hover:bg-emerald-600 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-emerald-400/30"
                >
                  <Activity className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Ke Modul 1: AI Trainer</span>
                </button>
              )}
            </div>
          </div>

          {/* Quick Stats Widget */}
          <div className="bg-slate-900/90 backdrop-blur-md rounded-2xl p-4 border border-emerald-500/30 grid grid-cols-2 gap-4 shrink-0 lg:min-w-[280px]">
            <div>
              <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider block">
                Titik Nyeri Terdeteksi
              </span>
              <span className="text-2xl font-black text-emerald-400">
                {selectedPainPoints.length} Area
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">VAS Avg: 6/10</span>
            </div>

            <div>
              <span className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider block">
                HRV Readiness
              </span>
              <span className="text-2xl font-black text-amber-400">64 ms</span>
              <span className="text-[10px] text-emerald-400 block mt-0.5">Score: 68/100</span>
            </div>

            <div className="col-span-2 pt-2 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs text-slate-300 font-medium">Protokol Hari Ini:</span>
              <span className="text-xs font-black text-emerald-300">{activeRoutine.durationMinutes} Menit Aktif</span>
            </div>
          </div>
        </div>
      </div>

      {/* Session completion banner if triggered */}
      {sessionCompletedFeedback && (
        <div className="p-4 rounded-2xl bg-emerald-500 text-slate-950 font-bold text-xs flex items-center justify-between shadow-md animate-in fade-in duration-200">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-slate-950" />
            <span>{sessionCompletedFeedback}</span>
          </div>
          <button
            onClick={() => setSessionCompletedFeedback(null)}
            className="text-slate-950 underline hover:no-underline font-black text-xs cursor-pointer"
          >
            Tutup
          </button>
        </div>
      )}

      {/* Sub-tab Navigation Switcher */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        <button
          onClick={() => setActiveRecoverySubTab('body_map')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeRecoverySubTab === 'body_map'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Peta Nyeri Anatomi & AI Generator</span>
        </button>

        <button
          onClick={() => setActiveRecoverySubTab('foam_rolling')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeRecoverySubTab === 'foam_rolling'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Foam Rolling & Trigger Point (SMR)</span>
        </button>

        <button
          onClick={() => setActiveRecoverySubTab('contrast_hydro')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeRecoverySubTab === 'contrast_hydro'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <Droplets className="w-4 h-4" />
          <span>Terapi Kontras & Hidroterapi</span>
        </button>

        <button
          onClick={() => setActiveRecoverySubTab('biometric_hrv')}
          className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeRecoverySubTab === 'biometric_hrv'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
          }`}
        >
          <Zap className="w-4 h-4" />
          <span>HRV, Tidur & Autoregulasi Saraf</span>
        </button>
      </div>

      {/* Main Tab Views */}
      {activeRecoverySubTab === 'body_map' && (
        <div className="space-y-6">
          {/* Interactive Anatomical Body Map */}
          <InteractiveBodyMap
            selectedPainPoints={selectedPainPoints}
            onTogglePainPoint={handleTogglePainPoint}
            onRemovePainPoint={handleRemovePainPoint}
            onUpdatePainPoint={handleUpdatePainPoint}
            onGenerateCustomRoutine={handleGenerateCustomRoutine}
            isGeneratingRoutine={isGeneratingRoutine}
            onLoadPreset={handleLoadPreset}
          />

          {/* Active Routine Card with Launch Player Button */}
          <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10.5px] font-black uppercase tracking-wider">
                  Protokol Pemulihan Terjadwal
                </span>
                <h3 className="text-xl font-black text-slate-900 mt-1">
                  {activeRoutine.title}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">{activeRoutine.subtitle}</p>
              </div>

              <button
                onClick={() => setIsPlayerOpen(true)}
                className="py-3 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md shadow-emerald-600/20 cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Mulai Sesi Terpandu ({activeRoutine.durationMinutes} Menit)</span>
              </button>
            </div>

            {/* Routine Steps List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {activeRoutine.steps.map((step, idx) => (
                <div
                  key={step.id}
                  className="p-4 rounded-2xl border border-slate-200/90 bg-slate-50/60 hover:bg-white hover:border-emerald-300 transition-all space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-black text-[11px] flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <span className="font-black text-slate-900">{step.title}</span>
                    </div>
                    <span className="font-mono text-slate-600 bg-white px-2 py-0.5 rounded-md border border-slate-200 font-bold">
                      {Math.round(step.durationSeconds / 60)} m
                    </span>
                  </div>

                  <p className="text-slate-600 leading-relaxed text-[11.5px]">
                    {step.instructions[0]}
                  </p>

                  {step.triggerPointCue && (
                    <div className="text-[11px] text-amber-800 bg-amber-50 p-2 rounded-xl border border-amber-200/60">
                      <strong>Cue: </strong>
                      {step.triggerPointCue}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Clinical Rationale & Cross-Module Sync Directives */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 pt-2 text-xs">
              <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-1">
                <span className="font-black text-emerald-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  Rasional Klinis AI
                </span>
                <p className="text-emerald-800/90 text-[11.5px] leading-relaxed">
                  {activeRoutine.aiClinicalRationale}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-cyan-50/80 border border-cyan-200 space-y-1">
                <span className="font-black text-cyan-900 flex items-center gap-1.5">
                  <Droplets className="w-4 h-4 text-cyan-600" />
                  Tips Rehidrasi & Elektrolit
                </span>
                <p className="text-cyan-800/90 text-[11.5px] leading-relaxed">
                  {activeRoutine.hydrationTip}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 space-y-1">
                <span className="font-black text-amber-900 flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-amber-600" />
                  Nutrisi Anti-Inflamasi
                </span>
                <p className="text-amber-800/90 text-[11.5px] leading-relaxed">
                  {activeRoutine.antiInflammatoryDietTip}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeRecoverySubTab === 'foam_rolling' && <FoamRollingSMRGuide />}

      {activeRecoverySubTab === 'contrast_hydro' && <ContrastTherapyGuide />}

      {activeRecoverySubTab === 'biometric_hrv' && <WearableRecoveryFusion />}

      {/* Guided Session Player Modal */}
      {isPlayerOpen && (
        <GuidedRecoverySessionPlayer
          routine={activeRoutine}
          onClose={() => setIsPlayerOpen(false)}
          onCompleteSession={handleCompleteSession}
        />
      )}

      {/* Case Study Andi Modal */}
      <CaseStudyAndiModal
        isOpen={isCaseStudyModalOpen}
        onClose={() => setIsCaseStudyModalOpen(false)}
        onApplyCaseProtocol={() => handleLoadPreset('andi_plantar')}
      />
    </div>
  );
};
