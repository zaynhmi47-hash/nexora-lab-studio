import React, { useState } from 'react';
import {
  HeartPulse,
  Moon,
  Zap,
  Activity,
  Sparkles,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  RefreshCw,
  ArrowRight,
  Sliders,
} from 'lucide-react';
import { WearableRecoveryMetrics } from '../../../types';
import { MOCK_WEARABLE_RECOVERY_METRICS } from '../data/recoveryData';

interface WearableRecoveryFusionProps {
  onSyncModule1Deload?: (intensityFactor: number) => void;
}

export const WearableRecoveryFusion: React.FC<WearableRecoveryFusionProps> = ({
  onSyncModule1Deload,
}) => {
  const [metrics, setMetrics] = useState<WearableRecoveryMetrics>(MOCK_WEARABLE_RECOVERY_METRICS);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncedWithTrainer, setSyncedWithTrainer] = useState<boolean>(false);

  const handleSimulateSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setMetrics((prev) => ({
        ...prev,
        hrvRmssdMs: 71,
        cnsRecoveryScore: 82,
        hrvStatus: 'optimal',
        morningStiffnessIndex: 3,
        suggestedWorkoutIntensityFactor: 0.95,
        isDeloadRecommended: false,
        recoverySummaryText:
          'Data biometrik terupdate: HRV naik ke 71ms (mendekati baseline 72ms) setelah hidrasi & peregangan fasia semalam. Sistem saraf Anda dalam status prima untuk latihan intensitas standar.',
      }));
    }, 1200);
  };

  const handleApplyDeload = () => {
    if (onSyncModule1Deload) {
      onSyncModule1Deload(metrics.suggestedWorkoutIntensityFactor);
    }
    setSyncedWithTrainer(true);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[11px] font-black uppercase tracking-wider">
              Biometric Fusion Algorithm
            </span>
            <span className="text-xs text-slate-400 font-medium">Smart Wearable Integration</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Kesiapan Sistem Saraf (HRV & Sleep Fusion)
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl leading-relaxed">
            Penggabungan data subjektif (rasa nyeri & kekakuan otot) dengan data objektif (Variabilitas Detak Jantung / HRV & fase Deep Sleep) untuk menentukan kapasitas adaptasi tubuh Anda hari ini.
          </p>
        </div>

        <button
          onClick={handleSimulateSync}
          disabled={isSyncing}
          className="px-3.5 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-2xs self-start md:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
          <span>{isSyncing ? 'Sinkronisasi Wearable...' : 'Tarik Data Smartwatch (HRV)'}</span>
        </button>
      </div>

      {/* Grid Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* HRV Card */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">HRV (rMSSD)</span>
            <HeartPulse className="w-4 h-4 text-rose-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{metrics.hrvRmssdMs} ms</span>
            <span className="text-[11px] font-bold text-slate-400">Baseline: {metrics.hrvBaselineMs} ms</span>
          </div>
          <div className="flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md">
            <TrendingDown className="w-3 h-3 text-amber-600" />
            <span>{metrics.hrvStatus === 'optimal' ? 'Parasimpatis Optimal' : 'Sedikit Tertekan (-11%)'}</span>
          </div>
        </div>

        {/* Deep Sleep Card */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Kualitas Tidur</span>
            <Moon className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{metrics.sleepQualityPercent}%</span>
            <span className="text-[11px] font-bold text-slate-400">
              Deep: {metrics.deepSleepDurationMinutes} m
            </span>
          </div>
          <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
            <TrendingUp className="w-3 h-3 text-emerald-600" />
            <span>Fase Pemulihan Otot Cukup</span>
          </div>
        </div>

        {/* Morning Stiffness VAS */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Kekakuan Pagi Hari</span>
            <Activity className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{metrics.morningStiffnessIndex} / 10</span>
            <span className="text-[11px] font-bold text-slate-400">Skala VAS</span>
          </div>
          <div className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md">
            Koreksi Rantai Betis & Punggung
          </div>
        </div>

        {/* CNS Recovery Score */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-900 to-slate-950 text-white border border-indigo-800 space-y-2 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-200">CNS Readiness Score</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-white">{metrics.cnsRecoveryScore} / 100</span>
            <span className="text-[11px] font-bold text-indigo-300">Autoregulasi</span>
          </div>
          <div className="text-[10.5px] font-black text-amber-300 bg-indigo-950/80 px-2 py-0.5 rounded-md border border-indigo-700/50">
            Saran Beban: {Math.round(metrics.suggestedWorkoutIntensityFactor * 100)}% Volume
          </div>
        </div>
      </div>

      {/* Auto-Deload Cross-Module Integration Bar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white border border-indigo-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-md">
        <div className="space-y-1 max-w-xl">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-black text-indigo-200 uppercase tracking-wider">
              Sinkronisasi Otomatis ke Modul 1 (AI Trainer)
            </span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {metrics.recoverySummaryText}
          </p>
        </div>

        <button
          onClick={handleApplyDeload}
          disabled={syncedWithTrainer}
          className={`px-4 py-2.5 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer shadow-sm ${
            syncedWithTrainer
              ? 'bg-emerald-600 text-white cursor-default'
              : 'bg-indigo-500 hover:bg-indigo-600 text-white shadow-indigo-500/20'
          }`}
        >
          {syncedWithTrainer ? (
            <>
              <ShieldCheck className="w-4 h-4" />
              <span>Tersinkron ke AI Trainer (Modul 1)</span>
            </>
          ) : (
            <>
              <span>Terapkan Autoregulasi Beban ({Math.round(metrics.suggestedWorkoutIntensityFactor * 100)}%)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
