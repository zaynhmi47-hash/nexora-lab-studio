import React, { useState, useEffect } from 'react';
import {
  Layers,
  Clock,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Camera,
  Info,
  ChevronRight,
  ShieldCheck,
  Flame,
} from 'lucide-react';

interface TriggerPointExercise {
  id: string;
  muscleName: string;
  muscleNameEn: string;
  category: 'lower_body' | 'upper_body' | 'spine_hips';
  holdTimeSec: number;
  triggerPointLocation: string;
  instructionSteps: string[];
  physiologicalBenefit: string;
  safetyCaution: string;
  recommendedPressure: 'Ringan (2-3/10)' | 'Sedang (4-6/10)' | 'Fokus (6-7/10)';
}

const TRIGGER_POINT_LIBRARY: TriggerPointExercise[] = [
  {
    id: 'smr_itb_tfl',
    muscleName: 'IT Band & Tensor Fasciae Latae (Paha Samping)',
    muscleNameEn: 'IT Band & TFL',
    category: 'lower_body',
    holdTimeSec: 45,
    triggerPointLocation: '1/3 bagian atas paha samping, sedikit di bawah tulang panggul (TFL)',
    instructionSteps: [
      'Berbaring miring di atas foam roller dengan tumpuan pada paha samping bagian atas.',
      'Gunakan kaki atas dan kedua tangan untuk mengatur persentase berat tubuh yang menekan roller.',
      'Gulingkan perlahan 2-3 cm ke atas dan ke bawah hingga menemukan titik paling sensitif.',
      'Tahan tekanan statis selama 30-45 detik sambil bernapas rileks hingga rasa nyeri mereda 50%.',
    ],
    physiologicalBenefit: 'Mengurangi tarikan lateral pada tempurung lutut (mencegah Runner’s Knee & ITB Friction).',
    safetyCaution: 'Jangan menggelinding langsung di atas tonjolan tulang panggul atau persendian lutut.',
    recommendedPressure: 'Sedang (4-6/10)',
  },
  {
    id: 'smr_piriformis_glute',
    muscleName: 'Bokong & Piriformis (Pelepas Saraf Sciatic)',
    muscleNameEn: 'Gluteus Medius & Piriformis',
    category: 'spine_hips',
    holdTimeSec: 40,
    triggerPointLocation: 'Di tengah lekukan bokong (area kantong belakang celana)',
    instructionSteps: [
      'Duduk di atas foam roller atau bola pijat (lacrosse ball).',
      'Silangkan pergelangan kaki kanan di atas lutut kiri (posisi Figure-4).',
      'Miringkan tubuh sedikit ke arah bokong kanan.',
      'Lakukan gerakan melingkar kecil pada otot piriformis hingga menemukan titik simpul otot.',
    ],
    physiologicalBenefit: 'Mencegah jepitan saraf sciatic yang sering memicu kesemutan dan nyeri menjalar ke kaki.',
    safetyCaution: 'Hindari tekanan tajam langsung bila timbul rasa kesemutan menjalar.',
    recommendedPressure: 'Fokus (6-7/10)',
  },
  {
    id: 'smr_thoracic_spine',
    muscleName: 'Punggung Tengah & Torakal (Anti-Bungkuk)',
    muscleNameEn: 'Thoracic Spine Extension',
    category: 'upper_body',
    holdTimeSec: 45,
    triggerPointLocation: 'Antara kedua tulang belikat hingga punggung tengah (T4 - T10)',
    instructionSteps: [
      'Letakkan roller tegak lurus di bawah punggung atas.',
      'Tautkan jari-jari di belakang kepala untuk menyangga leher.',
      'Angkat pinggul sedikit dan gulingkan perlahan dari bawah leher hingga punggung tengah.',
      'Turunkan pinggul, lalu lakukan ekstensi lembut membuka dada ke belakang.',
    ],
    physiologicalBenefit: 'Meningkatkan kapasitas ekspansi paru-paru dan membebani bahu secara optimal saat overhead lift.',
    safetyCaution: 'Jangan menggelinding di area punggung bawah (lumbal) yang tidak dilindungi tulang rusuk.',
    recommendedPressure: 'Sedang (4-6/10)',
  },
  {
    id: 'smr_plantar_fascia',
    muscleName: 'Fascia Telapak Kaki & Lengkung Arch',
    muscleNameEn: 'Plantar Fascia Release',
    category: 'lower_body',
    holdTimeSec: 60,
    triggerPointLocation: 'Tepat di depan tonjolan tulang tumit bagian medial',
    instructionSteps: [
      'Gunakan bola lacrosse, bola tenis, atau botol es beku.',
      'Berdiri atau duduk tegak, letakkan bola di bawah lengkung kaki.',
      'Injak bola dengan 40-60% berat tubuh dan gulingkan perlahan dari tumit ke bantalan jari kaki.',
      'Tahan pada titik paling kaku selama 30 detik.',
    ],
    physiologicalBenefit: 'Mengendurkan seluruh rantai fasia posterior (Superficial Back Line) dari telapak kaki hingga dahi.',
    safetyCaution: 'Jangan menekan terlalu agresif pada fase nyeri akut yang masih meradang parah.',
    recommendedPressure: 'Sedang (4-6/10)',
  },
  {
    id: 'smr_pectoralis_minor',
    muscleName: 'Dada Depan & Pectoralis Minor (Pelepas Bahu)',
    muscleNameEn: 'Pec Minor Ball Release',
    category: 'upper_body',
    holdTimeSec: 35,
    triggerPointLocation: 'Di bawah tulang selangka, dekat pertemuan bahu depan dan ketiak',
    instructionSteps: [
      'Gunakan bola pijat kecil di antara dada depan dan dinding.',
      'Condongkan tubuh ke depan menekan bola pada area dada samping.',
      'Gerakkan lengan ke atas dan ke bawah (seperti gerakan salju) untuk melepaskan adhesi fasia.',
    ],
    physiologicalBenefit: 'Mengembalikan posisi tulang belikat yang tertarik ke depan (Rounded Shoulder Correction).',
    safetyCaution: 'Hindari menekan langsung di atas pembuluh darah ketiak.',
    recommendedPressure: 'Sedang (4-6/10)',
  },
];

export const FoamRollingSMRGuide: React.FC = () => {
  const [selectedExercise, setSelectedExercise] = useState<TriggerPointExercise>(
    TRIGGER_POINT_LIBRARY[0]
  );
  const [timerSeconds, setTimerSeconds] = useState<number>(selectedExercise.holdTimeSec);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [cameraCheckActive, setCameraCheckActive] = useState<boolean>(false);

  useEffect(() => {
    setTimerSeconds(selectedExercise.holdTimeSec);
    setIsTimerRunning(false);
  }, [selectedExercise]);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev - 1);
      }, 1000);
    } else if (timerSeconds === 0) {
      setIsTimerRunning(false);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, timerSeconds]);

  const handleResetTimer = () => {
    setTimerSeconds(selectedExercise.holdTimeSec);
    setIsTimerRunning(false);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full bg-teal-100 text-teal-800 text-[11px] font-black uppercase tracking-wider">
              Self-Myofascial Release (SMR)
            </span>
            <span className="text-xs text-slate-400 font-medium">Trigger Point Precision</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Panduan Foam Rolling & Trigger Point Release
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl leading-relaxed">
            Teknik pelepasan simpul fasia (myofascial adhesions) untuk mengembalikan kelenturan serat otot, mempercepat aliran limfatik, dan membebaskan saraf yang terjepit.
          </p>
        </div>

        {/* Camera Pose Guidance Toggle */}
        <button
          onClick={() => setCameraCheckActive(!cameraCheckActive)}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-2xs ${
            cameraCheckActive
              ? 'bg-emerald-600 text-white'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
        >
          <Camera className="w-4 h-4" />
          <span>{cameraCheckActive ? 'Mode Kamera AI Aktif' : 'Panduan Kamera (CV)'}</span>
        </button>
      </div>

      {/* Main Grid: Selector Tabs + Active Trigger Point Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Exercise Selector List (4 cols) */}
        <div className="lg:col-span-4 space-y-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Daftar Trigger Point Utama
          </span>
          <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
            {TRIGGER_POINT_LIBRARY.map((item) => {
              const isSelected = selectedExercise.id === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setSelectedExercise(item)}
                  className={`w-full p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col gap-1 ${
                    isSelected
                      ? 'border-teal-600 bg-teal-50/70 shadow-sm ring-1 ring-teal-500'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-slate-900">{item.muscleName}</span>
                    <span className="text-[10.5px] font-bold text-teal-700 bg-teal-100/70 px-2 py-0.5 rounded-md">
                      {item.holdTimeSec}s
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 line-clamp-1">
                    {item.triggerPointLocation}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Col: Active Exercise Stage & Step Timer (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 flex flex-col justify-between shadow-md">
          <div className="space-y-4">
            {/* Top Detail */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-800">
              <div>
                <span className="text-[11px] font-bold text-teal-400 uppercase tracking-wider">
                  Target: {selectedExercise.muscleNameEn}
                </span>
                <h4 className="text-lg sm:text-xl font-black text-white mt-0.5">
                  {selectedExercise.muscleName}
                </h4>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold text-slate-300 bg-slate-800 px-2.5 py-1 rounded-xl border border-slate-700">
                  Tekanan: {selectedExercise.recommendedPressure}
                </span>
              </div>
            </div>

            {/* Camera posture check prompt if toggled */}
            {cameraCheckActive && (
              <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between animate-in fade-in duration-200">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="font-bold">
                    Computer Vision memantau sudut tulang belakang & posisi tumpuan berat badan Anda.
                  </span>
                </div>
                <span className="text-[10px] bg-emerald-500/20 px-2 py-0.5 rounded-md text-emerald-200 font-mono">
                  Align: 94% Optimal
                </span>
              </div>
            )}

            {/* Trigger Point & Instruction Steps */}
            <div className="space-y-3">
              <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 text-xs">
                <span className="text-amber-400 font-black">Lokasi Trigger Point Kunci: </span>
                <span className="text-slate-300">{selectedExercise.triggerPointLocation}</span>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Langkah Eksekusi Terpandu:
                </span>
                <div className="space-y-1.5">
                  {selectedExercise.instructionSteps.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-200">
                      <span className="w-4 h-4 rounded-full bg-teal-500/20 text-teal-400 text-[10.5px] font-black flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span className="leading-relaxed">{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Physiological & Safety Note */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-[11.5px]">
                <div className="p-3 rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-300">
                  <strong className="font-bold block text-teal-200 mb-0.5">Manfaat Fisiologis:</strong>
                  {selectedExercise.physiologicalBenefit}
                </div>
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300">
                  <strong className="font-bold block text-amber-200 mb-0.5">Peringatan Keamanan:</strong>
                  {selectedExercise.safetyCaution}
                </div>
              </div>
            </div>
          </div>

          {/* Integrated Trigger Point Hold Timer */}
          <div className="mt-6 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="text-3xl font-black text-white font-mono">{timerSeconds}s</div>
              <div className="text-xs text-slate-400">
                <div className="font-bold text-slate-300">Target Tahan Tekanan</div>
                <div>Tahan hingga nyeri berkurang 50%</div>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={handleResetTimer}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all cursor-pointer"
                title="Reset Timer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsTimerRunning(!isTimerRunning)}
                className={`flex-1 sm:flex-none py-2.5 px-5 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer ${
                  isTimerRunning
                    ? 'bg-amber-500 hover:bg-amber-600 text-slate-950'
                    : 'bg-teal-500 hover:bg-teal-600 text-slate-950'
                }`}
              >
                {isTimerRunning ? (
                  <>
                    <Pause className="w-4 h-4" />
                    <span>Jeda Timer SMR</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>Mulai Tahan Titik ({selectedExercise.holdTimeSec}s)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
