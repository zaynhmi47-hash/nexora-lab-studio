import React from 'react';
import {
  X,
  Flame,
  ShieldCheck,
  Activity,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Footprints,
  Dumbbell,
  Utensils,
  Camera,
} from 'lucide-react';
import { CASE_STUDY_ANDI } from '../data/recoveryData';

interface CaseStudyAndiModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyCaseProtocol?: () => void;
}

export const CaseStudyAndiModal: React.FC<CaseStudyAndiModalProps> = ({
  isOpen,
  onClose,
  onApplyCaseProtocol,
}) => {
  if (!isOpen) return null;

  const caseData = CASE_STUDY_ANDI;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col my-auto animate-in fade-in zoom-in duration-200">
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 flex items-start justify-between bg-gradient-to-r from-red-50 via-rose-50 to-white">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-red-100 text-red-800 text-[10.5px] font-black uppercase tracking-wider">
                Studi Kasus Klinis Interaktif
              </span>
              <span className="text-xs text-slate-500 font-bold">Kasus 01: Cedera Pelari</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Kasus Andi: Nyeri Tumit & Plantar Fasciitis Akut Pasca 10K
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-xl">
              Bagaimana Recovery Lab AI mendeteksi inflamasi fascia dini, menghentikan latihan destruktif, dan memulihkan kondisi pelari dalam 7 hari.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white border border-slate-200 text-slate-400 hover:text-slate-700 transition-all cursor-pointer shadow-2xs"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto max-h-[70vh] space-y-6">
          {/* User Persona & Complaint Card */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
            <div>
              <span className="text-slate-400 font-bold block">Profil Pengguna:</span>
              <span className="font-black text-slate-900 text-sm">{caseData.personaName} ({caseData.age} Thn)</span>
              <span className="text-slate-500 block text-[11px] mt-0.5">{caseData.sport}</span>
            </div>

            <div>
              <span className="text-slate-400 font-bold block">Keluhan Utama:</span>
              <span className="font-bold text-red-700 leading-snug">{caseData.chiefComplaint}</span>
            </div>

            <div>
              <span className="text-slate-400 font-bold block">Skala Nyeri Awal:</span>
              <div className="flex items-center gap-2 mt-1">
                <span className="px-2.5 py-1 rounded-xl bg-red-600 text-white font-black text-xs">
                  VAS {caseData.severityVas} / 10
                </span>
                <span className="text-[11px] text-red-600 font-bold">Nyeri Menusuk Tajam</span>
              </div>
            </div>
          </div>

          {/* AI Diagnosis & Anatomical Root Cause */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 text-white border border-slate-800 space-y-3 shadow-sm">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-black text-emerald-300 uppercase tracking-wider">
                Diagnosis Anatomical Knowledge Graph AI
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div>
                <span className="text-slate-400 block font-medium">Kondisi Utama:</span>
                <span className="font-black text-white text-sm">{caseData.aiDiagnosis.primaryCondition}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-300 space-y-1">
                <span className="font-bold text-emerald-400">Akar Biomekanika: </span>
                <span className="leading-relaxed">{caseData.aiDiagnosis.underlyingBiomechanics}</span>
              </div>
            </div>
          </div>

          {/* Step 1 & 2: Immediate Actions & Guided Protocol */}
          <div className="space-y-3">
            <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <Footprints className="w-4 h-4 text-red-600" />
              <span>Protokol Intervensi & Pemulihan Bertahap</span>
            </h4>

            {/* Immediate actions */}
            <div className="p-3.5 rounded-2xl bg-red-50/80 border border-red-200 text-xs space-y-1.5">
              <span className="font-black text-red-900">Tindakan Darurat Hari Pertama:</span>
              <ul className="space-y-1 text-red-800/90 list-disc list-inside">
                {caseData.immediateActions.map((act, idx) => (
                  <li key={idx} className="leading-relaxed">{act}</li>
                ))}
              </ul>
            </div>

            {/* Phase breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {caseData.guidedRehabProtocol.map((phase, idx) => (
                <div key={idx} className="p-3.5 rounded-2xl border border-slate-200 bg-white space-y-2 text-xs">
                  <div className="font-black text-slate-900 border-b border-slate-100 pb-1.5">
                    <span className="text-emerald-700 block text-[10.5px] uppercase font-mono">{phase.dayRange}</span>
                    <span>{phase.phaseName}</span>
                  </div>
                  <ul className="space-y-1 text-slate-600 list-disc list-inside text-[11.5px]">
                    {phase.actions.map((act, aIdx) => (
                      <li key={aIdx} className="leading-relaxed">{act}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Cross Module Ecosystem Sync */}
          <div className="space-y-3">
            <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-600" />
              <span>Sinkronisasi Otomatis Lintas 3 Modul AI HealthMate</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
                <div className="flex items-center gap-1.5 font-black text-emerald-900">
                  <Dumbbell className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Modul 1: AI Trainer</span>
                </div>
                <p className="text-emerald-800 text-[11px] leading-relaxed">
                  {caseData.crossModuleIntegration.trainerModuleSubstitution}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-teal-50 border border-teal-200 space-y-1">
                <div className="flex items-center gap-1.5 font-black text-teal-900">
                  <Camera className="w-3.5 h-3.5 text-teal-600" />
                  <span>Modul 2: FormGuard</span>
                </div>
                <p className="text-teal-800 text-[11px] leading-relaxed">
                  {caseData.crossModuleIntegration.formGuardNextFocus}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 space-y-1">
                <div className="flex items-center gap-1.5 font-black text-amber-900">
                  <Utensils className="w-3.5 h-3.5 text-amber-600" />
                  <span>Modul 6: AI Dietitian</span>
                </div>
                <p className="text-amber-800 text-[11px] leading-relaxed">
                  {caseData.crossModuleIntegration.nutritionAntiInflammatory}
                </p>
              </div>
            </div>
          </div>

          {/* Outcome after 1 week */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white space-y-2 shadow-md">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-emerald-200 uppercase tracking-wider">
                Hasil Evaluasi Hari ke-7
              </span>
              <span className="text-xs font-black bg-white/20 px-2.5 py-0.5 rounded-lg text-white">
                VAS {caseData.outcomeAfterOneWeek.painScoreBefore}/10 ➔ {caseData.outcomeAfterOneWeek.painScoreAfter}/10
              </span>
            </div>
            <p className="text-xs text-white/95 leading-relaxed">
              {caseData.outcomeAfterOneWeek.recoveryVerdict}
            </p>
            <div className="text-[11px] text-emerald-100 bg-emerald-800/50 p-2 rounded-xl border border-emerald-500/30">
              <strong className="font-bold text-white">Kesiapan Lari Kembali: </strong>
              {caseData.outcomeAfterOneWeek.returnToRunSafetyCheck}
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-100 cursor-pointer"
          >
            Tutup Studi Kasus
          </button>

          <button
            onClick={() => {
              if (onApplyCaseProtocol) onApplyCaseProtocol();
              onClose();
            }}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs transition-all shadow-md shadow-emerald-600/20 flex items-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-emerald-200" />
            <span>Muat Protokol Plantar Fasciitis ke Peta Nyeri</span>
          </button>
        </div>
      </div>
    </div>
  );
};
