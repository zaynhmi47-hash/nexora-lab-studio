import React, { useState } from 'react';
import {
  Activity,
  AlertCircle,
  Sparkles,
  RotateCw,
  Plus,
  Trash2,
  Sliders,
  CheckCircle2,
  Info,
  ChevronRight,
  Flame,
  Zap,
} from 'lucide-react';
import { BodyPainPoint, PainSensationType, BodyPartId } from '../../../types';
import { ANATOMICAL_BODY_ZONES, AnatomicalBodyZone } from '../data/recoveryData';

interface InteractiveBodyMapProps {
  selectedPainPoints: BodyPainPoint[];
  onTogglePainPoint: (zone: AnatomicalBodyZone, sensation: PainSensationType, severity: number) => void;
  onRemovePainPoint: (id: string) => void;
  onUpdatePainPoint: (id: string, updates: Partial<BodyPainPoint>) => void;
  onGenerateCustomRoutine: () => void;
  isGeneratingRoutine: boolean;
  onLoadPreset: (presetId: 'andi_plantar' | 'desk_neck_back' | 'post_squat_legs') => void;
}

export const InteractiveBodyMap: React.FC<InteractiveBodyMapProps> = ({
  selectedPainPoints,
  onTogglePainPoint,
  onRemovePainPoint,
  onUpdatePainPoint,
  onGenerateCustomRoutine,
  isGeneratingRoutine,
  onLoadPreset,
}) => {
  const [activeView, setActiveView] = useState<'front' | 'back'>('back');
  const [hoveredZone, setHoveredZone] = useState<AnatomicalBodyZone | null>(null);
  const [activeModalZone, setActiveModalZone] = useState<AnatomicalBodyZone | null>(null);
  const [modalSensation, setModalSensation] = useState<PainSensationType>('tight');
  const [modalSeverity, setModalSeverity] = useState<number>(5);

  const filteredZones = ANATOMICAL_BODY_ZONES.filter((z) => z.view === activeView);

  const getZonePainPoint = (zoneId: string) => {
    return selectedPainPoints.find((p) => p.id === zoneId);
  };

  const handleZoneClick = (zone: AnatomicalBodyZone) => {
    const existing = getZonePainPoint(zone.id);
    if (existing) {
      // If already added, open modal with existing values or allow removal
      setModalSensation(existing.sensation);
      setModalSeverity(existing.severity);
      setActiveModalZone(zone);
    } else {
      setModalSensation('tight');
      setModalSeverity(5);
      setActiveModalZone(zone);
    }
  };

  const handleSaveModalPoint = () => {
    if (!activeModalZone) return;
    onTogglePainPoint(activeModalZone, modalSensation, modalSeverity);
    setActiveModalZone(null);
  };

  const getSensationColor = (sensation: PainSensationType) => {
    switch (sensation) {
      case 'sharp':
        return {
          fill: '#ef4444',
          stroke: '#991b1b',
          glow: 'rgba(239, 68, 68, 0.6)',
          badge: 'bg-red-500 text-white',
          text: 'Tajam / Tusuk (Potensi Cedera/Strain)',
        };
      case 'tight':
        return {
          fill: '#f59e0b',
          stroke: '#b45309',
          glow: 'rgba(245, 158, 11, 0.6)',
          badge: 'bg-amber-500 text-white',
          text: 'Pegal / Kaku (Ketegangan Fascia/DOMS)',
        };
      case 'fatigued':
        return {
          fill: '#3b82f6',
          stroke: '#1d4ed8',
          glow: 'rgba(59, 130, 246, 0.6)',
          badge: 'bg-blue-500 text-white',
          text: 'Lelah / Berat (Akumulasi Metabolik/CNS)',
        };
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm transition-all">
      {/* Header section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-black uppercase tracking-wider">
              Anatomical Pain Mapping
            </span>
            <span className="text-xs text-slate-400 font-medium">Biomechanical Knowledge Graph</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Peta Nyeri & Ketegangan Tubuh Interaktif
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl leading-relaxed">
            Sentuh area tubuh pada model anatomi di bawah untuk menandai sensasi pegal, kekakuan sendi, atau nyeri menusuk. AI akan menghubungkannya secara otomatis dengan riwayat latihan 48 jam terakhir Anda.
          </p>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onLoadPreset('andi_plantar')}
            className="px-3 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Flame className="w-3.5 h-3.5 text-red-500" />
            <span>Preset: Kasus Andi (Tumit)</span>
          </button>
          <button
            onClick={() => onLoadPreset('desk_neck_back')}
            className="px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
          >
            <Sliders className="w-3.5 h-3.5 text-amber-600" />
            <span>Preset: Duduk Kantor</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Body Model & Details Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-6">
        {/* Left Col: SVG Interactive Human Canvas (5 cols) */}
        <div className="lg:col-span-5 flex flex-col items-center bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 rounded-3xl p-5 border border-slate-800 text-white relative shadow-inner overflow-hidden">
          {/* Top Switcher: Front vs Back View */}
          <div className="w-full flex items-center justify-between z-10 mb-2">
            <div className="flex items-center gap-1.5 bg-slate-800/90 backdrop-blur-md p-1 rounded-2xl border border-slate-700">
              <button
                onClick={() => setActiveView('front')}
                className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  activeView === 'front'
                    ? 'bg-emerald-500 text-slate-950 shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Tampak Depan (Anterior)
              </button>
              <button
                onClick={() => setActiveView('back')}
                className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  activeView === 'back'
                    ? 'bg-emerald-500 text-slate-950 shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Tampak Belakang (Posterior)
              </button>
            </div>

            <button
              onClick={() => setActiveView(activeView === 'front' ? 'back' : 'front')}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all cursor-pointer"
              title="Putar Model Anatomi"
            >
              <RotateCw className="w-4 h-4 text-emerald-400" />
            </button>
          </div>

          {/* Interactive Anatomical SVG Model */}
          <div className="relative w-full max-w-[320px] aspect-[1/1.6] flex items-center justify-center my-1">
            <svg
              viewBox="0 0 100 160"
              className="w-full h-full drop-shadow-[0_0_15px_rgba(16,185,129,0.15)] select-none"
            >
              {/* Subtle Body Silhouette Wireframe */}
              <defs>
                <linearGradient id="bodyGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#1e293b" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#0f172a" stopOpacity="0.9" />
                </linearGradient>
                <filter id="glowEffect" x="-50%" y="-50%" width="200%" height="200%">
                  <feGaussianBlur stdDeviation="2" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              {/* Head */}
              <ellipse cx="50" cy="15" rx="7.5" ry="9.5" fill="url(#bodyGradient)" stroke="#334155" strokeWidth="0.8" />
              {/* Neck */}
              <path d="M 46 24 L 46 27 L 54 27 L 54 24 Z" fill="#1e293b" stroke="#334155" strokeWidth="0.8" />
              {/* Torso & Shoulder silhouette */}
              <path
                d="M 32 28 C 38 27 62 27 68 28 C 72 35 70 54 65 65 C 60 74 62 76 63 76 L 37 76 C 38 76 40 74 35 65 C 30 54 28 35 32 28 Z"
                fill="url(#bodyGradient)"
                stroke="#334155"
                strokeWidth="0.8"
              />
              {/* Left Arm (viewer's left) */}
              <path
                d="M 31 29 C 27 38 25 50 24 64 C 23 72 22 79 21 86 C 20 88 18 88 18 86 C 19 78 21 70 23 60 C 25 48 27 38 31 29 Z"
                fill="url(#bodyGradient)"
                stroke="#334155"
                strokeWidth="0.8"
              />
              {/* Right Arm (viewer's right) */}
              <path
                d="M 69 29 C 73 38 75 50 76 64 C 77 72 78 79 79 86 C 80 88 82 88 82 86 C 81 78 79 70 77 60 C 75 48 73 38 69 29 Z"
                fill="url(#bodyGradient)"
                stroke="#334155"
                strokeWidth="0.8"
              />
              {/* Left Leg (viewer's left) */}
              <path
                d="M 37 76 C 37 88 36 105 38 118 C 39 126 39 140 38 152 C 37 155 43 155 44 152 C 45 140 45 125 44 116 C 44 104 46 88 47 76 Z"
                fill="url(#bodyGradient)"
                stroke="#334155"
                strokeWidth="0.8"
              />
              {/* Right Leg (viewer's right) */}
              <path
                d="M 63 76 C 63 88 64 105 62 118 C 61 126 61 140 62 152 C 63 155 57 155 56 152 C 55 140 55 125 56 116 C 56 104 54 88 53 76 Z"
                fill="url(#bodyGradient)"
                stroke="#334155"
                strokeWidth="0.8"
              />

              {/* Spine / Centerline indicator */}
              {activeView === 'back' && (
                <path
                  d="M 50 25 L 50 76"
                  stroke="#10b981"
                  strokeWidth="0.6"
                  strokeDasharray="1.5,1.5"
                  opacity="0.5"
                />
              )}

              {/* Clickable anatomical trigger nodes */}
              {filteredZones.map((zone) => {
                const painPoint = getZonePainPoint(zone.id);
                const isSelected = !!painPoint;
                const isHovered = hoveredZone?.id === zone.id;
                const colors = painPoint ? getSensationColor(painPoint.sensation) : null;

                // Scale cy and cx from 0-100 to SVG 0-100/160
                const svgX = zone.cx;
                const svgY = (zone.cy / 100) * 160;

                return (
                  <g
                    key={zone.id}
                    className="cursor-pointer transition-all duration-300"
                    onMouseEnter={() => setHoveredZone(zone)}
                    onMouseLeave={() => setHoveredZone(null)}
                    onClick={() => handleZoneClick(zone)}
                  >
                    {/* Outer pulsating ring if selected */}
                    {isSelected && (
                      <circle
                        cx={svgX}
                        cy={svgY}
                        r={zone.r * 1.8}
                        fill="none"
                        stroke={colors?.fill}
                        strokeWidth="1"
                        opacity="0.8"
                        className="animate-ping"
                      />
                    )}

                    {/* Main Node */}
                    <circle
                      cx={svgX}
                      cy={svgY}
                      r={isHovered ? zone.r * 1.3 : zone.r}
                      fill={isSelected ? colors?.fill : isHovered ? '#10b981' : '#334155'}
                      stroke={isSelected ? '#ffffff' : isHovered ? '#34d399' : '#475569'}
                      strokeWidth={isSelected ? '1.5' : '1'}
                      filter={isSelected ? 'url(#glowEffect)' : undefined}
                      opacity={isSelected ? 0.95 : isHovered ? 0.9 : 0.65}
                    />

                    {/* Severity number tag inside node */}
                    {isSelected && (
                      <text
                        x={svgX}
                        y={svgY + 1.2}
                        textAnchor="middle"
                        fontSize="3.2"
                        fontWeight="bold"
                        fill="#ffffff"
                      >
                        {painPoint.severity}
                      </text>
                    )}

                    {/* Plus symbol if hovered and not selected */}
                    {!isSelected && isHovered && (
                      <text
                        x={svgX}
                        y={svgY + 1.2}
                        textAnchor="middle"
                        fontSize="3.5"
                        fontWeight="bold"
                        fill="#ffffff"
                      >
                        +
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>

            {/* Hover tooltip */}
            {hoveredZone && (
              <div className="absolute bottom-2 left-2 right-2 bg-slate-900/95 backdrop-blur-md border border-slate-700 p-2.5 rounded-xl text-left text-xs z-20 shadow-xl pointer-events-none transition-all">
                <div className="font-bold text-emerald-400 flex items-center justify-between">
                  <span>{hoveredZone.name}</span>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider">Klik untuk tandai</span>
                </div>
                <div className="text-[11px] text-slate-300 mt-0.5">
                  <span className="text-slate-400">Hubungan: </span>
                  {hoveredZone.anatomicalConnections}
                </div>
              </div>
            )}
          </div>

          {/* Sensation Legend */}
          <div className="w-full grid grid-cols-3 gap-1.5 mt-2 pt-2 border-t border-slate-800 text-[10px]">
            <div className="flex items-center gap-1.5 text-red-400">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 shrink-0" />
              <span>Tajam / Cedera</span>
            </div>
            <div className="flex items-center gap-1.5 text-amber-400">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />
              <span>Pegal / Kaku</span>
            </div>
            <div className="flex items-center gap-1.5 text-blue-400">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shrink-0" />
              <span>Lelah / Berat</span>
            </div>
          </div>
        </div>

        {/* Right Col: Selected Points Breakdown & AI Cross-Analysis (7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-slate-900">
                  Titik Nyeri & Ketegangan Terpilih
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
                  {selectedPainPoints.length} Area
                </span>
              </div>

              {selectedPainPoints.length > 0 && (
                <button
                  onClick={() => selectedPainPoints.forEach((p) => onRemovePainPoint(p.id))}
                  className="text-xs text-rose-600 hover:text-rose-700 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Hapus Semua</span>
                </button>
              )}
            </div>

            {/* Empty state or Active List */}
            {selectedPainPoints.length === 0 ? (
              <div className="bg-slate-50 rounded-2xl border border-dashed border-slate-300 p-8 text-center">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-3">
                  <Activity className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-slate-800">Belum ada titik tubuh yang ditandai</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto leading-relaxed">
                  Silakan sentuh atau klik lingkaran titik sendi pada model tubuh anatomi di sebelah kiri (atau klik salah satu preset kasus di atas).
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
                {selectedPainPoints.map((point) => {
                  const colors = getSensationColor(point.sensation);
                  return (
                    <div
                      key={point.id}
                      className="p-4 rounded-2xl border border-slate-200/90 bg-white hover:border-emerald-300 transition-all shadow-2xs space-y-3"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-black text-sm text-slate-900">{point.name}</span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${colors.badge}`}>
                              {point.sensation === 'sharp'
                                ? 'Tajam / Tusuk'
                                : point.sensation === 'tight'
                                ? 'Pegal / Kaku'
                                : 'Lelah / Berat'}
                            </span>
                            <span className="text-[11px] font-extrabold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                              VAS: {point.severity}/10
                            </span>
                          </div>
                          {point.probableCause && (
                            <p className="text-xs text-slate-600 mt-1 font-medium">
                              <span className="text-slate-400">Korelasi Latihan: </span>
                              {point.probableCause}
                            </p>
                          )}
                          {point.anatomicalConnection && (
                            <p className="text-[11px] text-emerald-800 mt-0.5 bg-emerald-50/70 p-1.5 rounded-lg">
                              <span className="font-bold">Rantai Fascia: </span>
                              {point.anatomicalConnection}
                            </p>
                          )}
                        </div>

                        <button
                          onClick={() => onRemovePainPoint(point.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-all cursor-pointer shrink-0"
                          title="Hapus Titik"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Interactive Severity Slider inside Card */}
                      <div className="flex items-center gap-3 pt-1 border-t border-slate-100 text-xs">
                        <span className="text-slate-500 shrink-0 font-medium">Ubah Keparahan:</span>
                        <input
                          type="range"
                          min="1"
                          max="10"
                          value={point.severity}
                          onChange={(e) =>
                            onUpdatePainPoint(point.id, { severity: parseInt(e.target.value) })
                          }
                          className="w-full accent-emerald-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg"
                        />
                        <span className="font-black text-slate-800 w-6 text-right">{point.severity}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* AI Cross Analysis & Action Footer */}
          <div className="mt-6 pt-4 border-t border-slate-100 space-y-3">
            {selectedPainPoints.length > 0 && (
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 border border-emerald-200 text-xs text-emerald-950 flex items-start gap-2.5 shadow-2xs">
                <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <div className="font-black text-emerald-900">Diagnosis Silang AI (Cross-Analysis 48 Jam)</div>
                  <p className="text-emerald-800/90 leading-relaxed text-[11.5px]">
                    {selectedPainPoints.some((p) => p.sensation === 'sharp')
                      ? '⚠️ Terdeteksi sensasi nyeri tajam. AI menyarankan protokol R.I.C.E., krioterapi es, dan menonaktifkan beban latihan berat pada area terkait.'
                      : 'AI mengidentifikasi kombinasi beban latihan sebelumnya dan postur statis. Siap meracik protokol pemulihan 12-18 menit bertarget myofascial.'}
                  </p>
                </div>
              </div>
            )}

            <button
              onClick={onGenerateCustomRoutine}
              disabled={selectedPainPoints.length === 0 || isGeneratingRoutine}
              className={`w-full py-3.5 px-5 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2.5 transition-all shadow-md cursor-pointer ${
                selectedPainPoints.length === 0
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white shadow-emerald-600/20 active:scale-[0.99]'
              }`}
            >
              {isGeneratingRoutine ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Meracik Protokol Pemulihan Personalisasi...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-emerald-200" />
                  <span>Generate Protokol Pemulihan AI Bertarget (10-20 Menit)</span>
                  <ChevronRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Point Editor Modal */}
      {activeModalZone && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-slate-200 shadow-2xl space-y-5 animate-in fade-in zoom-in duration-150">
            <div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase">
                Tandai Titik Anatomi
              </span>
              <h3 className="text-lg font-black text-slate-900 mt-1">{activeModalZone.name}</h3>
              <p className="text-xs text-slate-500 mt-0.5">{activeModalZone.anatomicalConnections}</p>
            </div>

            {/* Sensation Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700">Jenis Sensasi yang Dirasakan:</label>
              <div className="grid grid-cols-1 gap-2">
                <button
                  onClick={() => setModalSensation('tight')}
                  className={`p-3 rounded-xl border text-left text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
                    modalSensation === 'tight'
                      ? 'border-amber-500 bg-amber-50 text-amber-900 ring-2 ring-amber-400/20'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div>
                    <div className="font-black text-amber-900">Pegal / Kaku (Tightness / DOMS)</div>
                    <div className="text-[11px] text-amber-700 font-normal mt-0.5">
                      Ketegangan fascia, otot memendek, atau asam laktat
                    </div>
                  </div>
                  {modalSensation === 'tight' && <CheckCircle2 className="w-4 h-4 text-amber-600" />}
                </button>

                <button
                  onClick={() => setModalSensation('sharp')}
                  className={`p-3 rounded-xl border text-left text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
                    modalSensation === 'sharp'
                      ? 'border-red-500 bg-red-50 text-red-900 ring-2 ring-red-400/20'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div>
                    <div className="font-black text-red-900">Tajam / Tusuk (Sharp / Strain)</div>
                    <div className="text-[11px] text-red-700 font-normal mt-0.5">
                      Potensi mikro-robekan, radang sendi/tendon, atau cedera akut
                    </div>
                  </div>
                  {modalSensation === 'sharp' && <CheckCircle2 className="w-4 h-4 text-red-600" />}
                </button>

                <button
                  onClick={() => setModalSensation('fatigued')}
                  className={`p-3 rounded-xl border text-left text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
                    modalSensation === 'fatigued'
                      ? 'border-blue-500 bg-blue-50 text-blue-900 ring-2 ring-blue-400/20'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div>
                    <div className="font-black text-blue-900">Lelah / Berat (Fatigue / CNS)</div>
                    <div className="text-[11px] text-blue-700 font-normal mt-0.5">
                      Kelelahan sistem saraf pusat atau kehabisan glikogen
                    </div>
                  </div>
                  {modalSensation === 'fatigued' && <CheckCircle2 className="w-4 h-4 text-blue-600" />}
                </button>
              </div>
            </div>

            {/* Severity Slider */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700">Tingkat Rasa Sakit / Skala VAS (1 - 10):</label>
                <span className="text-sm font-black text-emerald-700 px-2 py-0.5 bg-emerald-50 rounded-lg">
                  {modalSeverity} / 10
                </span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={modalSeverity}
                onChange={(e) => setModalSeverity(parseInt(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>1: Ringan</span>
                <span>5: Cukup Mengganggu</span>
                <span>10: Sangat Menyakitkan</span>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setActiveModalZone(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleSaveModalPoint}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black cursor-pointer shadow-md shadow-emerald-600/20"
              >
                Simpan Titik
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
