import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  SkipForward,
  RotateCcw,
  Volume2,
  VolumeX,
  CheckCircle2,
  AlertTriangle,
  Heart,
  Wind,
  Layers,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  X,
} from 'lucide-react';
import { RecoveryRoutine, RecoveryStep } from '../../../types';

interface GuidedRecoverySessionPlayerProps {
  routine: RecoveryRoutine;
  onClose: () => void;
  onCompleteSession: (report: {
    routineId: string;
    durationMinutes: number;
    initialPainScore: number;
    finalPainScore: number;
    reliefScore: number;
    xpEarned: number;
  }) => void;
}

export const GuidedRecoverySessionPlayer: React.FC<GuidedRecoverySessionPlayerProps> = ({
  routine,
  onClose,
  onCompleteSession,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [timeRemainingSec, setTimeRemainingSec] = useState<number>(
    routine.steps[0]?.durationSeconds || 120
  );
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState<boolean>(true);
  const [breathPhase, setBreathPhase] = useState<'inhale' | 'hold' | 'exhale' | 'pause'>('inhale');
  const [breathCount, setBreathCount] = useState<number>(4);

  // Post Session Evaluation State
  const [showEvaluation, setShowEvaluation] = useState<boolean>(false);
  const [postSessionPainScore, setPostSessionPainScore] = useState<number>(2);

  const currentStep = routine.steps[currentStepIndex] || routine.steps[0];
  const totalSteps = routine.steps.length;

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Audio Speech Synthesis function
  const speakCue = (text: string) => {
    if (!isAudioEnabled || typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'id-ID';
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  // Trigger audio prompt when step changes
  useEffect(() => {
    if (currentStep?.audioPrompt) {
      speakCue(currentStep.audioPrompt);
    }
  }, [currentStepIndex, isAudioEnabled]);

  // Main step countdown timer
  useEffect(() => {
    if (isRunning && timeRemainingSec > 0) {
      timerRef.current = setInterval(() => {
        setTimeRemainingSec((prev) => prev - 1);
      }, 1000);
    } else if (timeRemainingSec === 0) {
      if (currentStepIndex < totalSteps - 1) {
        // Auto-advance to next step
        const nextIndex = currentStepIndex + 1;
        setCurrentStepIndex(nextIndex);
        setTimeRemainingSec(routine.steps[nextIndex].durationSeconds);
        speakCue(`Bagus! Lanjut ke gerakan berikutnya: ${routine.steps[nextIndex].title}`);
      } else {
        // Routine completed
        setIsRunning(false);
        setShowEvaluation(true);
        speakCue('Luar biasa! Sesi pemulihan aktif selesai. Silakan evaluasi rasa nyaman tubuh Anda.');
      }
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, timeRemainingSec, currentStepIndex, totalSteps, routine.steps]);

  // Breathing Pacer Cycle for breathing steps
  useEffect(() => {
    if (currentStep?.modality !== 'diaphragmatic_breathing' || !isRunning) return;

    const pattern = currentStep.breathingPattern || { inhaleSec: 4, holdSec: 7, exhaleSec: 8, pauseSec: 1 };
    let phase = breathPhase;
    let count = breathCount;

    const breathInterval = setInterval(() => {
      if (count > 1) {
        setBreathCount((prev) => prev - 1);
      } else {
        // Transition phases
        if (phase === 'inhale') {
          phase = pattern.holdSec > 0 ? 'hold' : 'exhale';
          count = pattern.holdSec > 0 ? pattern.holdSec : pattern.exhaleSec;
        } else if (phase === 'hold') {
          phase = 'exhale';
          count = pattern.exhaleSec;
        } else if (phase === 'exhale') {
          phase = pattern.pauseSec > 0 ? 'pause' : 'inhale';
          count = pattern.pauseSec > 0 ? pattern.pauseSec : pattern.inhaleSec;
        } else {
          phase = 'inhale';
          count = pattern.inhaleSec;
        }
        setBreathPhase(phase);
        setBreathCount(count);
      }
    }, 1000);

    return () => clearInterval(breathInterval);
  }, [currentStep, isRunning, breathPhase, breathCount]);

  const handleNextStep = () => {
    if (currentStepIndex < totalSteps - 1) {
      const nextIndex = currentStepIndex + 1;
      setCurrentStepIndex(nextIndex);
      setTimeRemainingSec(routine.steps[nextIndex].durationSeconds);
    } else {
      setShowEvaluation(true);
    }
  };

  const handlePrevStep = () => {
    if (currentStepIndex > 0) {
      const prevIndex = currentStepIndex - 1;
      setCurrentStepIndex(prevIndex);
      setTimeRemainingSec(routine.steps[prevIndex].durationSeconds);
    }
  };

  const handleRestartStep = () => {
    setTimeRemainingSec(currentStep.durationSeconds);
  };

  const handleFinishEvaluation = () => {
    onCompleteSession({
      routineId: routine.id,
      durationMinutes: routine.durationMinutes,
      initialPainScore: 7,
      finalPainScore: postSessionPainScore,
      reliefScore: Math.max(0, 7 - postSessionPainScore),
      xpEarned: 120,
    });
    onClose();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const stepProgressPercent =
    ((currentStep.durationSeconds - timeRemainingSec) / currentStep.durationSeconds) * 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="bg-slate-900 text-white rounded-3xl max-w-2xl w-full border border-slate-700 shadow-2xl overflow-hidden flex flex-col my-auto animate-in fade-in zoom-in duration-200">
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10.5px] font-black uppercase tracking-wider">
              Live Recovery Player
            </span>
            <span className="text-xs text-slate-400 font-medium">
              Langkah {currentStepIndex + 1} dari {totalSteps}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAudioEnabled(!isAudioEnabled)}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                isAudioEnabled
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
              title={isAudioEnabled ? 'Matikan Suara AI' : 'Aktifkan Suara AI'}
            >
              {isAudioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Routine Name & Overall Progress Bar */}
        <div className="px-5 pt-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5 font-medium">
            <span className="font-bold text-slate-200 truncate">{routine.title}</span>
            <span>{Math.round(((currentStepIndex + 1) / totalSteps) * 100)}% Total Selesai</span>
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-300"
              style={{ width: `${((currentStepIndex + 1) / totalSteps) * 100}%` }}
            />
          </div>
        </div>

        {/* Main Step Content */}
        <div className="p-5 sm:p-7 flex-1 space-y-6">
          {/* Step Title & Target Area */}
          <div className="text-center space-y-1">
            <span className="text-xs font-bold text-emerald-400 tracking-wide uppercase">
              Target: {currentStep.targetArea}
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {currentStep.title}
            </h3>
          </div>

          {/* Center Stage: Timer & Breathing Circle / Modality Visualizer */}
          <div className="relative flex flex-col items-center justify-center my-2">
            {/* Breathing Ring or Regular Countdown Ring */}
            {currentStep.modality === 'diaphragmatic_breathing' ? (
              <div className="relative flex flex-col items-center justify-center w-52 h-52 sm:w-60 sm:h-60 rounded-full bg-slate-950 border border-slate-800 shadow-inner">
                {/* Dynamic Breathing Halo Animation */}
                <div
                  className={`absolute inset-4 rounded-full border-2 transition-all duration-1000 ${
                    breathPhase === 'inhale'
                      ? 'scale-110 border-emerald-400 bg-emerald-500/10'
                      : breathPhase === 'hold'
                      ? 'scale-110 border-amber-400 bg-amber-500/10'
                      : breathPhase === 'exhale'
                      ? 'scale-90 border-blue-400 bg-blue-500/10'
                      : 'scale-95 border-slate-500 bg-slate-800/10'
                  }`}
                />

                <div className="relative z-10 text-center space-y-1">
                  <Wind className="w-6 h-6 text-emerald-400 mx-auto animate-pulse" />
                  <div className="text-2xl font-black uppercase tracking-wider text-white">
                    {breathPhase === 'inhale' && 'TARIK NAPAS'}
                    {breathPhase === 'hold' && 'TAHAN NAPAS'}
                    {breathPhase === 'exhale' && 'HEMBUSKAN'}
                    {breathPhase === 'pause' && 'RILEKS'}
                  </div>
                  <div className="text-3xl font-black text-emerald-300">{breathCount}s</div>
                  <div className="text-[11px] text-slate-400">Total Sisa: {formatTime(timeRemainingSec)}</div>
                </div>
              </div>
            ) : (
              <div className="relative flex flex-col items-center justify-center w-48 h-48 sm:w-56 sm:h-56 rounded-full bg-slate-950 border border-slate-800 shadow-inner">
                <svg className="absolute inset-0 w-full h-full -rotate-90">
                  <circle
                    cx="50%"
                    cy="50%"
                    r="44%"
                    className="text-slate-800"
                    strokeWidth="6"
                    stroke="currentColor"
                    fill="transparent"
                  />
                  <circle
                    cx="50%"
                    cy="50%"
                    r="44%"
                    className="text-emerald-500 transition-all duration-1000 ease-linear"
                    strokeWidth="6"
                    strokeDasharray={280}
                    strokeDashoffset={280 - (280 * stepProgressPercent) / 100}
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="transparent"
                  />
                </svg>

                <div className="relative z-10 text-center space-y-0.5">
                  <div className="text-4xl sm:text-5xl font-black text-white tracking-tighter">
                    {formatTime(timeRemainingSec)}
                  </div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    {isRunning ? 'Sedang Berjalan' : 'Dijeda'}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Trigger point tips or instructions list */}
          <div className="bg-slate-950/70 rounded-2xl p-4 border border-slate-800 space-y-2">
            {currentStep.triggerPointCue && (
              <div className="flex items-start gap-2 text-xs text-amber-300 bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                <span>
                  <strong className="font-black">Trigger Point Cue: </strong>
                  {currentStep.triggerPointCue}
                </span>
              </div>
            )}

            <div className="space-y-1.5 pt-1">
              {currentStep.instructions.map((inst, idx) => (
                <div key={idx} className="flex items-start gap-2 text-xs text-slate-300 leading-relaxed">
                  <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-black flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span>{inst}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Player Controls Bar */}
        <div className="p-4 sm:p-5 border-t border-slate-800 bg-slate-950 flex items-center justify-between gap-3">
          <button
            onClick={handlePrevStep}
            disabled={currentStepIndex === 0}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
              currentStepIndex === 0
                ? 'opacity-40 cursor-not-allowed text-slate-600'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
          >
            <span>Kembali</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRestartStep}
              className="p-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all cursor-pointer"
              title="Ulangi Langkah Ini"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsRunning(!isRunning)}
              className={`py-3 px-6 rounded-2xl font-black text-sm flex items-center gap-2 shadow-lg transition-all cursor-pointer ${
                isRunning
                  ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-amber-500/20'
                  : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 shadow-emerald-500/20'
              }`}
            >
              {isRunning ? (
                <>
                  <Pause className="w-4 h-4" />
                  <span>Jeda</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Lanjutkan</span>
                </>
              )}
            </button>

            <button
              onClick={handleNextStep}
              className="p-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all cursor-pointer"
              title="Lompat ke Langkah Berikutnya"
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => setShowEvaluation(true)}
            className="px-3 py-2 rounded-xl text-xs font-bold text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 transition-all cursor-pointer"
          >
            <span>Selesai</span>
          </button>
        </div>

        {/* Post Session Evaluation Modal */}
        {showEvaluation && (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-4">
            <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full text-center space-y-5 animate-in fade-in zoom-in duration-150">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <span className="text-[11px] font-black text-emerald-400 uppercase tracking-wider">
                  Sesi Pemulihan Tuntas
                </span>
                <h3 className="text-xl font-black text-white mt-1">Evaluasi Pasca-Sesi</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Bagaimana kondisi rasa nyeri atau kekakuan otot Anda saat ini?
                </p>
              </div>

              {/* VAS Pain Slider */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-left">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Tingkat Nyeri Baru:</span>
                  <span className="font-black text-emerald-400 text-sm bg-emerald-500/20 px-2 py-0.5 rounded-lg">
                    {postSessionPainScore} / 10
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="10"
                  value={postSessionPainScore}
                  onChange={(e) => setPostSessionPainScore(parseInt(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
                />
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>0: Bebas Nyeri</span>
                  <span>5: Masih Pegal</span>
                  <span>10: Nyeri Berat</span>
                </div>
              </div>

              {/* XP Award & Summary */}
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold">Hadiah Pemulihan:</span>
                </div>
                <span className="font-black text-emerald-300">+120 XP Recovery</span>
              </div>

              {/* Action Button */}
              <button
                onClick={handleFinishEvaluation}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-slate-950 font-black text-sm transition-all shadow-lg shadow-emerald-500/20 cursor-pointer"
              >
                Simpan & Sinkronisasi Ekosistem
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
