import React, { useState, useEffect } from 'react';
import {
  Droplets,
  Flame,
  Snowflake,
  Play,
  Pause,
  RotateCcw,
  Clock,
  Sparkles,
  AlertTriangle,
  Info,
  CheckCircle2,
  ShieldAlert,
} from 'lucide-react';
import { ContrastProtocol } from '../../../types';
import { CONTRAST_HYDRO_PROTOCOLS } from '../data/recoveryData';

export const ContrastTherapyGuide: React.FC = () => {
  const [selectedProtocol, setSelectedProtocol] = useState<ContrastProtocol>(
    CONTRAST_HYDRO_PROTOCOLS[0]
  );
  const [currentCycleIndex, setCurrentCycleIndex] = useState<number>(0);
  const [timeRemainingSec, setTimeRemainingSec] = useState<number>(
    selectedProtocol.cycles[0]?.durationSec || 180
  );
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const currentCycle = selectedProtocol.cycles[currentCycleIndex] || selectedProtocol.cycles[0];
  const totalCycles = selectedProtocol.cycles.length;

  useEffect(() => {
    setCurrentCycleIndex(0);
    setTimeRemainingSec(selectedProtocol.cycles[0]?.durationSec || 180);
    setIsRunning(false);
  }, [selectedProtocol]);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isRunning && timeRemainingSec > 0) {
      interval = setInterval(() => {
        setTimeRemainingSec((prev) => prev - 1);
      }, 1000);
    } else if (timeRemainingSec === 0) {
      if (currentCycleIndex < totalCycles - 1) {
        const next = currentCycleIndex + 1;
        setCurrentCycleIndex(next);
        setTimeRemainingSec(selectedProtocol.cycles[next].durationSec);
      } else {
        setIsRunning(false);
      }
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeRemainingSec, currentCycleIndex, totalCycles, selectedProtocol]);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-7 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-100 text-cyan-800 text-[11px] font-black uppercase tracking-wider">
              Hydrotherapy & Contrast Engine
            </span>
            <span className="text-xs text-slate-400 font-medium">Vascular Pumping Protocol</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Terapi Kontras & Hidroterapi Digital
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl leading-relaxed">
            Metode perendaman atau shower suhu bergantian (Panas vs Dingin) untuk menstimulasi efek pompa vaskular, mempercepat pembuangan limbah metabolik, dan menstabilkan sistem saraf otonom.
          </p>
        </div>

        {/* Protocol Selector Tabs */}
        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl">
          {CONTRAST_HYDRO_PROTOCOLS.map((proto) => (
            <button
              key={proto.id}
              onClick={() => setSelectedProtocol(proto)}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                selectedProtocol.id === proto.id
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {proto.goal === 'anti_inflammation' ? 'Anti-Inflamasi (3:1)' : 'Relaksasi Saraf (2:2)'}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Live Contrast Cycle Visualizer & Protocol Stages */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Live Dynamic Cycle Stage (6 cols) */}
        <div
          className={`lg:col-span-6 rounded-3xl p-6 border text-white flex flex-col justify-between shadow-lg transition-all duration-500 ${
            currentCycle.phase === 'cold'
              ? 'bg-gradient-to-b from-cyan-950 via-slate-950 to-cyan-950 border-cyan-700/50 shadow-cyan-900/20'
              : 'bg-gradient-to-b from-amber-950 via-slate-950 to-orange-950 border-amber-700/50 shadow-amber-900/20'
          }`}
        >
          <div className="space-y-4">
            {/* Top Indicator */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {currentCycle.phase === 'cold' ? (
                  <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-500/20 border border-cyan-400/30 text-cyan-300 text-xs font-black">
                    <Snowflake className="w-3.5 h-3.5 animate-spin" />
                    <span>FASE DINGIN (VASOKONSTRIKSI)</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/20 border border-amber-400/30 text-amber-300 text-xs font-black">
                    <Flame className="w-3.5 h-3.5 animate-pulse" />
                    <span>FASE HANGAT (VASODILATASI)</span>
                  </div>
                )}
              </div>

              <span className="text-xs text-slate-400 font-bold">
                Siklus {currentCycleIndex + 1} / {totalCycles}
              </span>
            </div>

            {/* Target Temperature & Countdown Display */}
            <div className="text-center py-4 space-y-1">
              <div className="text-xs font-bold text-slate-300 tracking-wider">
                {currentCycle.temperatureDesc}
              </div>
              <div className="text-5xl sm:text-6xl font-black font-mono tracking-tighter text-white">
                {formatTime(timeRemainingSec)}
              </div>
              <div className="text-xs text-slate-400 pt-1">{currentCycle.actionGuidance}</div>
            </div>

            {/* Physiological Effect Pill */}
            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-700/60 text-xs space-y-1">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                Mekanisme Biologis:
              </span>
              <p className="text-slate-400 leading-relaxed text-[11.5px]">
                {currentCycle.physiologicalEffect}
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
            <button
              onClick={() => {
                setTimeRemainingSec(currentCycle.durationSec);
                setIsRunning(false);
              }}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all cursor-pointer"
              title="Reset Siklus"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsRunning(!isRunning)}
              className={`flex-1 py-3 px-5 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer ${
                isRunning
                  ? 'bg-amber-500 hover:bg-amber-600 text-slate-950'
                  : 'bg-cyan-500 hover:bg-cyan-600 text-slate-950'
              }`}
            >
              {isRunning ? (
                <>
                  <Pause className="w-4 h-4" />
                  <span>Jeda Siklus</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>Mulai Siklus Kontras</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Col: Full Routine Timeline & Sauna Guidance (6 cols) */}
        <div className="lg:col-span-6 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Urutan Siklus Terapi ({selectedProtocol.totalDurationMin} Menit Total)
            </span>

            <div className="space-y-2">
              {selectedProtocol.cycles.map((c, idx) => {
                const isActive = currentCycleIndex === idx;
                return (
                  <div
                    key={idx}
                    className={`p-3 rounded-2xl border text-xs flex items-center justify-between transition-all ${
                      isActive
                        ? c.phase === 'cold'
                          ? 'border-cyan-500 bg-cyan-50/80 ring-2 ring-cyan-400/20'
                          : 'border-amber-500 bg-amber-50/80 ring-2 ring-amber-400/20'
                        : 'border-slate-200 bg-white opacity-80'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`w-6 h-6 rounded-full text-[11px] font-black flex items-center justify-center shrink-0 ${
                          c.phase === 'cold'
                            ? 'bg-cyan-100 text-cyan-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {idx + 1}
                      </span>
                      <div>
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <span>{c.phase === 'cold' ? 'Air Dingin' : 'Air Hangat'}</span>
                          <span className="text-slate-400 font-normal">({c.temperatureDesc})</span>
                        </div>
                        <div className="text-[11px] text-slate-500 line-clamp-1">
                          {c.actionGuidance}
                        </div>
                      </div>
                    </div>

                    <span className="font-mono font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md">
                      {Math.round(c.durationSec / 60)} m
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Sauna / Post-Therapy Care */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
            <div className="flex items-center gap-2 font-bold text-slate-900">
              <Droplets className="w-4 h-4 text-cyan-600" />
              <span>Instruksi Pasca-Terapi & Rehidrasi:</span>
            </div>
            <p className="text-slate-600 leading-relaxed text-[11.5px]">
              {selectedProtocol.postTherapyAdvice}
            </p>
            <div className="text-[11px] text-rose-700 font-medium bg-rose-50 p-2 rounded-xl border border-rose-100">
              <strong className="font-bold">Kontraindikasi Medis: </strong>
              {selectedProtocol.contraindications.join(', ')}.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
