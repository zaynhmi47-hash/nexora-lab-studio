import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Trophy,
  Activity,
  Clock,
  Flame,
  Sparkles,
  RotateCcw,
  Save,
  CheckCircle2,
  AlertTriangle,
  Bot,
  ShieldCheck,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { WorkoutSessionSummary } from '../../types/bodyAI';
import { ExerciseEngine } from '../../services/bodyAI/exerciseEngine';
import { UserProfile } from '../../types';

interface WorkoutResultScreenProps {
  summary: WorkoutSessionSummary;
  userProfile: UserProfile;
  onTryAgain: () => void;
  onSaveWorkout: (summary: WorkoutSessionSummary) => void;
  onReturnToDashboard: () => void;
}

export const WorkoutResultScreen: React.FC<WorkoutResultScreenProps> = ({
  summary,
  userProfile,
  onTryAgain,
  onSaveWorkout,
  onReturnToDashboard,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  const [aiCoachingSummary, setAiCoachingSummary] = useState<string | null>(
    summary.geminiCoachingSummary || null
  );
  const [isSaved, setIsSaved] = useState<boolean>(false);

  // Request AI Coaching Analysis from Gemini (Compact metrics only, zero camera frames)
  const handleRequestGeminiCoaching = async () => {
    try {
      setIsAiLoading(true);

      const compactPayload = ExerciseEngine.createCompactGeminiPayload(summary);

      const prompt = `Analisis sesi latihan berikut secara ringkas, berikan apresiasi, soroti form score, dan berikan 2 saran biomekanika terbaik untuk perbaikan repetisi berikutnya.
Data Sesi Latihan:
- Latihan: ${compactPayload.exercise}
- Total Repetisi: ${compactPayload.reps}
- Durasi: ${compactPayload.durationSeconds} detik
- Skor Form Rata-rata: ${compactPayload.formScore}%
- Rincian Metrik: Alignment ${compactPayload.scoreBreakdown.alignment}%, Depth ${compactPayload.scoreBreakdown.depth}%, Stability ${compactPayload.scoreBreakdown.stability}%, Symmetry ${compactPayload.scoreBreakdown.symmetry}%, Tempo ${compactPayload.scoreBreakdown.tempo}%
- Masalah Form Terdeteksi: ${compactPayload.detectedIssues.length > 0 ? compactPayload.detectedIssues.join(', ') : 'Tidak ada anomali signifikan'}

Pedoman Keselamatan:
- JANGAN mendiagnosis cedera medis.
- Berikan bahasa positif, membangun, dan fokus pada teknik gerakan.`;

      const res = await fetch('/api/ai/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          context: {
            userProfile: {
              name: userProfile.name,
              primaryGoal: userProfile.primaryGoal,
              fitnessLevel: userProfile.fitnessLevel,
              language: userProfile.language,
            },
            verifiedMetrics: {
              activeCaloriesBurned: summary.caloriesBurnedEstimate,
              dailySteps: 4500,
            },
          },
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to fetch Gemini coaching');
      }

      const data = await res.json();
      const text =
        data.reply ||
        (isIndonesian
          ? 'Sesi yang solid! Kedalaman dan kestabilan gerak Anda sangat konsisten. Pertahankan tempo terkontrol saat fase penurunan beban.'
          : 'Great session! Your depth and stability were consistent. Focus on controlled eccentric pacing on your next set.');

      setAiCoachingSummary(text);
      summary.geminiCoachingSummary = text;
    } catch (err) {
      console.warn('Gemini coaching fallback:', err);
      const fallback = isIndonesian
        ? 'Sesi latihan yang sangat baik! Form score Anda mencapai ' +
          summary.formScore +
          '%. Fokus pada menjaga lutut tetap sejajar dan aktifkan otot inti secara stabil.'
        : 'Solid workout session! Your form score reached ' +
          summary.formScore +
          '%. Keep your joints aligned and maintain core engagement.';
      setAiCoachingSummary(fallback);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleSave = () => {
    setIsSaved(true);
    onSaveWorkout(summary);
  };

  const scoreColor =
    summary.formScore >= 80
      ? 'text-emerald-400'
      : summary.formScore >= 60
      ? 'text-amber-400'
      : 'text-rose-400';

  return (
    <div id="workout-result-screen" className="max-w-4xl mx-auto space-y-6 pb-16">
      {/* Top Banner */}
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 text-center space-y-4 shadow-2xl relative overflow-hidden"
      >
        <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center shadow-lg border border-emerald-500/30">
          <Trophy className="w-8 h-8" />
        </div>

        <div className="space-y-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
            {isIndonesian ? 'Ringkasan Latihan Selesai' : 'Workout Complete'}
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-white">
            {summary.exerciseName}
          </h1>
        </div>

        {/* High-Level Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3">
          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-center">
            <span className="text-[11px] text-slate-400 uppercase font-semibold block">
              {summary.exerciseType === 'plank' ? (isIndonesian ? 'Durasi' : 'Hold Time') : (isIndonesian ? 'Total Reps' : 'Total Reps')}
            </span>
            <span className="text-2xl font-black text-white font-mono">
              {summary.exerciseType === 'plank' ? `${summary.durationSeconds}s` : summary.totalReps}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-center">
            <span className="text-[11px] text-slate-400 uppercase font-semibold block">
              {isIndonesian ? 'Skor Form' : 'Form Score'}
            </span>
            <span className={`text-2xl font-black font-mono ${scoreColor}`}>
              {summary.formScore}%
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-center">
            <span className="text-[11px] text-slate-400 uppercase font-semibold block">
              {isIndonesian ? 'Durasi' : 'Duration'}
            </span>
            <span className="text-2xl font-black text-slate-200 font-mono">
              {Math.floor(summary.durationSeconds / 60)}m {summary.durationSeconds % 60}s
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-center">
            <span className="text-[11px] text-slate-400 uppercase font-semibold block">
              {isIndonesian ? 'Est. Kalori' : 'Est. Burn'}
            </span>
            <span className="text-2xl font-black text-amber-400 font-mono">
              ~{summary.caloriesBurnedEstimate} kcal
            </span>
          </div>
        </div>
      </motion.div>

      {/* Form Breakdown + Issues Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
        {/* Form Score Metric Decomposition */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
          <h3 className="text-base font-bold text-white flex items-center justify-between">
            <span>{isIndonesian ? 'Analisis Rincian Form' : 'Form Breakdown Metrics'}</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </h3>

          <div className="space-y-3.5">
            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">{isIndonesian ? 'Kelurusan Sendi (Alignment)' : 'Joint Alignment'}</span>
                <span className="font-mono text-emerald-400 font-bold">{summary.scoreBreakdown.alignment}%</span>
              </div>
              <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${summary.scoreBreakdown.alignment}%` }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">{isIndonesian ? 'Kedalaman Gerak (Depth)' : 'Range / Depth'}</span>
                <span className="font-mono text-teal-400 font-bold">{summary.scoreBreakdown.depth}%</span>
              </div>
              <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-teal-500 rounded-full" style={{ width: `${summary.scoreBreakdown.depth}%` }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">{isIndonesian ? 'Stabilitas Inti (Stability)' : 'Core Stability'}</span>
                <span className="font-mono text-indigo-400 font-bold">{summary.scoreBreakdown.stability}%</span>
              </div>
              <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${summary.scoreBreakdown.stability}%` }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">{isIndonesian ? 'Simetri Gerak (Symmetry)' : 'L/R Symmetry'}</span>
                <span className="font-mono text-cyan-400 font-bold">{summary.scoreBreakdown.symmetry}%</span>
              </div>
              <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-cyan-500 rounded-full" style={{ width: `${summary.scoreBreakdown.symmetry}%` }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">{isIndonesian ? 'Tempo & Kontrol' : 'Tempo & Control'}</span>
                <span className="font-mono text-amber-400 font-bold">{summary.scoreBreakdown.tempo}%</span>
              </div>
              <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full" style={{ width: `${summary.scoreBreakdown.tempo}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Detected Issues */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl flex flex-col justify-between">
          <div className="space-y-3">
            <h3 className="text-base font-bold text-white flex items-center justify-between">
              <span>{isIndonesian ? 'Catatan Form Terdeteksi' : 'Detected Form Observations'}</span>
              <AlertTriangle className="w-4 h-4 text-amber-400" />
            </h3>

            {summary.detectedIssues.length === 0 ? (
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-3 text-emerald-300 text-xs">
                <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-emerald-400" />
                <span>
                  {isIndonesian
                    ? 'Luar biasa! Tidak ada anomali atau kesalahan form signifikan yang terdeteksi selama sesi.'
                    : 'Great job! No significant biomechanical form deviations detected during this session.'}
                </span>
              </div>
            ) : (
              <div className="space-y-2">
                {summary.detectedIssues.map((issue, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-800/80 border border-amber-500/30 flex items-start gap-2.5 text-xs text-amber-200"
                  >
                    <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-400" />
                    <span>{issue}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 text-[11px] text-slate-400 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>
              {isIndonesian
                ? 'Semua data pose dihitung secara deterministik dan terlindungi privasi di perangkat.'
                : 'Pose metrics are deterministically computed on-device with zero cloud telemetry.'}
            </span>
          </div>
        </div>
      </div>

      {/* Gemini AI Coaching Card (Compact payload request) */}
      <div className="bg-slate-900/90 border border-emerald-500/40 rounded-3xl p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {isIndonesian ? 'Evaluasi Pelatih Cerdas Gemini AI' : 'Gemini AI Coaching Evaluation'}
              </h3>
              <p className="text-xs text-slate-400">
                {isIndonesian
                  ? 'Kirimkan metrik ringkas sesi untuk mendapatkan ulasan teknik & motivasi.'
                  : 'Receive personalized technique advice based on your compact session metrics.'}
              </p>
            </div>
          </div>

          {!aiCoachingSummary && (
            <button
              id="btn-request-gemini-coaching"
              onClick={handleRequestGeminiCoaching}
              disabled={isAiLoading}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-lg disabled:opacity-50"
            >
              {isAiLoading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              <span>{isIndonesian ? 'Analisis Sesi Saya' : 'Analyze My Workout'}</span>
            </button>
          )}
        </div>

        {aiCoachingSummary && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-100 text-xs sm:text-sm leading-relaxed space-y-2"
          >
            <div className="font-semibold text-emerald-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <span>{isIndonesian ? 'Ulasan Pelatih Gemini:' : 'Gemini Coach Review:'}</span>
            </div>
            <p>{aiCoachingSummary}</p>
          </motion.div>
        )}
      </div>

      {/* Action Footer Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <button
          onClick={onReturnToDashboard}
          className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs sm:text-sm font-semibold transition-colors cursor-pointer border border-slate-700"
        >
          {isIndonesian ? 'Kembali ke Beranda Activity' : 'Return to Activity'}
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={onTryAgain}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 transition-colors cursor-pointer border border-slate-700"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{isIndonesian ? 'Latihan Ulang' : 'Try Again'}</span>
          </button>

          <button
            onClick={handleSave}
            disabled={isSaved}
            className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-lg transition-colors cursor-pointer disabled:opacity-60"
          >
            {isSaved ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            <span>{isSaved ? (isIndonesian ? 'Tersimpan!' : 'Saved!') : (isIndonesian ? 'Simpan Latihan' : 'Save Workout')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
