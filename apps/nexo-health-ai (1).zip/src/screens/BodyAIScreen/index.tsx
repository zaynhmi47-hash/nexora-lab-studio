import React, { useState } from 'react';
import { ExerciseType, WorkoutSessionSummary } from '../../types/bodyAI';
import { UserProfile } from '../../types';
import { ExerciseSelectScreen } from './ExerciseSelectScreen';
import { CameraCalibrationScreen } from './CameraCalibrationScreen';
import { LiveWorkoutScreen } from './LiveWorkoutScreen';
import { WorkoutResultScreen } from './WorkoutResultScreen';
import { BodyAITestModal } from './BodyAITestModal';

export type BodyAIScreenMode = 'select' | 'calibration' | 'workout' | 'result';

interface BodyAIScreenProps {
  userProfile: UserProfile;
  initialExercise?: ExerciseType;
  onNavigateTab?: (tab: string) => void;
}

export const BodyAIScreen: React.FC<BodyAIScreenProps> = ({
  userProfile,
  initialExercise = 'squat',
  onNavigateTab,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [mode, setMode] = useState<BodyAIScreenMode>('select');
  const [selectedExercise, setSelectedExercise] = useState<ExerciseType>(initialExercise);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);
  const [latestSummary, setLatestSummary] = useState<WorkoutSessionSummary | null>(null);
  const [isTestModalOpen, setIsTestModalOpen] = useState<boolean>(false);

  const handleSelectExercise = (type: ExerciseType) => {
    setSelectedExercise(type);
    setMode('calibration');
  };

  const handleCalibrationComplete = (stream: MediaStream | null) => {
    setMediaStream(stream);
    setMode('workout');
  };

  const handleFinishWorkout = (summary: WorkoutSessionSummary) => {
    setLatestSummary(summary);
    setMode('result');
  };

  const handleTryAgain = () => {
    setMode('calibration');
  };

  const handleSaveWorkout = (summary: WorkoutSessionSummary) => {
    // Optionally trigger feedback or notification
    if (onNavigateTab) {
      onNavigateTab('workout');
    } else {
      setMode('select');
    }
  };

  const handleReturnToDashboard = () => {
    if (onNavigateTab) {
      onNavigateTab('workout');
    } else {
      setMode('select');
    }
  };

  return (
    <div id="body-ai-container" className="w-full min-h-[calc(100vh-140px)]">
      {mode === 'select' && (
        <ExerciseSelectScreen
          userProfile={userProfile}
          onSelectExercise={handleSelectExercise}
          onOpenTestSuite={() => setIsTestModalOpen(true)}
        />
      )}

      {mode === 'calibration' && (
        <CameraCalibrationScreen
          exerciseType={selectedExercise}
          userProfile={userProfile}
          onBack={() => setMode('select')}
          onCalibrationComplete={handleCalibrationComplete}
        />
      )}

      {mode === 'workout' && (
        <LiveWorkoutScreen
          exerciseType={selectedExercise}
          mediaStream={mediaStream}
          userProfile={userProfile}
          onFinishWorkout={handleFinishWorkout}
          onCancelWorkout={() => setMode('select')}
        />
      )}

      {mode === 'result' && latestSummary && (
        <WorkoutResultScreen
          summary={latestSummary}
          userProfile={userProfile}
          onTryAgain={handleTryAgain}
          onSaveWorkout={handleSaveWorkout}
          onReturnToDashboard={handleReturnToDashboard}
        />
      )}

      <BodyAITestModal
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
        isIndonesian={isIndonesian}
      />
    </div>
  );
};
