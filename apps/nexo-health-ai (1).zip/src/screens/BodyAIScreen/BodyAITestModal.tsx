import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Play,
  CheckCircle2,
  XCircle,
  Sparkles,
  TestTube,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';
import { runBodyAITestSuite, BodyAITestSuiteReport, TestResultItem } from '../../services/bodyAI/testBodyAI';

interface BodyAITestModalProps {
  isOpen: boolean;
  onClose: () => void;
  isIndonesian: boolean;
}

export const BodyAITestModal: React.FC<BodyAITestModalProps> = ({
  isOpen,
  onClose,
  isIndonesian,
}) => {
  const [report, setReport] = useState<BodyAITestSuiteReport | null>(() => runBodyAITestSuite());

  const handleRerunTests = () => {
    const res = runBodyAITestSuite();
    setReport(res);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden"
        >
          {/* Header */}
          <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <TestTube className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">
                  {isIndonesian ? 'Uji Otomatis Algoritma Body AI' : 'Body AI Pure Unit Test Suite'}
                </h3>
                <p className="text-xs text-slate-400">
                  {isIndonesian
                    ? 'Verifikasi matematika murni, transisi State Machine, filter derau, & kalibrasi'
                    : 'Validating pure geometry math, FSM cycles, noise debouncing & framing guards'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Test Metrics Summary */}
          {report && (
            <div className="p-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4 text-xs font-semibold">
                <span className="text-slate-300">
                  Total: <strong className="text-white font-mono">{report.totalTests}</strong>
                </span>
                <span className="text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  {report.passedTests} {isIndonesian ? 'Berhasil' : 'Passed'}
                </span>
                {report.failedTests > 0 && (
                  <span className="text-rose-400 flex items-center gap-1">
                    <XCircle className="w-4 h-4" />
                    {report.failedTests} {isIndonesian ? 'Gagal' : 'Failed'}
                  </span>
                )}
              </div>

              <button
                onClick={handleRerunTests}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-md transition-all"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{isIndonesian ? 'Jalankan Ulang Pengujian' : 'Rerun Suite'}</span>
              </button>
            </div>
          )}

          {/* Test Results List */}
          <div className="p-5 overflow-y-auto space-y-3 flex-1">
            {report?.results.map((item: TestResultItem) => (
              <div
                key={item.id}
                className={`p-3.5 rounded-2xl border flex items-start gap-3 text-xs ${
                  item.passed
                    ? 'bg-emerald-950/20 border-emerald-500/30 text-slate-200'
                    : 'bg-rose-950/30 border-rose-500/40 text-rose-200'
                }`}
              >
                {item.passed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
                )}

                <div className="space-y-0.5 flex-1">
                  <div className="flex items-center justify-between">
                    <strong className="font-bold text-white">{item.name}</strong>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 uppercase">
                      {item.category}
                    </span>
                  </div>
                  <p className="text-slate-300">{item.message}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{isIndonesian ? '100% Fungsi Murni Bebas Efek Samping' : '100% Deterministic Pure Unit Tests'}</span>
            </span>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium cursor-pointer"
            >
              {isIndonesian ? 'Tutup' : 'Close'}
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
