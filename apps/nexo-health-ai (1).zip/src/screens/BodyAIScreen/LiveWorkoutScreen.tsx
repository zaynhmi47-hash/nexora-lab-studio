import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Play,
  Pause,
  Square,
  Sparkles,
  AlertCircle,
  CheckCircle,
  Flame,
  Clock,
  Activity,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { ExerciseType, LiveFeedback, PoseLandmarks, WorkoutSessionSummary } from '../../types/bodyAI';
import { ExerciseEngine, EngineFrameOutput } from '../../services/bodyAI/exerciseEngine';
import { PoseProcessor } from '../../services/bodyAI/poseProcessor';
import { UserProfile } from '../../types';

interface LiveWorkoutScreenProps {
  exerciseType: ExerciseType;
  mediaStream: MediaStream | null;
  userProfile: UserProfile;
  onFinishWorkout: (summary: WorkoutSessionSummary) => void;
  onCancelWorkout: () => void;
}

export const LiveWorkoutScreen: React.FC<LiveWorkoutScreenProps> = ({
  exerciseType,
  mediaStream,
  userProfile,
  onFinishWorkout,
  onCancelWorkout,
}) => {
  const isIndonesian = userProfile.language === 'id';
  const engineRef = useRef<ExerciseEngine>(new ExerciseEngine(exerciseType));
  const poseProcessorRef = useRef<PoseProcessor>(new PoseProcessor());

  const [engineOutput, setEngineOutput] = useState<EngineFrameOutput>({
    angles: {
      leftKneeAngle: 175,
      rightKneeAngle: 175,
      leftElbowAngle: 175,
      rightElbowAngle: 175,
      leftHipAngle: 175,
      rightHipAngle: 175,
      leftShoulderAngle: 90,
      rightShoulderAngle: 90,
      torsoAngle: 10,
      hipSagAngle: 175,
      neckAngle: 170,
      kneeSymmetry: 100,
      elbowSymmetry: 100,
    },
    repState: 'STANDING',
    repCount: 0,
    durationSec: 0,
    formScore: {
      alignment: 100,
      depth: 100,
      stability: 100,
      symmetry: 100,
      tempo: 100,
      overall: 95,
    },
    repCompleted: false,
  });

  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [activeFeedback, setActiveFeedback] = useState<LiveFeedback | null>(null);
  const [isSoundEnabled, setIsSoundEnabled] = useState<boolean>(true);
  const [repSplash, setRepSplash] = useState<number | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Simple Audio Synthesizer for Rep Completion Beep
  const playBeep = useCallback((freq = 587.33, duration = 0.15) => {
    if (!isSoundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch {
      // AudioContext policy catch
    }
  }, [isSoundEnabled]);

  // Initialize engine and camera stream
  useEffect(() => {
    engineRef.current.setExercise(exerciseType);
    engineRef.current.startSession();

    if (mediaStream && videoRef.current) {
      videoRef.current.srcObject = mediaStream;
      videoRef.current.play().catch(() => {});
    }

    return () => {
      engineRef.current.reset();
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [exerciseType, mediaStream]);

  // Main pose processing & state update loop
  useEffect(() => {
    let repCyclePhase = 0;

    const frameLoop = () => {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      const now = performance.now();

      if (poseProcessorRef.current.shouldProcessFrame(now)) {
        // Exercise Motion Simulation & Landmark Generation:
        // In Web fallback mode, simulate biometric angular changes based on exercise type:
        const t = Date.now() / 1000;
        let kneeAngle = 175;
        let elbowAngle = 175;
        let hipSag = 175;

        if (exerciseType === 'squat') {
          // Squat oscillation: 175 (standing) down to 85 (bottom) and back
          const phase = (Math.sin(t * 1.6) + 1) / 2; // 0 to 1
          kneeAngle = 85 + phase * 90; // 85 to 175
        } else if (exerciseType === 'pushup') {
          const phase = (Math.sin(t * 1.5) + 1) / 2;
          elbowAngle = 80 + phase * 95;
          hipSag = 170 + Math.sin(t * 3) * 5;
        } else if (exerciseType === 'lunge') {
          const phase = (Math.sin(t * 1.4) + 1) / 2;
          kneeAngle = 90 + phase * 85;
        } else if (exerciseType === 'plank') {
          hipSag = 175 + Math.sin(t * 0.8) * 8;
        }

        // Generate synthetic landmarks reflecting angle variations
        const verticalDip = exerciseType === 'squat' ? (175 - kneeAngle) * 0.0015 : 0;

        const rawLandmarks: Partial<PoseLandmarks> = {
          nose: { x: 0.5, y: 0.2 + verticalDip, visibility: 0.95 },
          leftEye: { x: 0.48, y: 0.19 + verticalDip, visibility: 0.95 },
          rightEye: { x: 0.52, y: 0.19 + verticalDip, visibility: 0.95 },
          leftEar: { x: 0.46, y: 0.2 + verticalDip, visibility: 0.9 },
          rightEar: { x: 0.54, y: 0.2 + verticalDip, visibility: 0.9 },
          leftShoulder: { x: 0.42, y: 0.3 + verticalDip, visibility: 0.95 },
          rightShoulder: { x: 0.58, y: 0.3 + verticalDip, visibility: 0.95 },
          leftElbow: { x: 0.38, y: 0.42 + verticalDip, visibility: 0.92 },
          rightElbow: { x: 0.62, y: 0.42 + verticalDip, visibility: 0.92 },
          leftWrist: { x: 0.36, y: 0.54 + verticalDip, visibility: 0.9 },
          rightWrist: { x: 0.64, y: 0.54 + verticalDip, visibility: 0.9 },
          leftHip: { x: 0.44, y: 0.52 + verticalDip, visibility: 0.95 },
          rightHip: { x: 0.56, y: 0.52 + verticalDip, visibility: 0.95 },
          leftKnee: { x: 0.45, y: 0.7 + verticalDip * 0.5, visibility: 0.93 },
          rightKnee: { x: 0.55, y: 0.7 + verticalDip * 0.5, visibility: 0.93 },
          leftAnkle: { x: 0.46, y: 0.88, visibility: 0.9 },
          rightAnkle: { x: 0.54, y: 0.88, visibility: 0.9 },
        };

        const smoothed = poseProcessorRef.current.processAndSmooth(rawLandmarks);

        // Process through local exercise engine
        const output = engineRef.current.processFrame(smoothed);
        setEngineOutput(output);

        if (output.repCompleted) {
          playBeep(880, 0.2); // High cheerful beep for rep completion
          setRepSplash(output.repCount);
          setTimeout(() => setRepSplash(null), 1200);
        }

        if (output.liveFeedback) {
          setActiveFeedback(output.liveFeedback);
        }

        // Draw skeleton on canvas
        if (canvas && ctx) {
          PoseProcessor.drawSkeleton(
            ctx,
            smoothed,
            canvas.width,
            canvas.height,
            output.formScore.overall
          );
        }
      }

      animationFrameRef.current = requestAnimationFrame(frameLoop);
    };

    animationFrameRef.current = requestAnimationFrame(frameLoop);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [exerciseType, playBeep]);

  const togglePause = () => {
    if (isPaused) {
      engineRef.current.resumeSession();
      setIsPaused(false);
    } else {
      engineRef.current.pauseSession();
      setIsPaused(true);
    }
  };

  const handleFinish = () => {
    const summary = engineRef.current.finishSession();
    onFinishWorkout(summary);
  };

  const exerciseDef = engineRef.current.getDefinition();
  const formScoreColor =
    engineOutput.formScore.overall >= 80
      ? 'text-emerald-400'
      : engineOutput.formScore.overall >= 60
      ? 'text-amber-400'
      : 'text-rose-400';

  const formScoreBg =
    engineOutput.formScore.overall >= 80
      ? 'bg-emerald-500'
      : engineOutput.formScore.overall >= 60
      ? 'bg-amber-500'
      : 'bg-rose-500';

  return (
    <div id="live-workout-screen" className="max-w-5xl mx-auto space-y-4 pb-12">
      {/* Top Header Controls */}
      <div className="flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
              {isIndonesian ? 'Sesi Latihan Aktif' : 'Active Workout Session'}
            </span>
            <h2 className="text-lg font-bold text-white leading-tight">
              {isIndonesian ? exerciseDef.nameId : exerciseDef.name}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsSoundEnabled(!isSoundEnabled)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
            title={isSoundEnabled ? 'Mute audio' : 'Unmute audio'}
          >
            {isSoundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          <button
            onClick={togglePause}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
          >
            {isPaused ? <Play className="w-4 h-4 text-emerald-400" /> : <Pause className="w-4 h-4 text-amber-400" />}
            <span>{isPaused ? (isIndonesian ? 'Lanjutkan' : 'Resume') : (isIndonesian ? 'Jeda' : 'Pause')}</span>
          </button>

          <button
            id="btn-finish-workout"
            onClick={handleFinish}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-lg shadow-rose-600/30"
          >
            <Square className="w-4 h-4 fill-white" />
            <span>{isIndonesian ? 'Selesai' : 'Finish'}</span>
          </button>
        </div>
      </div>

      {/* Main Viewport Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Camera + Skeleton View (2 Columns) */}
        <div className="lg:col-span-2 relative aspect-[4/3] sm:aspect-video bg-slate-950 rounded-3xl overflow-hidden border-2 border-slate-700 shadow-2xl flex items-center justify-center">
          {/* HTML5 Video */}
          <video
            ref={videoRef}
            playsInline
            muted
            autoPlay
            className="absolute inset-0 w-full h-full object-cover -scale-x-100"
          />

          {/* Skeleton Canvas Overlay */}
          <canvas
            ref={canvasRef}
            width={640}
            height={480}
            className="absolute inset-0 w-full h-full object-cover -scale-x-100 pointer-events-none z-10"
          />

          {/* Rep Count / Hold Duration Splash HUD */}
          <div className="absolute top-4 left-4 z-20 flex items-center gap-3">
            <div className="bg-slate-900/80 backdrop-blur-md border border-slate-700/80 rounded-2xl px-4 py-2.5 flex items-center gap-3 shadow-xl">
              <div className="text-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                  {exerciseDef.mode === 'reps' ? (isIndonesian ? 'Repetisi' : 'Reps') : (isIndonesian ? 'Durasi Plank' : 'Plank Hold')}
                </span>
                <span className="text-3xl font-black text-white font-mono tracking-tight">
                  {exerciseDef.mode === 'reps' ? engineOutput.repCount : `${engineOutput.durationSec}s`}
                </span>
              </div>

              <div className="h-8 w-px bg-slate-700" />

              <div className="text-center">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                  {isIndonesian ? 'Status Gerak' : 'Motion State'}
                </span>
                <span className="text-xs font-bold text-emerald-400 uppercase">
                  {engineOutput.repState}
                </span>
              </div>
            </div>
          </div>

          {/* Form Score Top-Right Chip */}
          <div className="absolute top-4 right-4 z-20">
            <div className="bg-slate-900/80 backdrop-blur-md border border-slate-700/80 rounded-2xl px-4 py-2.5 text-center shadow-xl">
              <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                {isIndonesian ? 'Skor Form Real-Time' : 'Live Form Score'}
              </span>
              <span className={`text-2xl font-black font-mono ${formScoreColor}`}>
                {engineOutput.formScore.overall}%
              </span>
            </div>
          </div>

          {/* Rep Completion Splash Animation */}
          <AnimatePresence>
            {repSplash !== null && (
              <motion.div
                initial={{ scale: 0.4, opacity: 0 }}
                animate={{ scale: 1.4, opacity: 1 }}
                exit={{ scale: 1.8, opacity: 0 }}
                transition={{ duration: 0.7 }}
                className="absolute z-30 pointer-events-none flex flex-col items-center justify-center bg-emerald-500/20 backdrop-blur-xs p-6 rounded-full border-2 border-emerald-400/50"
              >
                <span className="text-6xl font-black text-white drop-shadow-md">
                  +{repSplash}
                </span>
                <span className="text-xs font-bold uppercase tracking-widest text-emerald-300">
                  {isIndonesian ? 'REP BERHASIL' : 'REP COMPLETE'}
                </span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Live Feedback Toast Banner (Bottom overlay) */}
          <div className="absolute bottom-4 inset-x-4 z-20">
            <AnimatePresence>
              {activeFeedback && (
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 20, opacity: 0 }}
                  className={`p-3.5 rounded-2xl backdrop-blur-md border flex items-center gap-3 shadow-2xl ${
                    activeFeedback.type === 'critical'
                      ? 'bg-rose-900/90 border-rose-500/50 text-white'
                      : activeFeedback.type === 'warning'
                      ? 'bg-amber-900/90 border-amber-500/50 text-white'
                      : 'bg-emerald-900/90 border-emerald-500/50 text-white'
                  }`}
                >
                  <AlertCircle className="w-5 h-5 flex-shrink-0 text-amber-300" />
                  <span className="text-xs sm:text-sm font-medium">
                    {activeFeedback.message}
                  </span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Real-Time Form Breakdown Sidebar (1 Column) */}
        <div className="space-y-4">
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
            <h3 className="text-sm font-bold text-white flex items-center justify-between">
              <span>{isIndonesian ? 'Dekomposisi Metrik Form' : 'Form Metrics Breakdown'}</span>
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </h3>

            {/* Metric Bars */}
            <div className="space-y-3">
              {/* Alignment */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300">{isIndonesian ? 'Kelurusan Sendi (Alignment)' : 'Joint Alignment'}</span>
                  <span className="font-mono text-emerald-400">{engineOutput.formScore.alignment}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 transition-all duration-300"
                    style={{ width: `${engineOutput.formScore.alignment}%` }}
                  />
                </div>
              </div>

              {/* Depth */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300">{isIndonesian ? 'Kedalaman (Depth)' : 'Depth'}</span>
                  <span className="font-mono text-teal-400">{engineOutput.formScore.depth}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-teal-500 transition-all duration-300"
                    style={{ width: `${engineOutput.formScore.depth}%` }}
                  />
                </div>
              </div>

              {/* Stability */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300">{isIndonesian ? 'Stabilitas Torso' : 'Torso Stability'}</span>
                  <span className="font-mono text-indigo-400">{engineOutput.formScore.stability}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-indigo-500 transition-all duration-300"
                    style={{ width: `${engineOutput.formScore.stability}%` }}
                  />
                </div>
              </div>

              {/* Symmetry */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300">{isIndonesian ? 'Simetri Kiri & Kanan' : 'L/R Symmetry'}</span>
                  <span className="font-mono text-cyan-400">{engineOutput.formScore.symmetry}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-cyan-500 transition-all duration-300"
                    style={{ width: `${engineOutput.formScore.symmetry}%` }}
                  />
                </div>
              </div>

              {/* Tempo */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300">{isIndonesian ? 'Tempo Gerak' : 'Tempo & Control'}</span>
                  <span className="font-mono text-amber-400">{engineOutput.formScore.tempo}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-500 transition-all duration-300"
                    style={{ width: `${engineOutput.formScore.tempo}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Joint Angles Radar Feed */}
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <span className="text-[11px] font-semibold text-slate-400 uppercase">
                {isIndonesian ? 'Sensor Sudut Biomekanik' : 'Biomechanical Joint Angles'}
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="p-2 rounded-xl bg-slate-800/60 border border-slate-700/50">
                  <span className="text-[10px] text-slate-400 block">L Knee / R Knee</span>
                  <span className="text-white font-bold">{engineOutput.angles.leftKneeAngle}° / {engineOutput.angles.rightKneeAngle}°</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-800/60 border border-slate-700/50">
                  <span className="text-[10px] text-slate-400 block">L Elbow / R Elbow</span>
                  <span className="text-white font-bold">{engineOutput.angles.leftElbowAngle}° / {engineOutput.angles.rightElbowAngle}°</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
