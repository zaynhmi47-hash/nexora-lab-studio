import React from 'react';
import { motion } from 'motion/react';
import {
  Dumbbell,
  ShieldAlert,
  ChevronRight,
  Flame,
  Clock,
  Target,
  Sparkles,
  Camera,
  Activity,
  CheckCircle2,
  TestTube,
} from 'lucide-react';
import { ExerciseType } from '../../types/bodyAI';
import { getAllExercises } from '../../services/bodyAI/exercises';
import { UserProfile } from '../../types';
import { getTranslation } from '../../data/translations';

interface ExerciseSelectScreenProps {
  userProfile: UserProfile;
  onSelectExercise: (type: ExerciseType) => void;
  onOpenTestSuite: () => void;
}

export const ExerciseSelectScreen: React.FC<ExerciseSelectScreenProps> = ({
  userProfile,
  onSelectExercise,
  onOpenTestSuite,
}) => {
  const isIndonesian = userProfile.language === 'id';
  const t = (key: string) => getTranslation(userProfile.language, key);
  const exercises = getAllExercises();

  return (
    <div id="exercise-select-screen" className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'MediaPipe Pose AI On-Device' : 'MediaPipe Pose On-Device AI'}</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            {isIndonesian ? 'Pilih Gerakan Latihan Body AI' : 'Select Body AI Exercise'}
          </h1>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            {isIndonesian
              ? 'Analisis gerakan real-time 100% lokal di perangkat Anda. Privasi terjamin tanpa pengunggahan video mentah ke server.'
              : 'Real-time computer-vision exercise tracking processed 100% on-device. Zero raw video uploaded.'}
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              id="btn-open-bodyai-tests"
              onClick={onOpenTestSuite}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-medium text-white transition-colors"
            >
              <TestTube className="w-4 h-4 text-emerald-300" />
              <span>{isIndonesian ? 'Uji Algoritma Pure Math & FSM' : 'Run Pure Math & FSM Tests'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Safety Notice Banner (Mandatory safety disclaimer) */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 flex items-start gap-3 text-amber-300 text-xs leading-relaxed">
        <ShieldAlert className="w-5 h-5 flex-shrink-0 mt-0.5 text-amber-400" />
        <div>
          <strong className="font-semibold block mb-0.5">
            {isIndonesian ? 'Panduan Keselamatan & Kesehatan:' : 'Health & Safety Guidance:'}
          </strong>
          {isIndonesian
            ? 'Fitur ini menyediakan panduan kebugaran dan biomekanika tubuh, BUKAN sistem diagnostik medis atau cedera klinis. Hentikan latihan jika merasakan nyeri akut dan konsultasikan dengan tenaga medis.'
            : 'This feature provides fitness and biomechanical form guidance, NOT medical or injury diagnosis. Stop exercising immediately if you feel pain and consult a healthcare professional.'}
        </div>
      </div>

      {/* Exercise Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
        {exercises.map((ex) => {
          const isSquat = ex.type === 'squat';
          const isPushup = ex.type === 'pushup';
          const isLunge = ex.type === 'lunge';
          const isPlank = ex.type === 'plank';

          const accentColor = isSquat
            ? 'emerald'
            : isPushup
            ? 'indigo'
            : isLunge
            ? 'teal'
            : 'cyan';

          return (
            <motion.div
              key={ex.type}
              id={`exercise-card-${ex.type}`}
              whileHover={{ y: -3 }}
              transition={{ duration: 0.2 }}
              className="bg-slate-800/80 border border-slate-700/80 hover:border-emerald-500/50 rounded-2xl p-5 sm:p-6 flex flex-col justify-between shadow-lg relative group transition-all"
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                      {ex.category.replace('_', ' ')}
                    </span>
                    <h3 className="text-xl font-bold text-white group-hover:text-emerald-300 transition-colors">
                      {isIndonesian ? ex.nameId : ex.name}
                    </h3>
                  </div>

                  <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-700/60 text-slate-300 border border-slate-600/50">
                    {ex.difficulty}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 line-clamp-2">
                  {isIndonesian ? ex.cameraSetupAdviceId : ex.cameraSetupAdvice}
                </p>

                {/* Target Muscles */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5 text-emerald-400" />
                    {isIndonesian ? 'Target Otot Utama:' : 'Target Muscle Groups:'}
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {(isIndonesian ? ex.targetMusclesId : ex.targetMuscles).map((m, idx) => (
                      <span
                        key={idx}
                        className="text-[11px] px-2 py-0.5 rounded-md bg-slate-900/60 text-slate-300 border border-slate-700/50"
                      >
                        {m}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Metrics Meta */}
                <div className="pt-2 grid grid-cols-2 gap-2 text-xs border-t border-slate-700/50 text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{ex.mode === 'reps' ? `${ex.defaultTargetReps} Reps` : `${ex.defaultTargetDurationSec}s Hold`}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Camera className="w-3.5 h-3.5 text-teal-400" />
                    <span>{ex.idealDistanceMeters}</span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <button
                id={`btn-select-${ex.type}`}
                onClick={() => onSelectExercise(ex.type)}
                className="mt-5 w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-medium text-sm flex items-center justify-center gap-2 shadow-md hover:shadow-emerald-500/20 transition-all cursor-pointer"
              >
                <span>{isIndonesian ? 'Mulai Analisis Gerakan' : 'Start Motion Analysis'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
