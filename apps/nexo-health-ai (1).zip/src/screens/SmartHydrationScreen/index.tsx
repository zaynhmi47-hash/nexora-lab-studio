import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Droplets,
  Sun,
  Flame,
  ArrowLeft,
  Activity,
  Sparkles,
  Plus,
  Minus,
  CheckCircle2,
  Clock,
  Zap,
  Info,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';
import { UserProfile, DailyLog } from '../../types';

interface SmartHydrationScreenProps {
  userProfile: UserProfile;
  dailyLog: DailyLog;
  onAddWater: (ml: number) => void;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const SmartHydrationScreen: React.FC<SmartHydrationScreenProps> = ({
  userProfile,
  dailyLog,
  onAddWater,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // Climate and exercise adjustment parameters
  const [ambientTemp, setAmbientTemp] = useState<number>(31); // 31°C tropical Indonesia
  const [workoutDuration, setWorkoutDuration] = useState<number>(45); // 45 min workout
  const [sweatRate, setSweatRate] = useState<'low' | 'medium' | 'high'>('medium');
  const [electrolytePillTaken, setElectrolytePillTaken] = useState(false);

  // Dynamic calculation of fluid requirements
  const baseTarget = userProfile.dailyWaterTargetMl || 2500;
  const tempAddition = ambientTemp > 28 ? (ambientTemp - 28) * 60 : 0;
  const exerciseAddition = workoutDuration * (sweatRate === 'high' ? 14 : sweatRate === 'medium' ? 10 : 7);
  const totalDynamicTarget = Math.round(baseTarget + tempAddition + exerciseAddition);
  const currentIntake = dailyLog.waterIntakeMl;
  const percentComplete = Math.min(100, Math.round((currentIntake / totalDynamicTarget) * 100));

  // Estimated electrolyte loss (mg)
  const sodiumLossMg = Math.round(exerciseAddition * 0.9);
  const potassiumLossMg = Math.round(exerciseAddition * 0.2);
  const magnesiumLossMg = Math.round(exerciseAddition * 0.05);

  const hydrationTimeline = [
    { time: '07:00 WIB', label: isIndonesian ? 'Bangun Tidur (Metabolisme Kickstart)' : 'Morning Rise', amountMl: 500, done: currentIntake >= 500 },
    { time: '10:00 WIB', label: isIndonesian ? 'Kerja Fokus & Elektrolit Ringan' : 'Deep Work Session', amountMl: 400, done: currentIntake >= 900 },
    { time: '13:00 WIB', label: isIndonesian ? 'Pasca Makan Siang' : 'Post Lunch', amountMl: 400, done: currentIntake >= 1300 },
    { time: '16:00 WIB', label: isIndonesian ? 'Pre/Mid Workout Hidrasi' : 'Pre-Workout Boost', amountMl: 600, done: currentIntake >= 1900 },
    { time: '19:30 WIB', label: isIndonesian ? 'Makan Malam & Pemulihan Seluler' : 'Evening Wind-down', amountMl: 400, done: currentIntake >= 2300 },
    { time: '21:30 WIB', label: isIndonesian ? 'Sebelum Tidur (Sedikit Air)' : 'Pre-Sleep Sip', amountMl: 200, done: currentIntake >= totalDynamicTarget },
  ];

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-cyan-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-cyan-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m8_smart_hydration')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log Hidrasi' : 'Log Hydration Data'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #8:</span>
            <span className="px-3 py-1 rounded-full bg-cyan-100 text-cyan-900 font-extrabold border border-cyan-300">
              {isIndonesian ? 'Pelacak Hidrasi & Elektrolit Cerdas' : 'Smart Hydration & Electrolytes'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-cyan-600 via-sky-700 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-cyan-100 text-xs font-black">
              <Droplets className="w-3.5 h-3.5 text-cyan-300" />
              <span>{isIndonesian ? 'Kalkulator Elektrolit Dinamis & Cuaca' : 'Dynamic Climate & Osmolarity Engine'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Pelacak Hidrasi & Elektrolit Cerdas' : 'Smart Hydration & Electrolyte Tracker'}
            </h1>
            <p className="text-xs sm:text-sm text-cyan-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Kalkulasi kebutuhan cairan presisi berbasis suhu lingkungan tropis, durasi olahraga, dan perkiraan pelepasan natrium-kalium melalui keringat.'
                : 'Precise hydration requirements adjusted for tropical humidity, workout intensity, and estimated electrolyte sweat loss.'}
            </p>
          </div>

          {/* Quick Intake Counter Card */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-5 text-center min-w-[200px] shrink-0">
            <span className="text-[11px] text-cyan-200 uppercase font-black tracking-wider block">
              {isIndonesian ? 'Capaian Hari Ini' : 'Today Intake'}
            </span>
            <div className="text-3xl font-black text-white mt-1 font-mono">
              {currentIntake} <span className="text-xs font-bold text-cyan-300">/ {totalDynamicTarget} ml</span>
            </div>
            <div className="mt-2.5 h-2 w-full bg-white/20 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-cyan-400 to-emerald-300 rounded-full" style={{ width: `${percentComplete}%` }} />
            </div>
            <span className="text-[10px] text-cyan-200 mt-1 block font-bold">{percentComplete}% {isIndonesian ? 'Tercapai' : 'Target'}</span>
          </div>
        </div>
      </div>

      {/* Interactive Controls & Parameters Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Dynamic Environment & Workout Sliders */}
        <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 space-y-5 shadow-sm">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Sun className="w-5 h-5 text-amber-500" />
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
              {isIndonesian ? 'Parameter Lingkungan & Latihan' : 'Environmental Variables'}
            </h3>
          </div>

          {/* Ambient Temp */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-slate-700">
              <span>{isIndonesian ? 'Suhu Udara Tropis' : 'Ambient Temperature'}</span>
              <span className="text-cyan-700 font-black">{ambientTemp}°C</span>
            </div>
            <input
              type="range"
              min="20"
              max="40"
              value={ambientTemp}
              onChange={(e) => setAmbientTemp(Number(e.target.value))}
              className="w-full accent-cyan-600 cursor-pointer"
            />
          </div>

          {/* Workout Duration */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-slate-700">
              <span>{isIndonesian ? 'Durasi Latihan Fisik' : 'Workout Duration'}</span>
              <span className="text-cyan-700 font-black">{workoutDuration} menit</span>
            </div>
            <input
              type="range"
              min="0"
              max="150"
              step="15"
              value={workoutDuration}
              onChange={(e) => setWorkoutDuration(Number(e.target.value))}
              className="w-full accent-cyan-600 cursor-pointer"
            />
          </div>

          {/* Sweat Rate Mode */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-700 block">
              {isIndonesian ? 'Intensitas Keringat' : 'Sweat Rate'}
            </span>
            <div className="grid grid-cols-3 gap-2">
              {(['low', 'medium', 'high'] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => setSweatRate(level)}
                  className={`py-2 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                    sweatRate === level
                      ? 'bg-cyan-600 text-white font-black shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {level === 'low' ? 'Ringan' : level === 'medium' ? 'Sedang' : 'Tinggi'}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Logging Buttons */}
          <div className="pt-3 border-t border-slate-100 space-y-2">
            <span className="text-xs font-bold text-slate-700 block">
              {isIndonesian ? 'Catat Konsumsi Cepat:' : 'Quick Log Water:'}
            </span>
            <div className="grid grid-cols-3 gap-2">
              {[250, 500, 750].map((amount) => (
                <button
                  key={amount}
                  onClick={() => {
                    onAddWater(amount);
                    if (onAwardXp) onAwardXp(15);
                  }}
                  className="p-2.5 rounded-xl bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 text-cyan-800 text-xs font-black transition-all active:scale-95 cursor-pointer"
                >
                  +{amount}ml
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Middle: Electrolyte Osmolarity Breakdown */}
        <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 space-y-5 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500" />
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                {isIndonesian ? 'Estimasi Elektrolit Hilang' : 'Electrolyte Sweat Loss'}
              </h3>
            </div>
            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-100 text-amber-900">
              Osmolaritas
            </span>
          </div>

          <div className="space-y-3">
            <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200 flex items-center justify-between">
              <div>
                <strong className="text-xs text-amber-950 font-black block">Natrium (Sodium - Na+)</strong>
                <span className="text-[11px] text-amber-800 font-medium">Menjaga volume darah & konduksi saraf</span>
              </div>
              <span className="text-base font-black text-amber-900 font-mono">~{sodiumLossMg} mg</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-cyan-50/70 border border-cyan-200 flex items-center justify-between">
              <div>
                <strong className="text-xs text-cyan-950 font-black block">Kalium (Potassium - K+)</strong>
                <span className="text-[11px] text-cyan-800 font-medium">Mencegah kram otot & mengatur pompa jantung</span>
              </div>
              <span className="text-base font-black text-cyan-900 font-mono">~{potassiumLossMg} mg</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-indigo-50/70 border border-indigo-200 flex items-center justify-between">
              <div>
                <strong className="text-xs text-indigo-950 font-black block">Magnesium (Mg2+)</strong>
                <span className="text-[11px] text-indigo-800 font-medium">Sintesis ATP energi & relaksasi neuromuskular</span>
              </div>
              <span className="text-base font-black text-indigo-900 font-mono">~{magnesiumLossMg} mg</span>
            </div>
          </div>

          {/* Electrolyte Supplement Toggle */}
          <div className="pt-2">
            <button
              onClick={() => {
                setElectrolytePillTaken(!electrolytePillTaken);
                if (!electrolytePillTaken && onAwardXp) onAwardXp(30);
              }}
              className={`w-full p-3 rounded-2xl border text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                electrolytePillTaken
                  ? 'bg-emerald-100 border-emerald-300 text-emerald-900 font-black'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className={`w-4 h-4 ${electrolytePillTaken ? 'text-emerald-700' : 'text-slate-400'}`} />
                <span>{isIndonesian ? 'Minum Minuman / Tablet Isotonik' : 'Log Electrolyte Drink'}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-white/80 font-black">
                {electrolytePillTaken ? 'Tercatat ✓' : '+30 XP'}
              </span>
            </button>
          </div>
        </div>

        {/* Right: Smart Hourly Schedule */}
        <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 space-y-4 shadow-sm">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Clock className="w-5 h-5 text-cyan-600" />
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
              {isIndonesian ? 'Jadwal Hidrasi Optimal' : 'Hourly Hydration Pacing'}
            </h3>
          </div>

          <div className="space-y-2.5">
            {hydrationTimeline.map((item, idx) => (
              <div
                key={idx}
                className={`p-2.5 rounded-xl border flex items-center justify-between text-xs transition-all ${
                  item.done
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950 font-bold'
                    : 'bg-slate-50 border-slate-100 text-slate-600'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${item.done ? 'bg-emerald-500' : 'bg-slate-300'}`} />
                  <div>
                    <span className="font-mono text-[10px] text-slate-400 block">{item.time}</span>
                    <span className="font-semibold text-slate-800">{item.label}</span>
                  </div>
                </div>
                <span className="font-mono font-bold text-cyan-700">{item.amountMl} ml</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
