import React, { useState } from 'react';
import {
  Sparkles,
  Activity,
  Moon,
  Droplets,
  Scale,
  Clock,
  Calendar,
  FlaskConical,
  Plus,
  ArrowUpRight,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  X,
  Bot,
  Zap,
  Target,
  RefreshCw,
} from 'lucide-react';
import { useHealth } from '../../context/HealthContext';
import { useProfile } from '../../context/ProfileContext';
import { WellnessScore } from '../../components/health/WellnessScore';
import { HealthMetricCard } from '../../components/health/HealthMetricCard';
import { HealthTimeline } from '../../components/health/HealthTimeline';
import { SleepCard } from '../../components/health/SleepCard';
import { HydrationCard } from '../../components/health/HydrationCard';
import { WeightChart } from '../../components/health/WeightChart';
import { ProgressCard } from '../../components/health/ProgressCard';
import { WeeklyReport } from '../../components/health/WeeklyReport';
import { DailyBrief } from '../../components/health/DailyBrief';
import { runHealthTestSuite, TestSuiteSummary } from '../../services/health/testHealthSuite';
import { HealthEventType } from '../../types/health';

type HealthScreenTab =
  | 'overview'
  | 'activity_sleep'
  | 'hydration_weight'
  | 'timeline'
  | 'weekly_report'
  | 'test_suite';

interface HealthScreenProps {
  onNavigateToModule?: (moduleId: string) => void;
  onNavigateToTab?: (tab: string) => void;
}

export const HealthScreen: React.FC<HealthScreenProps> = ({
  onNavigateToModule,
  onNavigateToTab,
}) => {
  const { userProfile } = useProfile();
  const isIndonesian = userProfile.language !== 'en';

  const {
    todayRecord,
    weightHistory,
    wellnessScore,
    trends,
    weeklyReport,
    events,
    dailyAiBrief,
    isGeneratingAiBrief,
    isGeneratingWeeklyReport,
    addWater,
    logSleep,
    logWeight,
    logActivity,
    addHealthEvent,
    generateDailyAiBrief,
    generateWeeklyAiReport,
    resetTestData,
  } = useHealth();

  const [activeTab, setActiveTab] = useState<HealthScreenTab>('overview');
  const [isAddEventModalOpen, setIsAddEventModalOpen] = useState(false);
  const [testSummary, setTestSummary] = useState<TestSuiteSummary | null>(null);
  const [isRunningTests, setIsRunningTests] = useState(false);

  // New Event Form State
  const [newEventTitle, setNewEventTitle] = useState('');
  const [newEventType, setNewEventType] = useState<HealthEventType>('activity');
  const [newEventDesc, setNewEventDesc] = useState('');
  const [newEventTime, setNewEventTime] = useState(
    new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  );

  const handleCreateEvent = async () => {
    if (!newEventTitle.trim()) return;

    await addHealthEvent({
      type: newEventType,
      timestamp: newEventTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      date: todayRecord.date,
      title: newEventTitle.trim(),
      description: newEventDesc.trim() || (isIndonesian ? 'Aktivitas manual tercatat' : 'Manual activity logged'),
      source: 'manual',
    });

    setNewEventTitle('');
    setNewEventDesc('');
    setIsAddEventModalOpen(false);
  };

  const handleRunTestSuite = async () => {
    setIsRunningTests(true);
    try {
      const summary = await runHealthTestSuite();
      setTestSummary(summary);
    } finally {
      setIsRunningTests(false);
    }
  };

  const stepsTrend = trends.find((t) => t.metric === 'steps');
  const sleepTrend = trends.find((t) => t.metric === 'sleep');
  const waterTrend = trends.find((t) => t.metric === 'hydration');
  const weightTrend = trends.find((t) => t.metric === 'weight');

  return (
    <div id="health-intelligence-master-screen" className="min-h-screen bg-slate-950 text-slate-100 p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Intelligence Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-teal-950/40 border border-slate-800 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="space-y-1 relative z-10">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span>{isIndonesian ? 'SISTEM INTELIJEN KESEHATAN PERSONAL' : 'PERSONAL HEALTH INTELLIGENCE'}</span>
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 border border-slate-700">
              {todayRecord.date}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            {isIndonesian ? 'Health Intelligence & Analytics' : 'Health Intelligence & Analytics'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
            {isIndonesian
              ? 'Pusat komando terpadu yang memadukan data latihan Body AI, nutrisi, hidrasi, tidur, dan skor wellness harian Anda.'
              : 'Unified command center consolidating Body AI workouts, nutrition logs, smart hydration, sleep, and daily wellness intelligence.'}
          </p>
        </div>

        {/* Quick Top Actions */}
        <div className="flex items-center gap-2 relative z-10 shrink-0 flex-wrap">
          <button
            onClick={() => setIsAddEventModalOpen(true)}
            className="px-3.5 py-2 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold border border-slate-700 flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>{isIndonesian ? 'Catat Event' : 'Log Event'}</span>
          </button>

          <button
            onClick={() => {
              if (onNavigateToTab) onNavigateToTab('coach');
              else if (onNavigateToModule) onNavigateToModule('m16_doctor_triage');
            }}
            className="px-4 py-2 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg cursor-pointer transition-all"
          >
            <Bot className="w-4 h-4 text-emerald-200" />
            <span>{isIndonesian ? 'Tanya AI Coach' : 'Ask AI Coach'}</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs border-b border-slate-800">
        {[
          { id: 'overview', label: isIndonesian ? 'Dashboard Utama' : 'Overview', icon: Activity },
          { id: 'activity_sleep', label: isIndonesian ? 'Aktivitas & Tidur' : 'Activity & Sleep', icon: Moon },
          { id: 'hydration_weight', label: isIndonesian ? 'Hidrasi & Berat' : 'Hydration & Weight', icon: Droplets },
          { id: 'timeline', label: isIndonesian ? 'Timeline Terpadu' : 'Timeline', icon: Clock },
          { id: 'weekly_report', label: isIndonesian ? 'Laporan Mingguan' : 'Weekly Report', icon: Calendar },
          { id: 'test_suite', label: isIndonesian ? 'Suite Pengujian (15 Kasus)' : 'Test Suite (15 Tests)', icon: FlaskConical },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as HealthScreenTab)}
              className={`px-3.5 py-2 rounded-2xl font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW DASHBOARD */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-in fade-in">
          {/* Main Wellness Score Gauge Card */}
          <WellnessScore score={wellnessScore} isIndonesian={isIndonesian} />

          {/* Daily AI Brief Card */}
          <DailyBrief
            brief={dailyAiBrief}
            isIndonesian={isIndonesian}
            onRefresh={generateDailyAiBrief}
            isLoading={isGeneratingAiBrief}
          />

          {/* Core Metrics Quick Cards (Grid of 4) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <HealthMetricCard
              title={isIndonesian ? 'Langkah Aktif' : 'Daily Steps'}
              value={todayRecord.activity?.steps || 0}
              unit="langkah"
              goal={`${todayRecord.activity?.stepsGoal?.toLocaleString()} langkah`}
              progressPercentage={Math.round(
                ((todayRecord.activity?.steps || 0) / (todayRecord.activity?.stepsGoal || 8000)) * 100
              )}
              icon={Activity}
              iconColor="text-amber-400"
              iconBgColor="bg-amber-500/10 border-amber-500/20"
              trendDirection={stepsTrend?.direction}
              trendText={stepsTrend?.description}
              subtitle={`${todayRecord.activity?.activeMinutes || 0} mnt aktif`}
              onClick={() => setActiveTab('activity_sleep')}
            />

            <HealthMetricCard
              title={isIndonesian ? 'Waktu Tidur' : 'Sleep Duration'}
              value={todayRecord.sleep?.sleepDurationHours || 0}
              unit="jam"
              goal={`${todayRecord.sleep?.sleepGoalHours || 8} jam`}
              progressPercentage={Math.round(
                ((todayRecord.sleep?.sleepDurationHours || 0) / (todayRecord.sleep?.sleepGoalHours || 8)) * 100
              )}
              icon={Moon}
              iconColor="text-indigo-400"
              iconBgColor="bg-indigo-500/10 border-indigo-500/20"
              trendDirection={sleepTrend?.direction}
              trendText={sleepTrend?.description}
              subtitle={`Bangun ${todayRecord.sleep?.wakeTime || '06:30'}`}
              onClick={() => setActiveTab('activity_sleep')}
            />

            <HealthMetricCard
              title={isIndonesian ? 'Asupan Hidrasi' : 'Water Intake'}
              value={((todayRecord.hydration?.waterIntakeMl || 0) / 1000).toFixed(2)}
              unit="Liter"
              goal={`${((todayRecord.hydration?.waterGoalMl || 2500) / 1000).toFixed(1)} L`}
              progressPercentage={Math.round(
                ((todayRecord.hydration?.waterIntakeMl || 0) / (todayRecord.hydration?.waterGoalMl || 2500)) * 100
              )}
              icon={Droplets}
              iconColor="text-sky-400"
              iconBgColor="bg-sky-500/10 border-sky-500/20"
              trendDirection={waterTrend?.direction}
              trendText={waterTrend?.description}
              subtitle={`+250ml siap ditambah`}
              onClick={() => setActiveTab('hydration_weight')}
            />

            <HealthMetricCard
              title={isIndonesian ? 'Berat Badan' : 'Weight'}
              value={todayRecord.weight || 72.0}
              unit="kg"
              icon={Scale}
              iconColor="text-purple-400"
              iconBgColor="bg-purple-500/10 border-purple-500/20"
              trendDirection={weightTrend?.direction}
              trendText={weightTrend?.description}
              subtitle={isIndonesian ? 'Stabil konsisten' : 'Consistent baseline'}
              onClick={() => setActiveTab('hydration_weight')}
            />
          </div>

          {/* Goal Progress Banner & Timeline Quick Peek */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ProgressCard report={weeklyReport} isIndonesian={isIndonesian} />
            <HealthTimeline
              events={events.slice(0, 5)}
              isIndonesian={isIndonesian}
              onAddEventClick={() => setIsAddEventModalOpen(true)}
            />
          </div>
        </div>
      )}

      {/* TAB 2: ACTIVITY & SLEEP */}
      {activeTab === 'activity_sleep' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in fade-in">
          {/* Activity Deep-Dive */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
                  <Activity className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    {isIndonesian ? 'Aktivitas & Langkah Fisik' : 'Physical Movement & Steps'}
                  </h3>
                  <span className="text-[11px] text-slate-400">
                    {isIndonesian ? 'Kalori Terbakar & Menit Bergerak' : 'Active Minutes & Burned Calories'}
                  </span>
                </div>
              </div>

              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-xl bg-amber-500/10 text-amber-300 border border-amber-500/20">
                {Math.round(
                  ((todayRecord.activity?.steps || 0) / (todayRecord.activity?.stepsGoal || 8000)) * 100
                )}
                %
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
                <div className="text-[10px] text-slate-400">{isIndonesian ? 'Langkah' : 'Steps'}</div>
                <div className="text-xl font-black text-amber-400 font-mono">
                  {todayRecord.activity?.steps.toLocaleString()}
                </div>
                <div className="text-[10px] text-slate-500">
                  Target: {todayRecord.activity?.stepsGoal.toLocaleString()}
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
                <div className="text-[10px] text-slate-400">{isIndonesian ? 'Menit Aktif' : 'Active Mins'}</div>
                <div className="text-xl font-black text-white font-mono">
                  {todayRecord.activity?.activeMinutes}
                </div>
                <div className="text-[10px] text-slate-500">
                  Target: {todayRecord.activity?.activeMinutesGoal} mnt
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
                <div className="text-[10px] text-slate-400">{isIndonesian ? 'Kalori Bakar' : 'Calories'}</div>
                <div className="text-xl font-black text-emerald-400 font-mono">
                  {todayRecord.activity?.estimatedCaloriesBurned}
                </div>
                <div className="text-[10px] text-slate-500">kcal</div>
              </div>
            </div>

            {/* Quick Activity Logger Form */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="text-xs font-bold text-slate-200">
                {isIndonesian ? 'Tambah Langkah / Menit Aktif Manual' : 'Log Additional Steps/Active Time'}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    logActivity({
                      steps: (todayRecord.activity?.steps || 0) + 1000,
                      distanceKm: Number((((todayRecord.activity?.steps || 0) + 1000) * 0.00075).toFixed(2)),
                      estimatedCaloriesBurned: (todayRecord.activity?.estimatedCaloriesBurned || 0) + 40,
                    })
                  }
                  className="flex-1 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-amber-300 transition-all cursor-pointer text-center"
                >
                  +1.000 Langkah
                </button>
                <button
                  onClick={() =>
                    logActivity({
                      activeMinutes: (todayRecord.activity?.activeMinutes || 0) + 15,
                      estimatedCaloriesBurned: (todayRecord.activity?.estimatedCaloriesBurned || 0) + 75,
                    })
                  }
                  className="flex-1 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-white transition-all cursor-pointer text-center"
                >
                  +15 Mnt Olahraga
                </button>
              </div>
            </div>

            {/* Safety Footer */}
            <div className="flex items-center gap-1.5 text-[10px] text-slate-500">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="italic">
                {isIndonesian
                  ? 'Aktivitas fisik diestimasi dari sensor gerakan atau pencatatan manual.'
                  : 'Physical activity calculated from motion sensors and self-reported logs.'}
              </span>
            </div>
          </div>

          {/* Sleep Deep-Dive */}
          <SleepCard
            sleep={todayRecord.sleep}
            isIndonesian={isIndonesian}
            onSaveSleep={logSleep}
          />
        </div>
      )}

      {/* TAB 3: HYDRATION & WEIGHT */}
      {activeTab === 'hydration_weight' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in fade-in">
          <HydrationCard
            hydration={todayRecord.hydration}
            isIndonesian={isIndonesian}
            onAddWater={addWater}
          />

          <WeightChart
            weights={weightHistory}
            currentWeight={todayRecord.weight}
            isIndonesian={isIndonesian}
            onLogWeight={logWeight}
          />
        </div>
      )}

      {/* TAB 4: HEALTH TIMELINE */}
      {activeTab === 'timeline' && (
        <div className="space-y-6 animate-in fade-in">
          <HealthTimeline
            events={events}
            isIndonesian={isIndonesian}
            onAddEventClick={() => setIsAddEventModalOpen(true)}
          />
        </div>
      )}

      {/* TAB 5: WEEKLY REPORT */}
      {activeTab === 'weekly_report' && (
        <div className="space-y-6 animate-in fade-in">
          <WeeklyReport
            report={weeklyReport}
            isIndonesian={isIndonesian}
            onAskAi={generateWeeklyAiReport}
            isGeneratingAi={isGeneratingWeeklyReport}
          />
        </div>
      )}

      {/* TAB 6: TEST SUITE (15 SCENARIOS) */}
      {activeTab === 'test_suite' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6 shadow-2xl animate-in fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                  <FlaskConical className="w-3 h-3 text-indigo-400" />
                  <span>STEP 6 VERIFICATION TEST SUITE</span>
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
                {isIndonesian ? '15 Kasus Pengujian Arsitektur Health Analytics' : '15 Health Analytics Verification Scenarios'}
              </h2>
              <p className="text-xs text-slate-400 max-w-xl">
                {isIndonesian
                  ? 'Pengujian otomatis untuk integritas komputasi wellness score, trend engine, fallback data kosong, dan penanganan edge case.'
                  : 'Automated test harness verifying wellness math, trend direction logic, missing metrics resiliency, and offline fallbacks.'}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={resetTestData}
                className="px-3.5 py-2 rounded-2xl bg-slate-950 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 cursor-pointer transition-all"
              >
                {isIndonesian ? 'Reset Data Contoh' : 'Reset Seed Data'}
              </button>

              <button
                onClick={handleRunTestSuite}
                disabled={isRunningTests}
                className="px-5 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg cursor-pointer transition-all disabled:opacity-50"
              >
                {isRunningTests ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <FlaskConical className="w-4 h-4" />
                )}
                <span>{isRunningTests ? (isIndonesian ? 'Menjalankan...' : 'Running...') : (isIndonesian ? 'Jalankan 15 Pengujian' : 'Run 15 Tests')}</span>
              </button>
            </div>
          </div>

          {/* Test Summary Banner */}
          {testSummary && (
            <div
              className={`p-4 rounded-2xl border flex items-center justify-between ${
                testSummary.allPassed
                  ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                  : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                <div>
                  <div className="text-sm font-bold">
                    {testSummary.allPassed
                      ? (isIndonesian ? 'Semua 15 Skenario Lolos (100% Passed)' : 'All 15 Scenarios Passed (100%)')
                      : `${testSummary.failed} Pengujian Gagal`}
                  </div>
                  <div className="text-xs opacity-80">
                    {isIndonesian ? `Dieksekusi pada ${testSummary.executedAt}` : `Executed at ${testSummary.executedAt}`}
                  </div>
                </div>
              </div>

              <div className="text-xl font-mono font-black">
                {testSummary.passed} / {testSummary.total}
              </div>
            </div>
          )}

          {/* Test List Table */}
          <div className="space-y-2">
            {(testSummary ? testSummary.results : Array.from({ length: 15 }, (_, i) => ({
              id: i + 1,
              name: `Scenario ${i + 1}`,
              description: 'Klik "Jalankan 15 Pengujian" untuk memverifikasi logika.',
              passed: undefined,
              durationMs: 0,
            }))).map((t: any) => (
              <div
                key={t.id}
                className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/80 flex items-start justify-between gap-3 text-xs"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                      #{t.id}
                    </span>
                    <span className="font-bold text-white">{isIndonesian ? t.name : t.nameEn || t.name}</span>
                  </div>
                  <p className="text-[11px] text-slate-400">{t.description}</p>
                  {t.outputData && (
                    <div className="text-[10px] font-mono text-slate-500 pt-0.5">
                      Output: {JSON.stringify(t.outputData)}
                    </div>
                  )}
                </div>

                <div className="shrink-0">
                  {t.passed === true && (
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>PASS ({t.durationMs}ms)</span>
                    </span>
                  )}
                  {t.passed === false && (
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
                      FAIL
                    </span>
                  )}
                  {t.passed === undefined && (
                    <span className="text-[10px] font-mono text-slate-500">READY</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* CREATE EVENT MODAL */}
      {isAddEventModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-400" />
                <span>{isIndonesian ? 'Catat Aktivitas Kesehatan Baru' : 'Log New Health Event'}</span>
              </h3>
              <button
                onClick={() => setIsAddEventModalOpen(false)}
                className="p-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">
                  {isIndonesian ? 'Kategori Event' : 'Event Category'}
                </label>
                <select
                  value={newEventType}
                  onChange={(e) => setNewEventType(e.target.value as HealthEventType)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                >
                  <option value="activity">{isIndonesian ? 'Aktivitas / Gerak' : 'Activity / Movement'}</option>
                  <option value="workout">{isIndonesian ? 'Olahraga / Latihan' : 'Workout'}</option>
                  <option value="meal">{isIndonesian ? 'Makanan / Nutrisi' : 'Meal / Nutrition'}</option>
                  <option value="water">{isIndonesian ? 'Air Putih / Hidrasi' : 'Water / Hydration'}</option>
                  <option value="sleep">{isIndonesian ? 'Tidur / Istirahat' : 'Sleep / Recovery'}</option>
                  <option value="weight">{isIndonesian ? 'Penimbangan Berat Badan' : 'Weight'}</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">
                  {isIndonesian ? 'Judul Event' : 'Event Title'}
                </label>
                <input
                  type="text"
                  value={newEventTitle}
                  onChange={(e) => setNewEventTitle(e.target.value)}
                  placeholder={isIndonesian ? 'mis. Jalan Santai 20 Menit' : 'e.g. 20min brisk walk'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-medium"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">
                  {isIndonesian ? 'Deskripsi / Detail Metrik' : 'Description / Notes'}
                </label>
                <input
                  type="text"
                  value={newEventDesc}
                  onChange={(e) => setNewEventDesc(e.target.value)}
                  placeholder={isIndonesian ? 'mis. 2.5 km • 110 kcal' : 'e.g. 2.5 km • 110 kcal'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">
                  {isIndonesian ? 'Waktu (Jam:Menit)' : 'Timestamp'}
                </label>
                <input
                  type="text"
                  value={newEventTime}
                  onChange={(e) => setNewEventTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setIsAddEventModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:text-white"
              >
                {isIndonesian ? 'Batal' : 'Cancel'}
              </button>
              <button
                onClick={handleCreateEvent}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md cursor-pointer"
              >
                {isIndonesian ? 'Simpan Event' : 'Save Event'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
