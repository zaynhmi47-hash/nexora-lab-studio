import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Wind,
  Heart,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  ArrowLeft,
  Activity,
  CheckCircle2,
  ShieldCheck,
  Zap,
  Plus,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface AdaptiveMeditationScreenProps {
  userProfile: UserProfile;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const AdaptiveMeditationScreen: React.FC<AdaptiveMeditationScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [breathingPattern, setBreathingPattern] = useState<'box' | 'relax_478' | 'coherent'>('box');
  const [isActive, setIsActive] = useState(false);
  const [currentPhase, setCurrentPhase] = useState<'Inhale' | 'Hold' | 'Exhale' | 'HoldPost'>('Inhale');
  const [phaseSecondsLeft, setPhaseSecondsLeft] = useState(4);
  const [cyclesCompleted, setCyclesCompleted] = useState(0);
  const [binauralAudioOn, setBinauralAudioOn] = useState(true);
  const [liveHrv, setLiveHrv] = useState(64); // ms

  // Pattern Timing Configurations
  const patternConfigs = {
    box: { inhale: 4, hold1: 4, exhale: 4, hold2: 4, label: isIndonesian ? 'Box Breathing (4-4-4-4 Navy SEAL)' : 'Box Breathing (4-4-4-4)' },
    relax_478: { inhale: 4, hold1: 7, exhale: 8, hold2: 0, label: isIndonesian ? 'Teknik 4-7-8 (Penenang Saraf Vagus)' : '4-7-8 Relax' },
    coherent: { inhale: 5, hold1: 0, exhale: 5, hold2: 0, label: isIndonesian ? 'Resonansi Koheren 5.5s (Sinkron Jantung)' : 'Coherent Resonance (5.5s)' },
  };

  const currentConfig = patternConfigs[breathingPattern];

  // Pacer Timer
  useEffect(() => {
    let timer: any;
    if (isActive) {
      timer = setInterval(() => {
        setPhaseSecondsLeft((prev) => {
          if (prev > 1) return prev - 1;

          // Transition to next phase
          if (currentPhase === 'Inhale') {
            if (currentConfig.hold1 > 0) {
              setCurrentPhase('Hold');
              return currentConfig.hold1;
            } else {
              setCurrentPhase('Exhale');
              return currentConfig.exhale;
            }
          } else if (currentPhase === 'Hold') {
            setCurrentPhase('Exhale');
            return currentConfig.exhale;
          } else if (currentPhase === 'Exhale') {
            if (currentConfig.hold2 > 0) {
              setCurrentPhase('HoldPost');
              return currentConfig.hold2;
            } else {
              setCyclesCompleted((c) => c + 1);
              setLiveHrv((h) => Math.min(85, h + 2)); // HRV improves
              setCurrentPhase('Inhale');
              return currentConfig.inhale;
            }
          } else if (currentPhase === 'HoldPost') {
            setCyclesCompleted((c) => c + 1);
            setLiveHrv((h) => Math.min(85, h + 2));
            setCurrentPhase('Inhale');
            return currentConfig.inhale;
          }
          return currentConfig.inhale;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isActive, currentPhase, breathingPattern, currentConfig]);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-teal-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-teal-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m13_adaptive_meditation')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-teal-600 hover:bg-teal-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Sesi Meditasi' : 'Log Meditation Data'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #13:</span>
            <span className="px-3 py-1 rounded-full bg-teal-100 text-teal-900 font-extrabold border border-teal-300">
              {isIndonesian ? 'Meditasi Adaptif & Audio Napas HRV' : 'Adaptive Meditation & HRV Breath'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-teal-600 via-emerald-700 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-teal-100 text-xs font-black">
              <Wind className="w-3.5 h-3.5 text-teal-300" />
              <span>{isIndonesian ? 'Aktivasi Saraf Parasimpatis & Variabilitas Nadi' : 'Autonomic HRV Resonance'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Meditasi Adaptif & Pacer Napas HRV' : 'Adaptive Meditation & HRV Breath Pacer'}
            </h1>
            <p className="text-xs sm:text-sm text-teal-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Sinkronkan gelombang otak dan denyut jantung melalui panduan respirasi visual interaktif dengan frekuensi audio binaural 432 Hz.'
                : 'Co-modulate cardiopulmonary rhythms and activate vagal tone with interactive breathing visuals and binaural soundscapes.'}
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-5 text-center min-w-[200px] shrink-0">
            <span className="text-[11px] text-teal-200 uppercase font-black tracking-wider block">
              {isIndonesian ? 'HRV Real-Time' : 'Live HRV Score'}
            </span>
            <div className="text-3xl font-black text-white mt-1 font-mono">
              {liveHrv} <span className="text-xs font-bold text-teal-300">ms</span>
            </div>
            <span className="text-[10px] text-teal-200 mt-1 block font-bold">
              {cyclesCompleted} {isIndonesian ? 'Siklus Napas Lengkap' : 'Cycles Completed'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Breathing Pacer Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Central Animated Breathing Orb */}
        <div className="lg:col-span-2 bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-[32px] p-8 text-white shadow-xl flex flex-col items-center justify-between min-h-[480px] relative overflow-hidden">
          {/* Ambient light ring */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Pattern selector tabs */}
          <div className="relative z-10 flex flex-wrap justify-center gap-2 bg-white/5 p-1.5 rounded-2xl border border-white/10 w-full max-w-md">
            {(['box', 'relax_478', 'coherent'] as const).map((pat) => (
              <button
                key={pat}
                onClick={() => {
                  setBreathingPattern(pat);
                  setIsActive(false);
                  setCurrentPhase('Inhale');
                  setPhaseSecondsLeft(patternConfigs[pat].inhale);
                }}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                  breathingPattern === pat
                    ? 'bg-teal-500 text-slate-950 font-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {pat === 'box' ? 'Box (4-4-4-4)' : pat === 'relax_478' ? '4-7-8 Relax' : 'Koheren (5.5s)'}
              </button>
            ))}
          </div>

          {/* Animated Breathing Circle */}
          <div className="relative z-10 py-10 flex flex-col items-center justify-center">
            <motion.div
              animate={{
                scale: currentPhase === 'Inhale' ? 1.45 : currentPhase === 'Exhale' ? 1 : 1.45,
              }}
              transition={{
                duration: phaseSecondsLeft,
                ease: 'easeInOut',
              }}
              className="w-48 h-48 sm:w-56 sm:h-56 rounded-full bg-gradient-to-tr from-teal-500/30 via-emerald-400/20 to-cyan-500/30 border-2 border-teal-400/60 flex flex-col items-center justify-center shadow-2xl backdrop-blur-md relative"
            >
              <div className="text-center">
                <span className="text-xs font-black uppercase tracking-widest text-teal-300 block mb-1">
                  {currentPhase === 'Inhale'
                    ? (isIndonesian ? 'TARIK NAPAS' : 'INHALE')
                    : currentPhase === 'Hold' || currentPhase === 'HoldPost'
                    ? (isIndonesian ? 'TAHAN' : 'HOLD')
                    : (isIndonesian ? 'HEMBUSKAN' : 'EXHALE')}
                </span>
                <span className="text-5xl font-black text-white font-mono">{phaseSecondsLeft}</span>
                <span className="text-[11px] text-slate-400 font-mono block mt-1">detik tersisa</span>
              </div>
            </motion.div>
          </div>

          {/* Play/Pause & Reset Controls */}
          <div className="relative z-10 flex items-center gap-3 w-full max-w-sm">
            <button
              onClick={() => {
                setIsActive(!isActive);
                if (!isActive && onAwardXp) onAwardXp(15);
              }}
              className={`flex-1 py-3.5 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                isActive
                  ? 'bg-amber-500 hover:bg-amber-600 text-slate-950'
                  : 'bg-teal-500 hover:bg-teal-400 text-slate-950'
              }`}
            >
              {isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isActive ? (isIndonesian ? 'Jeda Latihan' : 'Pause') : (isIndonesian ? 'Mulai Napas Adaptif' : 'Start Session')}</span>
            </button>

            <button
              onClick={() => {
                setIsActive(false);
                setCurrentPhase('Inhale');
                setPhaseSecondsLeft(currentConfig.inhale);
                setCyclesCompleted(0);
              }}
              className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer border border-white/10"
              title="Reset"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Col: Audio Settings & Physiology Guide */}
        <div className="space-y-4">
          {/* Binaural Sound Toggle */}
          <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 space-y-4 shadow-sm">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                {binauralAudioOn ? <Volume2 className="w-5 h-5 text-teal-600" /> : <VolumeX className="w-5 h-5 text-slate-400" />}
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                  {isIndonesian ? 'Audio Binaural 432 Hz' : 'Binaural Audio'}
                </h3>
              </div>
              <button
                onClick={() => setBinauralAudioOn(!binauralAudioOn)}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  binauralAudioOn ? 'bg-teal-100 text-teal-900 font-black' : 'bg-slate-100 text-slate-500'
                }`}
              >
                {binauralAudioOn ? 'Aktif ✓' : 'Mati'}
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed font-medium">
              {isIndonesian
                ? 'Frekuensi suara harmonik 432 Hz merangsang osilasi gelombang alfa otak (8-12 Hz) untuk relaksasi mendalam.'
                : 'Harmonic 432 Hz frequencies stimulate alpha brainwave entrainment for deep parasympathetic focus.'}
            </p>
          </div>

          {/* Vagal Nerve & HRV Benefit Box */}
          <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 space-y-3 shadow-sm">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Activity className="w-5 h-5 text-emerald-600" />
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                {isIndonesian ? 'Manfaat Fisiologis Vagus' : 'Physiological Benefits'}
              </h3>
            </div>
            <ul className="space-y-2 text-xs text-slate-700 font-medium">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>Menurunkan kadar hormon kortisol darah dalam 3 menit.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>Meningkatkan Heart Rate Variability (HRV) & stabilitas irama jantung.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>Meredakan hiperventilasi dan ketegangan otot leher/bahu.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
