import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Dumbbell,
  Sparkles,
  Flame,
  Clock,
  CheckCircle2,
  Play,
  RotateCcw,
  Target,
  Zap,
  Award,
  ChevronRight,
  ShieldCheck,
  Activity,
  ArrowRight,
  Loader2,
  Calendar,
  Layers,
  Heart,
  Volume2,
  ArrowLeft,
} from 'lucide-react';
import { UserProfile, WorkoutPlan, Exercise, MealItem } from '../../types';
import { INITIAL_WORKOUT_PLAN } from '../../data/sampleData';
import { LiveWorkoutPoseGuard } from '../../components/modules/LiveWorkoutPoseGuard';

interface WorkoutGeneratorViewProps {
  userProfile: UserProfile;
  onFinishWorkout?: (plan: WorkoutPlan) => void;
  onLogMeal?: (meal: MealItem) => void;
  onNavigateTab?: (tab: any) => void;
}

export const WorkoutGeneratorView: React.FC<WorkoutGeneratorViewProps> = ({
  userProfile,
  onFinishWorkout,
  onNavigateTab,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // Generator Options
  const [selectedSplit, setSelectedSplit] = useState<'full_body' | 'upper' | 'lower' | 'hiit_core' | 'home_bodyweight'>('full_body');
  const [selectedDifficulty, setSelectedDifficulty] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const [durationMin, setDurationMin] = useState<number>(35);
  const [muscleSoreness, setMuscleSoreness] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Active Workout Plan
  const [currentPlan, setCurrentPlan] = useState<WorkoutPlan>(INITIAL_WORKOUT_PLAN);
  const [completedExercises, setCompletedExercises] = useState<Record<string, boolean>>({});
  const [isWorkoutActive, setIsWorkoutActive] = useState<boolean>(false);
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [showCompletionModal, setShowCompletionModal] = useState<boolean>(false);
  const [isLivePoseGuardOpen, setIsLivePoseGuardOpen] = useState<boolean>(false);

  // Soreness toggler
  const toggleSoreness = (muscle: string) => {
    setMuscleSoreness((prev) =>
      prev.includes(muscle) ? prev.filter((m) => m !== muscle) : [...prev, muscle]
    );
  };

  // Toggle Exercise completion
  const toggleExercise = (id: string) => {
    setCompletedExercises((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const completedCount = Object.values(completedExercises).filter(Boolean).length;
  const progressPercent = currentPlan.exercises.length > 0
    ? Math.round((completedCount / currentPlan.exercises.length) * 100)
    : 0;

  // AI Workout Plan Generator
  const handleGenerateAIWorkout = async () => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/workout/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userProfile,
          split: selectedSplit,
          difficulty: selectedDifficulty,
          durationMin,
          soreness: muscleSoreness,
          language: userProfile.language || 'id',
        }),
      });

      const json = await response.json();
      if (json.success && json.data) {
        setCurrentPlan(json.data);
        setCompletedExercises({});
        setIsWorkoutActive(false);
      } else {
        // Fallback generator
        generateLocalFallbackPlan();
      }
    } catch (e) {
      console.warn('Workout generation fallback used:', e);
      generateLocalFallbackPlan();
    } finally {
      setIsGenerating(false);
    }
  };

  const generateLocalFallbackPlan = () => {
    const splitTitles: Record<string, string> = {
      full_body: isIndonesian ? 'Full Body Hypertrophy & Stability' : 'Full Body Hypertrophy & Stability',
      upper: isIndonesian ? 'Upper Body Power & Posture' : 'Upper Body Power & Posture',
      lower: isIndonesian ? 'Lower Body Strength & Glutes' : 'Lower Body Strength & Glutes',
      hiit_core: isIndonesian ? 'HIIT Metabolic Burn & Core' : 'HIIT Metabolic Burn & Core',
      home_bodyweight: isIndonesian ? 'Home Calisthenics & Mobility' : 'Home Calisthenics & Mobility',
    };

    const fallbackExercises: Exercise[] = [
      {
        id: `ex_${Date.now()}_1`,
        name: selectedSplit === 'lower' ? 'Goblet Squat / Bulgarian Split' : 'Dynamic Push-Up / Bench Press',
        sets: 4,
        reps: '10 - 12 reps',
        targetMuscle: selectedSplit === 'lower' ? 'Quadriceps & Glutes' : 'Chest, Triceps & Core',
        instructions: isIndonesian
          ? 'Pertahankan postur dada tegak, kunci core, dan kendalikan tempo eksentrik selama 2 detik.'
          : 'Keep chest upright, brace core tightly, and control the 2-second eccentric lowering phase.',
      },
      {
        id: `ex_${Date.now()}_2`,
        name: selectedSplit === 'upper' ? 'Dumbbell Bent-Over Row' : 'Romanian Deadlift / Hip Hinge',
        sets: 3,
        reps: '12 reps',
        targetMuscle: selectedSplit === 'upper' ? 'Latissimus Dorsi & Rhomboids' : 'Hamstrings & Posterior Chain',
        instructions: isIndonesian
          ? 'Engsel pinggul ke belakang, jangan bungkukkan punggung bawah, tarik beban ke arah pinggang.'
          : 'Hinge back at the hips, maintain neutral lumbar curve, row smoothly towards hips.',
      },
      {
        id: `ex_${Date.now()}_3`,
        name: 'Plank Shoulder Taps & Anti-Rotation',
        sets: 3,
        reps: '45 detik',
        targetMuscle: 'Core & Scapular Stabilizers',
        instructions: isIndonesian
          ? 'Tahan posisi plank lurus tanpa menggoyangkan pinggul saat tangan menyentuh bahu bergantian.'
          : 'Hold steady plank without hip rotation while alternating shoulder taps.',
      },
      {
        id: `ex_${Date.now()}_4`,
        name: 'Walking Lunges / Jump Squats',
        sets: 3,
        reps: '12 langkah per kaki',
        targetMuscle: 'Quadriceps, Hamstrings & Cardio',
        instructions: isIndonesian
          ? 'Langkah terkontrol, lutut depan 90 derajat sejajar dengan jari kaki.'
          : 'Controlled strides, ensuring front knee stays aligned with toes at 90 degrees.',
      },
    ];

    const newPlan: WorkoutPlan = {
      id: `plan_${Date.now()}`,
      title: splitTitles[selectedSplit] || 'Custom AI Adaptive Workout',
      description: isIndonesian
        ? `Program latihan ${selectedDifficulty} berdurasi ${durationMin} menit disesuaikan untuk target ${userProfile.fitnessGoal}.`
        : `${selectedDifficulty} workout program for ${durationMin} min calibrated for ${userProfile.fitnessGoal}.`,
      difficulty: selectedDifficulty,
      estimatedDurationMin: durationMin,
      estimatedCaloriesBurned: Math.round(durationMin * 7.5),
      exercises: fallbackExercises,
      createdAt: new Date().toISOString(),
      sorenessAdjusted: muscleSoreness.length > 0,
    };

    setCurrentPlan(newPlan);
    setCompletedExercises({});
    setIsWorkoutActive(false);
  };

  const handleFinish = () => {
    setShowCompletionModal(true);
    if (onFinishWorkout) {
      onFinishWorkout(currentPlan);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-emerald-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* TOP NAVIGATION BREADCRUMB & BACK BUTTON */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('landing') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Beranda / Google Health Hub' : 'Back to Home / Google Health Hub'}</span>
        </button>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <span className="hidden sm:inline">Halaman Modul:</span>
          <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-extrabold border border-emerald-300">
            #1 Generator Latihan Adaptif
          </span>
        </div>
      </div>

      {/* GOOGLE HEALTH WORKOUT HERO HEADER */}
      <div className="rounded-[32px] bg-gradient-to-br from-slate-900 via-emerald-950 to-teal-950 text-white p-6 sm:p-9 border border-emerald-800/40 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/15 blur-[90px] rounded-full pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-8 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-black flex items-center gap-1.5 shadow-2xs">
                <Dumbbell className="w-3.5 h-3.5 text-emerald-400" />
                MODUL #1 • ADAPTIVE AI TRAINER
              </span>
              <span className="px-3 py-1 rounded-full bg-white/10 text-slate-200 text-xs font-semibold">
                Google Health Periodization
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white leading-tight">
              {isIndonesian ? (
                <>
                  Generator Latihan Adaptif &{' '}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
                    Periodisasi AI
                  </span>
                </>
              ) : (
                <>
                  Adaptive AI Workout &{' '}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
                    Periodization
                  </span>
                </>
              )}
            </h1>

            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed max-w-2xl">
              {isIndonesian
                ? 'AI menganalisis skor kesiapan harian, tingkat kelelahan otot, dan target kebugaran Anda untuk menyusun porsi latihan optimal tanpa risiko overtraining.'
                : 'Calibrated workout generator tailored to muscle fatigue, recovery scores, and fitness goals with auto-progressive overload.'}
            </p>
          </div>

          <div className="lg:col-span-4 bg-slate-900/80 border border-emerald-500/30 rounded-3xl p-4.5 space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span>Target Kebugaran:</span>
              <span className="text-emerald-400 uppercase font-black">{userProfile.fitnessGoal.replace('_', ' ')}</span>
            </div>
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span>Level Pengguna:</span>
              <span className="text-teal-300 font-bold">Level {userProfile.level} • {userProfile.xp} XP</span>
            </div>
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span>Streak Olahraga:</span>
              <span className="text-amber-400 font-black flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 fill-amber-400" />
                {userProfile.streakCount} Hari
              </span>
            </div>

            <div className="flex flex-col gap-2">
              <button
                onClick={() => onNavigateTab ? onNavigateTab('body_ai') : setIsLivePoseGuardOpen(true)}
                className="w-full py-2.5 px-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
              >
                <Activity className="w-4 h-4 text-slate-950" />
                <span>{isIndonesian ? 'MediaPipe Body AI Studio' : 'MediaPipe Body AI Studio'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* BODY AI DASHBOARD SECTION */}
      <div className="bg-slate-900 border border-emerald-500/30 rounded-[28px] p-6 text-white shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>Body AI</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  MediaPipe Pose
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {isIndonesian
                  ? 'Pelacakan repetisi & evaluasi biomekanik lokal (Squat, Push-up, Lunge, Plank)'
                  : 'On-device rep counting & biomechanical form analysis (Squat, Push-up, Lunge, Plank)'}
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab && onNavigateTab('body_ai')}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/20"
          >
            <span>{isIndonesian ? 'Analisis Gerakan (Analyze Movement)' : 'Analyze Movement'}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80">
            <span className="text-[10px] font-semibold text-slate-400 uppercase block">
              {isIndonesian ? 'Latihan Terakhir' : 'Recent Exercises'}
            </span>
            <span className="text-sm font-bold text-white">Squat & Push-Up</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80">
            <span className="text-[10px] font-semibold text-slate-400 uppercase block">
              {isIndonesian ? 'Skor Form Terbaik' : 'Best Form Score'}
            </span>
            <span className="text-sm font-bold text-emerald-400 font-mono">94%</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80">
            <span className="text-[10px] font-semibold text-slate-400 uppercase block">
              {isIndonesian ? 'Total Sesi Latihan' : 'Total Sessions'}
            </span>
            <span className="text-sm font-bold text-white font-mono">8 Sesi</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80">
            <span className="text-[10px] font-semibold text-slate-400 uppercase block">
              {isIndonesian ? 'Privasi Kamera' : 'Camera Privacy'}
            </span>
            <span className="text-sm font-bold text-teal-300">100% On-Device</span>
          </div>
        </div>
      </div>

      {/* GENERATOR CONFIGURATION & ACTIVE WORKOUT WORKSPACE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Generator Parameters */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-white border border-slate-200 rounded-[28px] p-5 sm:p-6 shadow-xs space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <Sparkles className="w-4 h-4 text-emerald-700" />
                </div>
                <h3 className="text-sm font-black text-slate-900">
                  {isIndonesian ? 'Konfigurasi Latihan AI' : 'AI Workout Config'}
                </h3>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                Gemini 3.6 Flash
              </span>
            </div>

            {/* Split Selection */}
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-700 block">
                {isIndonesian ? 'Jenis Split Latihan' : 'Workout Split'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'full_body', label: 'Full Body' },
                  { id: 'upper', label: 'Upper Body' },
                  { id: 'lower', label: 'Lower Body' },
                  { id: 'hiit_core', label: 'HIIT & Core' },
                  { id: 'home_bodyweight', label: 'Home Calisthenics' },
                ].map((split) => (
                  <button
                    key={split.id}
                    onClick={() => setSelectedSplit(split.id as any)}
                    className={`py-2 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer text-left ${
                      selectedSplit === split.id
                        ? 'bg-emerald-600 text-white shadow-2xs'
                        : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/80'
                    }`}
                  >
                    {split.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Difficulty & Duration */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-700 block">
                  {isIndonesian ? 'Intensitas' : 'Intensity'}
                </label>
                <select
                  value={selectedDifficulty}
                  onChange={(e) => setSelectedDifficulty(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-2.5 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="beginner">{isIndonesian ? 'Pemula (Beginner)' : 'Beginner'}</option>
                  <option value="intermediate">{isIndonesian ? 'Menengah (Medium)' : 'Intermediate'}</option>
                  <option value="advanced">{isIndonesian ? 'Lanjutan (Hard)' : 'Advanced'}</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-700 block">
                  {isIndonesian ? 'Durasi Latihan' : 'Duration'}
                </label>
                <select
                  value={durationMin}
                  onChange={(e) => setDurationMin(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-2.5 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value={20}>20 {isIndonesian ? 'Menit' : 'Mins'}</option>
                  <option value={35}>35 {isIndonesian ? 'Menit' : 'Mins'}</option>
                  <option value={45}>45 {isIndonesian ? 'Menit' : 'Mins'}</option>
                  <option value={60}>60 {isIndonesian ? 'Menit' : 'Mins'}</option>
                </select>
              </div>
            </div>

            {/* Muscle Soreness Tagger (DOMS) */}
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-700 flex items-center justify-between">
                <span>{isIndonesian ? 'Otot yang Masih Pegal / Soreness (DOMS)' : 'Muscle Soreness (DOMS)'}</span>
                <span className="text-[10px] text-slate-400 font-normal">AI akan menghindari</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {['Bahu', 'Dada', 'Punggung', 'Kaki / Paha', 'Lutut / Sendi', 'Perut / Core'].map((muscle) => {
                  const isSore = muscleSoreness.includes(muscle);
                  return (
                    <button
                      key={muscle}
                      onClick={() => toggleSoreness(muscle)}
                      className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                        isSore
                          ? 'bg-rose-600 text-white shadow-2xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border border-slate-200'
                      }`}
                    >
                      {isSore ? '⚠️ ' : ''}{muscle}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerateAIWorkout}
              disabled={isGenerating}
              className="w-full py-3.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{isIndonesian ? 'Menyusun Program AI...' : 'Generating AI Workout...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{isIndonesian ? 'Generate Program Latihan Baru' : 'Generate AI Workout'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Active Workout Session Card */}
        <div className="lg:col-span-7 space-y-5">
          <div className="bg-white border border-slate-200 rounded-[28px] p-5 sm:p-7 shadow-xs space-y-6">
            {/* Header of Active Workout */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-extrabold text-[10px] uppercase tracking-wider">
                    {currentPlan.difficulty}
                  </span>
                  {currentPlan.sorenessAdjusted && (
                    <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 font-bold text-[10px]">
                      Soreness Adjusted
                    </span>
                  )}
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  {currentPlan.title}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {currentPlan.description}
                </p>
              </div>

              {/* Progress Ring / Badge */}
              <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-2xl p-3 shrink-0">
                <div className="text-center">
                  <div className="text-xs font-bold text-slate-400">Target</div>
                  <div className="text-sm font-black text-slate-900 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-emerald-600" />
                    {currentPlan.estimatedDurationMin} min
                  </div>
                </div>
                <div className="w-px h-8 bg-slate-200" />
                <div className="text-center">
                  <div className="text-xs font-bold text-slate-400">Kalori</div>
                  <div className="text-sm font-black text-slate-900 flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 text-amber-500" />
                    {currentPlan.estimatedCaloriesBurned} kcal
                  </div>
                </div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-slate-600">
                  {isIndonesian ? 'Kemajuan Latihan:' : 'Workout Progress:'} {completedCount} / {currentPlan.exercises.length} Gerakan
                </span>
                <span className="text-emerald-700 font-black">{progressPercent}% Selesai</span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-300 rounded-full"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            {/* Exercise List */}
            <div className="space-y-3">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">
                {isIndonesian ? 'Daftar Gerakan Latihan' : 'Exercise List'}
              </h3>

              <div className="space-y-3">
                {currentPlan.exercises.map((ex, index) => {
                  const isDone = completedExercises[ex.id];
                  return (
                    <div
                      key={ex.id}
                      onClick={() => toggleExercise(ex.id)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                        isDone
                          ? 'bg-emerald-50/70 border-emerald-300 opacity-90'
                          : 'bg-slate-50 hover:bg-slate-100/80 border-slate-200'
                      }`}
                    >
                      <button
                        className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                          isDone ? 'bg-emerald-600 text-white' : 'border-2 border-slate-300 text-transparent'
                        }`}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </button>

                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex flex-wrap items-center justify-between gap-1.5">
                          <h4
                            className={`text-sm font-black leading-snug ${
                              isDone ? 'line-through text-slate-500' : 'text-slate-900'
                            }`}
                          >
                            {index + 1}. {ex.name}
                          </h4>
                          <span className="px-2 py-0.5 bg-white border border-slate-200 text-emerald-800 text-[10px] font-black rounded-lg">
                            {ex.sets} Set × {ex.reps}
                          </span>
                        </div>

                        <p className="text-xs text-slate-500 font-medium">
                          Target: <span className="text-slate-700 font-bold">{ex.targetMuscle}</span>
                        </p>

                        <p className="text-xs text-slate-600 leading-relaxed bg-white/80 p-2.5 rounded-xl border border-slate-200/60 mt-1">
                          {ex.instructions}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-100">
              <button
                onClick={() => setCompletedExercises({})}
                className="px-4 py-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>

              <button
                onClick={handleFinish}
                className="px-6 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black transition-all shadow-md active:scale-95 flex items-center gap-2 cursor-pointer"
              >
                <Award className="w-4 h-4" />
                <span>{isIndonesian ? 'Selesaikan Sesi Latihan (+50 XP)' : 'Finish Workout (+50 XP)'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Completion Modal */}
      <AnimatePresence>
        {showCompletionModal && (
          <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-[32px] p-6 sm:p-8 max-w-md w-full border border-emerald-200 shadow-2xl text-center space-y-5"
            >
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <Award className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h3 className="text-2xl font-black text-slate-900">
                  {isIndonesian ? 'Latihan Selesai! 🎉' : 'Workout Complete! 🎉'}
                </h3>
                <p className="text-xs text-slate-500">
                  {isIndonesian
                    ? `Kerja bagus! Anda telah membakar sekitar ~${currentPlan.estimatedCaloriesBurned} kcal.`
                    : `Great job! You burned approx ~${currentPlan.estimatedCaloriesBurned} kcal.`}
                </p>
              </div>

              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-1">
                <span className="text-[11px] font-bold text-emerald-800">Hadiah Gamifikasi:</span>
                <div className="text-lg font-black text-emerald-950">+50 XP & 1 Streak Point 🔥</div>
              </div>

              <button
                onClick={() => setShowCompletionModal(false)}
                className="w-full py-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black transition-colors cursor-pointer shadow-md"
              >
                {isIndonesian ? 'Kembali ke Dasbor' : 'Return to Dashboard'}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <LiveWorkoutPoseGuard
        isOpen={isLivePoseGuardOpen}
        onClose={() => setIsLivePoseGuardOpen(false)}
        userProfile={userProfile}
      />
    </div>
  );
};
