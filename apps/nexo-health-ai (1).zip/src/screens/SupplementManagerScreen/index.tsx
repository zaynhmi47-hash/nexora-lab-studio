import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Pill,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Sparkles,
  ArrowLeft,
  CheckCircle2,
  Plus,
  Trash2,
  Info,
  Calendar,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { UserProfile, DailyLog } from '../../types';

interface SupplementItem {
  id: string;
  name: string;
  dosage: string;
  timing: 'morning_with_food' | 'morning_empty' | 'midday' | 'evening_with_food' | 'bedtime';
  purpose: string;
  bioavailabilityTip: string;
  takenToday: boolean;
}

interface SupplementManagerScreenProps {
  userProfile: UserProfile;
  dailyLog?: DailyLog;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const SupplementManagerScreen: React.FC<SupplementManagerScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [supplements, setSupplements] = useState<SupplementItem[]>([
    {
      id: 's1',
      name: 'Vitamin D3 + K2 (MK-7)',
      dosage: '5000 IU / 100 mcg',
      timing: 'morning_with_food',
      purpose: isIndonesian ? 'Kesehatan tulang, imunitas & deposisi kalsium' : 'Bone density & calcium regulation',
      bioavailabilityTip: isIndonesian ? 'Larut lemak: Konsumsi bersama lemak sehat (alpukat/telur) untuk absorpsi 3x lipat' : 'Fat-soluble: Take with dietary fats for 3x absorption',
      takenToday: true,
    },
    {
      id: 's2',
      name: 'Omega-3 Fish Oil (EPA/DHA)',
      dosage: '1200 mg (700 EPA / 500 DHA)',
      timing: 'morning_with_food',
      purpose: isIndonesian ? 'Anti-inflamasi, kesehatan kardiovaskular & fungsi otak' : 'Anti-inflammatory & brain lipid integrity',
      bioavailabilityTip: isIndonesian ? 'Konsumsi saat makan utama untuk mencegah fishy aftertaste' : 'Take with largest meal to optimize bioavailability',
      takenToday: false,
    },
    {
      id: 's3',
      name: 'Magnesium Bisglycinate',
      dosage: '350 mg Elemental',
      timing: 'bedtime',
      purpose: isIndonesian ? 'Relaksasi otot, kualitas gelombang otak REM/Deep Sleep' : 'Neuromuscular relaxation & GABA receptor activation',
      bioavailabilityTip: isIndonesian ? 'Bentuk bisglycinate aman di lambung & tidak menyebabkan efek pencahar' : 'Bisglycinate chelate crosses blood-brain barrier cleanly',
      takenToday: false,
    },
    {
      id: 's4',
      name: 'Zinc Picolinate + Copper',
      dosage: '15 mg / 1 mg',
      timing: 'midday',
      purpose: isIndonesian ? 'Sintesis testosteron, imunitas seluler & regenerasi epitel' : 'Cellular immunity & hormone balance',
      bioavailabilityTip: isIndonesian ? 'Hindari minum bersamaan dengan kopi/kalsium tinggi (penghambat absorpsi)' : 'Do not co-ingest with high calcium or phytates',
      takenToday: false,
    },
  ]);

  const [selectedSynergyFilter, setSelectedSynergyFilter] = useState<'all' | 'morning' | 'evening'>('all');
  const [newSuppName, setNewSuppName] = useState('');
  const [newSuppDosage, setNewSuppDosage] = useState('');

  const handleToggleTaken = (id: string) => {
    setSupplements((prev) =>
      prev.map((s) => {
        if (s.id === id) {
          const next = !s.takenToday;
          if (next && onAwardXp) onAwardXp(25);
          return { ...s, takenToday: next };
        }
        return s;
      })
    );
  };

  const handleAddSupplement = () => {
    if (!newSuppName.trim()) return;
    const newItem: SupplementItem = {
      id: Date.now().toString(),
      name: newSuppName,
      dosage: newSuppDosage || 'Standard Dose',
      timing: 'morning_with_food',
      purpose: isIndonesian ? 'Suplemen Tambahan Personal' : 'Custom Supplement',
      bioavailabilityTip: isIndonesian ? 'Minum sesuai anjuran label dan perhatikan jadwal makan' : 'Follow label guidance with meal',
      takenToday: false,
    };
    setSupplements([...supplements, newItem]);
    setNewSuppName('');
    setNewSuppDosage('');
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-purple-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-purple-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m9_supplement_manager')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-purple-600 hover:bg-purple-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log Suplemen' : 'Log Supplement Data'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #9:</span>
            <span className="px-3 py-1 rounded-full bg-purple-100 text-purple-900 font-extrabold border border-purple-300">
              {isIndonesian ? 'Manajemen Suplemen & Interaksi Obat' : 'Personal Supplement & Drug Safety'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-purple-600 via-indigo-700 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-purple-100 text-xs font-black">
              <Pill className="w-3.5 h-3.5 text-purple-300" />
              <span>{isIndonesian ? 'Bioavailabilitas & Pengecekan Interaksi' : 'Bioavailability & Safety Matrix'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Manajemen Suplemen & Interaksi Aman' : 'Personal Supplement & Safety Manager'}
            </h1>
            <p className="text-xs sm:text-sm text-purple-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Jadwalkan vitamin dan mineral pada jendela penyerapan puncak serta audit potensi interaksi zat yang saling meniadakan atau berbahaya.'
                : 'Optimize peak micronutrient bioavailability timing and audit potential antagonistic nutrient collisions.'}
            </p>
          </div>

          {/* Quick Safety Summary */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-5 text-center min-w-[210px] shrink-0">
            <div className="flex items-center justify-center gap-2 text-emerald-300 text-xs font-black uppercase">
              <ShieldCheck className="w-4 h-4" />
              <span>{isIndonesian ? 'Interaksi Aman' : '0 Interactions'}</span>
            </div>
            <div className="text-2xl font-black text-white mt-1 font-mono">
              {supplements.filter((s) => s.takenToday).length} / {supplements.length}
            </div>
            <span className="text-[11px] text-purple-200 block mt-0.5 font-bold">
              {isIndonesian ? 'Suplemen Diminum Hari Ini' : 'Supplements Taken Today'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Interactive Supplement Stack + Safety Check Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Supplement Checklist & Bioavailability Guide */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black text-slate-900 tracking-tight">
              {isIndonesian ? 'Tumpukan Suplemen Harian Anda' : 'Your Daily Supplement Protocol'}
            </h2>
            <div className="flex gap-1 bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => setSelectedSynergyFilter('all')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  selectedSynergyFilter === 'all' ? 'bg-white text-purple-700 shadow-2xs font-black' : 'text-slate-500'
                }`}
              >
                Semua
              </button>
              <button
                onClick={() => setSelectedSynergyFilter('morning')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  selectedSynergyFilter === 'morning' ? 'bg-white text-purple-700 shadow-2xs font-black' : 'text-slate-500'
                }`}
              >
                Pagi
              </button>
              <button
                onClick={() => setSelectedSynergyFilter('evening')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  selectedSynergyFilter === 'evening' ? 'bg-white text-purple-700 shadow-2xs font-black' : 'text-slate-500'
                }`}
              >
                Malam
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {supplements.map((supp) => (
              <div
                key={supp.id}
                className={`border rounded-3xl p-5 transition-all shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  supp.takenToday
                    ? 'bg-emerald-50/50 border-emerald-200 text-slate-800'
                    : 'bg-white border-slate-200 hover:border-purple-300'
                }`}
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-slate-900">{supp.name}</span>
                    <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 text-[10px] font-bold font-mono">
                      {supp.dosage}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 font-medium leading-relaxed">{supp.purpose}</p>
                  <div className="flex items-center gap-1.5 text-[11px] text-purple-800 font-semibold bg-purple-50/80 p-2 rounded-xl border border-purple-100">
                    <Sparkles className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                    <span>{supp.bioavailabilityTip}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleToggleTaken(supp.id)}
                  className={`px-4 py-2.5 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 ${
                    supp.takenToday
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-purple-100 text-slate-700 hover:text-purple-900 border border-slate-200'
                  }`}
                >
                  <CheckCircle2 className={`w-4 h-4 ${supp.takenToday ? 'text-white' : 'text-slate-400'}`} />
                  <span>{supp.takenToday ? (isIndonesian ? 'Sudah Diminum' : 'Taken') : (isIndonesian ? 'Minum Sekarang' : 'Mark Taken')}</span>
                </button>
              </div>
            ))}
          </div>

          {/* Quick Add Custom Supplement Form */}
          <div className="bg-slate-50 border border-slate-200/90 rounded-3xl p-5 space-y-3">
            <h3 className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-purple-600" />
              <span>{isIndonesian ? 'Tambah Suplemen Kustom' : 'Add Custom Supplement'}</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <input
                type="text"
                placeholder={isIndonesian ? 'Nama vitamin / herba...' : 'Vitamin / Herb name...'}
                value={newSuppName}
                onChange={(e) => setNewSuppName(e.target.value)}
                className="sm:col-span-2 px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:outline-purple-500"
              />
              <input
                type="text"
                placeholder={isIndonesian ? 'Dosis (misal 500mg)...' : 'Dosage (e.g. 500mg)...'}
                value={newSuppDosage}
                onChange={(e) => setNewSuppDosage(e.target.value)}
                className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:outline-purple-500"
              />
            </div>
            <button
              onClick={handleAddSupplement}
              disabled={!newSuppName.trim()}
              className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs transition-all disabled:opacity-50 cursor-pointer shadow-xs"
            >
              {isIndonesian ? 'Simpan ke Protokol Harian (+10 XP)' : 'Save to Daily Protocol'}
            </button>
          </div>
        </div>

        {/* Right Col: Gemini Safety Audit & Interaction Rules */}
        <div className="space-y-4">
          <div className="bg-white border border-slate-200/90 rounded-3xl p-6 space-y-4 shadow-sm">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                {isIndonesian ? 'AI Safety & Collision Matrix' : 'Nutrient Synergy Matrix'}
              </h3>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
                <span className="font-black text-emerald-950 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Sinergi Positif: D3 + K2 + Lemak</span>
                </span>
                <p className="text-[11px] text-emerald-800 leading-relaxed font-medium">
                  K2 mengarahkan kalsium langsung ke matriks tulang alih-alih mengendap di pembuluh darah (arteri).
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 space-y-1">
                <span className="font-black text-amber-950 flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  <span>Hindari: Seng (Zinc) + Kalsium Tinggi</span>
                </span>
                <p className="text-[11px] text-amber-800 leading-relaxed font-medium">
                  Kedua mineral bersaing pada transporter divalent ion yang sama di usus. Beri jeda 2-3 jam.
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-indigo-50 border border-indigo-200 space-y-1">
                <span className="font-black text-indigo-950 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Waktu Magnesium Terbaik: Malam</span>
                </span>
                <p className="text-[11px] text-indigo-800 leading-relaxed font-medium">
                  Merangsang reseptor GABA penenang sistem saraf parasimpatis 45 menit sebelum tidur.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
