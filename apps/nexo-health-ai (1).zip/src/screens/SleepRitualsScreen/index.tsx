import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Moon,
  Clock,
  Sparkles,
  ArrowLeft,
  Coffee,
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  Bell,
  Sun,
  BedDouble,
  Zap,
  Plus,
} from 'lucide-react';
import { UserProfile, DailyLog } from '../../types';

interface SleepRitualsScreenProps {
  userProfile: UserProfile;
  dailyLog?: DailyLog;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const SleepRitualsScreen: React.FC<SleepRitualsScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [wakeTime, setWakeTime] = useState('06:00');
  const [caffeineCutoffDone, setCaffeineCutoffDone] = useState(true);
  const [blueLightFilterDone, setBlueLightFilterDone] = useState(false);
  const [temperatureCoolDone, setTemperatureCoolDone] = useState(false);
  const [breathingDone, setBreathingDone] = useState(false);

  // 90-minute sleep cycle calculation: 5 cycles (7.5h) or 6 cycles (9h) + 15 min sleep latency
  const calculateSleepTimes = (wake: string) => {
    const [h, m] = wake.split(':').map(Number);
    const wakeDate = new Date();
    wakeDate.setHours(h, m, 0, 0);

    const calcTime = (cycles: number) => {
      const d = new Date(wakeDate.getTime() - (cycles * 90 + 15) * 60000);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    return {
      fiveCycles: calcTime(5), // 7.5h sleep (recommended)
      sixCycles: calcTime(6), // 9h sleep (optimal recovery)
      fourCycles: calcTime(4), // 6h sleep (minimum)
    };
  };

  const sleepTimes = calculateSleepTimes(wakeTime);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-indigo-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-indigo-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m15_sleep_rituals')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log Tidur' : 'Log Sleep Data'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #15:</span>
            <span className="px-3 py-1 rounded-full bg-indigo-100 text-indigo-900 font-extrabold border border-indigo-300">
              {isIndonesian ? 'Kualitas Tidur & Ritual Malam' : 'Sleep Quality & Bedtime Rituals'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-indigo-700 via-slate-850 to-slate-950 rounded-[32px] p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-indigo-200 text-xs font-black">
              <Moon className="w-3.5 h-3.5 text-indigo-300" />
              <span>{isIndonesian ? 'Kalkulator Siklus 90-Menit & Audit Sirkadian' : 'Circadian 90-Min Lab'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Kualitas Tidur & Ritual Malam' : 'Sleep Quality & Bedtime Rituals'}
            </h1>
            <p className="text-xs sm:text-sm text-indigo-200/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Hitung waktu rebah tidur sempurna agar terbangun segar di puncak siklus tidur ultradian 90 menit tanpa grogginess (sleep inertia).'
                : 'Calculate optimal sleep onset to awaken at the apex of an ultradian 90-minute sleep cycle without sleep inertia.'}
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-5 text-center min-w-[200px] shrink-0">
            <span className="text-[11px] text-indigo-200 uppercase font-black tracking-wider block">
              {isIndonesian ? 'Waktu Bangun Target' : 'Target Wake Time'}
            </span>
            <div className="text-3xl font-black text-white mt-1 font-mono">
              {wakeTime} <span className="text-xs font-bold text-indigo-300">WIB</span>
            </div>
            <span className="text-[10px] text-indigo-200 mt-1 block font-bold">
              {isIndonesian ? '5 Siklus Lengkap (7.5 Jam)' : '5 Full Cycles (7.5h)'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: 90-Min Calculator + Bedtime Wind-Down Checklist */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: 90-Minute Sleep Cycle Calculator */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-indigo-600" />
              <h3 className="text-base font-black text-slate-900">
                {isIndonesian ? 'Kalkulator Waktu Tidur Optimal' : 'Sleep Onset Calculator'}
              </h3>
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-700 block">
              {isIndonesian ? 'Pilih Jam Bangun Tidur Anda Pagi Hari:' : 'Select Target Wake Time:'}
            </span>
            <input
              type="time"
              value={wakeTime}
              onChange={(e) => setWakeTime(e.target.value)}
              className="px-4 py-3 rounded-2xl border border-slate-200 bg-slate-50 text-sm font-bold font-mono text-slate-900 focus:outline-indigo-500 w-full"
            />
          </div>

          <div className="space-y-3 pt-2">
            <span className="text-xs font-black uppercase tracking-wider text-slate-500 block">
              {isIndonesian ? 'Pilihan Waktu Mulai Tidur Terbaik:' : 'Recommended Sleep Onset Times:'}
            </span>

            {/* 5 Cycles Recommended Card */}
            <div className="p-4 rounded-2xl bg-indigo-50 border-2 border-indigo-300 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-black text-indigo-950 font-mono">{sleepTimes.fiveCycles}</span>
                  <span className="px-2 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-black uppercase">
                    Rekomendasi Utama
                  </span>
                </div>
                <p className="text-xs text-indigo-800 mt-0.5 font-medium">5 Siklus Tidur (7 Jam 30 Menit)</p>
              </div>
              <BedDouble className="w-6 h-6 text-indigo-600" />
            </div>

            {/* 6 Cycles Maximum Recovery */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-base font-black text-slate-900 font-mono">{sleepTimes.sixCycles}</span>
                <p className="text-xs text-slate-500 mt-0.5 font-medium">6 Siklus Tidur (9 Jam - Atlet & Pemulihan Sakit)</p>
              </div>
              <Sparkles className="w-5 h-5 text-slate-400" />
            </div>

            {/* 4 Cycles Minimum */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-base font-black text-slate-900 font-mono">{sleepTimes.fourCycles}</span>
                <p className="text-xs text-slate-500 mt-0.5 font-medium">4 Siklus Tidur (6 Jam - Batas Minimal)</p>
              </div>
              <Sun className="w-5 h-5 text-slate-400" />
            </div>
          </div>
        </div>

        {/* Right: Bedtime Wind-Down Checklist & Disruptor Audit */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-4 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <h3 className="text-base font-black text-slate-900">
                {isIndonesian ? 'Ritual Penurunan Gelombang Otak' : 'Bedtime Wind-Down Protocol'}
              </h3>
            </div>
            <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900">
              Sirkadian
            </span>
          </div>

          <div className="space-y-3">
            {[
              {
                id: 'caffeine',
                title: isIndonesian ? 'Cut-off Kafein (8 Jam Sebelum Tidur)' : 'Caffeine Cut-off (8h before bed)',
                desc: isIndonesian ? 'Adenosin reseptor bebas dari blokade kafein.' : 'Adenosine receptors unblocked.',
                done: caffeineCutoffDone,
                toggle: () => setCaffeineCutoffDone(!caffeineCutoffDone),
                xp: 20,
              },
              {
                id: 'bluelight',
                title: isIndonesian ? 'Kacamata / Filter Layar Biru (90 Menit)' : 'Blue Light Filter (90m pre-bed)',
                desc: isIndonesian ? 'Mencegah supresi hormon melatonin oleh spektrum 480nm.' : 'Prevents melatonin suppression.',
                done: blueLightFilterDone,
                toggle: () => setBlueLightFilterDone(!blueLightFilterDone),
                xp: 25,
              },
              {
                id: 'temperature',
                title: isIndonesian ? 'Suhu Ruangan Sejuk (~19-21°C)' : 'Cool Bedroom Ambience (~19-21°C)',
                desc: isIndonesian ? 'Memicu penurunan suhu inti tubuh alami saat onset tidur.' : 'Triggers core body temperature dip.',
                done: temperatureCoolDone,
                toggle: () => setTemperatureCoolDone(!temperatureCoolDone),
                xp: 20,
              },
              {
                id: 'breathing',
                title: isIndonesian ? 'Peregangan / Relaksasi Napas 4-7-8' : '4-7-8 Calming Breath Stretch',
                desc: isIndonesian ? 'Menurunkan frekuensi denyut nadi dan tensi otot.' : 'Lowers resting heart rate before lying down.',
                done: breathingDone,
                toggle: () => setBreathingDone(!breathingDone),
                xp: 30,
              },
            ].map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  item.toggle();
                  if (!item.done && onAwardXp) onAwardXp(item.xp);
                }}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-4 ${
                  item.done
                    ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950'
                    : 'bg-slate-50 border-slate-200 hover:border-indigo-300'
                }`}
              >
                <div className="space-y-1">
                  <span className="text-xs font-black text-slate-900">{item.title}</span>
                  <p className="text-[11px] text-slate-600 font-medium">{item.desc}</p>
                </div>
                <button
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                    item.done ? 'bg-emerald-600 text-white' : 'border border-slate-300 bg-white text-slate-300'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
