import React, { useState } from 'react';
import { Award, Flame, Check, Trophy, Zap, CheckCircle2, Lock, ArrowRight, ArrowLeft, Sparkles, ShieldCheck } from 'lucide-react';
import { UserProfile, HabitItem, AchievementBadge } from '../../types';
import { INITIAL_HABITS, INITIAL_BADGES } from '../../data/sampleData';
import { CardCarousel } from '../../components/common/CardCarousel';

interface GamificationViewProps {
  userProfile: UserProfile;
  onUpdateXpAndStreak: (additionalXp: number) => void;
  onNavigateTab?: (tab: string) => void;
}

export const GamificationView: React.FC<GamificationViewProps> = ({
  userProfile,
  onUpdateXpAndStreak,
  onNavigateTab,
}) => {
  const isId = userProfile.language === 'id';
  const [habits, setHabits] = useState<HabitItem[]>(INITIAL_HABITS);
  const [badges, setBadges] = useState<AchievementBadge[]>(INITIAL_BADGES);

  const handleToggleHabit = (habitId: string) => {
    const updated = habits.map((h) => {
      if (h.id === habitId) {
        const nextCompleted = !h.completedToday;
        if (nextCompleted) {
          onUpdateXpAndStreak(h.xpReward);
        }
        return { ...h, completedToday: nextCompleted };
      }
      return h;
    });
    setHabits(updated);
  };

  const completedCount = habits.filter((h) => h.completedToday).length;

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-emerald-500 selection:text-white">
      {/* TOP NAVIGATION BREADCRUMB & BACK BUTTON */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('landing') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isId ? 'Kembali ke Beranda / Google Health Hub' : 'Back to Home / Google Health Hub'}</span>
        </button>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <span className="hidden sm:inline">Halaman Modul:</span>
          <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 font-extrabold border border-amber-300">
            Play Points, Streak & XP Gamifikasi
          </span>
        </div>
      </div>

      {/* Active Streak & Level Banner */}
      <div className="bg-white border border-emerald-100 rounded-[32px] p-6 sm:p-8 shadow-sm space-y-4 relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 z-10 relative">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-500 flex items-center justify-center text-white font-black text-2xl shadow-xs shrink-0">
              <Flame className="w-9 h-9 fill-white text-white animate-bounce" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-slate-900">
                  🔥 {userProfile.streakCount} {isId ? 'Hari Streak Sehat Aktif!' : 'Day Health Streak!'}
                </h1>
                <span className="bg-amber-50 text-amber-800 border border-amber-200 text-xs font-bold px-3 py-1 rounded-full">
                  Level {userProfile.level} Master
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                {isId
                  ? 'Selesaikan kebiasaan harian untuk menambah XP dan membuka lencana pencapaian baru.'
                  : 'Complete daily habits to gain XP and unlock new achievement badges.'}
              </p>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 w-full md:w-64 shrink-0">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-slate-600">{isId ? 'Kemajuan XP' : 'XP Progress'}</span>
              <span className="text-emerald-700 font-black">{userProfile.xp} / {userProfile.xpNextLevel} XP</span>
            </div>
            <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${(userProfile.xp / userProfile.xpNextLevel) * 100}%` }}
              />
            </div>
            <p className="text-[10px] text-slate-500 text-right font-medium">
              {userProfile.xpNextLevel - userProfile.xp} XP {isId ? 'menuju Level' : 'to Level'} {userProfile.level + 1}
            </p>
          </div>
        </div>
      </div>

      {/* BADGES CARD CAROUSEL (CARD CORSEL) */}
      <section className="space-y-3">
        <CardCarousel
          title={isId ? 'Lencana Pencapaian & Trofi' : 'Achievement Badges & Trophies'}
          subtitle={isId ? 'Geser untuk melihat trofi yang telah Anda raih dan target berikutnya' : 'Swipe or click arrows to view your unlocked achievements'}
          badge={isId ? 'Lencana Trofi' : 'Badges'}
          cardWidthClass="w-[260px] sm:w-[290px] md:w-[310px]"
        >
          {badges.map((badge) => (
            <div
              key={badge.id}
              className={`h-full border rounded-[24px] p-5 space-y-3 shadow-2xs transition-all duration-200 flex flex-col justify-between ${
                badge.unlocked
                  ? 'bg-white border-amber-300 ring-2 ring-amber-400/20'
                  : 'bg-slate-50 border-slate-200 opacity-80'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl shrink-0 ${
                      badge.unlocked
                        ? 'bg-amber-100 text-amber-800 border border-amber-200 shadow-2xs'
                        : 'bg-slate-200 text-slate-500 border border-slate-300'
                    }`}
                  >
                    {badge.unlocked ? <Award className="w-6 h-6 text-amber-600" /> : <Lock className="w-5 h-5" />}
                  </div>
                  {badge.unlocked ? (
                    <span className="text-[10px] bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-full font-bold">
                      {isId ? 'Terbuka' : 'Unlocked'}
                    </span>
                  ) : (
                    <span className="text-[10px] bg-slate-200 text-slate-600 px-2 py-0.5 rounded-full font-medium">
                      {badge.progressPercent}%
                    </span>
                  )}
                </div>

                <div>
                  <h4 className="text-sm font-bold text-slate-900 line-clamp-1">{badge.title}</h4>
                  <p className="text-xs text-slate-500 mt-0.5 leading-relaxed line-clamp-2">{badge.description}</p>
                </div>
              </div>

              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      badge.unlocked ? 'bg-amber-500' : 'bg-slate-400'
                    }`}
                    style={{ width: `${badge.progressPercent}%` }}
                  />
                </div>
                {badge.unlockedAt && (
                  <p className="text-[10px] text-slate-400 font-medium">
                    {isId ? 'Diraih pada' : 'Achieved on'} {badge.unlockedAt}
                  </p>
                )}
              </div>
            </div>
          ))}
        </CardCarousel>
      </section>

      {/* DAILY HABITS CHECKLIST CONTAINER */}
      <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 sm:p-8 shadow-2xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h3 className="font-bold text-slate-900 text-base sm:text-lg flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-700" />
              <span>{isId ? 'Daftar Kebiasaan Sehat Harian' : 'Daily Health Habits Checklist'}</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {completedCount} {isId ? 'dari' : 'of'} {habits.length} {isId ? 'kebiasaan selesai hari ini' : 'habits completed today'}
            </p>
          </div>

          <span className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full">
            {Math.round((completedCount / habits.length) * 100)}% {isId ? 'Selesai' : 'Done'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {habits.map((habit) => (
            <div
              key={habit.id}
              onClick={() => handleToggleHabit(habit.id)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 shadow-2xs ${
                habit.completedToday
                  ? 'bg-emerald-50/80 border-emerald-200 text-slate-900'
                  : 'bg-slate-50 border-slate-200 hover:border-emerald-200 text-slate-700'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold transition-colors ${
                    habit.completedToday
                      ? 'bg-emerald-600 text-white'
                      : 'border-2 border-slate-300 text-transparent'
                  }`}
                >
                  ✓
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{habit.defaultTitle}</h4>
                  <p className="text-xs text-slate-500">Target: {habit.target}</p>
                </div>
              </div>

              <span className="bg-emerald-100 border border-emerald-200 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-xl shrink-0">
                +{habit.xpReward} XP
              </span>
            </div>
          ))}
        </div>

        <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100 text-xs text-slate-600 space-y-1 mt-2">
          <p className="font-bold text-emerald-900 flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-emerald-600" />
            <span>{isId ? 'Sinkronisasi Otomatis Firestore:' : 'Automatic Firestore Synchronization:'}</span>
          </p>
          <p className="text-xs text-slate-600 leading-relaxed">
            {isId
              ? 'Setiap kebiasaan yang dicentang langsung tersimpan ke NoSQL Firestore dan menambahkan XP harian Anda secara instan.'
              : 'Each checked habit is automatically persisted to Firestore and increments your daily XP in real-time.'}
          </p>
        </div>
      </div>
    </div>
  );
};
