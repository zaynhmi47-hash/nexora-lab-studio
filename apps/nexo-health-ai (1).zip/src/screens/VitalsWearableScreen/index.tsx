import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Activity,
  Heart,
  Droplets,
  Wind,
  ShieldCheck,
  RefreshCw,
  Sparkles,
  ArrowLeft,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Radio,
  Plus,
} from 'lucide-react';
import { UserProfile, DailyLog } from '../../types';

interface VitalsWearableScreenProps {
  userProfile: UserProfile;
  dailyLog?: DailyLog;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const VitalsWearableScreen: React.FC<VitalsWearableScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [livePulse, setLivePulse] = useState(74);
  const [spo2, setSpo2] = useState(99);
  const [systolic, setSystolic] = useState(118);
  const [diastolic, setDiastolic] = useState(76);
  const [respiratoryRate, setRespiratoryRate] = useState(14);
  const [isSimulatingStrain, setIsSimulatingStrain] = useState(false);

  // Live heart rate micro fluctuation
  useEffect(() => {
    const timer = setInterval(() => {
      setLivePulse((prev) => {
        const delta = Math.floor(Math.random() * 3) - 1; // -1, 0, +1
        const target = isSimulatingStrain ? 115 : 74;
        return Math.max(60, Math.min(160, prev + delta + (target > prev ? 1 : -1)));
      });
    }, 1500);
    return () => clearInterval(timer);
  }, [isSimulatingStrain]);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-teal-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-teal-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m18_vitals_wearables')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-teal-600 hover:bg-teal-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log Vital' : 'Log Vital Signs'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #18:</span>
            <span className="px-3 py-1 rounded-full bg-teal-100 text-teal-900 font-extrabold border border-teal-300">
              {isIndonesian ? 'Pemantauan Tanda Vital & Wearables' : 'Vital Signs & Wearable Hub'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-teal-700 via-emerald-800 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-teal-100 text-xs font-black">
              <Radio className="w-3.5 h-3.5 text-teal-300 animate-pulse" />
              <span>{isIndonesian ? 'Frekuensi 1 Hz & Deteksi Dini Aritmia' : '1 Hz Sensor Stream & Anomaly AI'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Pemantauan Tanda Vital & Wearables' : 'Vital Signs & Wearable Hub'}
            </h1>
            <p className="text-xs sm:text-sm text-teal-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Integrasi langsung sensor optik PPG, denyut nadi istirahat, saturasi oksigen (SpO2), tensi darah, dan sistem alarm dini sebelum muncul gejala klinis.'
                : 'Direct optical PPG streaming, SpO2 monitoring, blood pressure trends, and predictive physiological strain alarms.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setIsSimulatingStrain(!isSimulatingStrain)}
              className={`px-4 py-2.5 rounded-2xl border text-xs font-bold transition-all cursor-pointer ${
                isSimulatingStrain
                  ? 'bg-amber-500 text-slate-950 font-black border-amber-400'
                  : 'bg-white/15 hover:bg-white/25 text-white border-white/20'
              }`}
            >
              {isSimulatingStrain
                ? (isIndonesian ? 'Simulasi Stres Aktif' : 'Simulating Stress')
                : (isIndonesian ? 'Uji Simulasi Beban' : 'Test Strain Mode')}
            </button>
          </div>
        </div>
      </div>

      {/* Real-Time Live Vitals Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Heart Rate */}
        <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 space-y-3 shadow-sm hover:border-rose-300 transition-all">
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600">
              <Heart className="w-5 h-5 animate-pulse" />
            </div>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              Live PPG
            </span>
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500">Denyut Nadi</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-3xl font-black text-slate-900 font-mono">{livePulse}</span>
              <span className="text-xs font-bold text-slate-400">bpm</span>
            </div>
          </div>
          <div className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Sinus Normal (HRV 68ms)</span>
          </div>
        </div>

        {/* SpO2 */}
        <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 space-y-3 shadow-sm hover:border-cyan-300 transition-all">
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-2xl bg-cyan-50 border border-cyan-200 text-cyan-600">
              <Droplets className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              Optimal
            </span>
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500">Saturasi Oksigen (SpO2)</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-3xl font-black text-slate-900 font-mono">{spo2}</span>
              <span className="text-xs font-bold text-slate-400">%</span>
            </div>
          </div>
          <div className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Perfusi Sangat Baik</span>
          </div>
        </div>

        {/* Blood Pressure */}
        <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 space-y-3 shadow-sm hover:border-teal-300 transition-all">
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-2xl bg-teal-50 border border-teal-200 text-teal-600">
              <Activity className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              Optimal
            </span>
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500">Tekanan Darah</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-3xl font-black text-slate-900 font-mono">{systolic}/{diastolic}</span>
              <span className="text-xs font-bold text-slate-400">mmHg</span>
            </div>
          </div>
          <div className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Normotensif Prima</span>
          </div>
        </div>

        {/* Respiratory Rate */}
        <div className="bg-white border border-slate-200/90 rounded-[28px] p-6 space-y-3 shadow-sm hover:border-indigo-300 transition-all">
          <div className="flex items-center justify-between">
            <div className="p-2.5 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-600">
              <Wind className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              Tenang
            </span>
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500">Frekuensi Napas</span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-3xl font-black text-slate-900 font-mono">{respiratoryRate}</span>
              <span className="text-xs font-bold text-slate-400">rpm</span>
            </div>
          </div>
          <div className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Eupnea Normal</span>
          </div>
        </div>
      </div>
    </div>
  );
};
