import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Shield,
  Zap,
  Target,
  Trophy,
  Sparkles,
  ArrowLeft,
  CheckCircle2,
  Lock,
  Clock,
  BookOpen,
  Award,
  RefreshCw,
  Plus,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface MentalResilienceScreenProps {
  userProfile: UserProfile;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const MentalResilienceScreen: React.FC<MentalResilienceScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [resilienceScore, setResilienceScore] = useState(82);
  const [completedDrills, setCompletedDrills] = useState<string[]>(['d1']);
  const [activeQuoteIdx, setActiveQuoteIdx] = useState(0);

  const stoicQuotes = [
    {
      author: 'Marcus Aurelius (Meditations)',
      quote: isIndonesian
        ? 'Anda memiliki kekuatan atas pikiran Anda — bukan peristiwa di luar. Sadarilah ini, dan Anda akan menemukan kekuatan sejati.'
        : 'You have power over your mind - not outside events. Realize this, and you will find strength.',
      exercise: isIndonesian ? 'Dichotomy of Control: Tuliskan 3 hal hari ini yang tidak bisa Anda kontrol dan relakan.' : 'Dichotomy of Control: Identify 3 uncontrollables today and release them.',
    },
    {
      author: 'Epictetus (Enchiridion)',
      quote: isIndonesian
        ? 'Bukan hal-hal di luar yang mengganggu manusia, melainkan penilaian dan opini yang mereka bentuk tentang hal-hal tersebut.'
        : 'Men are disturbed not by things, but by the view which they take of them.',
      exercise: isIndonesian ? 'Reframing Hambatan: Ubah 1 keluhan menjadi peluang melatih kesabaran.' : 'Turn an obstacle into an active patience drill.',
    },
    {
      author: 'Seneca (Letters from a Stoic)',
      quote: isIndonesian
        ? 'Kita lebih sering menderita dalam imajinasi kita daripada dalam kenyataan nyata.'
        : 'We suffer more often in imagination than in reality.',
      exercise: isIndonesian ? 'Reality Check: Apakah kekhawatiran ini akan bermakna 5 tahun dari sekarang?' : 'Ask: Will this issue matter 5 years from now?',
    },
  ];

  const resilienceDrills = [
    {
      id: 'd1',
      title: isIndonesian ? 'Deep Work Sprint 25 Menit (Zero Phone)' : '25-Min Deep Focus Sprint',
      category: 'Focus',
      xp: 40,
      desc: isIndonesian ? 'Kunci ponsel di ruangan lain saat mengerjakan 1 tugas terpenting.' : 'Phone outside room during primary high-leverage task.',
    },
    {
      id: 'd2',
      title: isIndonesian ? 'Impulse Delay 10 Menit' : '10-Min Dopamine Impulse Delay',
      category: 'Self-Control',
      xp: 35,
      desc: isIndonesian ? 'Saat ingin membuka media sosial atau ngemil impulsif, tahan selama 10 menit penuh.' : 'Delay impulsive snacking or social scrolling by 10 minutes.',
    },
    {
      id: 'd3',
      title: isIndonesian ? 'Paparan Dingin / Mandi Air Dingin 60s' : '60-Sec Cold Shower Exposure',
      category: 'Nervous System',
      xp: 50,
      desc: isIndonesian ? 'Latih respon pernapasan tenang saat menghadapi stres fisik mendadak.' : 'Calm breathing response under acute physical stress.',
    },
    {
      id: 'd4',
      title: isIndonesian ? 'Amor Fati Gratitude Journal' : 'Amor Fati Adversity Reframing',
      category: 'Mindset',
      xp: 30,
      desc: isIndonesian ? 'Tuliskan 1 kesulitan pekan ini dan cari 2 hikmah pembelajaran tak terduga.' : 'Extract 2 constructive lessons from a recent setback.',
    },
  ];

  const handleToggleDrill = (id: string, xp: number) => {
    if (completedDrills.includes(id)) {
      setCompletedDrills(completedDrills.filter((d) => d !== id));
    } else {
      setCompletedDrills([...completedDrills, id]);
      setResilienceScore((s) => Math.min(100, s + 3));
      if (onAwardXp) onAwardXp(xp);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-emerald-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m14_mental_resilience')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log Resiliensi' : 'Log Resilience Drill'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #14:</span>
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-extrabold border border-emerald-300">
              {isIndonesian ? 'Pelatihan Ketahanan Mental (Resiliensi)' : 'Mental Resilience & Focus'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-emerald-700 via-teal-800 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-emerald-100 text-xs font-black">
              <Shield className="w-3.5 h-3.5 text-emerald-300" />
              <span>{isIndonesian ? 'Neuroplastisitas & Stoikisme Terapan' : 'Neuroplasticity & Stoic Drills'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Pelatihan Ketahanan Mental' : 'Mental Resilience & Focus Training'}
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Latih otot mental melawan distraksi dopamin instan, kendalikan impuls, dan bangun ketenangan batin lewat latihan harian terukur.'
                : 'Build psychological antifragility through gamified impulse control drills, deep work focus protocols, and applied philosophy.'}
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-5 text-center min-w-[200px] shrink-0">
            <span className="text-[11px] text-emerald-200 uppercase font-black tracking-wider block">
              {isIndonesian ? 'Skor Resiliensi XP' : 'Resilience Score'}
            </span>
            <div className="text-3xl font-black text-white mt-1 font-mono">
              {resilienceScore} <span className="text-xs font-bold text-emerald-300">/ 100</span>
            </div>
            <span className="text-[10px] text-emerald-200 mt-1 block font-bold">
              {completedDrills.length} / {resilienceDrills.length} {isIndonesian ? 'Latihan Selesai' : 'Drills Done'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Stoic Philosophy Card + Gamified Daily Resilience Drills */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Stoic Mindset & Reframing Box */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-6 shadow-sm flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-emerald-600" />
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                  {isIndonesian ? 'Refleksi Stoik Harian' : 'Daily Stoic Reframing'}
                </h3>
              </div>
              <button
                onClick={() => setActiveQuoteIdx((prev) => (prev + 1) % stoicQuotes.length)}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Ganti Kutipan</span>
              </button>
            </div>

            <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
              <p className="text-sm font-semibold text-emerald-950 italic leading-relaxed">
                "{stoicQuotes[activeQuoteIdx].quote}"
              </p>
              <span className="text-xs font-black text-emerald-800 block">
                — {stoicQuotes[activeQuoteIdx].author}
              </span>
            </div>

            <div className="space-y-2">
              <span className="text-xs font-black uppercase text-slate-700 tracking-wider block">
                {isIndonesian ? 'Tantangan Refleksi Terapan:' : 'Applied Mental Exercise:'}
              </span>
              <p className="text-xs text-slate-600 leading-relaxed font-medium bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                {stoicQuotes[activeQuoteIdx].exercise}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if (onAwardXp) onAwardXp(25);
              alert(isIndonesian ? 'Refleksi stoik diselesaikan! +25 XP' : 'Stoic exercise completed! +25 XP');
            }}
            className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all cursor-pointer shadow-md"
          >
            {isIndonesian ? 'Tandai Refleksi Selesai (+25 XP)' : 'Complete Daily Reflection'}
          </button>
        </div>

        {/* Right: Gamified Resilience Drills Stack */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-4 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-teal-600" />
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wide">
                {isIndonesian ? 'Tantangan Ketahanan Mental Hari Ini' : 'Active Resilience Drills'}
              </h3>
            </div>
            <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900">
              XP Booster
            </span>
          </div>

          <div className="space-y-3">
            {resilienceDrills.map((drill) => {
              const isDone = completedDrills.includes(drill.id);
              return (
                <div
                  key={drill.id}
                  onClick={() => handleToggleDrill(drill.id, drill.xp)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-4 ${
                    isDone
                      ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950'
                      : 'bg-slate-50 border-slate-200 hover:border-emerald-300'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-slate-900">{drill.title}</span>
                      <span className="px-2 py-0.2 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                        +{drill.xp} XP
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 font-medium leading-relaxed">{drill.desc}</p>
                  </div>

                  <button
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                      isDone ? 'bg-emerald-600 text-white' : 'border border-slate-300 bg-white text-slate-300'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
