import React, { useState, useEffect } from 'react';
import {
  Layers,
  Sparkles,
  Search,
  ChevronRight,
  Activity,
  Dumbbell,
  Camera,
  HeartPulse,
  Trophy,
  UserCheck,
  UtensilsCrossed,
  Utensils,
  Scan,
  Droplets,
  Pill,
  Sparkle,
  MessageSquareHeart,
  Compass,
  Wind,
  Shield,
  Moon,
  Stethoscope,
  FileText,
  Heart,
  Zap,
  ArrowLeft,
} from 'lucide-react';
import { UserProfile, HealthModuleId, HealthModuleMetadata } from '../../types';
import { HEALTH_MODULES } from '../../data/healthModulesData';
import { GroupedModuleCarousel } from '../../components/modules/GroupedModuleCarousel';
import { CustomModuleCards } from '../../components/modules/CustomModuleCards';
import { ModuleSynergyWorkbench } from '../../components/modules/ModuleSynergyWorkbench';

interface ModuleHubViewProps {
  userProfile: UserProfile;
  initialModuleId?: HealthModuleId;
  onNavigateTab?: (tab: any) => void;
}

export const ModuleHubView: React.FC<ModuleHubViewProps> = ({
  userProfile,
  initialModuleId,
  onNavigateTab,
}) => {
  const isIndonesian = userProfile.language === 'id';
  const [activeModule, setActiveModule] = useState<HealthModuleMetadata>(
    HEALTH_MODULES.find((m) => m.id === initialModuleId) || HEALTH_MODULES[0]
  );

  // Sync activeModule if initialModuleId changes
  useEffect(() => {
    if (initialModuleId) {
      const found = HEALTH_MODULES.find((m) => m.id === initialModuleId);
      if (found) {
        setActiveModule(found);
      }
    }
  }, [initialModuleId]);

  const handleLaunchModuleDirect = (mod: HealthModuleMetadata) => {
    setActiveModule(mod);
    if (!onNavigateTab) return;
    
    if (mod.id === 'm1_adaptive_trainer') {
      onNavigateTab('workout');
    } else if (mod.id === 'm2_form_cv') {
      onNavigateTab('form_guard');
    } else if (mod.id === 'm3_active_recovery') {
      onNavigateTab('recovery');
    } else if (mod.id === 'm4_sport_performance') {
      onNavigateTab('sport');
    } else if (mod.id === 'm5_posture_ergonomics') {
      onNavigateTab('posture');
    } else if (mod.id === 'm6_ai_dietitian' || mod.id === 'm7_food_scanner') {
      onNavigateTab('nutrition');
    } else if (mod.id === 'm8_smart_hydration') {
      onNavigateTab('smart_hydration');
    } else if (mod.id === 'm9_supplement_manager') {
      onNavigateTab('supplement_manager');
    } else if (mod.id === 'm10_mindful_eating') {
      onNavigateTab('mindful_eating');
    } else if (mod.id === 'm11_cbt_therapy') {
      onNavigateTab('cbt_therapy');
    } else if (mod.id === 'm12_emotion_stress_map') {
      onNavigateTab('emotion_stress');
    } else if (mod.id === 'm13_adaptive_meditation') {
      onNavigateTab('adaptive_meditation');
    } else if (mod.id === 'm14_mental_resilience') {
      onNavigateTab('mental_resilience');
    } else if (mod.id === 'm15_sleep_rituals') {
      onNavigateTab('sleep_rituals');
    } else if (mod.id === 'm16_doctor_triage') {
      onNavigateTab('doctor_consultation');
    } else if (mod.id === 'm17_electronic_health_record') {
      onNavigateTab('ehr');
    } else if (mod.id === 'm18_vitals_wearables') {
      onNavigateTab('vitals_wearables');
    } else if (mod.id === 'm19_longevity_screening') {
      onNavigateTab('longevity_bioage');
    } else if (mod.id === 'm20_hormonal_reproductive') {
      onNavigateTab('hormonal_health');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-8 text-slate-800 selection:bg-emerald-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* TOP NAVIGATION BREADCRUMB & BACK BUTTON */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('landing') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Beranda / Untuk Anda' : 'Back to Home / For You'}</span>
        </button>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
          <span className="hidden sm:inline">Modul Terpilih:</span>
          <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-extrabold border border-emerald-300">
            #{activeModule.moduleNumber} {isIndonesian ? activeModule.title : activeModule.titleEn}
          </span>
        </div>
      </div>

      {/* HEADER SECTION: Google Play Store Style */}
      <section className="bg-gradient-to-br from-emerald-500/10 via-white to-teal-500/10 border border-emerald-200/80 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-2xs">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-100/90 text-emerald-900 border border-emerald-200 text-xs font-black">
              <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
              <span>{isIndonesian ? 'Koleksi 20 Modul Google Health' : 'Google Health 20 Modules Catalog'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {isIndonesian ? 'Pusat 20 Modul AI Terintegrasi' : 'Integrated 20 Health AI Modules'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Jelajahi ekosistem kesehatan komprehensif. Geser kartu paket 4-in-1 di bawah ini untuk berpindah kelompok modul dan scroll ke bawah untuk melihat sinergi, ranking terpopuler, dan uji coba langsung.'
                : 'Explore our complete health ecosystem. Swipe the 4-in-1 card deck below and scroll down for synergies, rankings, and live AI workbench.'}
            </p>
          </div>

          {/* Quick Metrics Badges */}
          <div className="flex flex-wrap md:flex-col gap-2.5 shrink-0">
            <div className="bg-white border border-emerald-100 rounded-2xl p-3 shadow-2xs flex items-center gap-3">
              <div className="p-2 bg-emerald-600 text-white rounded-xl">
                <Layers className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-black text-slate-900">20 Modul Lengkap</div>
                <div className="text-[10px] text-emerald-700 font-bold">5 Paket Geser 4-in-1</div>
              </div>
            </div>

            <div className="bg-white border border-emerald-100 rounded-2xl p-3 shadow-2xs flex items-center gap-3">
              <div className="p-2 bg-teal-600 text-white rounded-xl">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-black text-slate-900">Gemini AI Orchestrator</div>
                <div className="text-[10px] text-teal-700 font-bold">Real-time Biometrics</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 1. THE 4-IN-1 CARD DECK CAROUSEL (Geser ke samping untuk melihat kartu lain) */}
      {/* ========================================================================= */}
      <section className="space-y-2">
        <GroupedModuleCarousel
          onSelectModule={handleLaunchModuleDirect}
          isIndonesian={isIndonesian}
        />
      </section>

      {/* ========================================================================= */}
      {/* 2. AI WORKBENCH & SYNERGY PIPELINE (Uji coba parameter interaktif) */}
      {/* ========================================================================= */}
      <section className="pt-2">
        <ModuleSynergyWorkbench
          userProfile={userProfile}
          activeModule={activeModule}
          onSelectModule={handleLaunchModuleDirect}
          isIndonesian={isIndonesian}
        />
      </section>

      {/* ========================================================================= */}
      {/* 3. DIVERSE CUSTOM CARDS BELOW (Scroll ke bawah untuk gaya kartu yang berbeda) */}
      {/* ========================================================================= */}
      <section className="pt-2">
        <CustomModuleCards
          userProfile={userProfile}
          activeModule={activeModule}
          onSelectModule={handleLaunchModuleDirect}
          onNavigateTab={onNavigateTab}
          isIndonesian={isIndonesian}
        />
      </section>
    </div>
  );
};
