import React, { useRef, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Bot,
  RotateCcw,
  Mic,
  ShieldCheck,
  Zap,
  Info,
  ChevronRight,
  FlaskConical,
  X,
  Volume2,
} from 'lucide-react';
import { useConversation } from '../context/ConversationContext';
import { useProfile } from '../context/ProfileContext';
import { ChatBubble, ChatInput, TypingIndicator, PromptCard } from '../components/ai';
import { AI_TEST_SCENARIOS, TestScenario } from '../services/ai/testScenarios';
import { TabType } from '../components/layout/NavBar';

interface CoachScreenProps {
  onNavigateTab?: (tab: TabType) => void;
}

export const CoachScreen: React.FC<CoachScreenProps> = ({ onNavigateTab }) => {
  const { profile } = useProfile();
  const {
    messages,
    isLoading,
    isThinking,
    suggestedPrompts,
    sendMessage,
    retryLastMessage,
    clearConversation,
    sendSuggestedPrompt,
  } = useConversation();

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [activeVoiceModal, setActiveVoiceModal] = useState(false);

  const isIndonesian = profile.language !== 'en';

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  const handleRunTestScenario = async (scenario: TestScenario) => {
    setIsTestModalOpen(false);
    await sendMessage(scenario.sampleInput);
  };

  const getToneLabel = () => {
    const tone = profile.aiTone || 'friendly';
    switch (tone) {
      case 'clinical':
        return isIndonesian ? 'Klinis & Objektif' : 'Clinical & Objective';
      case 'motivational':
        return isIndonesian ? 'Motivasi Tinggi' : 'High Motivation';
      case 'calm':
        return isIndonesian ? 'Tenang & Mindful' : 'Calm & Mindful';
      case 'friendly':
      default:
        return isIndonesian ? 'Ramah & Empatik' : 'Friendly & Warm';
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-3 sm:px-6 py-4 flex flex-col h-[calc(100vh-8rem)] min-h-[550px]">
      {/* Header Bar */}
      <div className="bg-white border border-slate-200/90 rounded-2xl px-4 py-3 shadow-xs mb-3 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20">
            <Bot size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-extrabold text-slate-900 leading-none">
                AI Health Coach
              </h1>
              <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                <Sparkles size={11} className="text-emerald-600" />
                Gemini 3
              </span>
            </div>
            <p className="text-xs text-slate-700 mt-0.5 flex items-center gap-1.5">
              <span>Persona: <strong className="text-slate-800 font-semibold">{getToneLabel()}</strong></span>
              <span className="text-slate-300">•</span>
              <span className="text-emerald-600 font-medium">Bimbingan Kebugaran & Nutrisi</span>
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Test Scenarios Suite Button */}
          <button
            onClick={() => setIsTestModalOpen(true)}
            title="Uji 10 Skenario AI Coach"
            className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300 transition cursor-pointer"
          >
            <FlaskConical size={14} className="text-indigo-600" />
            <span className="hidden md:inline">Uji Skenario</span>
          </button>

          {/* Voice Interaction Button Placeholder */}
          <button
            onClick={() => setActiveVoiceModal(true)}
            title="Mode Suara (Voice Interaction)"
            className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-200 transition cursor-pointer"
          >
            <Volume2 size={14} className="text-emerald-600" />
            <span className="hidden sm:inline">Suara</span>
          </button>

          {/* Clear Conversation */}
          <button
            onClick={clearConversation}
            title="Mulai Ulang Percakapan"
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
          >
            <RotateCcw size={16} />
          </button>
        </div>
      </div>

      {/* Main Chat Conversation Scroll Area */}
      <div className="flex-1 bg-slate-50/50 border border-slate-200/80 rounded-2xl p-3 sm:p-5 overflow-y-auto space-y-4 shadow-inner mb-3">
        {messages.map((msg, index) => (
          <ChatBubble
            key={msg.id || index}
            message={msg}
            onRetry={retryLastMessage}
            onSelectPrompt={sendSuggestedPrompt}
            isLast={index === messages.length - 1}
          />
        ))}

        {isThinking && <TypingIndicator label="AI sedang menganalisis..." />}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts Shelf if only welcome message */}
      {messages.length <= 1 && (
        <div className="mb-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">
            <Zap size={13} className="text-amber-500" />
            <span>Pertanyaan Populer:</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
            {suggestedPrompts.slice(0, 3).map((prompt, idx) => (
              <PromptCard
                key={idx}
                prompt={prompt}
                onClick={sendSuggestedPrompt}
                disabled={isLoading}
              />
            ))}
          </div>
        </div>
      )}

      {/* Bottom Chat Input Bar */}
      <div className="shrink-0">
        <ChatInput
          onSendMessage={sendMessage}
          isLoading={isLoading}
          onVoiceClickPlaceholder={() => setActiveVoiceModal(true)}
          placeholder={
            isIndonesian
              ? 'Tanyakan panduan latihan, saran makanan, hidrasi, atau kualitas tidur...'
              : 'Ask about workouts, nutrition, hydration, or sleep hygiene...'
          }
        />
      </div>

      {/* Test Scenarios Modal */}
      <AnimatePresence>
        {isTestModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white border border-slate-200 rounded-3xl max-w-2xl w-full p-5 sm:p-6 shadow-2xl max-h-[85vh] flex flex-col"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
                    <FlaskConical size={18} />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900">Suite Pengujian AI Coach (10 Skenario)</h3>
                    <p className="text-xs text-slate-500">Uji kehandalan respons, triage etika medis, & lokalisasi</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsTestModalOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
                {AI_TEST_SCENARIOS.map((scenario) => (
                  <div
                    key={scenario.id}
                    className="p-3 rounded-xl border border-slate-200 hover:border-indigo-300 bg-slate-50 hover:bg-indigo-50/40 transition flex items-start justify-between gap-3"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold text-[10px] flex items-center justify-center">
                          {scenario.number}
                        </span>
                        <span className="text-xs font-bold text-slate-900">{scenario.title}</span>
                        <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">
                          {scenario.expectedResponseType}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mb-1">"{scenario.sampleInput}"</p>
                      <p className="text-[11px] text-slate-500 italic">{scenario.notes}</p>
                    </div>
                    <button
                      onClick={() => handleRunTestScenario(scenario)}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 transition shrink-0 cursor-pointer flex items-center gap-1"
                    >
                      <span>Uji</span>
                      <ChevronRight size={13} />
                    </button>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Voice Info Modal */}
      <AnimatePresence>
        {activeVoiceModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-6 shadow-2xl text-center"
            >
              <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-4">
                <Mic size={28} />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Live Voice Coaching (Step 4 & 5)</h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-5">
                Fitur percakapan audio dua arah berkecepatan tinggi dengan <strong>LiveKit & Gemini Live API</strong> serta analisis postur kamera <strong>MediaPipe</strong> akan diintegrasikan pada langkah berikutnya.
              </p>
              <button
                onClick={() => setActiveVoiceModal(false)}
                className="w-full py-2.5 rounded-xl bg-slate-900 text-white font-bold text-sm hover:bg-slate-800 transition cursor-pointer"
              >
                Mengerti
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
