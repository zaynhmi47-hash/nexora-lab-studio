import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Heart,
  Sparkles,
  Calendar,
  Activity,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Thermometer,
  Zap,
  Flame,
  Sun,
  ShieldCheck,
  Plus,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface HormonalHealthScreenProps {
  userProfile: UserProfile;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const HormonalHealthScreen: React.FC<HormonalHealthScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [currentCycleDay, setCurrentCycleDay] = useState(14); // Day 14 = Ovulatory peak
  const [bbtTemperature, setBbtTemperature] = useState(36.6); // Celcius
  const [energyLevel, setEnergyLevel] = useState<'high' | 'moderate' | 'low'>('high');

  // Cycle phase detection based on day
  const getPhaseInfo = (day: number) => {
    if (day <= 5) {
      return {
        name: isIndonesian ? 'Fase Menstruasi (Hari 1-5)' : 'Menstrual Phase (Day 1-5)',
        hormoneState: isIndonesian ? 'Estrogen & Progesteron Rendah' : 'Low Estrogen & Progesterone',
        workout: isIndonesian ? 'Yoga restoratif, jalan santai, peregangan lembut' : 'Restorative yoga, gentle walks',
        nutrition: isIndonesian ? 'Zat besi tinggi (bayam, daging merah), magnesium, kaldu hangat' : 'Iron-rich greens, warm broths',
        theme: 'bg-rose-50 border-rose-200 text-rose-950',
      };
    } else if (day <= 13) {
      return {
        name: isIndonesian ? 'Fase Folikular (Hari 6-13)' : 'Follicular Phase (Day 6-13)',
        hormoneState: isIndonesian ? 'Kenaikan Estrogen & Sensitivitas Insulin Tinggi' : 'Rising Estrogen & High Insulin Sensitivity',
        workout: isIndonesian ? 'Latihan beban progresif (PR lift), HIIT, kardio intensif' : 'Progressive overload, HIIT, sprint intervals',
        nutrition: isIndonesian ? 'Karbohidrat kompleks, makanan fermentasi (probiotik), sayuran silang' : 'Complex carbs, fermented probiotics',
        theme: 'bg-teal-50 border-teal-200 text-teal-950',
      };
    } else if (day <= 16) {
      return {
        name: isIndonesian ? 'Fase Ovulasi (Hari 14-16)' : 'Ovulatory Phase (Day 14-16)',
        hormoneState: isIndonesian ? 'Puncak Estrogen, Lonjakan LH & Testosteron Tertinggi' : 'Peak Estrogen, LH Surge & Testosterone Peak',
        workout: isIndonesian ? 'Kekuatan maksimal, daya tahan kardiovaskular puncak, powerlifting' : 'Max strength testing, peak athletic output',
        nutrition: isIndonesian ? 'Antioksidan tinggi (berry), serat tinggi untuk eliminasi metabolit estrogen' : 'High antioxidant berries, fiber for estrogen clearance',
        theme: 'bg-purple-50 border-purple-200 text-purple-950',
      };
    } else {
      return {
        name: isIndonesian ? 'Fase Luteal (Hari 17-28)' : 'Luteal Phase (Day 17-28)',
        hormoneState: isIndonesian ? 'Dominasi Progesteron & Peningkatan Laju Metabolisme Basal (+100-250 kkal)' : 'Progesterone Dominance & Elevated BMR',
        workout: isIndonesian ? 'Beban moderat, pilates, tempo terkontrol, hindari overtraining' : 'Moderate weights, steady-state cardio, pilates',
        nutrition: isIndonesian ? 'B6, magnesium (dark chocolate), karbohidrat lambat serap, elektrolit' : 'Vitamin B6, magnesium, slow-burning starches',
        theme: 'bg-amber-50 border-amber-200 text-amber-950',
      };
    }
  };

  const currentPhase = getPhaseInfo(currentCycleDay);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-purple-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-purple-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m20_hormonal_health')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-purple-600 hover:bg-purple-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log Hormonal' : 'Log Cycle Data'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #20:</span>
            <span className="px-3 py-1 rounded-full bg-purple-100 text-purple-900 font-extrabold border border-purple-300">
              {isIndonesian ? 'Kesehatan Reproduksi & Hormonal' : 'Reproductive & Hormonal Health'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-purple-700 via-pink-800 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-purple-100 text-xs font-black">
              <Heart className="w-3.5 h-3.5 text-purple-300" />
              <span>{isIndonesian ? 'Sinkronisasi Siklus & Keseimbangan Endokrin' : 'Cycle Syncing & Endocrine Balance'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Kesehatan Reproduksi & Hormonal' : 'Reproductive & Hormonal Health'}
            </h1>
            <p className="text-xs sm:text-sm text-purple-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Sinkronkan intensitas latihan olahraga, target nutrisi, dan manajemen beban stres sesuai fluktuasi hormon alami tubuh.'
                : 'Align workout intensity, macronutrient distribution, and stress thresholds to biological hormonal rhythms.'}
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-5 text-center min-w-[200px] shrink-0">
            <span className="text-[11px] text-purple-200 uppercase font-black tracking-wider block">
              {isIndonesian ? 'Hari Siklus Hormon' : 'Cycle Day'}
            </span>
            <div className="text-3xl font-black text-white mt-1 font-mono">
              Hari ke-{currentCycleDay} <span className="text-xs font-bold text-purple-200">/ 28</span>
            </div>
            <span className="text-[10px] text-purple-200 mt-1 block font-bold">
              {isIndonesian ? 'Fase Puncak Energi' : 'Peak Energy Phase'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Interactive Grid: Cycle Phase Syncer + Guidance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Cycle Day Slider & Phase Status */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-slate-700">
              <span>{isIndonesian ? 'Pilih Hari Siklus (1 - 28):' : 'Select Cycle Day (1 - 28):'}</span>
              <span className="text-purple-700 font-black">Hari ke-{currentCycleDay}</span>
            </div>
            <input
              type="range"
              min="1"
              max="28"
              value={currentCycleDay}
              onChange={(e) => setCurrentCycleDay(Number(e.target.value))}
              className="w-full accent-purple-600 cursor-pointer"
            />
          </div>

          {/* Active Phase Banner */}
          <div className={`p-5 rounded-3xl border ${currentPhase.theme} space-y-2 shadow-xs`}>
            <span className="text-xs font-black uppercase tracking-wider block">
              {currentPhase.name}
            </span>
            <div className="text-sm font-bold">{currentPhase.hormoneState}</div>
          </div>

          {/* BBT Temperature Log */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-slate-700">
              <span className="flex items-center gap-1.5">
                <Thermometer className="w-4 h-4 text-purple-600" />
                <span>{isIndonesian ? 'Suhu Tubuh Basal (BBT Pagi):' : 'Basal Body Temperature (BBT):'}</span>
              </span>
              <span className="text-purple-700 font-black font-mono">{bbtTemperature} °C</span>
            </div>
            <input
              type="range"
              min="36.0"
              max="37.5"
              step="0.1"
              value={bbtTemperature}
              onChange={(e) => setBbtTemperature(Number(e.target.value))}
              className="w-full accent-purple-600 cursor-pointer"
            />
          </div>
        </div>

        {/* Right: Cycle-Synced Workout & Nutrition Recommendations */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-4 shadow-sm">
          <h3 className="text-base font-black text-slate-900 pb-3 border-b border-slate-100">
            {isIndonesian ? 'Rekomendasi Sinkronisasi Siklus' : 'Cycle Syncing Protocols'}
          </h3>

          <div className="space-y-3">
            <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200 space-y-1">
              <span className="text-xs font-black text-teal-950 flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-teal-600" />
                <span>{isIndonesian ? 'Panduan Latihan Olahraga' : 'Workout Guidance'}</span>
              </span>
              <p className="text-xs text-teal-900 leading-relaxed font-medium">
                {currentPhase.workout}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-purple-50 border border-purple-200 space-y-1">
              <span className="text-xs font-black text-purple-950 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-600" />
                <span>{isIndonesian ? 'Panduan Makronutrisi & Elektrolit' : 'Nutrition Guidance'}</span>
              </span>
              <p className="text-xs text-purple-900 leading-relaxed font-medium">
                {currentPhase.nutrition}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
