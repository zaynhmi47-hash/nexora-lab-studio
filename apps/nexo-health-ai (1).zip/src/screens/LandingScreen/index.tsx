import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Activity,
  Utensils,
  Dumbbell,
  Flame,
  Star,
  Zap,
  TrendingUp,
  Layers,
  Heart,
  Droplets,
  Stethoscope,
  Camera,
  HeartPulse,
  Award,
  ChevronRight,
  Compass,
  Moon,
  Video,
  Play,
  Volume2,
  Search,
  Calendar,
  Clock,
  UserCheck,
  Plus,
  CheckCircle2,
  SlidersHorizontal,
} from 'lucide-react';
import { UserProfile, HealthModuleId, DailyLog } from '../../types';
import { TabType } from '../../components/layout/NavBar';
import { BiometricVitalsDeck } from '../../components/modules/BiometricVitalsDeck';
import { EquilibriumVitalityRadar } from '../../components/modules/EquilibriumVitalityRadar';
import { AiHealthCompanionModal } from '../../components/modules/AiHealthCompanionModal';
import { SleepAnalysisStudio } from '../../components/modules/SleepAnalysisStudio';
import { DoctorSpecialistDeck } from '../../components/modules/DoctorSpecialistDeck';
import { LiveWorkoutPoseGuard } from '../../components/modules/LiveWorkoutPoseGuard';

interface LandingViewProps {
  userProfile: UserProfile;
  dailyLog?: DailyLog;
  onNavigateTab: (tab: TabType) => void;
  onSelectModule?: (moduleId: HealthModuleId) => void;
  onAddWater?: (amountMl: number) => void;
  onStartOnboarding?: () => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  userProfile,
  dailyLog = {
    date: new Date().toISOString().split('T')[0],
    waterIntakeMl: 1500,
    caloriesConsumed: 1290,
    carbsG: 145,
    proteinG: 92,
    fatG: 48,
    stepsCount: 6420,
    sleepHours: 7.75,
    weightKg: userProfile.weightKg,
  },
  onNavigateTab,
  onSelectModule,
  onAddWater,
  onStartOnboarding,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // Modal States
  const [isAiCompanionOpen, setIsAiCompanionOpen] = useState(false);
  const [isSleepStudioOpen, setIsSleepStudioOpen] = useState(false);
  const [isLiveWorkoutOpen, setIsLiveWorkoutOpen] = useState(false);

  // Search filter for Doctors / Symptoms (Screenshots 1 & 12)
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialtyFilter, setSelectedSpecialtyFilter] = useState('all');

  const specialtyFilters = [
    { id: 'all', label: isIndonesian ? 'Semua' : 'All' },
    { id: 'cardiology', label: isIndonesian ? 'Kardiologi' : 'Cardiologist' },
    { id: 'psychology', label: isIndonesian ? 'Psikologi' : 'Psychologist' },
    { id: 'physio', label: isIndonesian ? 'Fisioterapi' : 'Physiotherapy' },
    { id: 'nutrition', label: isIndonesian ? 'Gizi & Nutrisi' : 'Nutritionist' },
  ];

  // Quick Daily Shortcuts
  const quickShortcuts = [
    {
      id: 'body_ai',
      label: isIndonesian ? 'Body AI Exercise' : 'Body AI Exercise',
      desc: isIndonesian ? 'MediaPipe pose & analisis repetisi on-device' : 'MediaPipe pose & rep analysis on-device',
      icon: Activity,
      bg: 'bg-emerald-600',
      tag: 'MediaPipe',
    },
    {
      id: 'coach',
      label: isIndonesian ? 'AI Health Coach' : 'AI Health Coach',
      desc: isIndonesian ? 'Tanya bimbingan kebugaran, nutrisi & tidur' : 'Chat workouts, nutrition & sleep hygiene',
      icon: Sparkles,
      bg: 'bg-teal-600',
      tag: 'Gemini 3',
    },
    {
      id: 'doctor_consultation',
      label: isIndonesian ? 'Dokter AI Klinis' : 'AI Doctor Triage',
      desc: isIndonesian ? 'Konsultasi gejala & triase red-flag' : 'Symptom triage & anamnesis',
      icon: Stethoscope,
      bg: 'bg-teal-600',
      tag: isIndonesian ? 'Medis' : 'Medical',
    },
    {
      id: 'workout',
      label: isIndonesian ? 'AI Adaptive Workout' : 'Adaptive Workout',
      desc: isIndonesian ? 'Periodisasi dinamis & target otot' : 'Dynamic periodization & reps',
      icon: Dumbbell,
      bg: 'bg-indigo-600',
      tag: isIndonesian ? 'Fisik' : 'Physical',
    },
    {
      id: 'nutrition',
      label: isIndonesian ? 'NutriGenius & Vision' : 'AI Food Scanner',
      desc: isIndonesian ? 'Pindai piring makan & makronutrisi' : 'Snap meal photos & calories',
      icon: Utensils,
      bg: 'bg-emerald-700',
      tag: isIndonesian ? 'Gizi' : 'Nutrition',
    },
  ];

  // Calorie calculations (Screenshots 5, 8, 11, 16)
  const calorieTarget = userProfile.dailyCalorieTarget || 2150;
  const caloriesLeft = Math.max(0, calorieTarget - dailyLog.caloriesConsumed);
  const caloriePercent = Math.min(100, Math.round((dailyLog.caloriesConsumed / calorieTarget) * 100));

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-8 text-slate-800 selection:bg-emerald-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* 0. HEALTH AI PERSONALIZATION & ONBOARDING PROMPT BANNER */}
      {onStartOnboarding && (
        <section className="bg-gradient-to-r from-emerald-900 via-slate-900 to-teal-950 text-white rounded-3xl p-5 sm:p-6 shadow-md relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 flex items-center justify-center shrink-0 shadow-xs">
                <Sparkles className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/30 text-emerald-300 text-3xs font-extrabold uppercase tracking-wider border border-emerald-500/40">
                    {userProfile.hasCompletedOnboarding ? 'Profil Terpersonalisasi' : 'Langkah 2: Onboarding'}
                  </span>
                  <span className="text-3xs text-slate-300 font-medium">
                    {userProfile.name} • {userProfile.age} Thn • {userProfile.primaryGoal ? userProfile.primaryGoal.replace('_', ' ') : 'Kebugaran'}
                  </span>
                </div>
                <h2 className="text-base sm:text-lg font-black text-white">
                  {userProfile.hasCompletedOnboarding
                    ? (isIndonesian ? 'Personalisasi AI Health Coach & Profile Siap' : 'AI Health Coach Personalization Ready')
                    : (isIndonesian ? 'Lengkapi Profil Onboarding Personal Anda (14 Langkah)' : 'Complete Your 14-Step AI Health Onboarding')}
                </h2>
                <p className="text-xs text-slate-300 max-w-2xl">
                  {isIndonesian
                    ? 'Sistem cerdas menyaring data biometrik, target, gaya hidup, pola tidur, dan preferensi gaya coach untuk pengalaman terbaik.'
                    : 'Smart onboarding customizes your AI workout periodization, calorie targets, macro ratios, and communication tone.'}
                </p>
              </div>
            </div>

            <button
              onClick={onStartOnboarding}
              className="px-5 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/25 transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer"
            >
              <span>{userProfile.hasCompletedOnboarding ? 'Sesuaikan Profil AI' : 'Mulai Onboarding Sekarang'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </section>
      )}

      {/* 1. TOP HEALTHCARE SEARCH & DOCTOR CATEGORY BAR (Screenshots 1 & 12) */}
      <section className="bg-white border border-slate-200/90 rounded-3xl p-4 sm:p-5 shadow-xs space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black shadow-md shadow-emerald-600/20">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-slate-900">
                {isIndonesian ? 'Temukan Dokter & Konsultasi AI' : 'Find Your Doctor & AI Clinic'}
              </h2>
              <p className="text-xs text-slate-500">
                {isIndonesian ? 'Lebih dari 40 dokter spesialis siap melayani secara instan' : '40+ certified specialists and AI diagnostic bots'}
              </p>
            </div>
          </div>

          {/* Search Input Bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isIndonesian ? 'Cari dokter spesialis, gejala, atau obat...' : 'Search doctor, symptoms, or clinic...'}
              className="w-full bg-slate-50 border border-slate-200 rounded-full pl-9 pr-4 py-2 text-xs font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Specialty Filter Chips */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
          {specialtyFilters.map((flt) => (
            <button
              key={flt.id}
              onClick={() => setSelectedSpecialtyFilter(flt.id)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                selectedSpecialtyFilter === flt.id
                  ? 'bg-slate-900 text-white shadow-xs font-black'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200'
              }`}
            >
              {flt.label}
            </button>
          ))}
        </div>
      </section>

      {/* 2. WELCOME & DAILY READINESS STATUS CARD */}
      <section className="bg-gradient-to-br from-emerald-800 via-teal-850 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-400/15 blur-3xl rounded-full pointer-events-none" />
        <div className="absolute bottom-0 left-1/4 w-64 h-64 bg-teal-300/10 blur-2xl rounded-full pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-8 space-y-3.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-white/15 backdrop-blur-md border border-white/20 text-emerald-200 font-extrabold text-[11px] uppercase tracking-wide">
                ✨ {isIndonesian ? 'Ringkasan Harian Anda' : 'Your Daily Briefing'}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 text-[10px] font-bold">
                {isIndonesian ? 'Kesiapan: 92% Optimal' : 'Readiness: 92% Optimal'}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white leading-tight">
              {isIndonesian
                ? `Selamat Siap, ${userProfile.name}! Tubuh Anda Dalam Kondisi Prima.`
                : `Welcome Back, ${userProfile.name}! You are in Peak Readiness.`}
            </h1>

            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed max-w-2xl font-medium">
              {isIndonesian
                ? 'Sistem AI telah mensinkronisasi data tidur dan pemulihan otot Anda. Variabilitas denyut jantung (HRV) stabil di 62 ms dengan kualitas tidur 85 poin.'
                : 'Your AI system synced sleep and muscle recovery metrics. Heart rate variability (HRV) is steady at 62 ms with 85 sleep score.'}
            </p>

            {/* Daily Biometrics Summary Pills */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/15">
                <div className="flex items-center gap-1.5 text-[10px] text-emerald-300 font-bold">
                  <Flame className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>Streak Harian</span>
                </div>
                <div className="text-base sm:text-lg font-black text-white mt-0.5">
                  {userProfile.streakCount} Hari
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/15">
                <div className="flex items-center gap-1.5 text-[10px] text-teal-300 font-bold">
                  <Droplets className="w-3.5 h-3.5 text-cyan-300" />
                  <span>Target Air</span>
                </div>
                <div className="text-base sm:text-lg font-black text-white mt-0.5">
                  {dailyLog.waterIntakeMl} / {userProfile.dailyWaterTargetMl} ml
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/15">
                <div className="flex items-center gap-1.5 text-[10px] text-amber-300 font-bold">
                  <Award className="w-3.5 h-3.5 text-amber-300" />
                  <span>Play Points XP</span>
                </div>
                <div className="text-base sm:text-lg font-black text-white mt-0.5">
                  {userProfile.xp} XP
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/15">
                <div className="flex items-center gap-1.5 text-[10px] text-emerald-200 font-bold">
                  <Activity className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Kesiapan HRV</span>
                </div>
                <div className="text-base sm:text-lg font-black text-white mt-0.5">
                  68 ms (Bagus)
                </div>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="lg:col-span-4 flex flex-col gap-3">
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => setIsAiCompanionOpen(true)}
              className="w-full py-4 px-5 rounded-2xl bg-white text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl hover:bg-slate-50 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-emerald-700" />
              <span>{isIndonesian ? 'Tanya Clara AI Health Guide' : 'Ask Clara AI Guide'}</span>
              <ArrowRight className="w-4 h-4 text-slate-900" />
            </motion.button>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setIsSleepStudioOpen(true)}
                className="py-2.5 px-3 rounded-2xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-white/20"
              >
                <Moon className="w-3.5 h-3.5 text-indigo-300" />
                <span>{isIndonesian ? 'Studio Tidur' : 'Sleep Studio'}</span>
              </button>

              <button
                onClick={() => setIsLiveWorkoutOpen(true)}
                className="py-2.5 px-3 rounded-2xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-white/20"
              >
                <Play className="w-3.5 h-3.5 text-teal-300" />
                <span>{isIndonesian ? 'Pose Guard AI' : 'Live Workout'}</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 3. UPCOMING SCHEDULE & TELEMEDICINE CARD (Screenshots 1 & 12) */}
      <section className="bg-slate-900 text-white rounded-3xl p-5 sm:p-6 border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-between gap-5">
        <div className="flex items-center gap-4 w-full md:w-auto">
          <img
            src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80"
            alt="Dr. Ethan Brooks"
            referrerPolicy="no-referrer"
            className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-400 shadow-md"
          />
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                {isIndonesian ? 'Jadwal Hari Ini' : 'Upcoming Schedule'}
              </span>
              <span className="text-xs text-slate-400 font-mono">10:30 AM</span>
            </div>
            <h3 className="text-sm sm:text-base font-black text-white">
              Dr. Ethan Brooks, Sp.JP
            </h3>
            <p className="text-xs text-slate-300">
              {isIndonesian ? 'Konsultasi Evaluasi Ritme Jantung & EKG' : 'Cardiovascular & ECG Evaluation Consult'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto justify-end">
          <button
            onClick={() => onNavigateTab('doctor_consultation')}
            className="flex-1 md:flex-none py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
          >
            <Video className="w-4 h-4" />
            <span>{isIndonesian ? 'Masuk Ruang Telemedisin' : 'Join Video Call'}</span>
          </button>
        </div>
      </section>

      {/* 4. EQUILIBRIUM VITALITY RADAR (6-Pillar Interactive Orbit Dial) */}
      <section>
        <EquilibriumVitalityRadar
          userProfile={userProfile}
          dailyLog={dailyLog}
          isIndonesian={isIndonesian}
          onNavigateTab={onNavigateTab}
        />
      </section>

      {/* 5. BIOMETRIC VITALS DECK (Date Strip + 3D Heart Card + 4-in-1 Vitals + Activity Steps) */}
      <section>
        <BiometricVitalsDeck
          userProfile={userProfile}
          dailyLog={dailyLog}
          onNavigateTab={onNavigateTab}
          onOpenSleepStudio={() => setIsSleepStudioOpen(true)}
          onOpenAiGuide={() => setIsAiCompanionOpen(true)}
          onAddWater={onAddWater}
        />
      </section>

      {/* 5. NUTRITION & CALORIE RING BENTO CARD (Screenshots 5, 8, 11, 16) */}
      <section className="bg-white border border-slate-200/90 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-50 text-amber-700">
              <Utensils className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-slate-900">
                {isIndonesian ? 'Jurnal Nutrisi & Target Kalori Harian' : 'Nutrition & Daily Calorie Budget'}
              </h2>
              <p className="text-xs text-slate-500">
                {isIndonesian ? 'Dilacak dengan AI Vision & Gemini Dietitian' : 'Tracked with AI Vision & Dietitian'}
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('nutrition')}
            className="flex items-center gap-1.5 text-xs font-black text-emerald-700 hover:text-emerald-800 transition-colors cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Pindai Makanan' : 'Scan Meal'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          {/* Calorie Gauge Ring */}
          <div className="md:col-span-4 flex flex-col items-center justify-center p-4 bg-slate-50 rounded-2xl border border-slate-200/80 text-center">
            <div className="relative w-32 h-32 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-slate-200"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className="text-amber-500"
                  strokeDasharray={`${caloriePercent}, 100`}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-xl font-black text-slate-900">{dailyLog.caloriesConsumed}</span>
                <span className="text-[10px] text-slate-400 font-bold uppercase">/ {calorieTarget} kcal</span>
              </div>
            </div>
            <span className="text-xs font-black text-amber-700 mt-2">
              {caloriesLeft} kcal {isIndonesian ? 'Tersisa Hari Ini' : 'Remaining'}
            </span>
          </div>

          {/* Macro Progress Bars */}
          <div className="md:col-span-8 space-y-3">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-black">
                <span className="text-slate-700">{isIndonesian ? 'Karbohidrat' : 'Carbohydrates'}</span>
                <span className="text-teal-700">{dailyLog.carbsG}g / {userProfile.dailyCarbsTargetG || 220}g</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div style={{ width: `${Math.min(100, (dailyLog.carbsG / (userProfile.dailyCarbsTargetG || 220)) * 100)}%` }} className="bg-teal-500 h-full rounded-full" />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-black">
                <span className="text-slate-700">{isIndonesian ? 'Protein Otot' : 'Muscle Protein'}</span>
                <span className="text-emerald-700">{dailyLog.proteinG}g / {userProfile.dailyProteinTargetG || 140}g</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div style={{ width: `${Math.min(100, (dailyLog.proteinG / (userProfile.dailyProteinTargetG || 140)) * 100)}%` }} className="bg-emerald-600 h-full rounded-full" />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-black">
                <span className="text-slate-700">{isIndonesian ? 'Lemak Sehat' : 'Healthy Fat'}</span>
                <span className="text-amber-700">{dailyLog.fatG}g / {userProfile.dailyFatTargetG || 65}g</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div style={{ width: `${Math.min(100, (dailyLog.fatG / (userProfile.dailyFatTargetG || 65)) * 100)}%` }} className="bg-amber-500 h-full rounded-full" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. CLARA AI COMPANION INTERACTIVE BANNER */}
      <section className="bg-gradient-to-r from-teal-900 via-emerald-950 to-slate-900 text-white rounded-[32px] p-6 sm:p-7 border border-emerald-800/60 shadow-xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="absolute top-0 right-1/3 w-64 h-64 bg-emerald-400/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center gap-4 sm:gap-5 z-10">
          {/* Glowing 3D Orb Mini */}
          <div
            onClick={() => setIsAiCompanionOpen(true)}
            className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-teal-400 via-emerald-300 to-amber-200 shadow-xl shadow-emerald-400/30 flex items-center justify-center border-2 border-white/80 shrink-0 cursor-pointer animate-pulse"
          >
            <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-gradient-to-br from-emerald-500 via-teal-400 to-cyan-300 flex items-center justify-center text-white">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 text-[10px] font-black border border-emerald-400/30">
                Clara AI Health Companion
              </span>
              <span className="text-[11px] text-slate-300 font-bold">Online 24/7</span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-white">
              {isIndonesian ? 'Ada keluhan fisik atau ingin cek gejala hari ini?' : 'Need a symptom check or dietary review?'}
            </h3>
            <p className="text-xs text-slate-300 max-w-lg">
              {isIndonesian
                ? 'Triase medis instan berbasis Gemini 3.6 dengan skala nyeri visual, rekomendasi obat OTC, dan panduan gaya hidup.'
                : 'Instant Gemini-powered clinical intake with visual pain scaling, OTC remedies, and lifestyle triage.'}
            </p>
          </div>
        </div>

        <motion.button
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => setIsAiCompanionOpen(true)}
          className="py-3 px-5 rounded-2xl bg-white text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg hover:bg-slate-50 transition-all cursor-pointer shrink-0 z-10"
        >
          <span>{isIndonesian ? 'Buka Dialog Clara' : 'Launch Clara'}</span>
          <ChevronRight className="w-4 h-4 text-emerald-800" />
        </motion.button>
      </section>

      {/* 7. DOCTOR & CLINICAL SPECIALISTS DECK */}
      <section>
        <DoctorSpecialistDeck
          userProfile={userProfile}
          onNavigateToFullDoctor={() => onNavigateTab('doctor_consultation')}
          onSelectDoctorToConsult={(docName, specialty) => {
            onNavigateTab('doctor_consultation');
          }}
        />
      </section>

      {/* 8. QUICK ACTION SHORTCUTS (4 Core Access Pillars) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm sm:text-base font-black text-slate-900 tracking-tight">
              {isIndonesian ? 'Akses Cepat Fitur Utama' : 'Quick Access Pillars'}
            </h3>
          </div>
          <span className="text-xs font-bold text-slate-500">
            {isIndonesian ? '4 Fitur Unggulan' : '4 Core Features'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
          {quickShortcuts.map((item) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.id}
                whileHover={{ y: -3 }}
                onClick={() => onNavigateTab(item.id as TabType)}
                className="bg-white border border-slate-200/90 hover:border-emerald-300 rounded-3xl p-4.5 shadow-2xs hover:shadow-lg transition-all duration-300 cursor-pointer flex flex-col justify-between space-y-3 group"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className={`p-3 rounded-2xl ${item.bg} text-white shadow-xs group-hover:scale-105 transition-transform`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                      {item.tag}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-sm font-black text-slate-900 group-hover:text-emerald-700 transition-colors">
                      {item.label}
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-emerald-700">
                  <span>{isIndonesian ? 'Mulai Sekarang' : 'Launch'}</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* 9. PROMOTIONAL SHOWCASE BANNER FOR 20 MODUL (Direct Route to ModuleHub) */}
      <section className="bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 text-white rounded-[32px] p-6 sm:p-8 border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute -top-12 -right-12 w-64 h-64 bg-emerald-500/20 blur-3xl rounded-full pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black uppercase tracking-wider border border-emerald-500/30">
                🚀 {isIndonesian ? 'Koleksi Lengkap' : 'Complete Suite'}
              </span>
              <span className="text-xs text-slate-400 font-medium">
                {isIndonesian ? 'Tampilan Baru: Kartu Geser 4-in-1' : 'New: Swipeable 4-in-1 Card Decks'}
              </span>
            </div>

            <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {isIndonesian ? 'Eksplorasi Seluruh 20 Modul Kesehatan' : 'Explore All 20 Health AI Modules'}
            </h3>

            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {isIndonesian
                ? 'Koleksi lengkap 20 modul kini tersusun rapi di Pusat Modul dengan komponen kartu geser 4-in-1 yang interaktif, visual bento sinergi, dan konsol uji coba real-time.'
                : 'All 20 modules are now organized in the Modules Hub featuring 4-in-1 swipe decks, cross-module bento synergies, and live testing sandboxes.'}
            </p>
          </div>

          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => onNavigateTab('modules_hub')}
            className="py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-lg shadow-emerald-950/40"
          >
            <span>{isIndonesian ? 'Jelajahi 20 Modul' : 'Explore 20 Modules'}</span>
            <ChevronRight className="w-4 h-4" />
          </motion.button>
        </div>
      </section>

      {/* MODALS */}
      <AiHealthCompanionModal
        isOpen={isAiCompanionOpen}
        onClose={() => setIsAiCompanionOpen(false)}
        userProfile={userProfile}
        onLaunchDoctorConsult={() => {
          setIsAiCompanionOpen(false);
          onNavigateTab('doctor_consultation');
        }}
      />

      <SleepAnalysisStudio
        isOpen={isSleepStudioOpen}
        onClose={() => setIsSleepStudioOpen(false)}
        userProfile={userProfile}
      />

      <LiveWorkoutPoseGuard
        isOpen={isLiveWorkoutOpen}
        onClose={() => setIsLiveWorkoutOpen(false)}
        userProfile={userProfile}
      />
    </div>
  );
};
