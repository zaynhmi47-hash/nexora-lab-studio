import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  FileText,
  ShieldCheck,
  Lock,
  Download,
  Upload,
  Sparkles,
  ArrowLeft,
  Activity,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Plus,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface EhrScreenProps {
  userProfile: UserProfile;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const EhrScreen: React.FC<EhrScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [activeTabSub, setActiveTabSub] = useState<'biomarkers' | 'vaccines' | 'records'>('biomarkers');

  const biomarkerData = [
    { name: 'HbA1c (Glukosa 3 Bulan)', value: '5.2%', range: '< 5.7%', status: 'optimal', trend: 'down', date: '12 Jan 2026' },
    { name: 'Kolesterol LDL (Jahat)', value: '98 mg/dL', range: '< 100 mg/dL', status: 'optimal', trend: 'down', date: '12 Jan 2026' },
    { name: 'Kolesterol HDL (Baik)', value: '62 mg/dL', range: '> 50 mg/dL', status: 'optimal', trend: 'up', date: '12 Jan 2026' },
    { name: 'Trigliserida', value: '110 mg/dL', range: '< 150 mg/dL', status: 'optimal', trend: 'down', date: '12 Jan 2026' },
    { name: 'Tekanan Darah (Systolic/Diastolic)', value: '118/76 mmHg', range: '< 120/80', status: 'optimal', trend: 'stable', date: 'Hari Ini' },
    { name: 'Vitamin D 25-OH', value: '48 ng/mL', range: '30 - 80 ng/mL', status: 'optimal', trend: 'up', date: '12 Jan 2026' },
  ];

  const vaccineRecords = [
    { name: 'Hepatitis B Booster', date: '15 Mar 2024', location: 'RS Pondok Indah', batch: 'HB-99214', status: 'Valid' },
    { name: 'Influenza Quadrivalent', date: '10 Nov 2025', location: 'Klinik Sehat', batch: 'FL-2025B', status: 'Active (1 Yr)' },
    { name: 'Tetanus Toxoid (Tdap)', date: '04 Jun 2021', location: 'RS Siloam', batch: 'TD-44310', status: 'Valid s/d 2031' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-emerald-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m17_ehr')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log RME' : 'Log EHR Record'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #17:</span>
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-extrabold border border-emerald-300">
              {isIndonesian ? 'Rekam Medis Elektronik (RME) Terpusat' : 'Electronic Health Record (EHR)'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-emerald-700 via-teal-800 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-emerald-100 text-xs font-black">
              <Lock className="w-3.5 h-3.5 text-emerald-300" />
              <span>{isIndonesian ? 'Enkripsi AES-256 GCM & Standar HL7 / FHIR' : 'AES-256 Encrypted EHR Vault'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Rekam Medis Elektronik (RME)' : 'Centralized Electronic Health Record'}
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Penyimpanan aman hasil tes darah laboratorium, riwayat vaksinasi, dan tren biomarker jangka panjang terpadu satu pintu.'
                : 'Secure repository for clinical blood panels, vaccination timelines, and longitudinal biomarker analytics.'}
            </p>
          </div>

          <div className="flex gap-2 shrink-0">
            <button
              onClick={() => alert(isIndonesian ? 'Dokumen PDF resume medis klinis berhasil diunduh!' : 'Clinical PDF exported!')}
              className="px-4 py-2.5 rounded-2xl bg-white/15 hover:bg-white/25 border border-white/20 text-white text-xs font-bold transition-all flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isIndonesian ? 'Ekspor Ringkasan Dokter' : 'Export Doctor PDF'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Subtab Switcher */}
      <div className="flex gap-2 bg-slate-200/80 p-1.5 rounded-2xl w-fit">
        <button
          onClick={() => setActiveTabSub('biomarkers')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTabSub === 'biomarkers' ? 'bg-white text-emerald-950 font-black shadow-xs' : 'text-slate-600'
          }`}
        >
          {isIndonesian ? 'Biomarker Darah & Lab' : 'Biomarkers & Lab'}
        </button>
        <button
          onClick={() => setActiveTabSub('vaccines')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTabSub === 'vaccines' ? 'bg-white text-emerald-950 font-black shadow-xs' : 'text-slate-600'
          }`}
        >
          {isIndonesian ? 'Riwayat Vaksin' : 'Vaccines'}
        </button>
      </div>

      {/* Biomarkers Grid */}
      {activeTabSub === 'biomarkers' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {biomarkerData.map((b, idx) => (
            <div
              key={idx}
              className="bg-white border border-slate-200/90 rounded-3xl p-5 space-y-3 shadow-sm hover:border-emerald-300 transition-all"
            >
              <div className="flex items-start justify-between gap-2">
                <span className="text-xs font-black text-slate-900 leading-tight">{b.name}</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase">
                  {b.status}
                </span>
              </div>

              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-slate-900 font-mono">{b.value}</span>
                <span className="text-xs text-slate-400 font-medium">Ref: {b.range}</span>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Diperbarui: {b.date}</span>
                <span className="text-emerald-700 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Normal</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Vaccine Records List */}
      {activeTabSub === 'vaccines' && (
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 space-y-4 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-base font-black text-slate-900">
              {isIndonesian ? 'Sertifikat & Paspor Vaksinasi' : 'Vaccination History & Records'}
            </h3>
            <button
              onClick={() => alert(isIndonesian ? 'Silakan unggah sertifikat vaksin...' : 'Upload vaccine certificate...')}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tambah Vaksin</span>
            </button>
          </div>

          <div className="space-y-3">
            {vaccineRecords.map((vac, i) => (
              <div
                key={i}
                className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <span className="text-xs font-black text-slate-900">{vac.name}</span>
                  <div className="text-[11px] text-slate-500 mt-0.5 space-x-2">
                    <span>{vac.date}</span>
                    <span>•</span>
                    <span>{vac.location}</span>
                    <span>•</span>
                    <span className="font-mono">Batch: {vac.batch}</span>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-black w-fit">
                  {vac.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
