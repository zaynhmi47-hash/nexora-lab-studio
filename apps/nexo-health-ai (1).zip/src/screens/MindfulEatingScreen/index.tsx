import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Sparkle,
  Utensils,
  Clock,
  Play,
  Pause,
  RotateCcw,
  Heart,
  ArrowLeft,
  CheckCircle2,
  Smile,
  AlertCircle,
  Volume2,
  Sparkles,
  Zap,
  Plus,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface MindfulEatingScreenProps {
  userProfile: UserProfile;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const MindfulEatingScreen: React.FC<MindfulEatingScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // 20-Chew Pacing Timer State
  const [isPacingActive, setIsPacingActive] = useState(false);
  const [chewCount, setChewCount] = useState(0);
  const [bitesCompleted, setBitesCompleted] = useState(0);
  const [secondsRemainingInBite, setSecondsRemainingInBite] = useState(20);

  // Satiety Audit State
  const [hungerLevelBefore, setHungerLevelBefore] = useState(7); // 1-10
  const [fullnessLevelAfter, setFullnessLevelAfter] = useState(5); // 1-10
  const [eatingType, setEatingType] = useState<'physical' | 'emotional' | 'boredom'>('physical');
  const [sensoryNotes, setSensoryNotes] = useState('');

  // Chew pacing countdown effect
  useEffect(() => {
    let timer: any;
    if (isPacingActive && secondsRemainingInBite > 0) {
      timer = setInterval(() => {
        setSecondsRemainingInBite((prev) => prev - 1);
        setChewCount((prev) => prev + 1);
      }, 1000);
    } else if (isPacingActive && secondsRemainingInBite === 0) {
      setBitesCompleted((prev) => prev + 1);
      setSecondsRemainingInBite(20);
      setChewCount(0);
      if (onAwardXp) onAwardXp(10);
    }
    return () => clearInterval(timer);
  }, [isPacingActive, secondsRemainingInBite]);

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-emerald-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-emerald-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m10_mindful_eating')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log Mindful' : 'Log Mindful Data'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #10:</span>
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-extrabold border border-emerald-300">
              {isIndonesian ? 'Detoks Digital & Mindful Eating' : 'Mindful Eating & Satiety Journal'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-emerald-600 via-teal-700 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-emerald-100 text-xs font-black">
              <Sparkle className="w-3.5 h-3.5 text-emerald-300" />
              <span>{isIndonesian ? 'Sensitivitas Leptin & Pacing Mengunyah' : 'Leptin Satiety & 20-Chew Pacer'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Detoks Digital & Mindful Eating' : 'Mindful Eating & Satiety Journal'}
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Latih kesadaran makan penuh, kendalikan hormon rasa kenyang (leptin), dan gunakan timer 20-kunyahan per suapan untuk meredakan overeating.'
                : 'Cultivate sensory satiety awareness, optimize leptin signaling, and eliminate mindless digital eating with a 20-chew pacer.'}
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-5 text-center min-w-[200px] shrink-0">
            <span className="text-[11px] text-emerald-200 uppercase font-black tracking-wider block">
              {isIndonesian ? 'Suapan Sadar Selesai' : 'Mindful Bites'}
            </span>
            <div className="text-3xl font-black text-white mt-1 font-mono">
              {bitesCompleted} <span className="text-xs font-bold text-emerald-300">suapan</span>
            </div>
            <span className="text-[10px] text-emerald-200 mt-1 block font-bold">
              {isIndonesian ? '20 detik per suapan' : '20s chew duration'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Interactive Chew Pacer + Hunger Audit */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: 20-Chew Pacing Engine */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-black text-slate-900">
                  {isIndonesian ? 'Timer Irama Mengunyah (20 Detik)' : '20-Chew Rhythm Pacer'}
                </h3>
              </div>
              <span className="text-xs font-mono font-black text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                {secondsRemainingInBite}s
              </span>
            </div>

            {/* Circular Visual Pacing Indicator */}
            <div className="py-8 flex flex-col items-center justify-center space-y-4">
              <div className="relative w-44 h-44 rounded-full bg-emerald-50 border-4 border-emerald-200 flex flex-col items-center justify-center shadow-inner">
                <motion.div
                  animate={{ scale: isPacingActive ? [1, 1.06, 1] : 1 }}
                  transition={{ duration: 1.2, repeat: Infinity }}
                  className="text-center"
                >
                  <span className="text-4xl font-black text-slate-900 font-mono block">
                    {secondsRemainingInBite}
                  </span>
                  <span className="text-[11px] font-black uppercase text-emerald-700 tracking-wider">
                    {isIndonesian ? 'Kunyah Perlahan' : 'Chew Mindfully'}
                  </span>
                </motion.div>
              </div>

              <p className="text-xs text-slate-500 text-center max-w-xs leading-relaxed font-medium">
                {isIndonesian
                  ? 'Letakkan sendok saat mengunyah. Nikmati tekstur, aroma, dan rasa sebelum menelan.'
                  : 'Rest your utensils between bites. Savor flavors and textures thoroughly.'}
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex gap-3">
            <button
              onClick={() => setIsPacingActive(!isPacingActive)}
              className={`flex-1 py-3.5 rounded-2xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer ${
                isPacingActive
                  ? 'bg-amber-600 hover:bg-amber-700 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
              }`}
            >
              {isPacingActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPacingActive ? (isIndonesian ? 'Jeda Pacing' : 'Pause') : (isIndonesian ? 'Mulai Suapan Baru' : 'Start Next Bite')}</span>
            </button>

            <button
              onClick={() => {
                setIsPacingActive(false);
                setSecondsRemainingInBite(20);
                setBitesCompleted(0);
              }}
              className="p-3.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition-all cursor-pointer"
              title="Reset"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right: Hunger Audit & Satiety Journal */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex items-center gap-2 pb-4 border-b border-slate-100">
            <Heart className="w-5 h-5 text-rose-500" />
            <h3 className="text-base font-black text-slate-900">
              {isIndonesian ? 'Audit Lapar Fisik vs Emosional' : 'Hunger & Satiety Audit'}
            </h3>
          </div>

          {/* Type of hunger selection */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-700 block">
              {isIndonesian ? 'Motivasi Utama Makan Saat Ini:' : 'Primary Eating Driver:'}
            </span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'physical', label: isIndonesian ? 'Lapar Fisik (Perut)' : 'Physical' },
                { id: 'emotional', label: isIndonesian ? 'Stres / Emosi' : 'Emotional' },
                { id: 'boredom', label: isIndonesian ? 'Kebiasaan / Bosan' : 'Boredom' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setEatingType(item.id as any)}
                  className={`py-2 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                    eatingType === item.id
                      ? 'bg-emerald-600 text-white font-black shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Hunger scale before & after */}
          <div className="space-y-4 pt-2">
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>{isIndonesian ? 'Tingkat Lapar Sebelum Makan (1-10)' : 'Hunger Before (1-10)'}</span>
                <span className="text-emerald-700 font-black">{hungerLevelBefore}/10</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={hungerLevelBefore}
                onChange={(e) => setHungerLevelBefore(Number(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>{isIndonesian ? 'Tingkat Kenyang Saat Ini (1-10)' : 'Satiety After (1-10)'}</span>
                <span className="text-emerald-700 font-black">{fullnessLevelAfter}/10</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={fullnessLevelAfter}
                onChange={(e) => setFullnessLevelAfter(Number(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>
          </div>

          {/* Sensory Reflection Text */}
          <div className="space-y-2 pt-2">
            <span className="text-xs font-bold text-slate-700 block">
              {isIndonesian ? 'Catatan Apresiasi Rasa & Tekstur:' : 'Sensory Appreciation Notes:'}
            </span>
            <textarea
              rows={2}
              placeholder={isIndonesian ? 'Misal: Rasa gurih rempah kuat, tekstur renyah...' : 'e.g. Rich umami, crunchy texture...'}
              value={sensoryNotes}
              onChange={(e) => setSensoryNotes(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 text-xs text-slate-800 focus:outline-emerald-500"
            />
          </div>

          <button
            onClick={() => {
              if (onAwardXp) onAwardXp(40);
              alert(isIndonesian ? 'Jurnal Mindful Eating berhasil disimpan! +40 XP' : 'Mindful eating logged! +40 XP');
            }}
            className="w-full py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-all cursor-pointer shadow-xs"
          >
            {isIndonesian ? 'Simpan Jurnal Makan Sadar (+40 XP)' : 'Save Mindful Journal'}
          </button>
        </div>
      </div>
    </div>
  );
};
