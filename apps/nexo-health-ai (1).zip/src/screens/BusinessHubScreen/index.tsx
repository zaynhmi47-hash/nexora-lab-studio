import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Building2,
  Users,
  FileText,
  Activity,
  Key,
  Plus,
  Search,
  Download,
  Printer,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ChevronRight,
  TrendingUp,
  Stethoscope,
  Pill,
  Lock,
  ArrowRight,
  RefreshCw,
  QrCode,
  Heart,
  Copy,
  Check,
  X
} from 'lucide-react';
import { UserProfile, ModularHealthDataEntry } from '../../types';
import { getPlanDetails, isFeatureAccessible } from '../../data/subscriptionPlans';

interface PatientRecord {
  id: string;
  name: string;
  age: number;
  gender: 'L' | 'P';
  phone: string;
  lastVisit: string;
  condition: string;
  status: 'optimal' | 'monitoring' | 'critical';
  bp: string;
  glucose: number;
  activePrescriptionsCount: number;
}

const INITIAL_PATIENTS: PatientRecord[] = [
  {
    id: 'PT-1082',
    name: 'Budi Santoso, S.Kom',
    age: 42,
    gender: 'L',
    phone: '+62 812-8821-9921',
    lastVisit: '2026-08-20',
    condition: 'Hipertensi Stage 1 & Sindrom Metabolik',
    status: 'monitoring',
    bp: '138/88 mmHg',
    glucose: 118,
    activePrescriptionsCount: 2,
  },
  {
    id: 'PT-1083',
    name: 'Dr. Siti Nurhaliza',
    age: 36,
    gender: 'P',
    phone: '+62 813-7711-2345',
    lastVisit: '2026-08-21',
    condition: 'Pemulihan Cedera Lutut & Postur Ergonomis',
    status: 'optimal',
    bp: '118/76 mmHg',
    glucose: 92,
    activePrescriptionsCount: 1,
  },
  {
    id: 'PT-1084',
    name: 'Ahmad Fauzi',
    age: 58,
    gender: 'L',
    phone: '+62 856-9923-1100',
    lastVisit: '2026-08-19',
    condition: 'Diabetes Melitus Tipe 2 & Kolesterol Tinggi',
    status: 'critical',
    bp: '145/95 mmHg',
    glucose: 184,
    activePrescriptionsCount: 3,
  },
  {
    id: 'PT-1085',
    name: 'Rina Anggraini',
    age: 28,
    gender: 'P',
    phone: '+62 818-0922-8712',
    lastVisit: '2026-08-21',
    condition: 'Program Diet Kebugaran & Manajemen Stres',
    status: 'optimal',
    bp: '112/72 mmHg',
    glucose: 88,
    activePrescriptionsCount: 1,
  },
];

interface BusinessHubScreenProps {
  userProfile: UserProfile;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
  onOpenUpgradeModal: () => void;
  modularLogs?: ModularHealthDataEntry[];
}

export const BusinessHubScreen: React.FC<BusinessHubScreenProps> = ({
  userProfile,
  onUpdateProfile,
  onOpenUpgradeModal,
  modularLogs = [],
}) => {
  const isIndonesian = userProfile.language === 'id';
  const plan = userProfile.subscriptionPlan || 'free';
  const isBusinessOrEnterprise = plan === 'business' || plan === 'enterprise';

  const [activeTab, setActiveTab] = useState<'patients' | 'prescriptions' | 'analytics' | 'api'>('patients');
  const [patients, setPatients] = useState<PatientRecord[]>(INITIAL_PATIENTS);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<PatientRecord>(INITIAL_PATIENTS[0]);

  // Prescription Generator Form
  const [rxDiagnosis, setRxDiagnosis] = useState('Hipertensi Primer (ICD-10: I10)');
  const [rxMedicines, setRxMedicines] = useState('1. Amlodipine 5mg - 1x1 tab pagi\n2. Captopril 25mg - 2x1 tab prn\n3. Suplemen CoQ10 100mg - 1x1 kaplet');
  const [rxNotes, setRxNotes] = useState('Kurangi asupan natrium/garam di bawah 2000mg/hari. Kontrol ulang dalam 14 hari.');
  const [isCopiedKey, setIsCopiedKey] = useState(false);
  const [showAddPatientModal, setShowAddPatientModal] = useState(false);

  // New Patient Form
  const [newPtName, setNewPtName] = useState('');
  const [newPtAge, setNewPtAge] = useState(30);
  const [newPtGender, setNewPtGender] = useState<'L' | 'P'>('L');
  const [newPtPhone, setNewPtPhone] = useState('+62 8');
  const [newPtCondition, setNewPtCondition] = useState('');

  const handleAddPatient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPtName.trim()) return;

    const newRecord: PatientRecord = {
      id: `PT-${Math.floor(1000 + Math.random() * 9000)}`,
      name: newPtName,
      age: Number(newPtAge),
      gender: newPtGender,
      phone: newPtPhone,
      lastVisit: new Date().toISOString().split('T')[0],
      condition: newPtCondition || 'Pemeriksaan Rutin',
      status: 'monitoring',
      bp: '120/80 mmHg',
      glucose: 100,
      activePrescriptionsCount: 1,
    };

    setPatients([newRecord, ...patients]);
    setNewPtName('');
    setShowAddPatientModal(false);
  };

  const filteredPatients = patients.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.condition.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6" id="business-clinic-hub-screen">
      {/* Top Clinic Header */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden border border-slate-800">
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-wrap items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-teal-500/20 text-teal-300 border border-teal-500/30">
                <Building2 className="w-5 h-5" />
              </span>
              <span className="text-xs font-black uppercase tracking-wider text-teal-300">
                {isIndonesian ? 'Google Health Business & Clinic Platform' : 'Google Health Clinic Platform'}
              </span>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${isBusinessOrEnterprise ? 'bg-emerald-500 text-slate-950' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'}`}>
                {isBusinessOrEnterprise ? (plan === 'enterprise' ? 'ENTERPRISE RS' : 'BISNIS KLINIK PRO') : 'PREVIEW MODE'}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
              <span>{userProfile.clinicName || (isIndonesian ? 'Klinik & Laboratorium Terpadu' : 'Integrated Medical Hub')}</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {isIndonesian
                ? 'Dasbor terpusat untuk dokter, ahli gizi, dan staf klinik mengelola rekam medis pasien, mencetak resep berlogo resmi, serta integrasi SIMRS.'
                : 'Centralized workspace for clinicians and dietitians to monitor patient cohorts, generate electronic prescriptions, and manage SIMRS API.'}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            {!isBusinessOrEnterprise ? (
              <button
                onClick={onOpenUpgradeModal}
                className="px-5 py-3 rounded-2xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-teal-500/20 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isIndonesian ? 'Upgrade ke Paket Bisnis (Rp 249rb)' : 'Upgrade to Business Hub'}</span>
              </button>
            ) : (
              <div className="bg-white/10 border border-white/10 rounded-2xl p-3.5 text-right space-y-0.5">
                <p className="text-[10px] text-slate-300 uppercase font-bold">{isIndonesian ? 'Kapasitas Pasien' : 'Patient Slots'}</p>
                <p className="text-lg font-black text-emerald-300">{patients.length} / 50 Terisi</p>
              </div>
            )}
          </div>
        </div>

        {/* Tab Navigation inside Business Hub */}
        <div className="mt-8 pt-4 border-t border-white/10 flex items-center gap-2 overflow-x-auto no-scrollbar relative z-10">
          {[
            { id: 'patients', label: isIndonesian ? 'Manajemen Pasien & Klien' : 'Patient Management', icon: Users },
            { id: 'prescriptions', label: isIndonesian ? 'Generator Resep & EHR Medis' : 'Prescription & EHR Generator', icon: FileText },
            { id: 'analytics', label: isIndonesian ? 'Analitik Kohort Pasien' : 'Cohort Analytics', icon: Activity },
            { id: 'api', label: isIndonesian ? 'Kunci API & Webhook SIMRS' : 'API & SIMRS Webhooks', icon: Key },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-teal-500 text-slate-950 font-black shadow-md'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* NON-BUSINESS BANNER ALERT */}
      {!isBusinessOrEnterprise && (
        <div className="bg-amber-50 border border-amber-200 rounded-3xl p-5 sm:p-6 flex flex-col md:flex-row items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center gap-3.5">
            <div className="p-3 bg-amber-500/20 text-amber-900 rounded-2xl shrink-0">
              <Lock className="w-6 h-6 text-amber-700" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-amber-900">
                {isIndonesian ? 'Mode Pratinjau Fitur Bisnis & Klinik' : 'Business & Clinic Hub Preview Mode'}
              </h3>
              <p className="text-xs text-amber-800 leading-relaxed mt-0.5">
                {isIndonesian
                  ? 'Anda sedang melihat pratinjau dasbor manajemen klinik. Tingkatkan ke Paket Bisnis untuk membuka penyimpanan tak terbatas, cetak resep resmi berlogo, dan akses API.'
                  : 'Upgrade to Business Hub to unlock full patient slots, white-label PDF prescriptions, and SIMRS API endpoints.'}
              </p>
            </div>
          </div>
          <button
            onClick={onOpenUpgradeModal}
            className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-2 cursor-pointer shrink-0 shadow-sm"
          >
            <span>{isIndonesian ? 'Buka Kunci Paket Bisnis' : 'Unlock Business Plan'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* TAB 1: MANAJEMEN PASIEN & KLIEN */}
      {activeTab === 'patients' && (
        <div className="space-y-6">
          {/* Controls Bar */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isIndonesian ? 'Cari nama pasien, ID Rekam Medis (RM), atau diagnosa...' : 'Search patient name, ID, or condition...'}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500/30"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowAddPatientModal(true)}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>{isIndonesian ? 'Daftarkan Pasien Baru' : 'Register New Patient'}</span>
              </button>
            </div>
          </div>

          {/* Patients Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {filteredPatients.map((patient) => (
              <div
                key={patient.id}
                onClick={() => setSelectedPatient(patient)}
                className={`p-5 rounded-2xl border transition-all cursor-pointer bg-white shadow-2xs hover:shadow-md ${
                  selectedPatient.id === patient.id
                    ? 'border-teal-500 ring-2 ring-teal-500/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-mono font-bold text-slate-500">{patient.id}</span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      patient.status === 'optimal'
                        ? 'bg-emerald-100 text-emerald-800'
                        : patient.status === 'monitoring'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {patient.status === 'optimal' ? 'Stabil' : patient.status === 'monitoring' ? 'Observasi' : 'Kritis'}
                  </span>
                </div>

                <h3 className="font-extrabold text-sm text-slate-900 truncate">{patient.name}</h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {patient.age} Tahun • Gender: {patient.gender}
                </p>

                <div className="mt-3 pt-3 border-t border-slate-100 space-y-1.5 text-xs">
                  <p className="text-[11px] text-slate-600 line-clamp-1 font-medium">
                    <span className="font-bold text-slate-700">Dx: </span>
                    {patient.condition}
                  </p>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                    <span>TD: <b>{patient.bp}</b></span>
                    <span>GDS: <b>{patient.glucose} mg/dL</b></span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Selected Patient Detailed Drawer Card */}
          {selectedPatient && (
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 font-black text-base flex items-center justify-center border border-teal-100">
                    {selectedPatient.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                      <span>{selectedPatient.name}</span>
                      <span className="text-xs font-mono font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md">
                        {selectedPatient.id}
                      </span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      {selectedPatient.age} Th • {selectedPatient.phone} • Terakhir Periksa: {selectedPatient.lastVisit}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setActiveTab('prescriptions')}
                    className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <FileText className="w-4 h-4" />
                    <span>{isIndonesian ? 'Tulis Resep & Rekam Medis' : 'Write Prescription & EHR'}</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Diagnosis Klinis</p>
                  <p className="text-xs font-extrabold text-slate-800 mt-1">{selectedPatient.condition}</p>
                </div>
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Tanda Vital Terakhir</p>
                  <p className="text-xs font-extrabold text-slate-800 mt-1">TD {selectedPatient.bp} • Gula {selectedPatient.glucose} mg/dL</p>
                </div>
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                  <p className="text-[10px] uppercase font-bold text-slate-400">Resep Obat Aktif</p>
                  <p className="text-xs font-extrabold text-slate-800 mt-1">{selectedPatient.activePrescriptionsCount} Terapi Farmakologi</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: GENERATOR RESEP DIGITAL & EHR */}
      {activeTab === 'prescriptions' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Form Editor */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-teal-600" />
                <h3 className="font-extrabold text-sm text-slate-900">
                  {isIndonesian ? 'Lembar Resep & Rekam Medis Elektronik' : 'Digital Prescription Form'}
                </h3>
              </div>
              <span className="text-xs font-bold text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-full">
                ICD-10 AI Supported
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Pilih Pasien / Klien</label>
                <select
                  value={selectedPatient.id}
                  onChange={(e) => {
                    const found = patients.find((p) => p.id === e.target.value);
                    if (found) setSelectedPatient(found);
                  }}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.id}) - {p.condition}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Diagnosis Klinis (ICD-10)</label>
                <input
                  type="text"
                  value={rxDiagnosis}
                  onChange={(e) => setRxDiagnosis(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Item Obat & Dosis Terapi (R/)</label>
                <textarea
                  rows={4}
                  value={rxMedicines}
                  onChange={(e) => setRxMedicines(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs focus:outline-none"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Instruksi & Pantangan Diet Pasien</label>
                <textarea
                  rows={2}
                  value={rxNotes}
                  onChange={(e) => setRxNotes(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-3 bg-teal-600 hover:bg-teal-700 text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <Printer className="w-4 h-4" />
                <span>{isIndonesian ? 'Cetak Lembar Resep Berlogo' : 'Print Branded Prescription'}</span>
              </button>
            </div>
          </div>

          {/* Live Printable Preview */}
          <div className="bg-slate-900 text-slate-100 rounded-3xl p-6 shadow-sm flex flex-col justify-between border border-slate-800">
            <div className="space-y-4">
              {/* Prescription Header */}
              <div className="flex items-center justify-between border-b border-slate-700 pb-4">
                <div>
                  <h4 className="font-black text-sm text-teal-400">{userProfile.clinicName || 'KLINIK SEHAT GOOGLE HEALTH'}</h4>
                  <p className="text-[10px] text-slate-400">SIP: 503/442-IDI/2026 • Telp: (021) 789-2211</p>
                  <p className="text-[10px] text-slate-400">Jl. Medika Pratama No. 88, Jakarta Selatan</p>
                </div>
                <div className="w-10 h-10 bg-teal-500/20 text-teal-300 rounded-xl flex items-center justify-center border border-teal-500/30 font-black">
                  <Stethoscope className="w-5 h-5" />
                </div>
              </div>

              {/* Patient Meta */}
              <div className="bg-slate-800/80 rounded-xl p-3 text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">Pasien:</span>
                  <span className="font-bold text-white">{selectedPatient.name} ({selectedPatient.id})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Tanggal Periksa:</span>
                  <span>{new Date().toISOString().split('T')[0]}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Diagnosis:</span>
                  <span className="text-teal-300 font-bold">{rxDiagnosis}</span>
                </div>
              </div>

              {/* Rx Script */}
              <div className="space-y-2 pt-2">
                <span className="text-sm font-black text-teal-400 italic">R /</span>
                <pre className="font-mono text-xs text-slate-200 whitespace-pre-wrap bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                  {rxMedicines}
                </pre>
              </div>

              {/* Notes */}
              <div className="text-xs text-slate-300">
                <span className="font-bold text-slate-400">Catatan: </span>
                <span>{rxNotes}</span>
              </div>
            </div>

            {/* Bottom Signature */}
            <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-xs">
              <div className="text-[10px] text-slate-400">
                <span>Terverifikasi Elektronik</span>
                <p className="font-mono text-[9px]">HASH: AES256-GH-{Math.random().toString(36).substring(2, 8).toUpperCase()}</p>
              </div>
              <div className="text-right">
                <p className="text-[11px] font-bold text-teal-300">dr. {userProfile.name}, Sp.GK</p>
                <p className="text-[10px] text-slate-400">Dokter Penanggung Jawab</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ANALITIK KOHORT PASIEN */}
      {activeTab === 'analytics' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
            <span className="text-xs font-bold text-slate-400 uppercase">Tingkat Kepatuhan Diet</span>
            <p className="text-2xl font-black text-slate-900">89.4%</p>
            <p className="text-xs text-emerald-600 font-bold">↑ +4.2% dari bulan lalu</p>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
            <span className="text-xs font-bold text-slate-400 uppercase">Pasien Target Optimal</span>
            <p className="text-2xl font-black text-emerald-700">38 / 50</p>
            <p className="text-xs text-slate-500">76% biomarker dalam rentang aman</p>
          </div>
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-1">
            <span className="text-xs font-bold text-slate-400 uppercase">Resep Diterbitkan</span>
            <p className="text-2xl font-black text-teal-700">142 Lembar</p>
            <p className="text-xs text-slate-500">Sinkronisasi Cloud Firestore aktif</p>
          </div>
        </div>
      )}

      {/* TAB 4: API KEYS & WEBHOOKS SIMRS */}
      {activeTab === 'api' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900">
                {isIndonesian ? 'Kunci API Integrasi SIMRS & Lab Eksternal' : 'SIMRS Hospital API Keys'}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {isIndonesian
                  ? 'Gunakan kunci ini untuk menyinkronkan data pasien secara otomatis dengan sistem rumah sakit eksternal.'
                  : 'Authenticate endpoints to push and pull clinical health records securely.'}
              </p>
            </div>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
              LIVE PROD
            </span>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
            <p className="text-[11px] font-bold text-slate-700">API Secret Key (Bearer Token):</p>
            <div className="flex items-center gap-2">
              <input
                type="password"
                readOnly
                value="gh_live_sec_89f92134a8872dd16a4f471baa767c1d633aeafd"
                className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-mono text-slate-700 focus:outline-none"
              />
              <button
                onClick={() => {
                  navigator.clipboard.writeText('gh_live_sec_89f92134a8872dd16a4f471baa767c1d633aeafd');
                  setIsCopiedKey(true);
                  setTimeout(() => setIsCopiedKey(false), 2000);
                }}
                className="p-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                {isCopiedKey ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{isCopiedKey ? 'Tersalin' : 'Salin'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD PATIENT MODAL */}
      <AnimatePresence>
        {showAddPatientModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddPatientModal(false)}
              className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            />

            <motion.form
              onSubmit={handleAddPatient}
              initial={{ scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.94, opacity: 0 }}
              className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl z-10 space-y-4 border border-slate-200"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="font-extrabold text-sm text-slate-900">
                  {isIndonesian ? 'Daftarkan Pasien Baru' : 'Register Patient'}
                </h3>
                <button
                  type="button"
                  onClick={() => setShowAddPatientModal(false)}
                  className="p-1.5 rounded-full bg-slate-100 text-slate-500 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Nama Lengkap Pasien</label>
                  <input
                    type="text"
                    required
                    value={newPtName}
                    onChange={(e) => setNewPtName(e.target.value)}
                    placeholder="Contoh: Hendra Kusuma, SE"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Usia (Tahun)</label>
                    <input
                      type="number"
                      value={newPtAge}
                      onChange={(e) => setNewPtAge(Number(e.target.value))}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">Gender</label>
                    <select
                      value={newPtGender}
                      onChange={(e) => setNewPtGender(e.target.value as any)}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                    >
                      <option value="L">Laki-Laki</option>
                      <option value="P">Perempuan</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Nomor Telepon / WhatsApp</label>
                  <input
                    type="text"
                    value={newPtPhone}
                    onChange={(e) => setNewPtPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Keluhan / Diagnosis Utama</label>
                  <input
                    type="text"
                    value={newPtCondition}
                    onChange={(e) => setNewPtCondition(e.target.value)}
                    placeholder="Contoh: Dislipidemia & Nyeri Sendi"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>{isIndonesian ? 'Simpan Data Pasien' : 'Save Patient'}</span>
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
