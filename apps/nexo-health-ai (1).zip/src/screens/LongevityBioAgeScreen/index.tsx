import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  Zap,
  TrendingDown,
  Activity,
  Heart,
  ShieldCheck,
  ArrowLeft,
  CheckCircle2,
  Clock,
  Dumbbell,
  Utensils,
  Award,
  Plus,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface LongevityBioAgeScreenProps {
  userProfile: UserProfile;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const LongevityBioAgeScreen: React.FC<LongevityBioAgeScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const chronologicalAge = userProfile.age || 28;
  const [fastingWindowHours, setFastingWindowHours] = useState(16); // 16:8 Intermittent fasting
  const [zone2HoursPerWeek, setZone2HoursPerWeek] = useState(3.5); // 3.5 hours Zone 2 cardio
  const [resistanceTrainingDays, setResistanceTrainingDays] = useState(4); // 4 days lifting
  const [sleepScoreAvg, setSleepScoreAvg] = useState(88); // 88/100

  // Biological age calculation
  const bioAgeDiscount = Math.round(
    (zone2HoursPerWeek >= 3 ? 1.8 : 0.8) +
    (resistanceTrainingDays >= 3 ? 1.5 : 0.5) +
    (fastingWindowHours >= 14 ? 1.2 : 0.4) +
    (sleepScoreAvg >= 85 ? 1.5 : 0.5)
  );

  const biologicalAge = Math.max(18, chronologicalAge - bioAgeDiscount);
  const longevityScore = Math.min(100, Math.round(70 + bioAgeDiscount * 5));

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-amber-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-amber-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m19_longevity_bioage')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-amber-600 hover:bg-amber-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log Longevity' : 'Log BioAge Data'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #19:</span>
            <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 font-extrabold border border-amber-300">
              {isIndonesian ? 'Skrining Longevity & Usia Biologis' : 'Longevity & Biological Age'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-amber-600 via-emerald-800 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-amber-100 text-xs font-black">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{isIndonesian ? 'Integritas Telomer & Mitokondria' : 'Cellular Rejuvenation & Autophagy'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Skrining Longevity & Usia Biologis' : 'Longevity & Biological Age'}
            </h1>
            <p className="text-xs sm:text-sm text-amber-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Estimasi usia biologis seluler dibandingkan usia KTP (kronologis) dan terapkan 4 pilar regenerasi sel: Kardio Zona 2, beban, puasa autofagi, dan tidur REM.'
                : 'Estimate phenotypic cellular biological age vs chronological age and implement evidence-based longevity interventions.'}
            </p>
          </div>

          {/* Biological Age Showcase */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-5 text-center min-w-[220px] shrink-0">
            <span className="text-[11px] text-amber-200 uppercase font-black tracking-wider block">
              {isIndonesian ? 'Usia Biologis Seluler' : 'Cellular Biological Age'}
            </span>
            <div className="text-4xl font-black text-white mt-1 font-mono">
              {biologicalAge} <span className="text-xs font-bold text-emerald-300">Tahun</span>
            </div>
            <span className="text-[11px] text-emerald-300 mt-1 block font-black">
              ▼ {bioAgeDiscount} {isIndonesian ? 'Tahun Lebih Muda dari KTP' : 'Years Younger than ID'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Longevity Drivers & Scientific Protocols */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Interactive Longevity Levers */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-6 shadow-sm">
          <h2 className="text-lg font-black text-slate-900 tracking-tight">
            {isIndonesian ? '4 Tuas Kebugaran Seluler Harian' : '4 Pillars of Cellular Longevity'}
          </h2>

          {/* Zone 2 Cardio Slider */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-slate-700">
              <span className="flex items-center gap-1.5">
                <Heart className="w-4 h-4 text-rose-500" />
                <span>{isIndonesian ? 'Kardio Zona 2 (Mitokondria):' : 'Zone 2 Cardio:'}</span>
              </span>
              <span className="text-emerald-700 font-black">{zone2HoursPerWeek} jam / minggu</span>
            </div>
            <input
              type="range"
              min="0"
              max="7"
              step="0.5"
              value={zone2HoursPerWeek}
              onChange={(e) => setZone2HoursPerWeek(Number(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer"
            />
          </div>

          {/* Resistance Training */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-slate-700">
              <span className="flex items-center gap-1.5">
                <Dumbbell className="w-4 h-4 text-teal-600" />
                <span>{isIndonesian ? 'Latihan Beban (Massa Tulang/Otot):' : 'Resistance Training:'}</span>
              </span>
              <span className="text-teal-700 font-black">{resistanceTrainingDays} hari / minggu</span>
            </div>
            <input
              type="range"
              min="0"
              max="6"
              value={resistanceTrainingDays}
              onChange={(e) => setResistanceTrainingDays(Number(e.target.value))}
              className="w-full accent-teal-600 cursor-pointer"
            />
          </div>

          {/* Fasting Autophagy Window */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold text-slate-700">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-500" />
                <span>{isIndonesian ? 'Jendela Puasa Berkala (Autofagi):' : 'Intermittent Fasting:'}</span>
              </span>
              <span className="text-amber-700 font-black">{fastingWindowHours} jam</span>
            </div>
            <input
              type="range"
              min="12"
              max="20"
              value={fastingWindowHours}
              onChange={(e) => setFastingWindowHours(Number(e.target.value))}
              className="w-full accent-amber-600 cursor-pointer"
            />
          </div>
        </div>

        {/* Right: Longevity Prescription Recommendations */}
        <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-4 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-base font-black text-slate-900">
              {isIndonesian ? 'Protokol Bukti Ilmiah Rejuvenasi' : 'Evidence-Based Protocol'}
            </h3>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 text-[10px] font-black uppercase">
              Score: {longevityScore}/100
            </span>
          </div>

          <div className="space-y-3 text-xs text-slate-700 font-medium">
            <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1">
              <strong className="text-emerald-950 font-black block">1. Efisiensi Biogenesis Mitokondria</strong>
              <p className="text-[11px] text-emerald-800 leading-relaxed">
                Pertahankan 150-180 menit/minggu di zona detak jantung 60-70% max HR untuk memaksimalkan oksidasi asam lemak dan kepadatan mitokondria.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-1">
              <strong className="text-amber-950 font-black block">2. Siklus Autofagi Seluler</strong>
              <p className="text-[11px] text-amber-800 leading-relaxed">
                Jendela puasa 16 jam membersihkan protein terakumulasi (senescent cells) dan merangsang aktivasi jalur AMPK / SIRT1.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200 space-y-1">
              <strong className="text-indigo-950 font-black block">3. Grip Strength & Biomarker Frailty</strong>
              <p className="text-[11px] text-indigo-800 leading-relaxed">
                Kekuatan cengkeraman tangan dan massa otot rangka (skeletal muscle) berkorelasi linear paling kuat dengan perlambatan all-cause mortality.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
