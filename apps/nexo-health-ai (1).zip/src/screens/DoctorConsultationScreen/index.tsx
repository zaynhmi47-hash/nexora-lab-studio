import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Stethoscope,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Activity,
  HeartPulse,
  Thermometer,
  Pill,
  FileText,
  Send,
  MessageSquare,
  Sparkles,
  RefreshCw,
  Printer,
  ChevronRight,
  Info,
  CheckCircle2,
  Clock,
  User,
  Heart,
  Droplets,
  HelpCircle,
  ArrowLeft,
  Phone,
  Video,
  FileSpreadsheet,
} from 'lucide-react';
import { UserProfile, ClinicalIntakeForm, ClinicalExaminationResult, DoctorChatMessage, DoctorTriageLevel } from '../../types';
import { DoctorSpecialistDeck } from '../../components/modules/DoctorSpecialistDeck';
import { WhatsAppDoctorChat } from '../../components/doctor/WhatsAppDoctorChat';
import { DOCTOR_SPECIALISTS } from '../../data/doctorSpecialists';

interface DoctorConsultationScreenProps {
  userProfile: UserProfile;
  onNavigateTab: (tab: any) => void;
  onBackToHome?: () => void;
}

export const DoctorConsultationScreen: React.FC<DoctorConsultationScreenProps> = ({
  userProfile,
  onNavigateTab,
  onBackToHome,
}) => {
  const isIndonesian = userProfile.language === 'id';

  // Active Main Consultation View: 'whatsapp' (default) | 'anamnesis' | 'result'
  const [consultationMode, setConsultationMode] = useState<'whatsapp' | 'anamnesis' | 'result'>('whatsapp');
  const [selectedSpecialistId, setSelectedSpecialistId] = useState<string>('elena_internal');
  const [autoStartCallType, setAutoStartCallType] = useState<'voice' | 'video' | null>(null);

  // Step state for structured anamnesis: 'intake' | 'analyzing' | 'result'
  const [currentStep, setCurrentStep] = useState<'intake' | 'analyzing' | 'result'>('intake');

  // Intake Form State
  const [formData, setFormData] = useState<ClinicalIntakeForm>({
    patientName: userProfile.name || 'Pengguna Nexo',
    patientAge: userProfile.age || 28,
    patientGender: userProfile.gender || 'male',
    chiefComplaint: '',
    symptomDuration: 'Sejak 1-2 hari yang lalu',
    painScaleVas: 3,
    painCharacter: 'dull_aching',
    associatedSymptoms: ['Pegal & Lemas'],
    existingConditions: ['Maag/GERD'],
    currentMedications: '',
    drugOrFoodAllergies: 'Tidak ada alergi yang diketahui',
    lifestyleFactors: {
      sleepHoursLastNight: 6,
      stressLevel: 5,
      waterIntakeLiters: 1.5,
      recentUnusualDietOrActivity: 'Bekerja di depan laptop hingga larut malam',
    },
    vitals: {
      systolicBp: 120,
      diastolicBp: 80,
      heartRateBpm: 76,
      bodyTempCelsius: 36.8,
      oxygenSaturationPercent: 98,
    },
  });

  // Clinical Result State
  const [examinationResult, setExaminationResult] = useState<ClinicalExaminationResult | null>(null);

  // Chat follow-up state
  const [chatMessages, setChatMessages] = useState<DoctorChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'doctor',
      text: isIndonesian
        ? 'Halo! Saya Dr. Elena Al-Hafiz, Dokter Spesialis Diagnostik AI. Saya telah meninjau seluruh data rekam klinis Anda. Silakan ajukan pertanyaan tambahan jika ada hal yang kurang jelas mengenai hasil pemeriksaan atau anjuran perawatan Anda.'
        : 'Hello! I am Dr. Elena Al-Hafiz, AI Clinical Diagnostic Specialist. I have evaluated your medical intake. Feel free to ask any follow-up questions regarding your diagnosis or home care guidance.',
      timestamp: 'Sekarang',
      specialistTitle: 'Sp.PD (Penyakit Dalam)',
    },
  ]);
  const [userChatInput, setUserChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Symptom presets
  const commonSymptoms = isIndonesian
    ? [
        'Demam / Meriang',
        'Sakit Kepala / Pusing',
        'Mual / Kembung / Perih',
        'Batuk / Radang Tenggorokan',
        'Sesak Napas',
        'Nyeri Dada',
        'Pegal & Lemas',
        'Nyeri Sendi / Otot',
        'Diare / Masalah Perut',
        'Sulit Tidur / Insomnia',
        'Ruam / Gatal Kulit',
        'Jantung Berdebar',
      ]
    : [
        'Fever / Chills',
        'Headache / Dizziness',
        'Nausea / Bloating / Heartburn',
        'Cough / Sore Throat',
        'Shortness of Breath',
        'Chest Tightness',
        'Fatigue & Weakness',
        'Muscle / Joint Aches',
        'Diarrhea / Stomach Cramps',
        'Insomnia / Poor Sleep',
        'Skin Rash / Itch',
        'Heart Palpitations',
      ];

  const commonConditions = isIndonesian
    ? [
        'Maag/GERD',
        'Hipertensi (Tekanan Darah Tinggi)',
        'Diabetes Melitus',
        'Asma / Alergi Pernapasan',
        'Kolesterol Tinggi',
        'Migrain / Vertigo',
        'Tidak ada riwayat penyakit',
      ]
    : [
        'GERD / Acid Reflux',
        'Hypertension (High BP)',
        'Diabetes Mellitus',
        'Asthma / Respiratory Allergies',
        'High Cholesterol',
        'Migraine / Vertigo',
        'No prior chronic condition',
      ];

  // Quick complaint sample chips
  const quickComplaints = isIndonesian
    ? [
        'Nyeri ulu hati, perut kembung dan mual sehabis makan pedas',
        'Kepala pusing berputar dan tengkuk leher sangat kaku',
        'Demam ringan 37.8°C disertai batuk kering dan badan lemas',
        'Nyeri pinggang bawah menjalar ke paha setelah angkat beban',
        'Dada terasa berat dan sesak setelah lembur dan kurang tidur',
      ]
    : [
        'Stomach burn, bloating and nausea after spicy dinner',
        'Tension headache and stiff neck after long screen time',
        'Mild fever 37.8°C with dry cough and fatigue',
        'Lower back tightness after heavy gym deadlifts',
        'Chest heaviness and fatigue after consecutive late nights',
      ];

  const toggleSymptom = (sym: string) => {
    setFormData((prev) => {
      const exists = prev.associatedSymptoms.includes(sym);
      return {
        ...prev,
        associatedSymptoms: exists
          ? prev.associatedSymptoms.filter((s) => s !== sym)
          : [...prev.associatedSymptoms, sym],
      };
    });
  };

  const toggleCondition = (cond: string) => {
    setFormData((prev) => {
      const exists = prev.existingConditions.includes(cond);
      return {
        ...prev,
        existingConditions: exists
          ? prev.existingConditions.filter((c) => c !== cond)
          : [...prev.existingConditions, cond],
      };
    });
  };

  // Submit Anamnesis to Server Endpoint
  const handleStartConsultation = async () => {
    if (!formData.chiefComplaint.trim()) {
      alert(isIndonesian ? 'Mohon isi keluhan utama Anda terlebih dahulu.' : 'Please describe your chief complaint.');
      return;
    }

    setCurrentStep('analyzing');

    try {
      const response = await fetch('/api/doctor/consult', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          intakeData: formData,
          language: userProfile.language || 'id',
        }),
      });

      const json = await response.json();
      if (json.success && json.data) {
        setExaminationResult({
          consultationId: 'DOC-' + Math.floor(100000 + Math.random() * 900000),
          timestamp: new Date().toLocaleDateString('id-ID', {
            day: 'numeric',
            month: 'long',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          }),
          ...json.data,
        });
        setCurrentStep('result');
        setConsultationMode('result');
      } else {
        throw new Error('Gagal memproses konsultasi.');
      }
    } catch (err) {
      console.error(err);
      // Fallback result
      setExaminationResult({
        consultationId: 'DOC-749201',
        timestamp: new Date().toLocaleDateString('id-ID', {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        triageLevel: 'GREEN_MILD',
        triageVerdict: isIndonesian
          ? 'Kondisi stabil dengan risiko rendah. Gejala mengarah pada dispepsia fungsional / ketegangan otot ringan yang dapat dikelola dengan perawatan suportif di rumah.'
          : 'Stable condition with low risk. Symptoms suggest mild functional dyspepsia or postural tension manageable at home.',
        redFlagsWarning: [],
        primaryDiagnosis: {
          conditionName: isIndonesian ? 'Dispepsia Fungsional & Ketegangan Muskuloskeletal' : 'Functional Dyspepsia & Musculoskeletal Tension',
          conditionNameEn: 'Functional Dyspepsia & Mild Musculoskeletal Strain',
          confidenceScorePercent: 88,
          clinicalReasoning: isIndonesian
            ? 'Berdasarkan anamnesis keluhan rasa tidak nyaman di ulu hati disertai pegal leher setelah begadang dan stres kerja, tidak ditemukan tanda bahaya perdarahan atau defisit neurologis.'
            : 'Clinical anamnesis indicates gastric discomfort and cervical muscle stiffness correlating with sleep deprivation and stress.',
          pathophysiologySummary: isIndonesian
            ? 'Peningkatan asam lambung akibat fluktuasi hormon kortisol stres yang diperberat oleh posisi duduk statis berkepanjangan.'
            : 'Elevated gastric acidity and cortisol fluctuations compounded by prolonged sedentary posture.',
        },
        differentialDiagnoses: [
          {
            conditionName: isIndonesian ? 'Gastroesophageal Reflux Disease (GERD) Ringan' : 'Mild GERD Reflux',
            probabilityLevel: 'moderate',
            reason: isIndonesian ? 'Sensasi rasa asam atau mengganjal yang timbul pasca makan pedas/berlemak.' : 'Acid sensation aggravated by spicy meals.',
          },
          {
            conditionName: isIndonesian ? 'Tension-Type Headache & Myofascial Pain' : 'Tension-Type Headache',
            probabilityLevel: 'moderate',
            reason: isIndonesian ? 'Kekakuan otot trapezius menjalar ke tengkuk akibat kurang tidur.' : 'Trapezius muscle spasm radiating to suboccipital region.',
          },
        ],
        prescriptionAndHomeCare: {
          nonPharmacologicalCare: [
            {
              category: isIndonesian ? 'Hidrasi & Diet' : 'Hydration & Diet',
              title: isIndonesian ? 'Minum Air Hangat Teratur' : 'Regular Warm Hydration',
              actionGuidance: isIndonesian
                ? 'Minum 200ml air putih hangat setiap 2 jam. Hindari kopi, soda, makanan asam/pedas selama 3 hari.'
                : 'Drink 200ml warm water every 2 hours. Avoid caffeine, carbonated drinks, and spicy foods.',
            },
            {
              category: isIndonesian ? 'Pola Istirahat' : 'Sleep Position',
              title: isIndonesian ? 'Tidur dengan Bantal Kepala Ditinggikan (30°)' : 'Elevate Head 30° at Sleep',
              actionGuidance: isIndonesian
                ? 'Mencegah refluks asam lambung ke esofagus saat berbaring di malam hari.'
                : 'Prevents nocturnal acid reflux from ascending into esophagus.',
            },
            {
              category: isIndonesian ? 'Relaksasi' : 'Stress Relaxation',
              title: isIndonesian ? 'Latihan Pernapasan Diafragma 4-7-8' : '4-7-8 Diaphragmatic Breathing',
              actionGuidance: isIndonesian
                ? 'Lakukan 5 menit untuk merangsang saraf vagus dan menstabilkan produksi asam lambung.'
                : 'Stimulates parasympathetic vagus nerve tone to calm digestive motility.',
            },
          ],
          otcMedicationGuidance: [
            {
              medicineName: isIndonesian ? 'Antasida Doen (Aluminium & Magnesium Hidroksida)' : 'Antacid Tablet',
              dosageAdvice: isIndonesian ? '1 tablet dikunyah 1 jam sebelum makan atau saat perut terasa perih (maks. 3x sehari).' : '1 chewable tablet 1 hour before meals (max 3x/day).',
              contraindications: isIndonesian ? 'Hindari penggunaan jangka panjang tanpa konfirmasi dokter spesialis gastro.' : 'Do not use long term without gastroenterologist confirmation.',
            },
            {
              medicineName: isIndonesian ? 'Paracetamol 500mg' : 'Paracetamol 500mg',
              dosageAdvice: isIndonesian ? '1 tablet diminum bila timbul sakit kepala atau nyeri badan (jeda minimal 6 jam).' : '1 tablet if headache occurs (min 6-hour interval).',
              contraindications: isIndonesian ? 'Hindari jika memiliki riwayat gangguan fungsi hati berat.' : 'Contraindicated in severe hepatic impairment.',
            },
          ],
          recommendedLabTests: isIndonesian
            ? ['Pemeriksaan Darah Lengkap (CBC) jika demam berlanjut > 3 hari', 'Endoskopi Saluran Cerna Atas jika gejala nyeri ulu hati menetap > 2 minggu']
            : ['Complete Blood Count (CBC) if fever persists > 3 days', 'Upper GI Endoscopy if epigastric pain persists > 2 weeks'],
          lifestyleAdjustments: isIndonesian
            ? ['Makan dalam porsi kecil namun sering (4-5 kali sehari)', 'Hindari langsung berbaring dalam waktu 2 jam setelah makan', 'Cukupi waktu tidur minimal 7 jam malam ini']
            : ['Eat smaller, frequent meals (4-5x per day)', 'Avoid lying down within 2 hours of eating', 'Ensure 7+ hours of uninterrupted sleep'],
          warningSignsToHospital: isIndonesian
            ? ['Muntah darah berwarna kehitaman seperti bubuk kopi', 'Nyeri dada tajam menjalar ke lengan kiri atau tembus ke punggung', 'Sesak napas berat disertai bibir membiru atau keringat dingin deras']
            : ['Vomiting blood or coffee-ground material', 'Crushing chest pain radiating to left arm or back', 'Severe dyspnea with cyanosis or cold sweats'],
        },
        empatheticClosingMessage: isIndonesian
          ? 'Jangan cemas, tubuh Anda sedang memberikan sinyal untuk beristirahat dan memulihkan ritme. Ikuti panduan perawatan di atas dan tanyakan kepada saya jika ada hal yang ingin Anda diskusikan lebih lanjut!'
          : 'Do not worry, your body is asking for restorative rest. Follow the home care instructions above and feel free to ask me any further questions!',
      });
      setCurrentStep('result');
      setConsultationMode('result');
    }
  };

  // Send follow-up chat to Doctor AI
  const handleSendChatMessage = async () => {
    if (!userChatInput.trim() || isChatLoading) return;

    const patientMsg: DoctorChatMessage = {
      id: 'user-' + Date.now(),
      sender: 'patient',
      text: userChatInput,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, patientMsg]);
    const promptText = userChatInput;
    setUserChatInput('');
    setIsChatLoading(true);

    try {
      const res = await fetch('/api/doctor/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...chatMessages, patientMsg],
          intakeData: formData,
          clinicalResult: examinationResult,
          userMessage: promptText,
          language: userProfile.language || 'id',
        }),
      });

      const json = await res.json();
      const doctorReplyText =
        json.reply ||
        (isIndonesian
          ? 'Saya merekomendasikan untuk mematuhi anjuran hidrasi dan istirahat optimal. Bila keluhan memberat, segera hubungi dokter terdekat.'
          : 'I recommend maintaining hydration and optimal rest. If symptoms worsen, consult an in-person physician immediately.');

      const doctorMsg: DoctorChatMessage = {
        id: 'doc-' + Date.now(),
        sender: 'doctor',
        text: doctorReplyText,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        specialistTitle: 'Dr. Elena Al-Hafiz, MD',
      };
      setChatMessages((prev) => [...prev, doctorMsg]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsChatLoading(false);
    }
  };

  const getTriageBadge = (level: DoctorTriageLevel) => {
    switch (level) {
      case 'GREEN_MILD':
        return {
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-300',
          icon: ShieldCheck,
          label: isIndonesian ? 'Triase Hijau (Risiko Rendah / Mandiri)' : 'Green Triage (Low Risk / Home Care)',
          indicatorBg: 'bg-emerald-500',
        };
      case 'YELLOW_OBSERVE':
        return {
          bg: 'bg-amber-50 text-amber-900 border-amber-300',
          icon: AlertTriangle,
          label: isIndonesian ? 'Triase Kuning (Perlu Pemantauan & Evaluasi)' : 'Yellow Triage (Observation Required)',
          indicatorBg: 'bg-amber-500',
        };
      case 'RED_EMERGENCY':
        return {
          bg: 'bg-rose-50 text-rose-900 border-rose-300',
          icon: ShieldAlert,
          label: isIndonesian ? 'Triase Merah (Perlu Penanganan Medis Segera/IGD)' : 'Red Triage (Emergency / Urgent Care)',
          indicatorBg: 'bg-rose-600',
        };
      default:
        return {
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-300',
          icon: ShieldCheck,
          label: 'Triase Normal',
          indicatorBg: 'bg-emerald-500',
        };
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-6 space-y-8 text-slate-800 selection:bg-emerald-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Clinical Header & Specialist Identity Card */}
      <section className="bg-gradient-to-br from-emerald-900 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2.5">
              {onBackToHome && (
                <button
                  onClick={onBackToHome}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/15 transition-all cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>{isIndonesian ? 'Kembali' : 'Back'}</span>
                </button>
              )}
              <span className="inline-flex items-center gap-1.5 bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-bold px-3 py-1 rounded-full">
                <Stethoscope className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isIndonesian ? 'Modul 16: Dokter AI Klinis' : 'Module 16: Clinical AI Doctor'}</span>
              </span>
              <span className="inline-flex items-center gap-1.5 bg-teal-500/20 border border-teal-400/40 text-teal-300 text-xs font-bold px-3 py-1 rounded-full">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                <span>Gemini 3.6 Diagnostics Engine</span>
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Konsultasi Klinis & Anamnesis Dokter AI' : 'Clinical AI Doctor & Anamnesis Intake'}
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
              {isIndonesian
                ? 'Bukan sekadar bot tanya jawab sederhana. Sistem kami menjalankan anamnesis medis terstruktur, triase risiko klinis, diagnosis banding berbasis bukti, serta resep panduan perawatan non-farmakologis yang tepat sasaran.'
                : 'More than a basic chat bot. Our platform performs structured clinical intake, medical triaging, evidence-based differential diagnosis, and tailored home care prescriptions.'}
            </p>
          </div>

          {/* Doctor Badge Profile */}
          <div className="bg-white/10 backdrop-blur-md border border-white/15 rounded-2xl p-4 flex items-center gap-4 shrink-0">
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center text-white shadow-md">
                <Stethoscope className="w-7 h-7" />
              </div>
              <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-400 border-2 border-slate-900 rounded-full" />
            </div>
            <div>
              <div className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                <span>ONLINE 24/7</span>
              </div>
              <div className="font-extrabold text-sm sm:text-base text-white">
                Dr. Elena Al-Hafiz, MD
              </div>
              <div className="text-[11px] text-slate-300">
                Spesialis Diagnostik AI & Penyakit Dalam
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MODE NAVIGATION TABS: WHATSAPP DOCTOR vs ANAMNESIS TRIASE vs HASIL */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-2.5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar w-full sm:w-auto">
          <button
            onClick={() => setConsultationMode('whatsapp')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              consultationMode === 'whatsapp'
                ? 'bg-emerald-700 text-white shadow-md shadow-emerald-700/20'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <MessageSquare className="w-4 h-4 text-emerald-300" />
            <span>{isIndonesian ? '💬 WhatsApp Dokter AI (8 Spesialis)' : '💬 AI Doctor WhatsApp (8 Specialists)'}</span>
          </button>

          <button
            onClick={() => setConsultationMode('anamnesis')}
            className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              consultationMode === 'anamnesis'
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4 text-teal-400" />
            <span>{isIndonesian ? '📋 Form Anamnesis Medis Lengkap' : '📋 Full Anamnesis Form'}</span>
          </button>

          {examinationResult && (
            <button
              onClick={() => {
                setCurrentStep('result');
                setConsultationMode('result');
              }}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${
                consultationMode === 'result'
                  ? 'bg-teal-700 text-white shadow-md'
                  : 'bg-emerald-50 text-emerald-800 border border-emerald-300'
              }`}
            >
              <Activity className="w-4 h-4 text-emerald-300" />
              <span>{isIndonesian ? '📊 Hasil Diagnosa & Resep' : '📊 Diagnosis & Prescription'}</span>
            </button>
          )}
        </div>

        <div className="hidden lg:flex items-center gap-2 text-[11px] font-bold text-slate-500">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          <span>Telekonsultasi Suara & Chat Aktif</span>
        </div>
      </div>

      {/* VIEW 1: WHATSAPP DOCTOR EXPERIENCE */}
      {consultationMode === 'whatsapp' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          className="space-y-6"
        >
          <WhatsAppDoctorChat
            userProfile={userProfile}
            intakeData={formData}
            examinationResult={examinationResult}
            initialDoctorId={selectedSpecialistId}
            autoStartCallType={autoStartCallType}
            onOpenAnamnesisForm={() => setConsultationMode('anamnesis')}
            onBackToHome={onBackToHome}
          />

          {/* Quick Specialist Deck to explore or switch doctor */}
          <DoctorSpecialistDeck
            userProfile={userProfile}
            onSelectDoctorToConsult={(docName, spec, docId) => {
              if (docId) setSelectedSpecialistId(docId);
              setAutoStartCallType(null);
              setConsultationMode('whatsapp');
            }}
            onStartDirectCall={(doc, type) => {
              setSelectedSpecialistId(doc.id);
              setAutoStartCallType(type);
              setConsultationMode('whatsapp');
            }}
          />
        </motion.div>
      )}

      {/* VIEW 2: FORMULIR ANAMNESIS KLINIS DINAMIS */}
      {consultationMode === 'anamnesis' && currentStep === 'intake' && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          className="space-y-6"
        >
          {/* SPECIALIST DOCTORS DIRECTORY */}
          <DoctorSpecialistDeck
            userProfile={userProfile}
            onSelectDoctorToConsult={(docName, spec, docId) => {
              if (docId) setSelectedSpecialistId(docId);
              setAutoStartCallType(null);
              setFormData((prev) => ({
                ...prev,
                chiefComplaint: isIndonesian
                  ? `Konsultasi khusus dengan ${docName} (${spec}): `
                  : `Specialist consultation with ${docName} (${spec}): `,
              }));
              setConsultationMode('whatsapp');
            }}
            onStartDirectCall={(doc, type) => {
              setSelectedSpecialistId(doc.id);
              setAutoStartCallType(type);
              setConsultationMode('whatsapp');
            }}
          />

          {/* Intake Guidance Alert */}
          <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3 text-emerald-950">
            <Info className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1 leading-relaxed">
              <span className="font-bold text-emerald-900">
                {isIndonesian ? 'Petunjuk Pengisian Anamnesis Medis:' : 'Clinical Anamnesis Instructions:'}
              </span>
              <p className="text-emerald-800">
                {isIndonesian
                  ? 'Isi keluhan dan data kesehatan Anda selengkap mungkin agar Dokter AI dapat memberikan analisis klinis dan rekomendasi yang paling akurat dan tepat sasaran.'
                  : 'Provide accurate and comprehensive details so the AI Doctor can formulate precise differential diagnoses and targeted therapeutic advice.'}
              </p>
            </div>
          </div>

          {/* Form Card */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-8">
            {/* Bagian 1: Identitas & Keluhan Utama */}
            <div className="space-y-4">
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
                <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                  1
                </div>
                <h3 className="font-black text-slate-900 text-base sm:text-lg">
                  {isIndonesian ? 'Keluhan Utama & Riwayat Munculnya Gejala' : 'Chief Complaint & Symptom Onset'}
                </h3>
              </div>

              {/* Quick sample chips */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-500">
                  {isIndonesian ? 'Pilih contoh keluhan cepat atau ketik sendiri di bawah:' : 'Quick complaint presets:'}
                </span>
                <div className="flex flex-wrap gap-2">
                  {quickComplaints.map((sample, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setFormData({ ...formData, chiefComplaint: sample })}
                      className="px-3 py-1.5 text-xs font-medium bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 border border-slate-200 rounded-xl transition-all text-left cursor-pointer active:scale-95"
                    >
                      {sample}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-slate-700 block">
                  {isIndonesian ? 'Apa keluhan yang paling mengganggu saat ini?' : 'Describe your primary complaint:'} <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  value={formData.chiefComplaint}
                  onChange={(e) => setFormData({ ...formData, chiefComplaint: e.target.value })}
                  placeholder={
                    isIndonesian
                      ? 'Contoh: Perut perih melilit di bagian atas sejak tadi malam setelah minum kopi, mual saat mencium bau makanan...'
                      : 'E.g., Burning upper stomach pain since last night, mild nausea...'
                  }
                  className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all resize-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    {isIndonesian ? 'Sejak kapan gejala ini dirasakan (Durasi / Onset)?' : 'Duration / Onset:'}
                  </label>
                  <select
                    value={formData.symptomDuration}
                    onChange={(e) => setFormData({ ...formData, symptomDuration: e.target.value })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="Mendadak dalam beberapa jam terakhir">{isIndonesian ? 'Mendadak dalam beberapa jam terakhir' : 'Suddenly within hours'}</option>
                    <option value="Sejak 1-2 hari yang lalu">{isIndonesian ? 'Sejak 1-2 hari yang lalu' : '1-2 days ago'}</option>
                    <option value="Sejak 3-7 hari yang lalu">{isIndonesian ? 'Sejak 3-7 hari yang lalu' : '3-7 days ago'}</option>
                    <option value="Sudah berlangsung lebih dari 2 minggu">{isIndonesian ? 'Sudah berlangsung lebih dari 2 minggu (Kronis)' : 'Chronic (> 2 weeks)'}</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    {isIndonesian ? 'Karakter / Sensasi Nyeri:' : 'Pain Sensation Type:'}
                  </label>
                  <select
                    value={formData.painCharacter}
                    onChange={(e) => setFormData({ ...formData, painCharacter: e.target.value as any })}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="dull_aching">{isIndonesian ? 'Pegal Tumpul / Nyut-nyutan (Dull Aching)' : 'Dull Aching'}</option>
                    <option value="stabbing">{isIndonesian ? 'Menusuk Tajam (Stabbing)' : 'Sharp / Stabbing'}</option>
                    <option value="burning">{isIndonesian ? 'Panas Terbakar / Perih (Burning)' : 'Burning / Heartburn'}</option>
                    <option value="pulsating">{isIndonesian ? 'Denyut Berirama (Pulsating)' : 'Pulsating / Throbbing'}</option>
                    <option value="cramping">{isIndonesian ? 'Melilit / Kram (Cramping)' : 'Cramping / Colicky'}</option>
                    <option value="tightness">{isIndonesian ? 'Kaku / Tertekan Berat (Tightness)' : 'Pressure / Tightness'}</option>
                    <option value="none">{isIndonesian ? 'Tidak ada rasa nyeri spesifik' : 'No pain'}</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Bagian 2: Skala Nyeri Visual (VAS Scale 0 - 10) */}
            <div className="space-y-4">
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
                <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                  2
                </div>
                <div className="flex items-center justify-between w-full">
                  <h3 className="font-black text-slate-900 text-base sm:text-lg">
                    {isIndonesian ? 'Tingkat Keparahan / Skala Nyeri (NRS / VAS 0-10)' : 'Pain Severity Scale (0-10)'}
                  </h3>
                  <span className={`text-xs font-black px-3 py-1 rounded-full border ${
                    formData.painScaleVas >= 7
                      ? 'bg-rose-50 text-rose-800 border-rose-200'
                      : formData.painScaleVas >= 4
                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                      : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  }`}>
                    {formData.painScaleVas} / 10 {formData.painScaleVas >= 7 ? '(Berat)' : formData.painScaleVas >= 4 ? '(Sedang)' : '(Ringan)'}
                  </span>
                </div>
              </div>

              <div className="space-y-3 p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <input
                  type="range"
                  min="0"
                  max="10"
                  step="1"
                  value={formData.painScaleVas}
                  onChange={(e) => setFormData({ ...formData, painScaleVas: parseInt(e.target.value) })}
                  className="w-full h-3 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                />
                <div className="flex justify-between text-[10px] sm:text-xs font-bold text-slate-500">
                  <span>0 - Bebas Nyeri</span>
                  <span>3 - Nyeri Ringan</span>
                  <span>5 - Mengganggu Fokus</span>
                  <span>7 - Sangat Nyeri</span>
                  <span>10 - Tak Tertahankan</span>
                </div>
              </div>
            </div>

            {/* Bagian 3: Gejala Penyerta Multi-Pills */}
            <div className="space-y-4">
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
                <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                  3
                </div>
                <h3 className="font-black text-slate-900 text-base sm:text-lg">
                  {isIndonesian ? 'Gejala Penyerta Lainnya' : 'Associated Symptoms'}
                </h3>
              </div>

              <div className="flex flex-wrap gap-2">
                {commonSymptoms.map((sym) => {
                  const isSelected = formData.associatedSymptoms.includes(sym);
                  return (
                    <button
                      key={sym}
                      type="button"
                      onClick={() => toggleSymptom(sym)}
                      className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-emerald-600 text-white shadow-xs scale-102 border border-emerald-600'
                          : 'bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                      <span>{sym}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Bagian 4: Riwayat Penyakit & Alergi */}
            <div className="space-y-4">
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
                <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                  4
                </div>
                <h3 className="font-black text-slate-900 text-base sm:text-lg">
                  {isIndonesian ? 'Riwayat Penyakit, Alergi & Obat yang Dikonsumsi' : 'Medical History, Allergies & Current Meds'}
                </h3>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-600 block">
                  {isIndonesian ? 'Riwayat Penyakit Terdahulu:' : 'Existing Chronic Conditions:'}
                </label>
                <div className="flex flex-wrap gap-2">
                  {commonConditions.map((cond) => {
                    const isSelected = formData.existingConditions.includes(cond);
                    return (
                      <button
                        key={cond}
                        type="button"
                        onClick={() => toggleCondition(cond)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-teal-700 text-white border border-teal-700'
                            : 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {cond}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    {isIndonesian ? 'Obat / Suplemen yang Sedang Diminum:' : 'Current Medications:'}
                  </label>
                  <input
                    type="text"
                    value={formData.currentMedications}
                    onChange={(e) => setFormData({ ...formData, currentMedications: e.target.value })}
                    placeholder={isIndonesian ? 'Contoh: Vitamin C, Amlodipine 5mg, dsb (bisa kosong)' : 'E.g., Vit C, Multivitamin'}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    {isIndonesian ? 'Riwayat Alergi Obat / Makanan:' : 'Drug & Food Allergies:'}
                  </label>
                  <input
                    type="text"
                    value={formData.drugOrFoodAllergies}
                    onChange={(e) => setFormData({ ...formData, drugOrFoodAllergies: e.target.value })}
                    placeholder={isIndonesian ? 'Contoh: Alergi Penisilin, Seafood (atau Tidak ada)' : 'E.g., Penicillin allergy'}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* Bagian 5: Tanda Vital Terkini (Opsional/Terpantau) */}
            <div className="space-y-4">
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
                <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                  5
                </div>
                <h3 className="font-black text-slate-900 text-base sm:text-lg">
                  {isIndonesian ? 'Tanda Vital Terkini (Bila Ada Data Pengukuran)' : 'Vital Signs (Optional / Estimated)'}
                </h3>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                  <div className="flex items-center gap-1.5 text-slate-500 text-[10px] font-bold">
                    <Activity className="w-3.5 h-3.5 text-rose-500" />
                    <span>Tekanan Darah (BP)</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      value={formData.vitals.systolicBp || 120}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          vitals: { ...formData.vitals, systolicBp: parseInt(e.target.value) || 120 },
                        })
                      }
                      className="w-14 p-1.5 text-xs font-black bg-white border border-slate-300 rounded-lg text-center"
                    />
                    <span className="text-xs font-bold text-slate-400">/</span>
                    <input
                      type="number"
                      value={formData.vitals.diastolicBp || 80}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          vitals: { ...formData.vitals, diastolicBp: parseInt(e.target.value) || 80 },
                        })
                      }
                      className="w-14 p-1.5 text-xs font-black bg-white border border-slate-300 rounded-lg text-center"
                    />
                    <span className="text-[10px] text-slate-400">mmHg</span>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                  <div className="flex items-center gap-1.5 text-slate-500 text-[10px] font-bold">
                    <Heart className="w-3.5 h-3.5 text-rose-500" />
                    <span>Detak Jantung (HR)</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      value={formData.vitals.heartRateBpm || 76}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          vitals: { ...formData.vitals, heartRateBpm: parseInt(e.target.value) || 76 },
                        })
                      }
                      className="w-16 p-1.5 text-xs font-black bg-white border border-slate-300 rounded-lg text-center"
                    />
                    <span className="text-[10px] text-slate-400">bpm</span>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                  <div className="flex items-center gap-1.5 text-slate-500 text-[10px] font-bold">
                    <Thermometer className="w-3.5 h-3.5 text-amber-500" />
                    <span>Suhu Tubuh (Temp)</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      step="0.1"
                      value={formData.vitals.bodyTempCelsius || 36.8}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          vitals: { ...formData.vitals, bodyTempCelsius: parseFloat(e.target.value) || 36.8 },
                        })
                      }
                      className="w-16 p-1.5 text-xs font-black bg-white border border-slate-300 rounded-lg text-center"
                    />
                    <span className="text-[10px] text-slate-400">°C</span>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                  <div className="flex items-center gap-1.5 text-slate-500 text-[10px] font-bold">
                    <Droplets className="w-3.5 h-3.5 text-cyan-500" />
                    <span>Saturasi Oksigen (SpO2)</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      value={formData.vitals.oxygenSaturationPercent || 98}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          vitals: { ...formData.vitals, oxygenSaturationPercent: parseInt(e.target.value) || 98 },
                        })
                      }
                      className="w-16 p-1.5 text-xs font-black bg-white border border-slate-300 rounded-lg text-center"
                    />
                    <span className="text-[10px] text-slate-400">%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Submit Action Button */}
            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-slate-500 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{isIndonesian ? 'Enkripsi data klinis terisolasi & sesuai standar privasi GDPR' : 'Isolated GDPR-compliant clinical encryption'}</span>
              </div>

              <button
                type="button"
                onClick={handleStartConsultation}
                className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-emerald-700/25 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Stethoscope className="w-4 h-4" />
                <span>{isIndonesian ? 'Mulai Analisis Klinis Dokter AI' : 'Start Clinical AI Diagnostic'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* STEP 2: ANIMASI SCANNING & DIAGNOSTIC REASONING */}
      {currentStep === 'analyzing' && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white border border-emerald-200 rounded-3xl p-12 text-center space-y-6 shadow-xl max-w-xl mx-auto my-8"
        >
          <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
            <div className="absolute inset-0 bg-emerald-500/20 rounded-full animate-ping" />
            <div className="w-20 h-20 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-full flex items-center justify-center text-white shadow-lg relative z-10">
              <Stethoscope className="w-10 h-10 animate-pulse" />
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-xl sm:text-2xl font-black text-slate-900">
              {isIndonesian ? 'Dokter AI Sedang Menganalisis Anamnesis...' : 'Clinical AI Engine Evaluating Anamnesis...'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
              {isIndonesian
                ? 'Memadukan keluhan utama, skala nyeri, riwayat medis, dan tanda vital untuk menentukan triase risiko dan diagnosis banding yang tepat.'
                : 'Correlating chief complaint, pain severity, medical history, and vitals to stratify triage risk and differential diagnoses.'}
            </p>
          </div>

          <div className="flex items-center justify-center gap-2 text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 py-2 px-4 rounded-full max-w-xs mx-auto">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600 animate-spin" />
            <span>Gemini 3.6 Diagnostic Reasoning</span>
          </div>
        </motion.div>
      )}

      {/* STEP 3: HASIL PEMERIKSAAN KLINIS & RESEP DIGITAL */}
      {((consultationMode === 'result' || currentStep === 'result') && examinationResult) && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          {/* Action Ribbon: Re-consult & Print Summary */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black text-slate-700">
                {isIndonesian ? 'Nomor Konsultasi:' : 'Consultation ID:'}
              </span>
              <span className="font-mono text-xs font-black text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                {examinationResult.consultationId}
              </span>
              <span className="text-xs text-slate-400 hidden sm:inline">• {examinationResult.timestamp}</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPrintModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold border border-slate-300 transition-all cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{isIndonesian ? 'Cetak Lembar Rekam Medis' : 'Print Summary'}</span>
              </button>
              <button
                onClick={() => {
                  setCurrentStep('intake');
                  setConsultationMode('whatsapp');
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{isIndonesian ? 'Konsultasi WhatsApp Baru' : 'New Consultation'}</span>
              </button>
            </div>
          </div>

          {/* Triage Level Banner */}
          {(() => {
            const triageInfo = getTriageBadge(examinationResult.triageLevel);
            const TriageIcon = triageInfo.icon;
            return (
              <div className={`p-5 rounded-3xl border ${triageInfo.bg} flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm`}>
                <div className="flex items-center gap-3.5">
                  <div className="p-3 bg-white rounded-2xl shadow-xs shrink-0">
                    <TriageIcon className="w-6 h-6 text-slate-900" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`w-2.5 h-2.5 rounded-full ${triageInfo.indicatorBg} animate-pulse`} />
                      <h3 className="text-base sm:text-lg font-black text-slate-950">
                        {triageInfo.label}
                      </h3>
                    </div>
                    <p className="text-xs sm:text-sm font-medium mt-0.5 leading-relaxed text-slate-800">
                      {examinationResult.triageVerdict}
                    </p>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Red Flags Warning Box if present */}
          {examinationResult.redFlagsWarning && examinationResult.redFlagsWarning.length > 0 && (
            <div className="bg-rose-50 border-2 border-rose-300 rounded-3xl p-5 space-y-2 text-rose-950">
              <div className="flex items-center gap-2 font-black text-sm text-rose-900">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>{isIndonesian ? 'PERINGATAN TANDA BAHAYA (RED FLAGS):' : 'CRITICAL RED FLAGS DETECTED:'}</span>
              </div>
              <ul className="list-disc list-inside text-xs space-y-1 font-semibold text-rose-800">
                {examinationResult.redFlagsWarning.map((flag, idx) => (
                  <li key={idx}>{flag}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Diagnosis Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Primary Diagnosis Sheet */}
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 space-y-5 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                    <FileText className="w-4 h-4" />
                  </div>
                  <h3 className="font-black text-slate-900 text-base">
                    {isIndonesian ? 'Diagnosis Primer & Patofisiologi' : 'Primary Diagnosis & Clinical Reasoning'}
                  </h3>
                </div>
                <span className="text-xs font-extrabold bg-emerald-100 text-emerald-900 px-3 py-1 rounded-full border border-emerald-200">
                  {examinationResult.primaryDiagnosis.confidenceScorePercent}% Confidence
                </span>
              </div>

              <div className="space-y-3">
                <div className="text-lg sm:text-xl font-black text-slate-950">
                  {examinationResult.primaryDiagnosis.conditionName}
                </div>
                <div className="text-xs font-semibold text-slate-500 italic">
                  {examinationResult.primaryDiagnosis.conditionNameEn}
                </div>

                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2">
                  <span className="text-xs font-bold text-slate-700 block">
                    {isIndonesian ? 'Dasar Penalaran Klinis (Clinical Reasoning):' : 'Clinical Reasoning:'}
                  </span>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    {examinationResult.primaryDiagnosis.clinicalReasoning}
                  </p>
                </div>

                <div className="p-3.5 bg-emerald-50/70 rounded-2xl border border-emerald-100 space-y-1.5">
                  <span className="text-xs font-bold text-emerald-900 block">
                    {isIndonesian ? 'Mekanisme / Patofisiologi Tubuh:' : 'Pathophysiology Summary:'}
                  </span>
                  <p className="text-xs text-emerald-800 leading-relaxed">
                    {examinationResult.primaryDiagnosis.pathophysiologySummary}
                  </p>
                </div>
              </div>

              {/* Diagnosis Diferensial / Pembanding */}
              <div className="pt-3 border-t border-slate-100 space-y-2.5">
                <span className="text-xs font-extrabold text-slate-700 block uppercase tracking-wider">
                  {isIndonesian ? 'Diagnosis Banding (Differential Diagnoses):' : 'Differential Diagnoses:'}
                </span>
                <div className="space-y-2">
                  {examinationResult.differentialDiagnoses.map((diff, idx) => (
                    <div key={idx} className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/70 flex items-start justify-between gap-3 text-xs">
                      <div>
                        <div className="font-bold text-slate-900">{diff.conditionName}</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">{diff.reason}</div>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase shrink-0 ${
                        diff.probabilityLevel === 'high'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-200 text-slate-700'
                      }`}>
                        {diff.probabilityLevel}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Prescription & Home Care Guidance */}
            <div className="lg:col-span-5 bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 space-y-5 shadow-xs">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
                <div className="p-2 bg-teal-100 text-teal-800 rounded-xl">
                  <Pill className="w-4 h-4" />
                </div>
                <h3 className="font-black text-slate-900 text-base">
                  {isIndonesian ? 'Panduan Terapi & Perawatan Mandiri' : 'Prescription & Home Care Protocol'}
                </h3>
              </div>

              {/* Non-Pharmacological Care Steps */}
              <div className="space-y-2.5">
                <span className="text-xs font-bold text-slate-700 block">
                  {isIndonesian ? 'Perawatan Non-Farmakologis di Rumah:' : 'Non-Pharmacological Care:'}
                </span>
                <div className="space-y-2">
                  {examinationResult.prescriptionAndHomeCare.nonPharmacologicalCare.map((care, idx) => (
                    <div key={idx} className="p-3 bg-teal-50/60 rounded-2xl border border-teal-100 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-teal-950">{care.title}</span>
                        <span className="text-[10px] bg-teal-200/80 text-teal-900 px-2 py-0.5 rounded-full font-bold">
                          {care.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-teal-800 leading-relaxed">
                        {care.actionGuidance}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Safe OTC Guidance */}
              <div className="space-y-2.5 pt-2">
                <span className="text-xs font-bold text-slate-700 block">
                  {isIndonesian ? 'Panduan Obat Bebas (OTC) Terpilih:' : 'OTC Medication Guidance:'}
                </span>
                <div className="space-y-2">
                  {examinationResult.prescriptionAndHomeCare.otcMedicationGuidance.map((med, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                      <div className="font-bold text-xs text-slate-900">{med.medicineName}</div>
                      <div className="text-[11px] text-slate-700 leading-relaxed">
                        {med.dosageAdvice}
                      </div>
                      <div className="text-[10px] text-rose-700 font-medium">
                        ⚠️ {med.contraindications}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Red Flags When to Go to Hospital */}
              <div className="p-3.5 bg-rose-50/70 rounded-2xl border border-rose-200 space-y-1.5">
                <span className="text-xs font-black text-rose-900 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                  <span>{isIndonesian ? 'Kapan Harus Segera ke IGD / RS?' : 'When to Seek Emergency Care:'}</span>
                </span>
                <ul className="text-[11px] text-rose-800 space-y-1 list-disc list-inside">
                  {examinationResult.prescriptionAndHomeCare.warningSignsToHospital.map((warn, idx) => (
                    <li key={idx}>{warn}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Empathetic Closing Note from Doctor */}
          <div className="p-5 bg-gradient-to-r from-emerald-50 via-white to-teal-50 rounded-3xl border border-emerald-200 flex items-start gap-4">
            <div className="p-3 bg-emerald-600 text-white rounded-2xl shadow-xs shrink-0">
              <Heart className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <span className="font-bold text-xs text-emerald-950">
                {isIndonesian ? 'Pesan Penutup dari Dr. Elena Al-Hafiz, MD:' : 'Closing Note from Dr. Elena Al-Hafiz, MD:'}
              </span>
              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed italic">
                "{examinationResult.empatheticClosingMessage}"
              </p>
            </div>
          </div>

          {/* INTERACTIVE FOLLOW-UP CHAT WITH DOCTOR AI */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-base sm:text-lg">
                    {isIndonesian ? 'Tanya Jawab Lanjutan dengan Dokter AI' : 'Interactive Doctor Follow-Up Consultation'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {isIndonesian ? 'Dokter AI memahami seluruh anamnesis dan hasil diagnosis di atas.' : 'AI Doctor has full memory of your intake and differential diagnosis.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Chat Thread */}
            <div className="space-y-3.5 max-h-96 overflow-y-auto pr-1">
              {chatMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3 ${msg.sender === 'patient' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.sender === 'doctor' && (
                    <div className="w-8 h-8 rounded-xl bg-emerald-700 text-white flex items-center justify-center shrink-0 shadow-xs text-xs font-bold">
                      Dr
                    </div>
                  )}
                  <div
                    className={`max-w-xl p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                      msg.sender === 'patient'
                        ? 'bg-emerald-600 text-white rounded-br-none shadow-xs'
                        : 'bg-slate-100 text-slate-800 rounded-bl-none border border-slate-200/80'
                    }`}
                  >
                    {msg.specialistTitle && (
                      <div className="text-[10px] font-bold text-emerald-800 mb-1">
                        {msg.specialistTitle}
                      </div>
                    )}
                    <div>{msg.text}</div>
                    <div
                      className={`text-[9px] mt-1.5 text-right ${
                        msg.sender === 'patient' ? 'text-emerald-100' : 'text-slate-400'
                      }`}
                    >
                      {msg.timestamp}
                    </div>
                  </div>
                </div>
              ))}

              {isChatLoading && (
                <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 bg-emerald-50 p-3 rounded-2xl max-w-xs border border-emerald-200">
                  <Sparkles className="w-4 h-4 text-emerald-600 animate-spin" />
                  <span>{isIndonesian ? 'Dokter Elena sedang mengetik jawaban...' : 'Doctor is typing response...'}</span>
                </div>
              )}
            </div>

            {/* Chat Input */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
              <input
                type="text"
                value={userChatInput}
                onChange={(e) => setUserChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendChatMessage()}
                placeholder={
                  isIndonesian
                    ? 'Tanyakan apa saja pada Dokter AI (cth: "Apakah saya boleh minum madu?", "Kapan obat ini diminum?")...'
                    : 'Ask anything to the AI Doctor...'
                }
                className="flex-1 p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="button"
                onClick={handleSendChatMessage}
                disabled={isChatLoading || !userChatInput.trim()}
                className="p-3.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-2xl shadow-xs transition-all cursor-pointer shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* PRINT / DOWNLOAD SUMMARY MODAL */}
      <AnimatePresence>
        {isPrintModalOpen && examinationResult && (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl border border-slate-200 max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-base">
                      {isIndonesian ? 'Lembar Ringkasan Rekam Medis Pasien' : 'Patient Clinical Summary Sheet'}
                    </h3>
                    <span className="text-xs text-slate-500 font-mono">
                      Ref: {examinationResult.consultationId}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setIsPrintModalOpen(false)}
                  className="px-3 py-1 text-xs font-bold text-slate-500 hover:text-slate-900 bg-slate-100 rounded-xl"
                >
                  ✕ Tutup
                </button>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-3 font-mono">
                <div className="grid grid-cols-2 gap-2 border-b border-slate-200 pb-2">
                  <div><strong>Pasien:</strong> {formData.patientName}</div>
                  <div><strong>Usia / Gender:</strong> {formData.patientAge} th / {formData.patientGender}</div>
                  <div><strong>Waktu Konsultasi:</strong> {examinationResult.timestamp}</div>
                  <div><strong>Triase:</strong> {examinationResult.triageLevel}</div>
                </div>

                <div className="space-y-1">
                  <div><strong>Keluhan Utama:</strong> {formData.chiefComplaint}</div>
                  <div><strong>Skala Nyeri:</strong> {formData.painScaleVas}/10 ({formData.painCharacter})</div>
                  <div><strong>Gejala Terpilih:</strong> {formData.associatedSymptoms.join(', ') || '-'}</div>
                </div>

                <div className="space-y-1 pt-2 border-t border-slate-200">
                  <div className="text-emerald-800 font-bold">
                    [DIAGNOSIS UTAMA]: {examinationResult.primaryDiagnosis.conditionName}
                  </div>
                  <div>{examinationResult.primaryDiagnosis.clinicalReasoning}</div>
                </div>

                <div className="space-y-1 pt-2 border-t border-slate-200">
                  <div className="font-bold">[RESEP & PERAWATAN NON-FARMAKOLOGIS]:</div>
                  {examinationResult.prescriptionAndHomeCare.nonPharmacologicalCare.map((c, i) => (
                    <div key={i}>• {c.title}: {c.actionGuidance}</div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={() => window.print()}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
                >
                  Cetak / Download PDF
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
