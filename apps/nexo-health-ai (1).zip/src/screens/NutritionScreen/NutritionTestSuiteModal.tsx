import React, { useState } from 'react';
import {
  X,
  Play,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Cpu,
  RefreshCw,
  Terminal,
} from 'lucide-react';
import {
  runNutritionTestSuite,
  NutritionTestSuiteReport,
} from '../../services/nutrition/testNutritionSuite';

interface NutritionTestSuiteModalProps {
  isOpen: boolean;
  onClose: () => void;
  isIndonesian: boolean;
}

export const NutritionTestSuiteModal: React.FC<NutritionTestSuiteModalProps> = ({
  isOpen,
  onClose,
  isIndonesian,
}) => {
  const [report, setReport] = useState<NutritionTestSuiteReport | null>(() => runNutritionTestSuite());
  const [isRunning, setIsRunning] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleRerun = () => {
    setIsRunning(true);
    setTimeout(() => {
      setReport(runNutritionTestSuite());
      setIsRunning(false);
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>{isIndonesian ? 'Unit Test Suite Nutrisi AI (10 Skenario)' : 'Nutrition AI Unit Test Suite'}</span>
                {report && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    {report.passedTests}/{report.totalTests} Passed
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">
                {isIndonesian
                  ? 'Verifikasi otomatis matematika gizi, validasi input, pipeline AI, dan batasan keselamatan.'
                  : 'Automated test runner for nutrition arithmetic, pipeline safety, and edge cases.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Test Cases Results List */}
        <div className="p-5 overflow-y-auto space-y-3 flex-1 text-xs">
          {report?.results.map((test) => (
            <div
              key={test.id}
              className={`p-3.5 rounded-2xl border transition-all space-y-1.5 ${
                test.passed
                  ? 'bg-slate-800/70 border-emerald-500/30'
                  : 'bg-rose-950/20 border-rose-500/40'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  {test.passed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  )}
                  <span className="font-bold text-white text-xs">{test.name}</span>
                </div>

                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-700">
                  {test.category}
                </span>
              </div>

              <p className="text-[11px] text-slate-300 pl-6 leading-relaxed">
                {test.message}
              </p>
            </div>
          ))}
        </div>

        {/* Footer Controls */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{isIndonesian ? '100% Deterministic & Safe Testing' : '100% Safe Verification'}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRerun}
              disabled={isRunning}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg cursor-pointer disabled:opacity-50"
            >
              {isRunning ? (
                <div className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
              ) : (
                <RefreshCw className="w-3.5 h-3.5" />
              )}
              <span>{isIndonesian ? 'Jalankan Ulang Test' : 'Rerun Suite'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
