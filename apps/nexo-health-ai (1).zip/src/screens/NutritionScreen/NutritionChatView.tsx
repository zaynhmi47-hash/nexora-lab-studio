import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  Send,
  Sparkles,
  Bot,
  User,
  ShieldCheck,
  RotateCcw,
  Utensils,
  Lightbulb,
} from 'lucide-react';
import { useNutrition } from '../../context/NutritionContext';
import { useProfile } from '../../context/ProfileContext';

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  suggestedActions?: string[];
}

export const NutritionChatView: React.FC = () => {
  const { dailySummary, foodEntries, currentMealPlan } = useNutrition();
  const { userProfile } = useProfile();
  const isIndonesian = userProfile.language !== 'en';

  const [inputMessage, setInputMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const initialGreeting = isIndonesian
    ? `Halo ${userProfile.name || 'Sobat Sehat'}! Saya Coach Nutrisi AI Anda. Hari ini Anda telah mencatat **${dailySummary.calories} kcal** (${dailySummary.protein}g protein). Ada yang ingin Anda tanyakan seputar resep, makronutrien, atau cara menjaga pola makan seimbang?`
    : `Hello ${userProfile.name || 'Friend'}! I'm your Nutrition AI Coach. You've logged **${dailySummary.calories} kcal** (${dailySummary.protein}g protein) today. How can I assist with recipes, macro pacing, or healthy meal ideas?`;

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_init',
      sender: 'ai',
      text: initialGreeting,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const quickPrompts = isIndonesian
    ? [
        'Berapa target protein ideal untuk tujuan saya?',
        'Ide cemilan sehat tinggi protein & rendah kalori',
        'Bagaimana cara membagi porsi karbohidrat dan sayur?',
        'Rekomendasi menu sarapan praktis sebelum olahraga',
      ]
    : [
        'What is my optimal protein intake target?',
        'High-protein & low-calorie snack ideas',
        'How to balance carbs and veggies on my plate?',
        'Quick pre-workout breakfast recommendations',
      ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputMessage).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg_user_${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      // Build minimal context for Gemini API token efficiency
      const relevantContext = {
        userProfile: {
          name: userProfile.name,
          goal: userProfile.primaryGoal,
          dailyCalorieTarget: userProfile.dailyCalorieTarget || 2000,
          dailyProteinTarget: userProfile.dailyProteinTargetG || 120,
          cuisinePreferences: userProfile.cuisinePreferences,
          dietPreferences: userProfile.dietPreferences,
          foodsToAvoid: userProfile.foodsToAvoid,
        },
        nutritionToday: {
          caloriesConsumed: dailySummary.calories,
          proteinConsumed: dailySummary.protein,
          carbsConsumed: dailySummary.carbs,
          fatConsumed: dailySummary.fat,
          recentFoods: foodEntries.slice(0, 4).map((f) => `${f.name} (${f.estimatedCalories} kcal)`),
        },
      };

      const response = await fetch('/api/ai/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          requestType: 'nutrition',
          relevantContext,
          language: userProfile.language || 'id',
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const resData = await response.json();
      const aiReplyText =
        resData.data?.text ||
        resData.text ||
        (isIndonesian
          ? 'Terima kasih atas pertanyaannya! Menjaga pola makan seimbang dengan protein cukup dan sayuran aneka warna adalah kunci utama konsistensi.'
          : 'Thank you! Balanced nutrition with adequate protein and colorful veggies is key for long-term health.');

      const aiMsg: ChatMessage = {
        id: `msg_ai_${Date.now()}`,
        sender: 'ai',
        text: aiReplyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      console.warn('Nutrition chat fallback:', err);
      // Deterministic supportive fallback
      const fallbackReply = isIndonesian
        ? `Untuk mendukung ${userProfile.primaryGoal || 'kebugaran'} Anda, utamakan asupan protein seperti telur, tempe, dada ayam, atau ikan. Pastikan porsi kalori harian Anda mendekati target ~${userProfile.dailyCalorieTarget || 2000} kcal dengan hidrasi air putih minimal 2 liter sehari.`
        : `To support your ${userProfile.primaryGoal || 'fitness'} goals, prioritize lean protein sources and wholesome complex carbohydrates. Stay hydrated with at least 2 liters of water daily.`;

      setMessages((prev) => [
        ...prev,
        {
          id: `msg_ai_${Date.now()}`,
          sender: 'ai',
          text: fallbackReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetChat = () => {
    setMessages([
      {
        id: 'msg_init',
        sender: 'ai',
        text: initialGreeting,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  return (
    <div id="nutrition-chat-screen" className="flex flex-col h-[calc(100vh-14rem)] min-h-[500px] bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-500 text-slate-950 flex items-center justify-center font-bold">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <span>{isIndonesian ? 'Coach Nutrisi & Pola Gizi AI' : 'Nutrition AI Coach'}</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Gemini Health AI
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              {isIndonesian
                ? 'Konsultasi edukasi gizi, resep, dan strategi pola makan personal.'
                : 'Personalized nutrition guidance, meal ideas, and macro coaching.'}
            </p>
          </div>
        </div>

        <button
          onClick={handleResetChat}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          title={isIndonesian ? 'Mulai Ulang Percakapan' : 'Reset Chat'}
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                  isUser ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-teal-400 border border-slate-700'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[85%] sm:max-w-[75%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed space-y-1.5 ${
                  isUser
                    ? 'bg-emerald-600 text-white rounded-tr-sm shadow-md'
                    : 'bg-slate-800/90 text-slate-200 border border-slate-700/80 rounded-tl-sm shadow-sm'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>
                <div className="text-[10px] text-right opacity-60 font-mono">{msg.timestamp}</div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-slate-800 text-teal-400 border border-slate-700 flex items-center justify-center">
              <Bot className="w-4 h-4 animate-pulse" />
            </div>
            <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80 text-xs text-slate-400 flex items-center gap-2">
              <div className="w-3 h-3 border-2 border-teal-400 border-t-transparent rounded-full animate-spin" />
              <span>{isIndonesian ? 'Coach sedang merumuskan saran nutrisi...' : 'Coach is analyzing nutrition response...'}</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Bar */}
      <div className="p-2.5 bg-slate-950/60 border-t border-slate-800 overflow-x-auto flex items-center gap-2 text-xs">
        <span className="text-slate-400 text-[11px] font-semibold flex items-center gap-1 pl-1 flex-shrink-0">
          <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
          <span>{isIndonesian ? 'Tanya Cepat:' : 'Quick Questions:'}</span>
        </span>
        {quickPrompts.map((prompt, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => handleSendMessage(prompt)}
            className="px-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 transition-all whitespace-nowrap cursor-pointer text-xs"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Bar & Safety Disclaimer */}
      <div className="p-3.5 bg-slate-950 border-t border-slate-800 space-y-2">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder={
              isIndonesian
                ? 'Tanyakan apa saja tentang nutrisi, resep, atau takaran makro...'
                : 'Ask anything about nutrition, recipes, or macros...'
            }
            className="flex-1 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-teal-500"
          />

          <button
            type="submit"
            disabled={!inputMessage.trim() || isLoading}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg transition-all cursor-pointer disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">{isIndonesian ? 'Kirim' : 'Send'}</span>
          </button>
        </form>

        <div className="flex items-center justify-between text-[10px] text-slate-400 px-1">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>
              {isIndonesian
                ? 'Edukasi gizi & gaya hidup sehat (bukan resep medis / diagnosis penyakit)'
                : 'Educational nutrition guidance (not clinical medical diagnosis)'}
            </span>
          </span>
          <span className="font-mono">Gemini 3.6 Flash</span>
        </div>
      </div>
    </div>
  );
};
