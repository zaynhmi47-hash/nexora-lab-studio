import React, { useState } from 'react';
import {
  Calendar,
  Sparkles,
  RefreshCw,
  Sliders,
  CheckCircle2,
  Utensils,
  ShoppingCart,
  Layers,
  Info,
} from 'lucide-react';
import { useNutrition } from '../../context/NutritionContext';
import { useProfile } from '../../context/ProfileContext';
import { MealPlanCard } from '../../components/nutrition/MealPlanCard';
import { GroceryList } from '../../components/nutrition/GroceryList';
import { FoodPreferencesModal } from './FoodPreferencesModal';
import { Meal } from '../../types/nutrition';

export const MealPlanView: React.FC = () => {
  const {
    currentMealPlan,
    isGeneratingPlan,
    generateMealPlan,
    groceryList,
    toggleGroceryItem,
    addGroceryItem,
    removeGroceryItem,
    clearCheckedGroceryItems,
    addMealPlanToGroceries,
    addFood,
  } = useNutrition();

  const { userProfile, updateProfile } = useProfile();
  const isIndonesian = userProfile.language !== 'en';

  const [planType, setPlanType] = useState<'daily' | 'weekly'>('daily');
  const [isPreferencesOpen, setIsPreferencesOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'plan' | 'groceries'>('plan');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleGenerate = async (type: 'daily' | 'weekly') => {
    setPlanType(type);
    try {
      await generateMealPlan(type);
      setToastMessage(
        isIndonesian
          ? `Rencana makan ${type === 'daily' ? 'harian' : 'mingguan'} berhasil dibuat!`
          : `Meal plan (${type}) generated successfully!`
      );
      setTimeout(() => setToastMessage(null), 3000);
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogMealItem = (meal: Meal) => {
    addFood({
      name: meal.name,
      mealType: meal.type,
      servingAmount: 1,
      servingUnit: meal.portionDesc || 'porsi',
      estimatedCalories: meal.estimatedCalories,
      estimatedProtein: meal.estimatedProtein,
      estimatedCarbs: meal.estimatedCarbs,
      estimatedFat: meal.estimatedFat,
      source: 'manual',
      notes: `Dari Meal Plan: ${meal.healthBenefits || ''}`,
      isVerified: false,
    });

    setToastMessage(
      isIndonesian
        ? `"${meal.name}" berhasil dicatat ke buku makanan!`
        : `"${meal.name}" logged to your food diary!`
    );
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div id="meal-plan-screen" className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 font-semibold">
              AI Meal Planner
            </span>
            <span className="text-xs text-slate-400">Gemini Pro Nutrition Architecture</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
            {isIndonesian ? 'Rencana Menu & Daftar Belanja' : 'Meal Planner & Grocery Checklist'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            {isIndonesian
              ? 'Rencana menu harian & mingguan yang dipersonalisasi sesuai target kalori dan preferensi rasa Anda.'
              : 'Personalized meal schedule tailored to your daily caloric targets and dietary lifestyle.'}
          </p>
        </div>

        {/* Top Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPreferencesOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border border-slate-700"
          >
            <Sliders className="w-3.5 h-3.5 text-teal-400" />
            <span>{isIndonesian ? 'Preferensi Diet' : 'Preferences'}</span>
          </button>

          <button
            onClick={() => handleGenerate(planType)}
            disabled={isGeneratingPlan}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
          >
            {isGeneratingPlan ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                <span>{isIndonesian ? 'Membuat Rencana...' : 'Planning...'}</span>
              </>
            ) : (
              <>
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{isIndonesian ? 'Generate Baru' : 'Regenerate'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2 shadow-lg animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Sub-Tab Navigation: Meal Plan vs Groceries */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('plan')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'plan'
              ? 'bg-teal-600 text-white shadow-md'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <Utensils className="w-3.5 h-3.5" />
          <span>{isIndonesian ? 'Rencana Menu Makan' : 'Meal Schedule'}</span>
        </button>

        <button
          onClick={() => setActiveTab('groceries')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'groceries'
              ? 'bg-teal-600 text-white shadow-md'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          <span>{isIndonesian ? 'Daftar Belanja Bahan' : 'Grocery Checklist'}</span>
          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-300">
            {groceryList.length}
          </span>
        </button>
      </div>

      {/* TAB 1: MEAL PLAN DISPLAY */}
      {activeTab === 'plan' && (
        <div className="space-y-6">
          {/* Quick Plan Switcher */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-semibold">{isIndonesian ? 'Tipe Rencana:' : 'Plan Duration:'}</span>
              <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl">
                <button
                  onClick={() => handleGenerate('daily')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    planType === 'daily' ? 'bg-teal-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {isIndonesian ? 'Harian (1 Hari)' : 'Daily'}
                </button>
                <button
                  onClick={() => handleGenerate('weekly')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    planType === 'weekly' ? 'bg-teal-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {isIndonesian ? 'Mingguan (7 Hari)' : 'Weekly'}
                </button>
              </div>
            </div>

            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-teal-400" />
              <span>
                {isIndonesian
                  ? `Target: ~${userProfile.dailyCalorieTarget || 2000} kcal/hari`
                  : `Target: ~${userProfile.dailyCalorieTarget || 2000} kcal/day`}
              </span>
            </div>
          </div>

          {/* Active Plan Card or Starter Generator Trigger */}
          {currentMealPlan ? (
            <MealPlanCard
              plan={currentMealPlan}
              isIndonesian={isIndonesian}
              onAddToGroceries={addMealPlanToGroceries}
              onLogMealItem={handleLogMealItem}
            />
          ) : (
            <div className="p-10 rounded-3xl bg-slate-900 border border-dashed border-slate-800 text-center space-y-4 shadow-xl">
              <div className="w-14 h-14 rounded-2xl bg-teal-500/10 text-teal-400 mx-auto flex items-center justify-center border border-teal-500/30">
                <Sparkles className="w-7 h-7" />
              </div>
              <div className="max-w-md mx-auto space-y-1">
                <h3 className="text-base font-bold text-white">
                  {isIndonesian ? 'Buat Rencana Menu Personalisasi Pertama Anda' : 'Generate Your First Smart Meal Plan'}
                </h3>
                <p className="text-xs text-slate-400">
                  {isIndonesian
                    ? 'AI merancang menu sarapan, makan siang, makan malam, dan snack sehat yang lezat sesuai target kalori Anda.'
                    : 'AI crafts breakfast, lunch, dinner, and snack options tailored to your macros.'}
                </p>
              </div>
              <button
                onClick={() => handleGenerate('daily')}
                disabled={isGeneratingPlan}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs sm:text-sm shadow-xl transition-all cursor-pointer inline-flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isIndonesian ? 'Mulai Buat Rencana Menu Harian' : 'Generate Daily Meal Plan'}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: GROCERY CHECKLIST */}
      {activeTab === 'groceries' && (
        <GroceryList
          items={groceryList}
          isIndonesian={isIndonesian}
          onToggleItem={toggleGroceryItem}
          onAddItem={addGroceryItem}
          onRemoveItem={removeGroceryItem}
          onClearChecked={clearCheckedGroceryItems}
        />
      )}

      {/* Food Preferences Modal */}
      <FoodPreferencesModal
        isOpen={isPreferencesOpen}
        onClose={() => setIsPreferencesOpen(false)}
        userProfile={userProfile}
        onSavePreferences={(prefs) => {
          updateProfile(prefs);
          setToastMessage(
            isIndonesian ? 'Preferensi pola makan berhasil disimpan!' : 'Preferences saved!'
          );
          setTimeout(() => setToastMessage(null), 3000);
        }}
      />
    </div>
  );
};
