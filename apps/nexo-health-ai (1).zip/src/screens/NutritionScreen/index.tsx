import React, { useState } from 'react';
import {
  Camera,
  Plus,
  Calendar,
  MessageSquare,
  Sparkles,
  Utensils,
  Sliders,
  Terminal,
  ChevronRight,
  TrendingUp,
  Apple,
  RotateCcw,
} from 'lucide-react';
import { useNutrition } from '../../context/NutritionContext';
import { useProfile } from '../../context/ProfileContext';
import { NutritionRing } from '../../components/nutrition/NutritionRing';
import { MacroCard } from '../../components/nutrition/MacroCard';
import { MealCard } from '../../components/nutrition/MealCard';
import { NutritionInsight } from '../../components/nutrition/NutritionInsight';
import { FoodAnalyzer } from '../../components/nutrition/FoodAnalyzer';
import { AddFoodModal } from './AddFoodModal';
import { MealPlanView } from './MealPlanView';
import { NutritionChatView } from './NutritionChatView';
import { FoodPreferencesModal } from './FoodPreferencesModal';
import { NutritionTestSuiteModal } from './NutritionTestSuiteModal';
import { MealType, FoodEntry } from '../../types/nutrition';

type NutritionTab = 'dashboard' | 'camera' | 'meal_plan' | 'chat';

export const NutritionScreen: React.FC = () => {
  const {
    foodEntries,
    dailySummary,
    insights,
    addFood,
    removeFood,
    updateFood,
    clearDay,
  } = useNutrition();

  const { userProfile, updateProfile } = useProfile();
  const isIndonesian = userProfile.language !== 'en';

  const [activeTab, setActiveTab] = useState<NutritionTab>('dashboard');
  const [isAddFoodOpen, setIsAddFoodOpen] = useState<boolean>(false);
  const [isFoodAnalyzerOpen, setIsFoodAnalyzerOpen] = useState<boolean>(false);
  const [isPreferencesOpen, setIsPreferencesOpen] = useState<boolean>(false);
  const [isTestSuiteOpen, setIsTestSuiteOpen] = useState<boolean>(false);
  const [selectedMealTypeForAdd, setSelectedMealTypeForAdd] = useState<MealType>('lunch');

  // Trigger add food for specific meal category
  const handleOpenAddFoodForMeal = (mealType: MealType) => {
    setSelectedMealTypeForAdd(mealType);
    setIsAddFoodOpen(true);
  };

  // Trigger camera analysis for specific meal
  const handleOpenFoodCamera = (mealType: MealType = 'lunch') => {
    setSelectedMealTypeForAdd(mealType);
    setIsFoodAnalyzerOpen(true);
  };

  // Confirm multiple AI candidate items into food log
  const handleConfirmAiFoods = (entries: Omit<FoodEntry, 'id' | 'createdAt'>[]) => {
    entries.forEach((e) => addFood(e));
  };

  return (
    <div id="nutrition-module-root" className="space-y-6 max-w-6xl mx-auto pb-12">
      {/* Top Header & Fast Action Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">
              STEP 5: NUTRITION AI
            </span>
            <span className="text-xs text-slate-400">
              {new Date().toLocaleDateString(isIndonesian ? 'id-ID' : 'en-US', {
                weekday: 'long',
                day: 'numeric',
                month: 'long',
                year: 'numeric',
              })}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">
            {isIndonesian ? 'Pusat Nutrisi & Smart Food Tracking' : 'Nutrition & Smart Food Tracking'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            {isIndonesian
              ? 'Pindai foto hidangan dengan AI, catat makanan harian, dan dapatkan meal plan personal.'
              : 'AI food photo analysis, macro tracking, and personalized adaptive meal plans.'}
          </p>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => handleOpenFoodCamera('lunch')}
            className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-950/40 transition-all cursor-pointer"
          >
            <Camera className="w-4 h-4" />
            <span>{isIndonesian ? 'Scan Foto AI' : 'Scan Food Photo'}</span>
          </button>

          <button
            onClick={() => setIsAddFoodOpen(true)}
            className="px-3.5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border border-slate-700"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>{isIndonesian ? 'Catat Manual' : 'Log Food'}</span>
          </button>

          <button
            onClick={() => setIsTestSuiteOpen(true)}
            className="p-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer border border-slate-700"
            title={isIndonesian ? 'Jalankan 10 Unit Test Nutrisi' : 'Run 10 Nutrition Unit Tests'}
          >
            <Terminal className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsPreferencesOpen(true)}
            className="p-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-teal-400 transition-colors cursor-pointer border border-slate-700"
            title={isIndonesian ? 'Preferensi Pola Makan' : 'Food Preferences'}
          >
            <Sliders className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Tab Navigation Bar */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`px-4 py-2.5 rounded-2xl font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'dashboard'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>{isIndonesian ? 'Dashboard & Buku Makanan' : 'Diary & Overview'}</span>
        </button>

        <button
          onClick={() => setActiveTab('meal_plan')}
          className={`px-4 py-2.5 rounded-2xl font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'meal_plan'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>{isIndonesian ? 'AI Meal Plan & Belanja' : 'Meal Plan & Grocery'}</span>
        </button>

        <button
          onClick={() => setActiveTab('chat')}
          className={`px-4 py-2.5 rounded-2xl font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'chat'
              ? 'bg-emerald-600 text-white shadow-lg'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>{isIndonesian ? 'Coach Nutrisi AI' : 'Nutrition AI Coach'}</span>
        </button>

        <button
          onClick={() => handleOpenFoodCamera('lunch')}
          className="px-3.5 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ml-auto"
        >
          <Camera className="w-3.5 h-3.5" />
          <span>{isIndonesian ? 'Kamera AI' : 'Camera'}</span>
        </button>
      </div>

      {/* TAB 1: MAIN NUTRITION DASHBOARD */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Calorie Ring Gauge & Pacing Stats */}
          <NutritionRing summary={dailySummary} isIndonesian={isIndonesian} />

          {/* Macro Breakdown Strip */}
          <MacroCard summary={dailySummary} isIndonesian={isIndonesian} />

          {/* 4 Meal Slots: Breakfast, Lunch, Dinner, Snack */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Utensils className="w-5 h-5 text-emerald-400" />
                <span>{isIndonesian ? 'Jadwal Makan Hari Ini' : "Today's Meals"}</span>
              </h2>

              {foodEntries.length > 0 && (
                <button
                  onClick={() => clearDay()}
                  className="text-xs text-slate-400 hover:text-rose-400 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{isIndonesian ? 'Reset Hari Ini' : 'Reset Day'}</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <MealCard
                mealSummary={dailySummary.mealsBreakdown.breakfast}
                isIndonesian={isIndonesian}
                onAddFoodClick={handleOpenAddFoodForMeal}
                onDeleteEntry={removeFood}
              />

              <MealCard
                mealSummary={dailySummary.mealsBreakdown.lunch}
                isIndonesian={isIndonesian}
                onAddFoodClick={handleOpenAddFoodForMeal}
                onDeleteEntry={removeFood}
              />

              <MealCard
                mealSummary={dailySummary.mealsBreakdown.dinner}
                isIndonesian={isIndonesian}
                onAddFoodClick={handleOpenAddFoodForMeal}
                onDeleteEntry={removeFood}
              />

              <MealCard
                mealSummary={dailySummary.mealsBreakdown.snack}
                isIndonesian={isIndonesian}
                onAddFoodClick={handleOpenAddFoodForMeal}
                onDeleteEntry={removeFood}
              />
            </div>
          </div>

          {/* Rule-Based Nutrition Insights */}
          <NutritionInsight insights={insights} isIndonesian={isIndonesian} />
        </div>
      )}

      {/* TAB 2: MEAL PLAN & GROCERIES */}
      {activeTab === 'meal_plan' && <MealPlanView />}

      {/* TAB 3: NUTRITION COACH CHAT */}
      {activeTab === 'chat' && <NutritionChatView />}

      {/* MODALS */}
      {/* 1. Add Food Modal (Manual, Barcode, Catalog) */}
      <AddFoodModal
        isOpen={isAddFoodOpen}
        onClose={() => setIsAddFoodOpen(false)}
        onAddEntry={addFood}
        userProfile={userProfile}
        initialMealType={selectedMealTypeForAdd}
      />

      {/* 2. AI Food Analyzer Modal (Camera / Photo / Gemini Multimodal) */}
      <FoodAnalyzer
        isOpen={isFoodAnalyzerOpen}
        onClose={() => setIsFoodAnalyzerOpen(false)}
        onConfirmLog={handleConfirmAiFoods}
        userProfile={userProfile}
        initialMealType={selectedMealTypeForAdd}
      />

      {/* 3. Food Preferences Modal */}
      <FoodPreferencesModal
        isOpen={isPreferencesOpen}
        onClose={() => setIsPreferencesOpen(false)}
        userProfile={userProfile}
        onSavePreferences={(prefs) => updateProfile(prefs)}
      />

      {/* 4. Automated 10 Unit Tests Modal */}
      <NutritionTestSuiteModal
        isOpen={isTestSuiteOpen}
        onClose={() => setIsTestSuiteOpen(false)}
        isIndonesian={isIndonesian}
      />
    </div>
  );
};

export { NutritionScreen as NutritionScannerView };
export default NutritionScreen;
