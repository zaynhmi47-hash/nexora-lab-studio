import React, { useState } from 'react';
import {
  X,
  PenTool,
  QrCode,
  Search,
  Plus,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Info,
} from 'lucide-react';
import { FoodEntry, MealType } from '../../types/nutrition';
import { BarcodeService } from '../../services/nutrition/barcodeScanner';
import { UserProfile } from '../../types';

interface AddFoodModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddEntry: (entry: Omit<FoodEntry, 'id' | 'createdAt'>) => void;
  userProfile: UserProfile;
  initialMealType?: MealType;
}

export const AddFoodModal: React.FC<AddFoodModalProps> = ({
  isOpen,
  onClose,
  onAddEntry,
  userProfile,
  initialMealType = 'lunch',
}) => {
  const isIndonesian = userProfile.language !== 'en';
  const [activeTab, setActiveTab] = useState<'manual' | 'barcode' | 'search'>('manual');

  // Manual Form State
  const [mealType, setMealType] = useState<MealType>(initialMealType);
  const [name, setName] = useState<string>('');
  const [servingAmount, setServingAmount] = useState<number>(100);
  const [servingUnit, setServingUnit] = useState<string>('g');
  const [calories, setCalories] = useState<number>(150);
  const [protein, setProtein] = useState<number>(10);
  const [carbs, setCarbs] = useState<number>(20);
  const [fat, setFat] = useState<number>(4);
  const [fiber, setFiber] = useState<number>(2);
  const [sodium, setSodium] = useState<number>(50);
  const [notes, setNotes] = useState<string>('');

  // Barcode Lookup State
  const [barcodeInput, setBarcodeInput] = useState<string>('');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scannedResult, setScannedResult] = useState<any | null>(null);
  const [barcodeError, setBarcodeError] = useState<string | null>(null);

  // Search Catalog State
  const [searchQuery, setSearchQuery] = useState<string>('');

  const sampleCatalog = [
    { name: 'Nasi Merah Organik Matang', serving: '150g (1 piring)', cal: 210, p: 5, c: 45, f: 1.5, fib: 3 },
    { name: 'Dada Ayam Rebus / Kukus', serving: '150g fillet', cal: 200, p: 40, c: 0, f: 3.5, fib: 0 },
    { name: 'Telur Ayam Omega Rebus (2 butir)', serving: '100g', cal: 140, p: 13, c: 1, f: 10, fib: 0 },
    { name: 'Tempe Kedelai Panggang', serving: '100g (2 potong)', cal: 190, p: 19, c: 9, f: 11, fib: 6 },
    { name: 'Tahu Putih Kukus Bening', serving: '120g', cal: 90, p: 10, c: 2, f: 5, fib: 1 },
    { name: 'Tumis Brokoli Minyak Zaitun', serving: '120g (1 mangkuk)', cal: 85, p: 3, c: 8, f: 5, fib: 4 },
    { name: 'Sayur Bayam Jagung Manis', serving: '150g mangkuk', cal: 65, p: 3, c: 12, f: 1, fib: 3 },
    { name: 'Ikan Kembung / Salmon Panggang', serving: '120g', cal: 220, p: 26, c: 0, f: 12, fib: 0 },
    { name: 'Oatmeal Gandum & Susu Rendah Lemak', serving: '250g mangkuk', cal: 260, p: 11, c: 44, f: 5, fib: 5 },
    { name: 'Greek Yogurt Plain & Biji Chia', serving: '150g', cal: 130, p: 14, c: 8, f: 4, fib: 3 },
  ];

  if (!isOpen) return null;

  // Handle Manual Save
  const handleSaveManual = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onAddEntry({
      name: name.trim(),
      mealType,
      servingAmount: Math.max(1, Number(servingAmount) || 100),
      servingUnit: servingUnit.trim() || 'g',
      estimatedCalories: Math.max(0, Number(calories) || 0),
      estimatedProtein: Math.max(0, Number(protein) || 0),
      estimatedCarbs: Math.max(0, Number(carbs) || 0),
      estimatedFat: Math.max(0, Number(fat) || 0),
      estimatedFiber: Math.max(0, Number(fiber) || 0),
      estimatedSodium: Math.max(0, Number(sodium) || 0),
      source: 'manual',
      notes: notes.trim() || undefined,
      isVerified: true,
    });

    onClose();
  };

  // Handle Barcode Search
  const handleBarcodeLookup = async (codeToLookup?: string) => {
    const code = codeToLookup || barcodeInput.trim();
    if (!code) return;

    try {
      setIsScanning(true);
      setBarcodeError(null);
      const product = await BarcodeService.lookupFoodByBarcode(code);
      if (product) {
        setScannedResult(product);
      } else {
        setBarcodeError(isIndonesian ? 'Barcode tidak ditemukan dalam database sampel.' : 'Barcode not found in sample database.');
      }
    } catch (err: any) {
      setBarcodeError(err.message || 'Lookup error');
    } finally {
      setIsScanning(false);
    }
  };

  const handleSaveScannedBarcode = () => {
    if (!scannedResult) return;
    const entryData = BarcodeService.convertToFoodEntry(scannedResult, mealType);
    onAddEntry(entryData);
    onClose();
  };

  // Handle Pick from Quick Catalog
  const handleSelectFromCatalog = (item: typeof sampleCatalog[0]) => {
    onAddEntry({
      name: item.name,
      mealType,
      servingAmount: 1,
      servingUnit: item.serving,
      estimatedCalories: item.cal,
      estimatedProtein: item.p,
      estimatedCarbs: item.c,
      estimatedFat: item.f,
      estimatedFiber: item.fib,
      source: 'manual',
      notes: 'Dipilih dari database makanan sehat terverifikasi',
      isVerified: true,
    });
    onClose();
  };

  const filteredCatalog = sampleCatalog.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <Plus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {isIndonesian ? 'Catat Makanan Baru' : 'Log Food Entry'}
              </h3>
              <p className="text-xs text-slate-400">
                {isIndonesian
                  ? 'Input manual, cari referensi gizi, atau pindai kode produk barcode.'
                  : 'Manual input, fast catalog search, or sample barcode lookup.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="p-3 border-b border-slate-800/80 bg-slate-950/40 flex items-center gap-2">
          <button
            onClick={() => setActiveTab('manual')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'manual'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <PenTool className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Input Manual' : 'Manual Entry'}</span>
          </button>

          <button
            onClick={() => setActiveTab('search')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'search'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Cari Menu Sehat' : 'Catalog Search'}</span>
          </button>

          <button
            onClick={() => setActiveTab('barcode')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'barcode'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>{isIndonesian ? 'Barcode Produk' : 'Barcode Lookup'}</span>
          </button>
        </div>

        {/* Meal Type Global Selector for this Session */}
        <div className="px-5 pt-3 flex items-center gap-2 text-xs">
          <span className="text-slate-400 font-semibold">{isIndonesian ? 'Sesi Makan:' : 'Meal:'}</span>
          {(['breakfast', 'lunch', 'dinner', 'snack'] as MealType[]).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setMealType(t)}
              className={`px-3 py-1 rounded-xl capitalize font-semibold transition-all cursor-pointer ${
                mealType === t
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-slate-800/80 text-slate-400 hover:text-white'
              }`}
            >
              {t === 'breakfast'
                ? (isIndonesian ? 'Sarapan' : 'Breakfast')
                : t === 'lunch'
                ? (isIndonesian ? 'Makan Siang' : 'Lunch')
                : t === 'dinner'
                ? (isIndonesian ? 'Malam' : 'Dinner')
                : (isIndonesian ? 'Snack' : 'Snack')}
            </button>
          ))}
        </div>

        {/* Modal Tab Content */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* TAB 1: MANUAL ENTRY FORM */}
          {activeTab === 'manual' && (
            <form onSubmit={handleSaveManual} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-300">
                  {isIndonesian ? 'Nama Makanan / Hidangan *' : 'Food Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={isIndonesian ? 'Misal: Nasi Merah, Dada Ayam Bakar, Sup Sayur' : 'e.g. Grilled Chicken Breast with Veggies'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">{isIndonesian ? 'Takaran Porsi' : 'Serving Amount'}</label>
                  <input
                    type="number"
                    value={servingAmount}
                    onChange={(e) => setServingAmount(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-slate-300">{isIndonesian ? 'Satuan' : 'Unit'}</label>
                  <input
                    type="text"
                    value={servingUnit}
                    onChange={(e) => setServingUnit(e.target.value)}
                    placeholder="g / porsi / mangkuk"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Nutritional Estimates Grid */}
              <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-3">
                <span className="font-bold text-white block">{isIndonesian ? 'Estimasi Kandungan Gizi:' : 'Nutritional Estimates:'}</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div>
                    <label className="text-[10px] text-slate-400 block font-bold">Kalori (kcal) *</label>
                    <input
                      type="number"
                      required
                      value={calories}
                      onChange={(e) => setCalories(Number(e.target.value))}
                      className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-emerald-400 block font-bold">Protein (g)</label>
                    <input
                      type="number"
                      value={protein}
                      onChange={(e) => setProtein(Number(e.target.value))}
                      className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-emerald-300 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-teal-400 block font-bold">Karbohidrat (g)</label>
                    <input
                      type="number"
                      value={carbs}
                      onChange={(e) => setCarbs(Number(e.target.value))}
                      className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-teal-300 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-amber-400 block font-bold">Lemak (g)</label>
                    <input
                      type="number"
                      value={fat}
                      onChange={(e) => setFat(Number(e.target.value))}
                      className="w-full px-2.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-amber-300 text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <div>
                    <label className="text-[10px] text-slate-400 block">Serat (Fiber g) - Opsional</label>
                    <input
                      type="number"
                      value={fiber}
                      onChange={(e) => setFiber(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block">Sodium (mg) - Opsional</label>
                    <input
                      type="number"
                      value={sodium}
                      onChange={(e) => setSodium(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-300">{isIndonesian ? 'Catatan Tambahan (Opsional)' : 'Notes'}</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={isIndonesian ? 'Contoh: Masak sendiri tanpa penyedap' : 'e.g. Home cooked'}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isIndonesian ? 'Simpan ke Buku Makanan' : 'Save to Food Diary'}</span>
              </button>
            </form>
          )}

          {/* TAB 2: SEARCH POPULAR CATALOG */}
          {activeTab === 'search' && (
            <div className="space-y-3 text-xs">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={isIndonesian ? 'Cari nama makanan sehat (misal: Ayam, Oatmeal, Tempe)...' : 'Search healthy catalog...'}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="space-y-2">
                {filteredCatalog.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => handleSelectFromCatalog(item)}
                    className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80 hover:border-emerald-500/60 hover:bg-slate-800 transition-all flex items-center justify-between gap-3 cursor-pointer group"
                  >
                    <div>
                      <h4 className="font-bold text-white text-xs group-hover:text-emerald-300 transition-colors">
                        {item.name}
                      </h4>
                      <span className="text-[11px] text-slate-400">
                        {item.serving} • P: {item.p}g • C: {item.c}g • F: {item.f}g
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-bold text-white font-mono">{item.cal} kcal</span>
                      <button className="p-1.5 rounded-xl bg-slate-700 text-emerald-400 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: BARCODE SCANNER LOOKUP */}
          {activeTab === 'barcode' && (
            <div className="space-y-4 text-xs">
              <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={barcodeInput}
                    onChange={(e) => setBarcodeInput(e.target.value)}
                    placeholder="Masukkan atau scan barcode (e.g. 8996001301014)"
                    className="flex-1 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={() => handleBarcodeLookup()}
                    disabled={isScanning || !barcodeInput.trim()}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {isScanning ? (
                      <div className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                    ) : (
                      <Search className="w-3.5 h-3.5" />
                    )}
                    <span>{isIndonesian ? 'Cari' : 'Lookup'}</span>
                  </button>
                </div>

                {barcodeError && (
                  <p className="text-rose-400 text-xs flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>{barcodeError}</span>
                  </p>
                )}
              </div>

              {/* Sample Barcodes Quick Try */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 block uppercase">
                  {isIndonesian ? 'Contoh Barcode Sampel (Mock Catalog Step 5):' : 'Sample Barcode Catalog:'}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {BarcodeService.getSampleBarcodes().slice(0, 4).map((b) => (
                    <button
                      key={b.barcode}
                      type="button"
                      onClick={() => {
                        setBarcodeInput(b.barcode);
                        handleBarcodeLookup(b.barcode);
                      }}
                      className="p-2 rounded-xl bg-slate-800/80 border border-slate-700/80 text-left hover:border-emerald-500 transition-all cursor-pointer flex items-center justify-between"
                    >
                      <div className="min-w-0 pr-1">
                        <span className="font-semibold text-white block truncate">{b.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{b.barcode}</span>
                      </div>
                      <span className="font-mono font-bold text-emerald-400 text-xs flex-shrink-0">{b.estimatedCalories} kcal</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Scanned Result Review */}
              {scannedResult && (
                <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">
                        Produk Terverifikasi (Mock)
                      </span>
                      <h4 className="font-bold text-white text-sm mt-1">{scannedResult.name}</h4>
                      <span className="text-[11px] text-slate-400 block">
                        {scannedResult.brand} • {scannedResult.servingAmount} {scannedResult.servingUnit}
                      </span>
                    </div>

                    <div className="text-right font-mono">
                      <span className="text-lg font-black text-white">{scannedResult.estimatedCalories}</span>
                      <span className="text-xs text-slate-400 ml-1">kcal</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 font-mono text-[11px]">
                    <span className="px-2 py-0.5 rounded bg-slate-900 text-emerald-300">P: {scannedResult.estimatedProtein}g</span>
                    <span className="px-2 py-0.5 rounded bg-slate-900 text-teal-300">C: {scannedResult.estimatedCarbs}g</span>
                    <span className="px-2 py-0.5 rounded bg-slate-900 text-amber-300">F: {scannedResult.estimatedFat}g</span>
                  </div>

                  <button
                    onClick={handleSaveScannedBarcode}
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{isIndonesian ? 'Konfirmasi & Catat Produk Ini' : 'Confirm & Log Barcode'}</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
