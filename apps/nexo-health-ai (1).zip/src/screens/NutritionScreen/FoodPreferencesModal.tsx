import React, { useState } from 'react';
import { X, Check, Utensils, Heart, ShieldAlert, Sparkles } from 'lucide-react';
import { UserProfile } from '../../types';

interface FoodPreferencesModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onSavePreferences: (prefs: {
    cuisinePreferences: string[];
    dietPreferences: string[];
    foodsToAvoid: string[];
  }) => void;
}

export const FoodPreferencesModal: React.FC<FoodPreferencesModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onSavePreferences,
}) => {
  const isIndonesian = userProfile.language !== 'en';

  const cuisineOptions = [
    { id: 'indonesian', label: isIndonesian ? 'Nusantara / Masakan Indonesia' : 'Indonesian Cuisine' },
    { id: 'asian', label: isIndonesian ? 'Asia Sehat (Jepang, Korea, Thai)' : 'Healthy Asian' },
    { id: 'mediterranean', label: isIndonesian ? 'Mediterania (Minyak Zaitun, Ikan)' : 'Mediterranean' },
    { id: 'western', label: isIndonesian ? 'Western Seimbang' : 'Balanced Western' },
    { id: 'middle_eastern', label: isIndonesian ? 'Timur Tengah' : 'Middle Eastern' },
  ];

  const dietOptions = [
    { id: 'high_protein', label: isIndonesian ? 'Tinggi Protein (Muscle & Fitness)' : 'High Protein' },
    { id: 'halal', label: isIndonesian ? 'Halal' : 'Halal' },
    { id: 'clean_eating', label: isIndonesian ? 'Clean Eating (Minim Minyak & Gula)' : 'Clean Eating' },
    { id: 'low_carb', label: isIndonesian ? 'Rendah Karbohidrat' : 'Low Carb' },
    { id: 'plant_based', label: isIndonesian ? 'Vegetarian / Plant-Based' : 'Plant-Based' },
    { id: 'pescatarian', label: isIndonesian ? 'Pescatarian (Ikan & Seafood)' : 'Pescatarian' },
  ];

  const avoidOptions = [
    { id: 'peanuts', label: isIndonesian ? 'Kacang Tanah' : 'Peanuts' },
    { id: 'seafood_allergy', label: isIndonesian ? 'Udang / Seafood' : 'Shellfish / Seafood' },
    { id: 'dairy_lactose', label: isIndonesian ? 'Laktosa / Susu Sapi' : 'Lactose / Dairy' },
    { id: 'gluten', label: isIndonesian ? 'Gluten / Tepung Terigu' : 'Gluten' },
    { id: 'deep_fried', label: isIndonesian ? 'Gorengan Berminyak Berlebih' : 'Deep Fried Foods' },
    { id: 'added_sugar', label: isIndonesian ? 'Gula Tambahan / Pemanis Buatan' : 'Added Sugars' },
  ];

  const [selectedCuisines, setSelectedCuisines] = useState<string[]>(
    userProfile.cuisinePreferences || ['indonesian', 'asian']
  );
  const [selectedDiets, setSelectedDiets] = useState<string[]>(
    userProfile.dietPreferences || ['high_protein', 'halal']
  );
  const [selectedAvoids, setSelectedAvoids] = useState<string[]>(
    userProfile.foodsToAvoid || []
  );

  if (!isOpen) return null;

  const toggleCuisine = (id: string) => {
    setSelectedCuisines((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const toggleDiet = (id: string) => {
    setSelectedDiets((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const toggleAvoid = (id: string) => {
    setSelectedAvoids((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleSave = () => {
    onSavePreferences({
      cuisinePreferences: selectedCuisines,
      dietPreferences: selectedDiets,
      foodsToAvoid: selectedAvoids,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/30">
              <Utensils className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {isIndonesian ? 'Preferensi Gizi & Pola Makan' : 'Food & Dietary Preferences'}
              </h3>
              <p className="text-xs text-slate-400">
                {isIndonesian
                  ? 'Menyesuaikan saran resep, meal plan, dan analisis AI secara personal.'
                  : 'Tailors meal plans and nutrition advice to your personal lifestyle.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Cuisines */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{isIndonesian ? 'Preferensi Masakan & Rasa' : 'Cuisine Preferences'}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {cuisineOptions.map((opt) => {
                const isSelected = selectedCuisines.includes(opt.id);
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => toggleCuisine(opt.id)}
                    className={`p-3 rounded-2xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-950/40 border-emerald-500 text-emerald-200'
                        : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:border-slate-600'
                    }`}
                  >
                    <span className="font-medium">{opt.label}</span>
                    <div
                      className={`w-4 h-4 rounded-md flex items-center justify-center border ${
                        isSelected ? 'bg-emerald-500 border-emerald-400 text-slate-950' : 'border-slate-600'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Diets */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white flex items-center gap-2">
              <Heart className="w-4 h-4 text-rose-400" />
              <span>{isIndonesian ? 'Gaya Pola Makan / Diet' : 'Dietary Styles'}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {dietOptions.map((opt) => {
                const isSelected = selectedDiets.includes(opt.id);
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => toggleDiet(opt.id)}
                    className={`p-3 rounded-2xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-teal-950/40 border-teal-500 text-teal-200'
                        : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:border-slate-600'
                    }`}
                  >
                    <span className="font-medium">{opt.label}</span>
                    <div
                      className={`w-4 h-4 rounded-md flex items-center justify-center border ${
                        isSelected ? 'bg-teal-500 border-teal-400 text-slate-950' : 'border-slate-600'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Avoid / Allergies */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>{isIndonesian ? 'Pantangan / Makanan Dihindari' : 'Foods to Avoid / Allergies'}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {avoidOptions.map((opt) => {
                const isSelected = selectedAvoids.includes(opt.id);
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => toggleAvoid(opt.id)}
                    className={`p-3 rounded-2xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-950/40 border-amber-500 text-amber-200'
                        : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:border-slate-600'
                    }`}
                  >
                    <span className="font-medium">{opt.label}</span>
                    <div
                      className={`w-4 h-4 rounded-md flex items-center justify-center border ${
                        isSelected ? 'bg-amber-500 border-amber-400 text-slate-950' : 'border-slate-600'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
          >
            {isIndonesian ? 'Batal' : 'Cancel'}
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shadow-lg cursor-pointer"
          >
            {isIndonesian ? 'Simpan Preferensi' : 'Save Preferences'}
          </button>
        </div>
      </div>
    </div>
  );
};
