import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  MessageSquareHeart,
  Brain,
  Shield,
  Sparkles,
  ArrowLeft,
  Send,
  CheckCircle2,
  RefreshCw,
  Heart,
  Lightbulb,
  Compass,
  Zap,
  Plus,
} from 'lucide-react';
import { UserProfile } from '../../types';

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
  suggestion?: string[];
}

interface CbtTherapyScreenProps {
  userProfile: UserProfile;
  onNavigateTab?: (tab: any) => void;
  onAwardXp?: (xp: number) => void;
  onOpenAddDataModal?: (moduleId?: string) => void;
}

export const CbtTherapyScreen: React.FC<CbtTherapyScreenProps> = ({
  userProfile,
  onNavigateTab,
  onAwardXp,
  onOpenAddDataModal,
}) => {
  const isIndonesian = userProfile.language === 'id';

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'ai',
      text: isIndonesian
        ? `Halo ${userProfile.name}. Saya adalah pendamping terapi kognitif perilaku (CBT) Anda. Apa pikiran atau situasi yang sedang membebani Anda hari ini? Mari kita periksa bukti dan susun perspektif yang lebih seimbang bersama.`
        : `Hello ${userProfile.name}. I am your CBT companion. What thoughts or emotions are weighing on you today? Let's examine the evidence and reframe them constructively.`,
      timestamp: '14:20',
      suggestion: isIndonesian
        ? ['Saya merasa kewalahan dengan pekerjaan', 'Saya takut membuat kesalahan', 'Teknik Grounding 5-4-3-2-1']
        : ['Overwhelmed with deadlines', 'Fear of failure', '5-4-3-2-1 Grounding Drill'],
    },
  ]);

  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // 5-4-3-2-1 Grounding Interactive State
  const [groundingStep, setGroundingStep] = useState<number | null>(null);

  const groundingStepsData = [
    { count: 5, sense: isIndonesian ? '5 Benda yang Anda LIHAT di sekitar' : '5 Things you SEE', prompt: isIndonesian ? 'Sebutkan 5 objek visual di ruangan Anda...' : 'Name 5 visual objects around you...' },
    { count: 4, sense: isIndonesian ? '4 Tekstur yang dapat Anda SENTUH' : '4 Things you TOUCH', prompt: isIndonesian ? 'Rasakan kain baju, meja, atau sandaran kursi...' : 'Feel your clothes, desk texture, or feet on floor...' },
    { count: 3, sense: isIndonesian ? '3 Suara yang Anda DENGAR' : '3 Things you HEAR', prompt: isIndonesian ? 'Dengarkan dengung AC, lalu lintas jauh, atau napas Anda...' : 'Listen to ambient hums, footsteps, or breathing...' },
    { count: 2, sense: isIndonesian ? '2 Aroma yang dapat Anda CIUM' : '2 Scents you SMELL', prompt: isIndonesian ? 'Aroma kopi, udara segar, atau aroma ruangan...' : 'Scent of coffee, air, or soap...' },
    { count: 1, sense: isIndonesian ? '1 Rasa di LIDAH atau Apresiasi Diri' : '1 Thing you TASTE / Grateful for', prompt: isIndonesian ? 'Satu hal positif tentang diri Anda saat ini...' : 'One strength you appreciate about yourself...' },
  ];

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsTyping(true);

    if (onAwardXp) onAwardXp(20);

    setTimeout(() => {
      setIsTyping(false);
      const aiReply: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: isIndonesian
          ? `Terima kasih telah berbagi, ${userProfile.name}. Dari sudut pandang CBT, mari kita identifikasi: Apakah ada jebakan distorsi kognitif seperti *Catastrophizing* (membayangkan kemungkinan terburuk) atau *All-or-Nothing Thinking*? Ingat, pikiran kita adalah hipotesis, bukan fakta mutlak. Bagaimana jika kita merumuskan 1 tindakan kecil yang berada dalam kendali Anda 10 menit ke depan?`
          : `Thank you for sharing, ${userProfile.name}. In cognitive therapy, let's explore if this thought involves *Catastrophizing* or *All-or-Nothing Thinking*. Thoughts are mental events, not absolute facts. What is one microscopic step fully within your locus of control right now?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestion: isIndonesian
          ? ['Lakukan Reframing Pikiran', 'Mulai Grounding 5-4-3-2-1', 'Tulis 1 Tindakan Mikro']
          : ['Cognitive Reframing', 'Start 5-4-3-2-1 Grounding', 'Micro Action Step'],
      };
      setMessages((prev) => [...prev, aiReply]);
    }, 1200);
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6 text-slate-800 selection:bg-indigo-500 selection:text-white w-full max-w-full overflow-hidden">
      {/* Top Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <button
          onClick={() => onNavigateTab ? onNavigateTab('modules_hub') : undefined}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white hover:bg-slate-100 border border-slate-200 text-xs font-black text-slate-800 hover:text-indigo-700 transition-all shadow-2xs cursor-pointer w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isIndonesian ? 'Kembali ke Pusat Modul' : 'Back to Module Hub'}</span>
        </button>

        <div className="flex items-center gap-3">
          {onOpenAddDataModal && (
            <button
              onClick={() => onOpenAddDataModal('m11_cbt_therapy')}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isIndonesian ? 'Tambah Log CBT' : 'Log CBT Session'}</span>
            </button>
          )}

          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span className="hidden sm:inline">Modul #11:</span>
            <span className="px-3 py-1 rounded-full bg-indigo-100 text-indigo-900 font-extrabold border border-indigo-300">
              {isIndonesian ? 'Terapi Percakapan CBT Berbasis AI' : '24/7 AI CBT Conversational Therapy'}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Header */}
      <div className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-slate-900 rounded-[32px] p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-indigo-100 text-xs font-black">
              <MessageSquareHeart className="w-3.5 h-3.5 text-indigo-300" />
              <span>{isIndonesian ? 'Restrukturisasi Kognitif & Grounding 24/7' : 'Cognitive Restructuring & Grounding'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-white">
              {isIndonesian ? 'Terapi Percakapan CBT Berbasis AI' : 'AI CBT Conversational Therapy'}
            </h1>
            <p className="text-xs sm:text-sm text-indigo-100/90 max-w-2xl leading-relaxed font-medium">
              {isIndonesian
                ? 'Dialog terarah berbasis Cognitive Behavioral Therapy untuk mengurai kecemasan, mengidentifikasi bias kognitif, dan mengembalikan regulasi emosional secara ilmiah.'
                : 'Evidence-based cognitive restructuring dialogues to disarm automatic negative thoughts and restore emotional clarity.'}
            </p>
          </div>

          <div className="flex gap-2 shrink-0">
            <button
              onClick={() => setGroundingStep(0)}
              className="px-4 py-2.5 rounded-2xl bg-white/15 hover:bg-white/25 border border-white/20 text-white text-xs font-bold transition-all flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{isIndonesian ? 'Teknik 5-4-3-2-1' : '5-4-3-2-1 Drill'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 5-4-3-2-1 Grounding Modal Overlay */}
      {groundingStep !== null && (
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200 rounded-3xl p-6 space-y-4 shadow-sm animate-in fade-in duration-300">
          <div className="flex items-center justify-between border-b border-indigo-100 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-xl bg-indigo-600 text-white font-black text-sm flex items-center justify-center">
                {groundingStepsData[groundingStep].count}
              </span>
              <h3 className="text-sm font-black text-indigo-950">
                {groundingStepsData[groundingStep].sense}
              </h3>
            </div>
            <button
              onClick={() => setGroundingStep(null)}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer"
            >
              Tutup
            </button>
          </div>
          <p className="text-xs text-indigo-900 font-medium leading-relaxed">
            {groundingStepsData[groundingStep].prompt}
          </p>
          <div className="flex justify-between items-center pt-2">
            <span className="text-[11px] font-bold text-indigo-500">Langkah {groundingStep + 1} dari 5</span>
            <button
              onClick={() => {
                if (groundingStep < 4) {
                  setGroundingStep(groundingStep + 1);
                } else {
                  setGroundingStep(null);
                  if (onAwardXp) onAwardXp(50);
                  alert(isIndonesian ? 'Latihan Grounding Selesai! Pikiran kembali tenang. +50 XP' : 'Grounding complete! +50 XP');
                }
              }}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold cursor-pointer"
            >
              {groundingStep < 4 ? (isIndonesian ? 'Lanjut ke Langkah Berikutnya' : 'Next Step') : (isIndonesian ? 'Selesaikan Sesi' : 'Complete')}
            </button>
          </div>
        </div>
      )}

      {/* Main Chat Interface */}
      <div className="bg-white border border-slate-200/90 rounded-[32px] p-6 sm:p-8 space-y-4 shadow-sm flex flex-col h-[520px]">
        {/* Messages List */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-3xl p-4 sm:p-5 text-xs sm:text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-indigo-600 text-white rounded-br-xs'
                    : 'bg-slate-100 text-slate-800 rounded-bl-xs border border-slate-200/80 font-medium'
                }`}
              >
                <p>{msg.text}</p>
                <span
                  className={`text-[10px] mt-1.5 block font-mono ${
                    msg.sender === 'user' ? 'text-indigo-200' : 'text-slate-400'
                  }`}
                >
                  {msg.timestamp}
                </span>
              </div>

              {/* Suggestions chips */}
              {msg.suggestion && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {msg.suggestion.map((sug, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendMessage(sug)}
                      className="px-3 py-1.5 rounded-full bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-[11px] font-bold text-indigo-700 transition-all cursor-pointer"
                    >
                      {sug}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600" />
              <span>{isIndonesian ? 'Pendamping CBT sedang memformulasikan respons...' : 'CBT Companion typing...'}</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
          <input
            type="text"
            placeholder={isIndonesian ? 'Tuliskan apa yang Anda rasakan atau pikirkan...' : 'Describe your thought or feeling...'}
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            className="flex-1 px-4 py-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-indigo-600"
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={!inputMessage.trim()}
            className="p-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white transition-all disabled:opacity-50 cursor-pointer shadow-md"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
