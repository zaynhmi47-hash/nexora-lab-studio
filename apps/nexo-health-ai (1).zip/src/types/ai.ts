import { UserProfile, PrimaryGoalType, ActivityLevelType, EquipmentType, AiToneType, LanguageCode } from '../types';

export type AIRequestType =
  | 'general'
  | 'fitness'
  | 'nutrition'
  | 'health'
  | 'sleep'
  | 'emergency_check';

export type AIResponseType =
  | 'text'
  | 'health_advice'
  | 'workout_recommendation'
  | 'nutrition_advice'
  | 'warning'
  | 'clarification'
  | 'emergency_guidance';

export interface AIMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string; // ISO format or time string
  responseType?: AIResponseType;
  structuredData?: AIStructuredData;
  suggestedPrompts?: string[];
  isError?: boolean;
  modelUsed?: string;
}

export interface AIStructuredData {
  title?: string;
  category?: 'fitness' | 'nutrition' | 'sleep' | 'hydration' | 'recovery' | 'general' | 'safety';
  keyPoints?: string[];
  actionItems?: string[];
  metrics?: Record<string, string | number>;
  disclaimer?: string;
  urgencyLevel?: 'low' | 'moderate' | 'high' | 'critical_emergency';
  recommendedProfessional?: string;
}

export interface AIRequest {
  message: string;
  requestType?: AIRequestType;
  conversationHistory?: AIMessage[];
  userProfile?: Partial<UserProfile>;
  contextOverride?: Record<string, any>;
  language?: LanguageCode;
  aiTone?: AiToneType;
}

export interface AIResponse {
  messageId: string;
  content: string;
  type: AIResponseType;
  structuredData?: AIStructuredData;
  followUpSuggestions?: string[];
  warnings?: string[];
  error?: string;
  modelUsed?: string;
}

/**
 * Interface for future token compression and long-term memory integration.
 * TODO: Integrate vector embeddings & conversation rolling summaries in later steps.
 */
export interface ConversationSummary {
  id: string;
  userId: string;
  createdAt: string;
  keyTopicsDiscussed: string[];
  lastAssessedGoals: string[];
  identifiedPreferences: Record<string, string>;
  activeHabitCommitments: string[];
  summaryText: string;
}

export interface AIModelConfig {
  simpleModel: string;
  generalModel: string;
  complexModel: string;
  temperature: number;
  maxRecentMessages: number;
}
