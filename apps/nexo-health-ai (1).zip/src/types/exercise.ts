import { ExerciseType, LandmarkName, FormScoreBreakdown, LiveFeedback, JointAngles } from './bodyAI';

export type TrackingMode = 'reps' | 'duration';

export interface ExerciseFormRule {
  id: string;
  name: string;
  weight: number; // For overall score calculation
  description: string;
  check: (angles: JointAngles, state: string, durationSec?: number) => {
    score: number;
    issue?: string;
    feedback?: string;
  };
}

export interface ExerciseDefinition {
  type: ExerciseType;
  name: string;
  nameId: string;
  category: 'lower_body' | 'upper_body' | 'core' | 'full_body';
  mode: TrackingMode;
  targetMuscles: string[];
  targetMusclesId: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  requiredLandmarks: LandmarkName[];
  cameraSetupAdvice: string;
  cameraSetupAdviceId: string;
  idealDistanceMeters: string;
  targetRepAngleThresholds: {
    start: number; // e.g. standing knee angle > 160
    triggerDescent: number; // < 140
    bottomDepth: number; // < 90 (good depth)
    triggerAscent: number; // > 120
    completion: number; // > 160
  };
  weights: {
    alignment: number;
    depth: number;
    stability: number;
    symmetry: number;
    tempo: number;
  };
  rules: ExerciseFormRule[];
  defaultTargetReps: number;
  defaultTargetDurationSec: number;
}
