export type ExerciseType = 'squat' | 'pushup' | 'lunge' | 'plank';

export interface PosePoint {
  x: number; // Normalized 0-1
  y: number; // Normalized 0-1
  z?: number;
  visibility?: number; // 0-1 confidence
}

export type LandmarkName =
  | 'nose'
  | 'leftEye'
  | 'rightEye'
  | 'leftEar'
  | 'rightEar'
  | 'leftShoulder'
  | 'rightShoulder'
  | 'leftElbow'
  | 'rightElbow'
  | 'leftWrist'
  | 'rightWrist'
  | 'leftHip'
  | 'rightHip'
  | 'leftKnee'
  | 'rightKnee'
  | 'leftAnkle'
  | 'rightAnkle';

export type PoseLandmarks = Record<LandmarkName, PosePoint>;

export interface JointAngles {
  leftKneeAngle: number;
  rightKneeAngle: number;
  leftElbowAngle: number;
  rightElbowAngle: number;
  leftHipAngle: number;
  rightHipAngle: number;
  leftShoulderAngle: number;
  rightShoulderAngle: number;
  torsoAngle: number;
  hipSagAngle: number;
  neckAngle: number;
  kneeSymmetry: number;
  elbowSymmetry: number;
}

export type CalibrationStatus =
  | 'CHECKING_PERMISSIONS'
  | 'PERMISSION_DENIED'
  | 'NO_BODY_DETECTED'
  | 'TOO_CLOSE'
  | 'TOO_FAR'
  | 'PARTIAL_BODY'
  | 'LOW_VISIBILITY'
  | 'PERFECT_FRAMING'
  | 'READY_COUNTDOWN';

export interface CalibrationResult {
  status: CalibrationStatus;
  message: string;
  isReady: boolean;
  visibilityScore: number; // 0 - 100
  framingScore: number; // 0 - 100
  missingLandmarks: LandmarkName[];
  suggestion: string;
}

export type RepState =
  | 'START'
  | 'STANDING'
  | 'TOP'
  | 'DESCENDING'
  | 'BOTTOM'
  | 'HOLDING'
  | 'ASCENDING'
  | 'FINISHED';

export interface FormScoreBreakdown {
  alignment: number; // 0 - 100
  depth: number; // 0 - 100
  stability: number; // 0 - 100
  symmetry: number; // 0 - 100
  tempo: number; // 0 - 100
  overall: number; // 0 - 100
}

export interface LiveFeedback {
  id: string;
  message: string;
  type: 'success' | 'warning' | 'info' | 'critical';
  timestamp: number;
  jointTarget?: LandmarkName | 'torso' | 'knees' | 'elbows' | 'hips' | 'spine';
}

export interface SingleRepData {
  repNumber: number;
  durationSec: number;
  eccentricDurationSec: number;
  concentricDurationSec: number;
  maxDepthAngle: number;
  scoreBreakdown: FormScoreBreakdown;
  issues: string[];
}

export interface WorkoutSessionSummary {
  id: string;
  exerciseType: ExerciseType;
  exerciseName: string;
  startTime: string;
  endTime: string;
  durationSeconds: number;
  totalReps: number;
  formScore: number;
  scoreBreakdown: FormScoreBreakdown;
  repsData: SingleRepData[];
  detectedIssues: string[];
  geminiCoachingSummary?: string;
  caloriesBurnedEstimate: number;
}
