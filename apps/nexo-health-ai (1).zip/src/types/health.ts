export type HealthEventType =
  | 'workout'
  | 'meal'
  | 'water'
  | 'sleep'
  | 'weight'
  | 'activity';

export interface ActivityMetrics {
  steps: number;
  stepsGoal: number;
  activeMinutes: number;
  activeMinutesGoal: number;
  distanceKm: number;
  estimatedCaloriesBurned: number;
}

export interface SleepMetrics {
  sleepDurationHours: number;
  sleepGoalHours: number;
  bedtime: string; // e.g. "23:00"
  wakeTime: string; // e.g. "07:00"
  sleepConsistencyScore: number; // 0-100
  qualityRating?: 'poor' | 'fair' | 'good' | 'optimal';
  notes?: string;
}

export interface HydrationEntry {
  id: string;
  timestamp: string;
  amountMl: number;
}

export interface HydrationMetrics {
  waterIntakeMl: number;
  waterGoalMl: number;
  hydrationEntries: HydrationEntry[];
}

export interface WeightEntry {
  id: string;
  date: string; // YYYY-MM-DD
  timestamp: string;
  weightKg: number;
  bodyFatPercentage?: number;
  note?: string;
  trend?: HealthTrendDirection;
}

export interface HealthEvent {
  id: string;
  type: HealthEventType;
  timestamp: string; // e.g. "08:30" or ISO string
  date: string; // YYYY-MM-DD
  title: string;
  description: string;
  source: 'manual' | 'body_ai' | 'nutrition_ai' | 'health_connect' | 'device';
  metrics?: {
    calories?: number;
    durationMinutes?: number;
    volumeMl?: number;
    weightKg?: number;
    reps?: number;
    exerciseName?: string;
    proteinG?: number;
    carbsG?: number;
    fatG?: number;
    steps?: number;
  };
  metadata?: Record<string, any>;
}

export interface WellnessScoreComponents {
  activity: number; // 0 - 100
  sleep: number; // 0 - 100
  nutrition: number; // 0 - 100
  hydration: number; // 0 - 100
  consistency: number; // 0 - 100
}

export interface WellnessScore {
  score: number; // 0 - 100
  previousScore?: number;
  status: 'optimal' | 'good' | 'fair' | 'needs_attention';
  components: WellnessScoreComponents;
  breakdownDetails: {
    activityMessage: string;
    sleepMessage: string;
    nutritionMessage: string;
    hydrationMessage: string;
    consistencyMessage: string;
  };
  educationalDisclaimer: string;
  lastCalculated: string;
}

export type HealthTrendDirection =
  | 'improving'
  | 'stable'
  | 'declining'
  | 'insufficient_data';

export interface HealthTrend {
  metric: 'wellness' | 'steps' | 'active_minutes' | 'sleep' | 'hydration' | 'nutrition' | 'weight';
  direction: HealthTrendDirection;
  currentValue: number;
  previousValue?: number;
  percentageChange?: number;
  description: string;
  period: '7d' | '30d';
  hasSufficientData: boolean;
}

export interface AIHealthInsight {
  id: string;
  category: 'positive' | 'suggestion' | 'warning' | 'neutral';
  headline: string;
  summary: string;
  positiveAreas: string[];
  suggestions: string[];
  focusArea: string;
  generatedAt: string;
  isAiGenerated: boolean;
}

export interface WeeklyReport {
  id: string;
  weekStartDate: string;
  weekEndDate: string;
  wellnessScore: {
    current: number;
    previous: number;
    delta: number;
  };
  activity: {
    workoutsCount: number;
    totalActiveMinutes: number;
    averageDailySteps: number;
    totalCaloriesBurned: number;
  };
  sleep: {
    averageHours: number;
    consistencyScore: number;
    targetMetDays: number;
  };
  hydration: {
    averageLiters: number;
    targetMetDays: number;
  };
  nutrition: {
    loggedDays: number;
    averageCalories: number;
    averageProteinG: number;
  };
  consistency: {
    plannedHabits: number;
    completedHabits: number;
    percentage: number;
  };
  goalProgress: {
    primaryGoal: string;
    progressPercentage: number;
    status: 'on_track' | 'lagging' | 'accelerating';
    summary: string;
  };
  aiInsight?: AIHealthInsight;
}

export interface DailyHealthRecord {
  date: string; // YYYY-MM-DD
  activity: ActivityMetrics;
  sleep: SleepMetrics;
  hydration: HydrationMetrics;
  nutrition: {
    caloriesConsumed: number;
    caloriesGoal: number;
    proteinG: number;
    carbsG: number;
    fatG: number;
    loggedMealsCount: number;
  };
  weight?: number;
  wellnessScore?: WellnessScore;
  events: HealthEvent[];
  notes?: string;
}
