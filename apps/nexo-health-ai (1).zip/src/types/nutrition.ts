/**
 * Nutrition AI & Smart Food Tracking Type Definitions
 * STEP 5 Architecture
 */

export type FoodEntrySource = 'manual' | 'ai_photo' | 'barcode';

export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface FoodEntry {
  id: string;
  name: string;
  mealType: MealType;
  servingAmount: number;
  servingUnit: string; // e.g. 'g', 'porsi', 'potong', 'cup', 'bowl', 'tbsp'
  estimatedCalories: number;
  estimatedProtein: number; // in grams
  estimatedCarbs: number;   // in grams
  estimatedFat: number;     // in grams
  estimatedFiber?: number;   // in grams
  estimatedSodium?: number;  // in mg
  source: FoodEntrySource;
  createdAt: string;        // ISO timestamp
  notes?: string;
  barcode?: string;
  photoUrl?: string;
  healthRating?: number;     // 1 to 10
  isVerified?: boolean;     // False by default for visual AI estimates
}

export interface MealSummary {
  mealType: MealType;
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  entryCount: number;
  items: FoodEntry[];
}

export interface NutritionSummary {
  date: string; // YYYY-MM-DD
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sodium: number;
  targetCalories: number;
  targetProtein: number;
  targetCarbs: number;
  targetFat: number;
  mealsBreakdown: {
    breakfast: MealSummary;
    lunch: MealSummary;
    dinner: MealSummary;
    snack: MealSummary;
  };
  calorieProgressPercent: number;
  proteinProgressPercent: number;
  carbsProgressPercent: number;
  fatProgressPercent: number;
}

export interface Meal {
  id: string;
  type: MealType;
  name: string;
  estimatedCalories: number;
  estimatedProtein: number;
  estimatedCarbs: number;
  estimatedFat: number;
  ingredients: string[];
  portionDesc?: string;
  cookingTimeMinutes?: number;
  instructions?: string[];
  healthBenefits?: string;
}

export interface GroceryItem {
  id: string;
  name: string;
  category: 'produce' | 'protein' | 'dairy' | 'grains' | 'pantry' | 'other';
  amount: string;
  isChecked: boolean;
  sourceMeal?: string;
}

export interface MealPlan {
  id: string;
  date: string;
  planType: 'daily' | 'weekly';
  title: string;
  targetCalories: number;
  targetProtein: number;
  targetCarbs: number;
  targetFat: number;
  meals: Meal[];
  nutritionTips?: string[];
  groceryItems?: GroceryItem[];
  generatedAt: string;
  disclaimer: string;
}

export type NutritionInsightType = 'positive' | 'suggestion' | 'warning' | 'neutral';

export interface NutritionInsight {
  id: string;
  type: NutritionInsightType;
  title: string;
  message: string;
  category: 'protein' | 'calories' | 'hydration' | 'variety' | 'timing' | 'balance';
  actionableTip?: string;
  timestamp: string;
}

export interface CandidateFoodItem {
  id: string;
  name: string;
  confidence: number;
  servingAmount: number;
  servingUnit: string;
  estimatedCalories: number;
  estimatedProtein: number;
  estimatedCarbs: number;
  estimatedFat: number;
  estimatedFiber?: number;
  category?: string;
}

export interface AiFoodAnalysisResult {
  mealName: string;
  overallEstimatedCalories: number;
  overallEstimatedProtein: number;
  overallEstimatedCarbs: number;
  overallEstimatedFat: number;
  healthRating: number;
  candidateFoods: CandidateFoodItem[];
  detectedObjects: string[];
  aiAdvice: string;
  isEstimateNotice: string;
  analyzedAt: string;
}

export interface BarcodeProduct {
  barcode: string;
  name: string;
  brand?: string;
  servingAmount: number;
  servingUnit: string;
  estimatedCalories: number;
  estimatedProtein: number;
  estimatedCarbs: number;
  estimatedFat: number;
  estimatedFiber?: number;
  estimatedSodium?: number;
  category?: string;
  isSampleMock: boolean;
}
